"""Setup script for ICF sections AI Search index."""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))

from dotenv import load_dotenv
load_dotenv()

from tools.icf_index_manager import ICFIndexManager


def main():
    """Create the ICF sections index."""
    print("="*80)
    print("ICF Sections AI Search Index Setup")
    print("="*80)
    print()
    
    # Check environment variables
    import os
    required_vars = ["AI_SEARCH_ENDPOINT", "AI_SEARCH_KEY"]
    missing = [var for var in required_vars if not os.getenv(var)]
    
    if missing:
        print(f"[ERROR] Missing required environment variables: {', '.join(missing)}")
        print("Please set these in your .env file")
        return 1
    
    try:
        # Get index name from env or use default
        index_name = os.getenv("AI_SEARCH_INDEX_NAME", "icf-sections-index")
        
        print(f"[INFO] Index name: {index_name}")
        print(f"[INFO] Search endpoint: {os.getenv('AI_SEARCH_ENDPOINT')}")
        print()
        
        # Create index manager
        manager = ICFIndexManager(index_name=index_name)
        
        # Use a dedicated ICF sections index name
        icf_index_name = "icf-sections-index"
        manager = ICFIndexManager(index_name=icf_index_name)
        
        # Check if index exists
        if manager.index_exists():
            print(f"[INFO] Index '{icf_index_name}' already exists")
            info = manager.get_index_info()
            if info:
                print(f"\nIndex Information:")
                print(f"  Name: {info['name']}")
                print(f"  Fields: {len(info['fields'])}")
                print(f"  Vector Search: {info['vector_search']}")
            print("\n[OK] Index is ready to use")
        else:
            print(f"[INFO] Creating ICF sections index '{icf_index_name}'...")
            manager.create_index()
            print(f"[OK] Index '{icf_index_name}' created successfully")
        
        print()
        print("[SUCCESS] Index setup complete!")
        print()
        print("Next steps:")
        print("  1. Run ingestion to index your Global ICF documents")
        print("  2. Test section matching with test_full_flow.py")
        
        return 0
        
    except Exception as e:
        print(f"\n[ERROR] Failed to setup index: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    exit_code = main()
    sys.exit(exit_code)

