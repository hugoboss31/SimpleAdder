"""
QA Agent for ICF Document Verification.
Verifies Generator output against country-specific checklists.
Adds missing changes to ensure full compliance.
Uses Azure AI Search with doctypeid filtering (1=ICF, 4=Review Checklist).
"""

import os
import json
import re
from datetime import datetime
from typing import List, Dict, Optional, Tuple, Any
from utils import RetryHandler
from openai import AzureOpenAI
from dotenv import load_dotenv

from services.document_handler import DocumentHandler
from .ingestion_agent import IngestionAgent
from services.qa_knowledge_loader import QAKnowledgeLoader, QARequirementRecord
from models.models import SectionNode, DocumentTree, QAFeedback, QAIssue
from services.app_insights import get_logger as get_ai_logger, track_event

load_dotenv()

SKIP_SECTIONS = [
    "table of contents",
    "contents",
    "abbreviations",
    "glossary",
    "signature page",
    "signatures",
    "table 1",
    "table 2",
    "table 3",
    "visit schedule",
    "table"
]


class QAAgent:
    """
    QA Agent for ICF verification.
    - Loads country-specific checklists from Azure AI Search (doctypeid=1 or 4)
    - Verifies Generator output against checklist requirements
    - Adds missing changes to ensure full compliance
    - Fully generic - works for any country based on knowledge base
    """
    
    SYSTEM_PROMPT = """You are an expert QA reviewer for Informed Consent Forms (ICF) with deep knowledge of ICH-GCP guidelines and international clinical trial regulations.

## YOUR MISSION
Verify that an ICF document section meets specific checklist requirements for {country}. If requirements are NOT satisfied, generate changes to add the missing content.

## TARGET COUNTRY: {country}

## CRITICAL RULES
1. **Check if requirement is already satisfied** in the section content
2. **Only generate changes for MISSING requirements** - do not duplicate existing content
3. **Use [QA-XXX] IDs** in the source field for all changes you generate
4. **Write patient-friendly content** at 8th grade reading level
5. **Be precise** - original_text must match exactly if using REPLACE
6. **Use ONLY regulatory citations from the checklist requirements** - do not invent references

## VERIFICATION PROCESS
For each requirement:
1. Read the requirement carefully
2. Check if the section content already addresses it
3. If YES → Mark as "satisfied" (no change needed)
4. If PARTIAL → Generate change to complete it
5. If NO → Generate ADD or REPLACE change to include it

## OUTPUT FORMAT
Return valid JSON:
{{
    "verification_results": [
        {{
            "req_id": "CHECKLIST-001",
            "status": "satisfied|partial|missing",
            "evidence": "Quote from section that satisfies this (if satisfied)",
            "reason": "Why it's satisfied/partial/missing"
        }}
    ],
    "changes": [
        {{
            "type": "ADD|REPLACE",
            "section_id": "SEC-XXX",
            "section": "Section name",
            "original_text": "Only for REPLACE - exact text to replace",
            "new_text": "Content to add/replace with",
            "location": "AFTER:SEC-XXX (only for ADD)",
            "reason": "Why this change is needed",
            "source": "[QA-XXX] Checklist requirement"
        }}
    ]
}}

## WRITING STYLE
- Use "you/your" to speak directly to the participant
- Write at 8th grade reading level
- Be warm, clear, and reassuring
- Explain medical/legal terms in simple words
- Use regulatory citations exactly as provided in checklist requirements
"""

    VALIDATION_SYSTEM_PROMPT = """You are a QA validator for Informed Consent Forms (ICF) with deep knowledge of ICH-GCP guidelines and international clinical trial regulations.

## YOUR ROLE
Validation-only: verify whether checklist requirements are satisfied.

## CRITICAL RULES
1. DO NOT generate or propose any content changes.
2. DO NOT rewrite the document.
3. Only assess whether each requirement is satisfied based on the provided section content.
4. Be strict and evidence-based: cite a short quote when satisfied.

## OUTPUT
Return valid JSON only.
"""

    VALIDATION_PROMPT = """You are validating a SINGLE SECTION of an ICF document for {country} checklist compliance.

Section ID: {section_id}
Section Heading: {section_heading}
Section Content:
{section_content}

CHECKLIST REQUIREMENTS TO VALIDATE:
{requirements_to_check}

Return valid JSON:
{{
    "verification_results": [
        {{
            "req_id": "CHECKLIST-001",
            "status": "satisfied|missing|warning",
            "evidence": "Short quote from the section if satisfied (else empty)",
            "reason": "Why satisfied/missing/warning",
            "severity": "MUST|SHOULD|COULD"
        }}
    ]
}}

Notes:
- Use status=missing when a MUST requirement is not present.
- Use status=warning when a SHOULD/COULD requirement is not fully met.
- Do not include any "changes" output.
"""

    SECTION_PROMPT = """You are verifying a SINGLE SECTION of an ICF document for {country} QA compliance.

## TARGET COUNTRY: {country}

## CURRENT SECTION
Section ID: {section_id}
Section Heading: {section_heading}
Section Content:
{section_content}

## CHECKLIST REQUIREMENTS TO VERIFY (from {country} knowledge base)
{requirements_to_check}

## EXISTING CHANGES ALREADY APPLIED BY GENERATOR
{existing_changes}

## YOUR TASK
1. For EACH requirement above, check if the section content (including existing changes) satisfies it
2. Mark each requirement as: satisfied, partial, or missing
3. Generate changes ONLY for partial or missing requirements
4. Do NOT duplicate content that already exists
5. Use ONLY regulatory citations from the checklist - do not invent references

Return JSON with verification_results and changes arrays.
"""

    def __init__(self, country: str, index_names: Optional[List[str]] = None):
        """
        Initialize QA Agent for a specific country.
        
        Args:
            country: Country code (e.g., 'usa', 'canada', 'uk')
        """
        self.country = country.lower()
        self.country_display = country.upper()
        
        self.doc_handler = DocumentHandler()
        self.ingestion = IngestionAgent()
        self.index_names = index_names
        self.qa_loader = QAKnowledgeLoader(country=self.country, index_names=index_names)
        self.logger = get_ai_logger("qa_agent")
        self._correlation_id: Optional[str] = None
        self._document_id: Optional[str] = None
        
        self.llm = AzureOpenAI(
            api_key=os.getenv("AZURE_OPENAI_API_KEY"),
            api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2025-01-01-preview"),
            azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT")
        )
        self.model = os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME", "gpt-4o")
        
        self.doc_tree: Optional[DocumentTree] = None
        self.checklist_requirements: List[QARequirementRecord] = []
        self.verification_results: List[Dict] = []
        
        self._log("info", f"QA Agent initialized for {self.country_display}")
    
    def _set_logging_context(self, correlation_id: Optional[str] = None, document_id: Optional[str] = None) -> None:
        if correlation_id is not None:
            self._correlation_id = correlation_id
        if document_id is not None:
            self._document_id = document_id
        self.ingestion.set_logging_context(self._correlation_id, self._document_id)

    def _build_dimensions(
        self,
        correlation_id: Optional[str] = None,
        document_id: Optional[str] = None,
        **extra: Optional[str]
    ) -> Optional[dict]:
        dims = {}
        corr = correlation_id or self._correlation_id
        doc = document_id or self._document_id
        if corr:
            dims["correlationId"] = corr
        if doc:
            dims["documentId"] = doc
        for key, value in extra.items():
            if value is not None:
                dims[key] = str(value)
        return {"custom_dimensions": dims} if dims else None

    def _log(
        self,
        level: str,
        message: str,
        correlation_id: Optional[str] = None,
        document_id: Optional[str] = None,
        **extra: Optional[str]
    ) -> None:
        dims = self._build_dimensions(correlation_id, document_id, **extra)
        log_method = getattr(self.logger, level, self.logger.info)
        if dims:
            log_method(message, extra=dims)
        else:
            log_method(message)

    def load_checklists(
        self,
        from_blob: bool = False,
        local_paths: List[str] = None,
        use_search_index: bool = True,
        allow_blob_fallback: bool = True
    ) -> int:
        """
        Load checklist requirements from Azure AI Search (doctypeid=1 or 4).
        Falls back to blob parsing if index is empty.
        
        Args:
            from_blob: If True, force load from Azure Blob storage (skip search index)
            local_paths: List of local file paths (if loading locally)
            use_search_index: If True (default), try Azure AI Search first
            
        Returns:
            Number of requirements loaded
        """
        self.checklist_requirements = []
        
        # Strategy 1: Try Azure AI Search with doctypeid filtering (preferred)
        if use_search_index and not from_blob and not local_paths:
            try:
                indexed_reqs = self._load_from_search_index()
                if indexed_reqs:
                    self.checklist_requirements = indexed_reqs
                    try:
                        track_event("ChecklistLoaded", {
                            "country": self.country,
                            "source": "ai_search",
                            "requirement_count": str(len(self.checklist_requirements)),
                            "index_names": ",".join(self.index_names or [])
                        })
                    except Exception:
                        pass
                    self._log(
                        "info",
                        "Loaded QA requirements from Azure AI Search",
                        requirement_count=len(self.checklist_requirements)
                    )
                    return len(self.checklist_requirements)
                else:
                    if allow_blob_fallback:
                        self._log("warning", "No indexed QA requirements found; falling back to blob")
                    else:
                        self._log("warning", "No indexed QA requirements found")
            except Exception as e:
                self._log("warning", f"Azure AI Search query failed: {e}")
        
        # Strategy 2: Fall back to blob parsing (optional)
        if allow_blob_fallback and (from_blob or (not local_paths and not self.checklist_requirements)):
            self.checklist_requirements = self.qa_loader.load_checklists_from_blob()
            try:
                track_event("ChecklistLoaded", {
                    "country": self.country,
                    "source": "blob",
                    "requirement_count": str(len(self.checklist_requirements))
                })
            except Exception:
                pass
            self._log(
                "info",
                "Loaded QA requirements from blob",
                requirement_count=len(self.checklist_requirements)
            )
        
        # Strategy 3: Local files
        elif local_paths:
            self.checklist_requirements = self.qa_loader.load_checklists_from_local(
                checklist_paths=local_paths
            )
            try:
                track_event("ChecklistLoaded", {
                    "country": self.country,
                    "source": "local",
                    "requirement_count": str(len(self.checklist_requirements))
                })
            except Exception:
                pass
            self._log(
                "info",
                "Loaded QA requirements from local files",
                requirement_count=len(self.checklist_requirements)
            )
        
        return len(self.checklist_requirements)
    
    def _load_from_search_index(self) -> List[QARequirementRecord]:
        """
        Load QA requirements from Azure AI Search using doctypeid filtering.
        Queries for doctypeid=1 (ICF) or doctypeid=4 (Review Checklist).
        Converts search results to QARequirementRecord objects.
        
        Returns:
            List of QARequirementRecord objects from the search index
        """
        requirements = []
        
        # Get all indexed QA requirements (doctypeid=1 or 4)
        indexed_docs = self.qa_loader.get_all_indexed_requirements()
        
        for idx, doc in enumerate(indexed_docs):
            # Determine checklist type from doctypeid
            doctypeid = doc.get('doctypeid', 0)
            if doctypeid == 1:
                checklist_type = "ICF_REQUIREMENT"
            elif doctypeid == 4:
                checklist_type = "REVIEW_CHECKLIST"
            else:
                checklist_type = "GENERAL"
            
            # Extract category from topic or section_type
            category = doc.get('topic', '') or doc.get('section_type', '') or 'General'
            
            # Generate scope tags from content
            content = doc.get('content', '')
            scope_tags = self._generate_scope_tags(content)
            
            # Create QARequirementRecord
            req = QARequirementRecord(
                req_id=doc.get('id', f"QA-{idx+1:03d}"),
                checklist_type=checklist_type,
                category=category,
                requirement_text=content,
                expected_clause=content,
                source_index=str(doc.get('source_index', '') or ''),
                regulation_ref="",  # Can be extracted from content if needed
                scope_tags=scope_tags,
                severity="required" if doc.get('is_required', False) else "recommended"
            )
            requirements.append(req)
        
        return requirements
    
    def _generate_scope_tags(self, text: str) -> List[str]:
        """Generate scope tags for matching requirements to sections."""
        tags = []
        text_lower = text.lower()
        
        tag_patterns = {
            'data_protection': ['privacy', 'confidential', 'data protection', 'personal data', 'personal information'],
            'authorization': ['authorization', 'authorisation', 'permission'],
            'withdrawal': ['withdraw', 'revoke', 'discontinue', 'stop participation'],
            'disclosure': ['disclosure', 'disclose'],
            'consent': ['consent', 'agree', 'signature'],
            'risks': ['risk', 'side effect', 'adverse', 'harm', 'danger'],
            'benefits': ['benefit', 'advantage'],
            'compensation': ['compensation', 'payment', 'reimburse', 'expense'],
            'injury': ['injury', 'harm', 'medical care'],
            'contact': ['contact', 'phone', 'call', 'question', 'emergency'],
            'voluntary': ['voluntary', 'free', 'choice', 'refuse'],
            'purpose': ['purpose', 'objective', 'aim', 'why'],
            'procedures': ['procedure', 'treatment', 'intervention', 'visit'],
            'alternatives': ['alternative', 'other treatment', 'other option'],
            'samples': ['blood', 'sample', 'genetic', 'tissue', 'specimen', 'biobank'],
            'pregnancy': ['pregnant', 'contraception', 'fertility'],
        }
        
        for tag, keywords in tag_patterns.items():
            if any(kw in text_lower for kw in keywords):
                tags.append(tag)
        
        return tags
    
    def query_requirements(self, query_text: str, top_k: int = 10) -> List[Dict]:
        """
        Query QA requirements from Azure AI Search using semantic search.
        Uses doctypeid=1 (ICF) or doctypeid=4 (Review Checklist) filtering.
        
        Args:
            query_text: The search query
            top_k: Number of results to return
            
        Returns:
            List of matching requirements from the search index
        """
        return self.qa_loader.query_checklist(query_text, top_k=top_k)
    
    def verify_and_fill_gaps(
        self,
        input_docx_path: str,
        output_docx_path: str,
        generator_changes: List[Dict] = None,
        correlation_id: str = None,
        document_id: str = None
    ) -> Dict:
        """
        Verify Generator output against checklists and fill any gaps.
        
        Args:
            input_docx_path: Path to document (Generator's output)
            output_docx_path: Path for final output with QA changes
            generator_changes: List of changes already applied by Generator
            correlation_id: Optional correlation ID for telemetry
            document_id: Optional document ID for telemetry
            
        Returns:
            Dict with verification summary and changes count
        """
        self._set_logging_context(correlation_id, document_id)
        self._log("info", "QA verification started", input_path=input_docx_path)
        
        self.doc_tree = self.ingestion.parse_document(input_docx_path)
        self._log("info", "Document parsed for QA", sections=len(self.doc_tree.get_all_sections_flat()))
        
        self._match_requirements_to_sections()
        
        section_cache = {}
        for section in self.doc_tree.get_all_sections_flat():
            section_cache[section.section_id] = section.heading
        self.doc_handler.set_section_cache(section_cache)
        
        section_requirements = self._group_requirements_by_section()
        
        all_changes = []
        all_verification_results = []
        
        for section in self.doc_tree.get_all_sections_flat():
            section_title = section.heading.lower().strip()
            
            if any(skip in section_title for skip in SKIP_SECTIONS):
                continue
            
            if re.match(r'^[\dA-Z]+[\.:\s]+.+\d+\s*$', section.heading.strip()):
                continue
            
            section_reqs = section_requirements.get(section.section_id, [])
            
            if section_reqs:
                self._log(
                    "info",
                    "Verifying section",
                    section_id=section.section_id,
                    section_heading=section.heading[:80]
                )
                try:
                    existing = self._get_existing_changes_for_section(
                        section.section_id, generator_changes or []
                    )
                    
                    results, changes = self._verify_section(section, section_reqs, existing)
                    all_verification_results.extend(results)
                    all_changes.extend(changes)
                    
                except Exception as e:
                    error_msg = str(e)
                    if "content_filter" in error_msg:
                        self._log(
                            "warning",
                            "Section skipped due to content filter",
                            section_id=section.section_id,
                            section_heading=section.heading[:80]
                        )
                    else:
                        self._log(
                            "error",
                            f"Error during QA verification: {error_msg[:100]}",
                            section_id=section.section_id,
                            section_heading=section.heading[:80]
                        )
                    continue
        
        self.verification_results = all_verification_results
        
        if all_changes:
            formatted_changes = self._format_changes(all_changes)
            self.doc_handler.create_tracked_changes_document(
                input_docx_path,
                formatted_changes,
                output_docx_path
            )
            self._log("info", "QA changes added", change_count=len(all_changes))
        else:
            import shutil
            shutil.copy(input_docx_path, output_docx_path)
            self._log("info", "No QA changes required")
        
        satisfied = len([r for r in all_verification_results if r.get('status') == 'satisfied'])
        partial = len([r for r in all_verification_results if r.get('status') == 'partial'])
        missing = len([r for r in all_verification_results if r.get('status') == 'missing'])
        
        return {
            'country': self.country_display,
            'total_requirements': len(self.checklist_requirements),
            'verified': len(all_verification_results),
            'satisfied': satisfied,
            'partial': partial,
            'missing': missing,
            'changes_added': len(all_changes),
            'output_path': output_docx_path
        }

    def verify_for_feedback(
        self,
        input_docx_path: str,
        iteration: int = 1,
        correlation_id: str = None,
        document_id: str = None
    ) -> QAFeedback:
        """
        Verify document and return feedback (no document modification).
        Used in feedback loop with Generator Agent.
        
        Args:
            input_docx_path: Path to document to verify
            iteration: Current iteration number (1-2)
            correlation_id: Optional correlation ID for telemetry
            document_id: Optional document ID for telemetry
            
        Returns:
            QAFeedback object with issues list
        """
        self._set_logging_context(correlation_id, document_id)
        self._log(
            "info",
            f"QA feedback verification (iteration {iteration})",
            input_path=input_docx_path
        )
        
        self.doc_tree = self.ingestion.parse_document(input_docx_path)
        self._log(
            "info",
            "Feedback document parsed",
            sections=len(self.doc_tree.get_all_sections_flat())
        )
        
        self._match_requirements_to_sections()
        
        section_requirements = self._group_requirements_by_section()
        
        sections_to_verify = []
        for section in self.doc_tree.get_all_sections_flat():
            section_title = section.heading.lower().strip()
            if any(skip in section_title for skip in SKIP_SECTIONS):
                continue
            if re.match(r'^[\dA-Z]+[\.:\s]+.+\d+\s*$', section.heading.strip()):
                continue
            section_reqs = section_requirements.get(section.section_id, [])
            if section_reqs:
                sections_to_verify.append((section, section_reqs))
        
        all_issues = []
        total_to_verify = len(sections_to_verify)
        
        for idx, (section, section_reqs) in enumerate(sections_to_verify, 1):
            self._log("info", f"Verifying section {idx}/{total_to_verify}: {section.heading}")
            try:
                results, _ = self._verify_section(section, section_reqs, [])
                for result in results:
                    status = result.get('status', 'missing')
                    if status in ['partial', 'missing']:
                        req_id = result.get('req_id', '')
                        req = next((r for r in section_reqs if r.req_id == req_id), None)
                        issue = QAIssue(
                            section_id=section.section_id,
                            section_heading=section.heading,
                            requirement_id=req_id,
                            requirement_text=req.requirement_text if req else '',
                            severity="MUST" if status == "missing" else "SHOULD",
                            instructions=result.get('reason', 'Add required content'),
                            checklist_type=req.checklist_type if req else '',
                            country=self.country
                        )
                        all_issues.append(issue)
            except Exception as e:
                error_msg = str(e)
                if "content_filter" not in error_msg:
                    self._log(
                        "error",
                        f"Error during QA feedback verification: {error_msg[:100]}",
                        section_id=section.section_id,
                        section_heading=section.heading[:80]
                    )
                continue
        
        if len(all_issues) == 0:
            status = "pass"
            qa_notes = f"All {self.country_display} checklist requirements are satisfied."
        else:
            status = "needs_revision"
            qa_notes = f"Found {len(all_issues)} issues requiring attention for {self.country_display} compliance."
        
        feedback = QAFeedback(
            status=status,
            issues=all_issues,
            qa_notes=qa_notes,
            iteration=iteration,
            country=self.country
        )
        
        self._log(
            "info",
            "QA feedback result",
            status=status,
            issue_count=len(all_issues)
        )
        return feedback
    
    def _match_requirements_to_sections(self):
        """Match checklist requirements to document sections using embeddings."""
        all_sections = self.doc_tree.get_all_sections_flat()
        sections_needing_embedding = [s for s in all_sections if not s.embedding]
        reqs_needing_embedding = [r for r in self.checklist_requirements if not r.embedding]
        total_sections = len(sections_needing_embedding)
        total_reqs = len(reqs_needing_embedding)

        for i, section in enumerate(sections_needing_embedding, 1):
            section.embedding = self.ingestion._embed(
                f"{section.heading} {section.full_text[:500]}"
            )
            self._log("info", f"Computing embeddings: {i}/{total_sections} sections, 0/{total_reqs} requirements")

        for i, req in enumerate(reqs_needing_embedding, 1):
            req.embedding = self.ingestion._embed(
                f"{req.category} {req.requirement_text}"
            )
            self._log("info", f"Computing embeddings: {total_sections}/{total_sections} sections, {i}/{total_reqs} requirements")
    
    def _group_requirements_by_section(self, min_score: float = 0.3) -> Dict[str, List[QARequirementRecord]]:
        """Group checklist requirements by their best-matching section."""
        grouped = {}
        
        for req in self.checklist_requirements:
            best_section = None
            best_score = 0.0
            
            for section in self.doc_tree.get_all_sections_flat():
                if req.embedding and section.embedding:
                    score = self._cosine_similarity(req.embedding, section.embedding)
                    
                    heading_lower = section.heading.lower()
                    for tag in req.scope_tags:
                        if tag in heading_lower:
                            score += 0.2
                    
                    if score > best_score:
                        best_score = score
                        best_section = section
            
            if best_section and best_score >= min_score:
                section_id = best_section.section_id
                if section_id not in grouped:
                    grouped[section_id] = []
                grouped[section_id].append(req)
        
        return grouped

    def _normalize_severity(self, severity: str) -> str:
        """Normalize severity levels to CRITICAL/MAJOR/MINOR."""
        sev = (severity or "").strip().upper()
        if sev in ("MUST", "REQUIRED", "CRITICAL"):
            return "CRITICAL"
        if sev in ("SHOULD", "RECOMMENDED", "MAJOR"):
            return "MAJOR"
        if sev in ("COULD", "MINOR"):
            return "MINOR"
        # Default to MAJOR for unknown non-empty severities; else MINOR
        return "MAJOR" if sev else "MINOR"

    def _verify_section_validation(
        self,
        section: SectionNode,
        requirements: List[QARequirementRecord],
    ) -> List[Dict[str, Any]]:
        """Deterministic validation-only verification for a single section (temperature 0.0)."""
        req_text = ""
        for req in requirements:
            req_text += f"\n[{req.req_id}] ({req.checklist_type} - {req.category})\n"
            req_text += f"Requirement: {req.requirement_text}\n"
            if req.regulation_ref:
                req_text += f"Regulation: {req.regulation_ref}\n"
            if getattr(req, "source_index", ""):
                req_text += f"SourceIndex: {req.source_index}\n"

        prompt = self.VALIDATION_PROMPT.format(
            country=self.country_display,
            section_id=section.section_id,
            section_heading=section.heading,
            section_content=section.full_text[:3500],
            requirements_to_check=req_text,
        )

        response = RetryHandler.retry_call(
            self.llm.chat.completions.create,
            kwargs={
                "model": self.model,
                "messages": [
                    {"role": "system", "content": self.VALIDATION_SYSTEM_PROMPT},
                    {"role": "user", "content": prompt},
                ],
                "temperature": 0.0,
                "response_format": {"type": "json_object"},
            },
            max_retries=3,
        )

        try:
            parsed = json.loads(response.choices[0].message.content)
        except Exception:
            return []
        results = parsed.get("verification_results", [])
        return results if isinstance(results, list) else []

    def validate_for_gate(
        self,
        document_path: str,
        correlation_id: Optional[str] = None,
        document_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Run deterministic validation-only QA suitable for the publishing gate."""
        self._set_logging_context(correlation_id, document_id)
        self._log("info", "QA gate validation started", input_path=document_path)

        if not self.checklist_requirements:
            self.load_checklists(use_search_index=True, from_blob=False, allow_blob_fallback=False)

        if not self.checklist_requirements:
            evaluated_at = datetime.utcnow().isoformat() + "Z"
            return {
                "qaStatus": "FAIL",
                "summary": {"totalChecks": 0, "passed": 0, "failed": 0, "warnings": 0},
                "failedChecks": [
                    {
                        "requirementId": "CHECKLISTS_NOT_LOADED",
                        "severity": "CRITICAL",
                        "reason": "No checklist requirements available for validation",
                        "sectionKey": "_precondition",
                    }
                ],
                "warnings": [],
                "evaluatedAt": evaluated_at,
            }

        self.doc_tree = self.ingestion.parse_document(document_path)
        self._match_requirements_to_sections()

        section_requirements = self._group_requirements_by_section(min_score=0.0)
        failed_checks: List[Dict[str, Any]] = []
        warnings: List[Dict[str, Any]] = []

        evaluated_at = datetime.utcnow().isoformat() + "Z"

        for section in self.doc_tree.get_all_sections_flat():
            section_title = section.heading.lower().strip()
            if any(skip in section_title for skip in SKIP_SECTIONS):
                continue
            if re.match(r'^[\dA-Z]+[\.:\s]+.+\d+\s*$', section.heading.strip()):
                continue

            reqs = section_requirements.get(section.section_id, [])
            if not reqs:
                continue

            try:
                results = self._verify_section_validation(section, reqs)
            except Exception as e:
                self._log(
                    "error",
                    f"QA validation error: {str(e)[:120]}",
                    section_id=section.section_id,
                    section_heading=section.heading[:80],
                )
                continue

            for r in results:
                req_id = str(r.get("req_id", "")).strip()
                status = str(r.get("status", "missing")).strip().lower()
                severity_raw = str(r.get("severity", ""))
                if not severity_raw:
                    severity_raw = "MUST" if status == "missing" else "SHOULD"
                severity = self._normalize_severity(severity_raw)
                reason = str(r.get("reason", "")).strip() or "Requirement not satisfied"

                if status in ("missing", "failed"):
                    failed_checks.append({
                        "requirementId": req_id,
                        "severity": severity,
                        "reason": reason,
                        "sectionKey": section.section_id,
                    })
                elif status in ("warning", "partial"):
                    warnings.append({
                        "requirementId": req_id,
                        "severity": severity,
                        "reason": reason,
                        "sectionKey": section.section_id,
                    })

        total = len(self.checklist_requirements)
        failed = len(failed_checks)
        warn = len(warnings)
        passed = max(0, total - failed - warn)

        qa_status = "PASS"
        if failed_checks:
            if any(c.get("severity") == "CRITICAL" for c in failed_checks):
                qa_status = "FAIL"
            else:
                qa_status = "REVIEW_REQUIRED"

        return {
            "qaStatus": qa_status,
            "summary": {
                "totalChecks": total,
                "passed": passed,
                "failed": failed,
                "warnings": warn,
            },
            "failedChecks": failed_checks,
            "warnings": warnings,
            "evaluatedAt": evaluated_at,
        }
    
    def _cosine_similarity(self, vec1: List[float], vec2: List[float]) -> float:
        """Calculate cosine similarity between two vectors."""
        import math
        dot_product = sum(a * b for a, b in zip(vec1, vec2))
        norm1 = math.sqrt(sum(a * a for a in vec1))
        norm2 = math.sqrt(sum(b * b for b in vec2))
        if norm1 == 0 or norm2 == 0:
            return 0.0
        return dot_product / (norm1 * norm2)
    
    def _get_existing_changes_for_section(
        self,
        section_id: str,
        generator_changes: List[Dict]
    ) -> List[Dict]:
        """Get changes already applied by Generator for this section."""
        return [c for c in generator_changes if c.get('section_id') == section_id]
    
    def _verify_section(
        self,
        section: SectionNode,
        requirements: List[QARequirementRecord],
        existing_changes: List[Dict]
    ) -> Tuple[List[Dict], List[Dict]]:
        """Verify a single section against its matched requirements."""
        
        req_text = ""
        for req in requirements:
            req_text += f"\n[{req.req_id}] ({req.checklist_type} - {req.category})\n"
            req_text += f"Requirement: {req.requirement_text}\n"
            if req.regulation_ref:
                req_text += f"Regulation: {req.regulation_ref}\n"
        
        existing_text = ""
        if existing_changes:
            for change in existing_changes:
                existing_text += f"- {change.get('type')}: {change.get('new_text', '')[:200]}...\n"
        else:
            existing_text = "No changes applied yet."
        
        prompt = self.SECTION_PROMPT.format(
            country=self.country_display,
            section_id=section.section_id,
            section_heading=section.heading,
            section_content=section.full_text[:3000],
            requirements_to_check=req_text,
            existing_changes=existing_text
        )
        
        try:
            system_content = self.SYSTEM_PROMPT.format(country=self.country_display)
            
            response = RetryHandler.retry_call(
                self.llm.chat.completions.create,
                kwargs={
                    "model": self.model,
                    "messages": [
                        {"role": "system", "content": system_content},
                        {"role": "user", "content": prompt}
                    ],
                    "temperature": 0.3,
                    "response_format": {"type": "json_object"}
                },
                max_retries=3
            )
            
            result = json.loads(response.choices[0].message.content)
            verification_results = result.get('verification_results', [])
            changes = result.get('changes', [])
            
            for change in changes:
                if 'section_id' not in change:
                    change['section_id'] = section.section_id
                if 'section' not in change:
                    change['section'] = section.heading
            
            return verification_results, changes
            
        except Exception as e:
            self._log(
                "error",
                f"Error verifying section: {e}",
                section_id=section.section_id,
                section_heading=section.heading[:80]
            )
            return [], []
    
    def _format_changes(self, changes: List[Dict]) -> List[Dict]:
        """Format changes for document handler."""
        formatted = []
        for change in changes:
            formatted_change = {
                'type': change.get('type', 'ADD'),
                'section': change.get('section', 'Unknown'),
                'section_id': change.get('section_id', ''),
                'reason': change.get('reason', ''),
                'source': change.get('source', '[QA] Checklist requirement')
            }
            
            if change.get('type') == 'REPLACE':
                formatted_change['original_text'] = change.get('original_text', '')
                formatted_change['new_text'] = change.get('new_text', '')
            elif change.get('type') == 'ADD':
                formatted_change['new_text'] = change.get('new_text', '')
                formatted_change['location'] = change.get('location', '')
            elif change.get('type') == 'DELETE':
                formatted_change['original_text'] = change.get('original_text', '')
            
            formatted.append(formatted_change)
        
        return formatted
    
    def check_index_status(self) -> Dict:
        """Check status of QA requirements in Azure AI Search index."""
        return self.qa_loader.check_sync_status()