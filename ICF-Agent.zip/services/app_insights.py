"""
Azure Application Insights integration using opencensus-ext-azure.

Three exporters:
1. AzureLogHandler    → App Insights "traces" table (general logs)
2. AzureEventHandler  → App Insights "customEvents" table (structured events)
3. metrics_exporter   → App Insights "customMetrics" table (numeric metrics)

Env var: APPLICATION_INSIGHTS_CONNECTION_STRING

Usage:
    from services.app_insights import get_logger, get_event_logger, track_event, track_metric

    logger = get_logger(__name__)
    logger.info("Processing document...")

    track_event("LearningStarted", {
        "icf_case_id": "CASE-001",
        "country": "usa",
        "iteration_id": "1"
    })

    track_metric("generation.duration_ms", 6858, {
        "icf_case_id": "CASE-001"
    })
"""

import os
import logging
import threading
from typing import Optional, Dict, Any

_loggers: Dict[str, logging.Logger] = {}
_event_logger: Optional[logging.Logger] = None
_handler_initialized = False
_azure_log_handler = None
_azure_event_handler = None
_metrics_exporter = None

CONNECTION_STRING_ENV = "APPLICATION_INSIGHTS_CONNECTION_STRING"


def _get_connection_string() -> Optional[str]:
    """Get App Insights connection string from environment."""
    return os.getenv(CONNECTION_STRING_ENV)


def _init_azure_log_handler():
    """Initialize AzureLogHandler for traces. Called once."""
    global _azure_log_handler, _handler_initialized

    if _handler_initialized:
        return _azure_log_handler

    _handler_initialized = True
    conn_str = _get_connection_string()

    if not conn_str:
        print(f"  ⚠️ App Insights not configured (no {CONNECTION_STRING_ENV})")
        return None

    try:
        from opencensus.ext.azure.log_exporter import AzureLogHandler

        _azure_log_handler = AzureLogHandler(connection_string=conn_str)
        # Ensure handler has a lock (Python 3.13+ uses it as context manager; opencensus may not set it)
        if getattr(_azure_log_handler, "lock", None) is None:
            _azure_log_handler.lock = threading.RLock()
        print("  ✓ AzureLogHandler initialized (traces)")
        return _azure_log_handler
    except ImportError:
        print("  ⚠️ opencensus-ext-azure not installed, App Insights disabled")
        return None
    except Exception as e:
        print(f"  ⚠️ AzureLogHandler init failed: {e}")
        return None


def _init_azure_event_handler():
    """Initialize AzureEventHandler for customEvents. Called once."""
    global _azure_event_handler

    if _azure_event_handler is not None:
        return _azure_event_handler

    conn_str = _get_connection_string()
    if not conn_str:
        return None

    try:
        from opencensus.ext.azure.log_exporter import AzureEventHandler

        _azure_event_handler = AzureEventHandler(connection_string=conn_str)
        if getattr(_azure_event_handler, "lock", None) is None:
            _azure_event_handler.lock = threading.RLock()
        print("  ✓ AzureEventHandler initialized (customEvents)")
        return _azure_event_handler
    except ImportError:
        return None
    except Exception as e:
        print(f"  ⚠️ AzureEventHandler init failed: {e}")
        return None


def _init_metrics_exporter():
    """Initialize metrics exporter for customMetrics. Called once."""
    global _metrics_exporter

    if _metrics_exporter is not None:
        return _metrics_exporter

    conn_str = _get_connection_string()
    if not conn_str:
        return None

    try:
        from opencensus.ext.azure import metrics_exporter as me

        _metrics_exporter = me.new_metrics_exporter(
            connection_string=conn_str,
            export_interval=60
        )
        print("  ✓ MetricsExporter initialized (customMetrics)")
        return _metrics_exporter
    except ImportError:
        return None
    except Exception as e:
        print(f"  ⚠️ MetricsExporter init failed: {e}")
        return None


def get_logger(name: str) -> logging.Logger:
    """
    Get a logger with AzureLogHandler attached.
    Logs go to both console AND App Insights traces table.
    Cached by name to avoid duplicate handlers.

    Args:
        name: Logger name (typically __name__)

    Returns:
        logging.Logger with AzureLogHandler + StreamHandler
    """
    if name in _loggers:
        return _loggers[name]

    logger = logging.getLogger(f"icf.{name}")
    logger.setLevel(logging.INFO)
    logger.propagate = False

    if not logger.handlers:
        console = logging.StreamHandler()
        console.setFormatter(logging.Formatter(
            '%(asctime)s [%(levelname)s] %(name)s: %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        ))
        logger.addHandler(console)

        azure_handler = _init_azure_log_handler()
        if azure_handler:
            logger.addHandler(azure_handler)

    _loggers[name] = logger
    return logger


def get_event_logger() -> logging.Logger:
    """
    Get the dedicated event logger with AzureEventHandler.
    Events go to App Insights customEvents table.
    Single shared instance.

    Returns:
        logging.Logger with AzureEventHandler
    """
    global _event_logger

    if _event_logger is not None:
        return _event_logger

    _event_logger = logging.getLogger("icf.events")
    _event_logger.setLevel(logging.INFO)
    _event_logger.propagate = False

    if not _event_logger.handlers:
        event_handler = _init_azure_event_handler()
        if event_handler:
            _event_logger.addHandler(event_handler)

    return _event_logger


def track_event(event_name: str, properties: Optional[Dict[str, Any]] = None):
    """
    Send a named event to App Insights customEvents table.
    Also logs to console via the main logger.

    Args:
        event_name: Event name (e.g., "LearningStarted", "ArtifactIndexed")
        properties: Key-value pairs for custom_dimensions (values must be strings)
    """
    dimensions = {"event_name": event_name}
    if properties:
        dimensions.update({k: str(v) for k, v in properties.items()})

    event_logger = get_event_logger()
    event_logger.info(event_name, extra={"custom_dimensions": dimensions})

    console_logger = get_logger("events")
    props_str = ", ".join(f"{k}={v}" for k, v in (properties or {}).items())
    console_logger.info(f"📊 EVENT: {event_name} | {props_str}")


def track_metric(metric_name: str, value: float, properties: Optional[Dict[str, Any]] = None):
    """
    Send a metric to App Insights.
    Uses AzureEventHandler with metric data in custom_dimensions
    (opencensus metrics_exporter requires stats/views setup which is heavyweight).

    Args:
        metric_name: Metric name (e.g., "generation.duration_ms")
        value: Numeric value
        properties: Additional context
    """
    dimensions = {
        "event_name": "Metric",
        "metric_name": metric_name,
        "metric_value": str(value)
    }
    if properties:
        dimensions.update({k: str(v) for k, v in properties.items()})

    event_logger = get_event_logger()
    event_logger.info(f"Metric:{metric_name}", extra={"custom_dimensions": dimensions})

    console_logger = get_logger("metrics")
    console_logger.info(f"📈 METRIC: {metric_name}={value}")


def track_exception(error: Exception, properties: Optional[Dict[str, Any]] = None):
    """
    Send an exception to App Insights exceptions table.
    Uses logger.exception() which AzureLogHandler routes to exceptions.

    Args:
        error: Exception object
        properties: Additional context
    """
    dimensions = {"event_name": "Exception"}
    if properties:
        dimensions.update({k: str(v) for k, v in properties.items()})

    logger = get_logger("exceptions")
    logger.exception(str(error), extra={"custom_dimensions": dimensions})


def flush():
    """Flush all handlers to ensure pending telemetry is sent."""
    for logger in _loggers.values():
        for handler in logger.handlers:
            try:
                handler.flush()
            except Exception:
                pass

    if _event_logger:
        for handler in _event_logger.handlers:
            try:
                handler.flush()
            except Exception:
                pass