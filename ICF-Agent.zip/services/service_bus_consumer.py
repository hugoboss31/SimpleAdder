"""
Azure Service Bus consumer for ICF job queues.
Processes generation, learn, and regenerate jobs from queues.
Uses structured logger with correlation ID support.
"""

import json
import os
import tempfile
import threading
from datetime import datetime
from urllib.parse import unquote

from utils.logger import get_logger

logger = get_logger("service_bus_consumer")


def _normalize_service_bus_connection_string(conn_str: str) -> str:
    """
    Normalize the connection string so SharedAccessKey is correctly decoded.
    Keys with + or = may be URL-encoded (%2B, %3D) in some sources; decode them
    so the SDK receives the correct key for SAS token generation.
    """
    parts = [s.split("=", 1) for s in conn_str.strip().rstrip(";").split(";")]
    if any(len(p) != 2 for p in parts):
        return conn_str
    result = []
    for k, v in parts:
        if k.lower() == "sharedaccesskey":
            v = unquote(v)  # Decode %2B->+, %3D->= so key is correct for SAS
        result.append(f"{k}={v}")
    return ";".join(result)

# Lazily import to avoid loading Azure SDK when Service Bus is not configured
_service_bus_client = None
_consumer_threads = []
_stop_event = threading.Event()


def _handle_generation_message(body: dict) -> None:
    """Process generation job from icf-generation-queue."""
    from agents import WorkflowManager
    from config import Config
    from app import download_from_blob_url, send_callback

    job_id = body.get("jobId", "unknown")
    correlation_id = body.get("correlationId") or job_id
    country = (body.get("country") or "").lower().replace(" ", "-").replace("_", "-")
    global_icf_document_id = body.get("globalIcfDocumentId", "")
    global_icf_blob_url = body.get("globalIcfBlobUrl", "")
    enable_qa_loop = body.get("enableQaLoop", True)
    icf_document_id = body.get("icfDocumentId")
    icf_case_id = body.get("icfCaseId") or ""
    callback_base_url = body.get("callbackBaseUrl", "") or Config.get_backend_base_url()

    if not icf_document_id or not global_icf_blob_url:
        raise ValueError("icfDocumentId and globalIcfBlobUrl are required")

    temp_path = None
    temp_dir = None
    output_path = None
    start_time = datetime.now()

    try:
        logger.info(f"[{job_id}] Starting ICF generation for country {country.upper()}", correlation_id=correlation_id)
        temp_path, _ = download_from_blob_url(global_icf_blob_url)

        temp_dir = tempfile.mkdtemp()

        # Build filename: CountryCode_StudyId_StudyName_ICFType_UserName_Version_Date.docx
        study_id = body.get("studyId", "")
        study_name = (body.get("studyName") or "").replace(" ", "_").replace("/", "_").replace("\\", "_").replace(":", "_").replace("*", "_").replace("?", "_").replace('"', "_").replace("<", "_").replace(">", "_").replace("|", "_")
        icf_type = (body.get("studyIcfType") or "").replace(" ", "_")
        user_name = (body.get("userName") or "User").replace(" ", "_").replace("/", "_").replace("\\", "_").replace(":", "_").replace("*", "_").replace("?", "_").replace('"', "_").replace("<", "_").replace(">", "_").replace("|", "_")
        version_str = "1.0"
        date_str = datetime.now().strftime("%d-%b-%Y")
        parts = [country.upper(), str(study_id), study_name, icf_type, user_name, version_str, date_str]
        parts_clean = [p for p in parts if p]
        if parts_clean:
            output_filename = "_".join(parts_clean) + ".docx"
        else:
            timestamp_str = datetime.now().strftime("%Y%m%d_%H%M%S")
            output_filename = f"{country.upper()}_ICF_{timestamp_str}.docx"

        output_path = os.path.join(temp_dir, output_filename)

        workflow = WorkflowManager(
            country=country,
            knowledge_base_path="knowledge_base",
            blob_container_name=os.getenv("AZURE_STORAGE_CONTAINER_NAME", "icf-country-dev"),
        )
        if enable_qa_loop:
            workflow.load_qa_checklists(use_search_index=True)

        result = workflow.run(
            input_docx_path=temp_path,
            output_docx_path=output_path,
            document_id=global_icf_document_id,
            icf_case_id=icf_case_id or None,
            correlation_id=correlation_id,
        )

        total_duration = (datetime.now() - start_time).total_seconds()
        storage_account = Config.AZURE_STORAGE_ACCOUNT_NAME
        container_name = Config.AZURE_STORAGE_CONTAINER_NAME
        blob_path = result.get("blob_path", "")
        full_blob_url = f"https://{storage_account}.blob.core.windows.net/{container_name}/{blob_path}"
        coverage_stats = result.get("coverage_stats") or {}

        if callback_base_url:
            callback_url = f"{callback_base_url.rstrip('/')}/api/generate-icf-callback"
            metadata = {
                "country": country.upper(),
                "iterations": result.get("iterations", 0),
                "total_changes": result.get("total_changes", 0),
                "duration_seconds": total_duration,
            }
            if coverage_stats:
                metadata.update(coverage_stats)
            send_callback(callback_url, {
                "status": 2,
                "filename": output_filename,
                "blob_url": full_blob_url,
                "icfDoc_id": icf_document_id,
                "icf_case_id": icf_case_id,
                "version_no": 1,
                "success": True,
                "error": None,
                "metadata": metadata,
            }, correlation_id=correlation_id)
        logger.info(f"[{job_id}] Generation completed successfully", correlation_id=correlation_id)
    except Exception as e:
        logger.exception(f"[{job_id}] Generation failed: {e}", correlation_id=correlation_id)
        if callback_base_url:
            callback_url = f"{callback_base_url.rstrip('/')}/api/generate-icf-callback"
            send_callback(callback_url, {
                "status": 0,
                "filename": None,
                "blob_url": None,
                "icfDoc_id": icf_document_id,
                "success": False,
                "error": str(e),
                "metadata": {"country": country.upper(), "duration_seconds": (datetime.now() - start_time).total_seconds()},
            }, correlation_id=correlation_id)
        raise
    finally:
        for path in (temp_path, output_path):
            if path and os.path.exists(path):
                try:
                    os.remove(path)
                except Exception:
                    pass
        if temp_dir and os.path.exists(temp_dir):
            try:
                os.rmdir(temp_dir)
            except Exception:
                pass


def _handle_learn_message(body: dict) -> None:
    """Process learn-only job from icf-learn-queue."""
    from services.comment_extractor import CommentExtractor
    from services.learning_artifacts import LearnPipeline
    from app import download_from_blob_url, send_callback

    job_id = body.get("jobId", "unknown")
    correlation_id = body.get("correlationId") or job_id
    feedback_blob_url = body.get("feedbackBlobUrl", "")
    icf_document_id = body.get("icfDocumentId")
    country_code = body.get("countryCode", "usa")
    country_id = body.get("countryId", 2)
    iteration_id = body.get("iterationId", 1)
    callback_base_url = body.get("callbackBaseUrl", "")

    if not feedback_blob_url or not icf_document_id:
        raise ValueError("feedbackBlobUrl and icfDocumentId are required")

    country = country_code.lower().replace(" ", "-").replace("_", "-")
    icf_case_id = str(icf_document_id)
    callback_url = f"{callback_base_url.rstrip('/')}/api/learn-callback" if callback_base_url else None

    temp_path = None
    start_time = datetime.now()

    try:
        logger.info(f"[{job_id}] Starting Learn-Only pipeline for ICF document {icf_document_id}", correlation_id=correlation_id)
        temp_path, _ = download_from_blob_url(feedback_blob_url)

        extractor = CommentExtractor()
        all_comments = extractor.extract_comments(temp_path)
        client_comments = [c for c in all_comments if c.is_client]
        comments_for_pipeline = [
            {
                "text": c.text,
                "linked_text": c.linked_text,
                "section_heading": c.section_title or "Unknown",
                "author": c.author,
            }
            for c in client_comments
        ]

        pipeline = LearnPipeline(country=country)
        result = pipeline.run_learn_only_pipeline(
            reviewed_path=temp_path,
            icf_case_id=icf_case_id,
            iteration_id=iteration_id,
            comments=comments_for_pipeline,
        )

        total_duration = (datetime.now() - start_time).total_seconds()
        if callback_url:
            track_changes = result.get("track_changes_extracted", 0)
            comments = result.get("comments_extracted", 0)
            indexed = result.get("artifacts_indexed", 0)
            total_items = track_changes + comments
            not_learned = max(0, total_items - indexed)
            send_callback(callback_url, {
                "icfDoc_id": icf_document_id,
                "status": 2 if result.get("success") else 0,
                "success": result.get("success", False),
                "icf_case_id": icf_case_id,
                "country": country.upper(),
                "countryid": country_id,
                "iteration_id": iteration_id,
                "artifacts_count": len(result.get("artifacts", [])),
                "artifacts_indexed": indexed,
                "artifacts_superseded": result.get("artifacts_superseded", 0),
                "artifact_blob_url": result.get("artifact_blob_url"),
                "error": None,
                "metadata": {
                    "track_changes_extracted": track_changes,
                    "comments_extracted": comments,
                    "duration_seconds": total_duration,
                    "feedback_items_total": total_items,
                    "feedback_items_learned": indexed,
                    "feedback_items_not_learned": not_learned,
                    "not_learned_items": result.get("not_learned_items", []),
                },
            }, correlation_id=correlation_id)
        logger.info(f"[{job_id}] Learn-Only completed successfully", correlation_id=correlation_id)
    except Exception as e:
        logger.exception(f"[{job_id}] Learn-Only failed: {e}", correlation_id=correlation_id)
        if callback_url:
            send_callback(callback_url, {
                "icfDoc_id": icf_document_id,
                "status": 0,
                "success": False,
                "icf_case_id": icf_case_id,
                "country": country.upper(),
                "countryid": country_id,
                "iteration_id": iteration_id,
                "artifacts_count": 0,
                "artifacts_indexed": 0,
                "artifacts_superseded": 0,
                "artifact_blob_url": None,
                "error": str(e),
                "metadata": {"duration_seconds": (datetime.now() - start_time).total_seconds()},
            }, correlation_id=correlation_id)
        raise
    finally:
        if temp_path and os.path.exists(temp_path):
            try:
                os.remove(temp_path)
                if os.path.dirname(temp_path):
                    os.rmdir(os.path.dirname(temp_path))
            except Exception:
                pass


def _handle_regen_message(body: dict) -> None:
    """Process learn-and-regenerate job from icf-regen-queue."""
    from agents.workflow import HumanReviewWorkflow
    from services.comment_extractor import CommentExtractor
    from services.learning_artifacts import LearnPipeline
    from models.models import RegenerateRequest
    from app import download_from_blob_url, send_callback
    import asyncio

    job_id = body.get("jobId", "unknown")
    correlation_id = body.get("correlationId") or job_id
    document_id = body.get("documentId")
    icf_case_id = body.get("icfCaseId", str(document_id))
    country_id = body.get("countryId", 2)
    country_name = body.get("countryName", "usa")
    reviewed_blob_url = body.get("reviewedBlobUrl", "")
    callback_base_url = body.get("callbackBaseUrl", "")
    current_version = body.get("currentVersion", 1)
    iteration_id = body.get("iterationId", 1)

    if not document_id or not reviewed_blob_url or not callback_base_url:
        raise ValueError("documentId, reviewedBlobUrl and callbackBaseUrl are required")

    study_id = body.get("studyId")
    study_name = body.get("studyName")
    study_icf_type = body.get("studyIcfType")
    user_name = body.get("userName")

    country = country_name.lower().replace(" ", "-").replace("_", "-")
    callback_url = f"{callback_base_url.rstrip('/')}/api/generate-icf-callback"
    temp_path = None
    learn_result = None
    start_time = datetime.now()

    try:
        logger.info(f"[{job_id}] Starting Learn-and-Regenerate for document {document_id}", correlation_id=correlation_id)
        temp_path, _ = download_from_blob_url(reviewed_blob_url)

        extractor = CommentExtractor()
        all_comments = extractor.extract_comments(temp_path)
        client_comments = [c for c in all_comments if c.is_client]
        comments_for_pipeline = [
            {
                "text": c.text,
                "linked_text": c.linked_text,
                "section_heading": c.section_title or "Unknown",
                "author": c.author,
            }
            for c in client_comments
        ]

        pipeline = LearnPipeline(country=country)
        learn_result = pipeline.run_learn_only_pipeline(
            reviewed_path=temp_path,
            icf_case_id=icf_case_id,
            iteration_id=iteration_id,
            comments=comments_for_pipeline,
        )

        if temp_path and os.path.exists(temp_path):
            try:
                os.remove(temp_path)
                os.rmdir(os.path.dirname(temp_path))
            except Exception:
                pass
        temp_path = None

        req = RegenerateRequest(
            job_id=job_id,
            document_id=str(document_id),
            icf_case_id=icf_case_id,
            countryid=country_id,
            country_name=country,
            reviewed_blob_url=reviewed_blob_url,
            callback_url=callback_url,
            current_version=current_version,
            iteration_id=iteration_id,
            study_id=study_id,
            study_name=study_name,
            study_icf_type=study_icf_type,
            user_name=user_name,
        )

        workflow = HumanReviewWorkflow()
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            callback_result = loop.run_until_complete(
                workflow.run(
                    req,
                    callback_url,
                    skip_dpo=False,
                    correlation_id=correlation_id,
                    send_callback=False,
                )
            )
            if learn_result and callback_result.metadata:
                callback_result.metadata.artifacts_indexed = learn_result.get("artifacts_indexed", 0)
                track_changes = learn_result.get("track_changes_extracted", 0)
                comments = learn_result.get("comments_extracted", 0)
                indexed = learn_result.get("artifacts_indexed", 0)
                total_items = track_changes + comments
                not_learned = max(0, total_items - indexed)
                callback_result.metadata.feedback_items_total = total_items
                callback_result.metadata.feedback_items_learned = indexed
                callback_result.metadata.feedback_items_not_learned = not_learned
                callback_result.metadata.not_learned_items = learn_result.get("not_learned_items", [])
        finally:
            loop.close()

        if callback_result and callback_url:
            send_callback(callback_url, callback_result.model_dump(), correlation_id=correlation_id)

        logger.info(f"[{job_id}] Learn-and-Regenerate completed successfully", correlation_id=correlation_id)
    except Exception as e:
        logger.exception(f"[{job_id}] Learn-and-Regenerate failed: {e}", correlation_id=correlation_id)
        total_duration = (datetime.now() - start_time).total_seconds()
        send_callback(callback_url, {
            "status": 0,
            "success": False,
            "filename": None,
            "blob_url": None,
            "icfDoc_id": document_id,
            "icf_case_id": icf_case_id,
            "version": None,
            "error": str(e),
            "metadata": {
                "country": country.upper(),
                "countryid": country_id,
                "iteration_id": iteration_id,
                "artifacts_indexed": learn_result.get("artifacts_indexed", 0) if learn_result else 0,
                "duration_seconds": total_duration,
            },
        }, correlation_id=correlation_id)
        raise
    finally:
        if temp_path and os.path.exists(temp_path):
            try:
                os.remove(temp_path)
                if os.path.dirname(temp_path):
                    os.rmdir(os.path.dirname(temp_path))
            except Exception:
                pass


def _get_transport_type():
    """Use Amqp (TCP) by default; AmqpOverWebsocket often causes amqp:client-error in some networks."""
    from azure.servicebus import TransportType
    use_ws = (os.getenv("SERVICEBUS_USE_WEBSOCKET") or "").strip().lower() in ("1", "true", "yes")
    return TransportType.AmqpOverWebsocket if use_ws else TransportType.Amqp


def _process_queue(queue_name: str, handler) -> None:
    """Receive and process messages from a queue."""
    from azure.servicebus import ServiceBusClient, TransportType
    from config import Config

    raw_conn = (Config.AZURE_SERVICE_BUS_CONNECTION_STRING or "").strip()
    if not raw_conn:
        logger.warning("AZURE_SERVICE_BUS_CONNECTION_STRING not set, consumer not starting")
        return

    retry_delay = 5.0
    max_retry_delay = 60.0  # Cap at 60s so we retry more frequently when connection fails
    transport = _get_transport_type()
    transport_name = "AmqpOverWebsocket" if transport == TransportType.AmqpOverWebsocket else "Amqp"

    while not _stop_event.is_set():
        try:
            conn_str = _normalize_service_bus_connection_string(raw_conn)
            client = ServiceBusClient.from_connection_string(
                conn_str, transport_type=transport
            )
            max_wait_time = 5
            receiver = client.get_queue_receiver(queue_name=queue_name)

            logger.info(f"Service Bus consumer started for queue: {queue_name} (transport={transport_name})")

            with client, receiver:
                while not _stop_event.is_set():
                    try:
                        messages = receiver.receive_messages(max_wait_time=max_wait_time)
                        for msg in messages:
                            if _stop_event.is_set():
                                break
                            try:
                                body = msg.body
                                if isinstance(body, bytes):
                                    body = json.loads(body.decode("utf-8"))
                                elif isinstance(body, str):
                                    body = json.loads(body)
                                handler(body)
                                receiver.complete_message(msg)
                            except Exception as e:
                                logger.exception(f"Error processing message from {queue_name}: {e}")
                                try:
                                    receiver.dead_letter_message(msg, reason="ProcessingFailed", error_description=str(e))
                                except Exception as dlq_err:
                                    logger.warning(f"Could not dead-letter message: {dlq_err}")
                                    receiver.abandon_message(msg)
                    except Exception as e:
                        if not _stop_event.is_set():
                            logger.warning(f"Receive error on {queue_name}: {e}")
                        break
            break  # success - exited normally
        except Exception as e:
            if _stop_event.is_set():
                break
            logger.warning(
                f"Service Bus connection failed for {queue_name}: {e}. "
                f"Retrying in {retry_delay:.0f}s (transport={transport_name}; set SERVICEBUS_USE_WEBSOCKET=1 to try WebSocket, or unset AZURE_SERVICE_BUS_CONNECTION_STRING to use HTTP only)."
            )
            _stop_event.wait(retry_delay)
            retry_delay = min(retry_delay * 2, max_retry_delay)

    logger.info(f"Service Bus consumer stopped for queue: {queue_name}")


def start_consumer() -> None:
    """Start the Service Bus consumer in background threads."""
    from config import Config
    
    if not Config.SERVICE_BUS_ENABLED:
        logger.info("Service Bus disabled via SERVICE_BUS_ENABLED=false, consumer not started (using HTTP endpoints)")
        return
    
    conn_str = Config.AZURE_SERVICE_BUS_CONNECTION_STRING
    if not conn_str:
        logger.warning("Service Bus enabled but AZURE_SERVICE_BUS_CONNECTION_STRING not set, consumer not started")
        return

    _stop_event.clear()

    queues_and_handlers = [
        ("icf-generation-queue", _handle_generation_message),
        ("icf-learn-queue", _handle_learn_message),
        ("icf-regen-queue", _handle_regen_message),
    ]

    for queue_name, handler in queues_and_handlers:
        t = threading.Thread(
            target=_process_queue,
            args=(queue_name, handler),
            daemon=True,
            name=f"sb-{queue_name}",
        )
        t.start()
        _consumer_threads.append(t)

    logger.info("Service Bus consumers started for all queues")


def stop_consumer() -> None:
    """Signal consumers to stop."""
    _stop_event.set()
    for t in _consumer_threads:
        t.join(timeout=10)
    _consumer_threads.clear()
    logger.info("Service Bus consumers stopped")
