"""Create test data files for ICF agentic flow testing."""

from pathlib import Path
from docx import Document
import pandas as pd

# Create test data directory
test_data_dir = Path("test_data")
test_data_dir.mkdir(exist_ok=True)

# Create test ICF DOCX
print("Creating test Global ICF...")
doc = Document()

# Title
doc.add_heading('INFORMED CONSENT FORM', 0)
doc.add_paragraph('This is a test Global ICF document for testing the agentic flow.')

# Section 1
doc.add_heading('WHAT IS THE STUDY ABOUT?', 1)
doc.add_paragraph('This study involves research to evaluate the safety and efficacy of a new investigational drug.')
doc.add_paragraph('The study will be conducted at multiple research sites.')

# Section 2
doc.add_heading('WHAT WILL HAPPEN TO ME DURING THE STUDY?', 1)
doc.add_paragraph('You will be asked to visit the clinic multiple times.')
doc.add_paragraph('During each visit, we will collect blood samples and perform physical examinations.')

# Section 3
doc.add_heading('WHAT ARE THE POSSIBLE RISKS?', 1)
doc.add_paragraph('There may be risks involved in participating in this study.')
doc.add_paragraph('Common side effects include headache and nausea.')

# Section 4
doc.add_heading('HOW TO CONTACT US', 1)
doc.add_paragraph('If you have any questions about this study, please contact Dr. Smith at 555-1234.')
doc.add_paragraph('For emergencies, contact the study coordinator.')

# Section 5
doc.add_heading('COMPENSATION', 1)
doc.add_paragraph('You will receive compensation for your participation in this study.')
doc.add_paragraph('Compensation will be provided at the end of the study.')

icf_path = test_data_dir / "global_icf.docx"
doc.save(str(icf_path))
print(f"[OK] Created: {icf_path}")

# Create test Excel customization plan
print("\nCreating test Excel customization plan...")
data = {
    'Item ID': ['USA-01', 'USA-02', 'USA-03', 'USA-04', 'USA-05'],
    'Topic': [
        'Contact for further information',
        'Compensation',
        'Data Protection',
        'Risks and Benefits',
        'Study Purpose'
    ],
    'Requirement Text': [
        'In case of study-related injury or questions, contact [PI name] at [phone] or emergency contact [number]',
        'Explicit statement about compensation for study-related injury',
        'HIPAA privacy notice and data protection requirements',
        'Description of reasonably foreseeable risks and discomforts',
        'Statement that research is conducted under FDA regulations'
    ],
    'Requirement Type': ['mandatory', 'mandatory', 'mandatory', 'mandatory', 'mandatory'],
    'Applies To': ['existing_section', 'existing_section', 'insert_new', 'existing_section', 'existing_section'],
    'Synonyms': [
        'HOW TO CONTACT US, contact information, who to contact',
        'payment, reimbursement, injury compensation',
        'privacy, confidentiality, HIPAA',
        'risks, side effects, adverse events',
        'purpose, objective, study description'
    ],
    'Importance': ['high', 'high', 'high', 'medium', 'medium']
}

df = pd.DataFrame(data)
excel_path = test_data_dir / "usa_customization_plan.xlsx"
df.to_excel(str(excel_path), index=False)
print(f"[OK] Created: {excel_path}")

print("\n[OK] Test data created successfully!")

