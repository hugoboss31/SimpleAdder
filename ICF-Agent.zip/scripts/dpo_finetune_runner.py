"""Automated DPO fine-tuning workflow for Azure OpenAI.

This script performs the following steps:
1. Downloads the latest learning/dpo_learning.jsonl dataset from Azure Blob Storage
2. Uploads the dataset to the Azure OpenAI Files API
3. Submits a DPO fine-tuning job and monitors it until completion
4. Updates the existing Azure OpenAI deployment to point at the new fine-tuned model
5. Removes training files older than the configured retention window
"""

from __future__ import annotations

import json
import os
import sys
import tempfile
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import List

import requests
from azure.core.exceptions import ResourceNotFoundError

# Ensure repository root is on the Python path when this script is executed directly
ROOT_DIR = Path(__file__).resolve().parent.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from config import Config
from services.client_manager import client_manager
from utils.logger import get_logger


class DPOFineTuneRunner:
    """Manages the end-to-end DPO fine-tuning and deployment workflow."""

    DATASET_BLOB_PATH = "learning/dpo_learning.jsonl"

    def __init__(self) -> None:
        self.logger = get_logger("dpo_finetune")
        self.endpoint = (Config.AZURE_OPENAI_ENDPOINT or "").rstrip("/")
        self.api_key = Config.AZURE_OPENAI_API_KEY
        self.api_version = Config.AZURE_OPENAI_API_VERSION or "2025-01-01-preview"
        self.base_model = Config.AZURE_OPENAI_MODEL_VERSION or Config.AZURE_OPENAI_DEPLOYMENT_NAME
        self.deployment_name = Config.AZURE_OPENAI_DEPLOYMENT_NAME
        self.retention_days = Config.DPO_FILE_RETENTION_DAYS
        self.poll_interval_seconds = Config.DPO_JOB_POLL_SECONDS
        self.file_wait_attempts = Config.DPO_FILE_WAIT_ATTEMPTS
        self._validate_config()

        self.session = requests.Session()
        self.session.headers.update({
            "api-key": self.api_key,
        })

        self.logger.info(
            "Initialized DPO fine-tune runner",
            context={
                "endpoint": self.endpoint,
                "baseModel": self.base_model,
                "deployment": self.deployment_name,
                "retentionDays": self.retention_days,
            },
        )

    def _validate_config(self) -> None:
        missing = [
            name
            for name, value in [
                ("AZURE_OPENAI_ENDPOINT", self.endpoint),
                ("AZURE_OPENAI_API_KEY", self.api_key),
                ("AZURE_OPENAI_DEPLOYMENT_NAME", self.deployment_name),
            ]
            if not value
        ]
        if missing:
            raise ValueError(f"Missing required configuration values: {', '.join(missing)}")

    # -------------------------------------------------------------------------
    # Dataset handling
    # -------------------------------------------------------------------------
    def download_dataset(self) -> tuple[str, int]:
        """Download the DPO dataset from blob storage to a temp file."""
        blob_service = client_manager.blob_service_client
        if not blob_service:
            raise RuntimeError("Blob service client is not configured")

        container = Config.AZURE_STORAGE_CONTAINER_NAME
        blob_client = blob_service.get_blob_client(container=container, blob=self.DATASET_BLOB_PATH)

        try:
            downloader = blob_client.download_blob()
            data = downloader.readall()
        except ResourceNotFoundError as exc:
            raise FileNotFoundError(
                f"Dataset blob '{self.DATASET_BLOB_PATH}' not found in container '{container}'"
            ) from exc

        if not data:
            raise ValueError("Downloaded dataset is empty")

        with tempfile.NamedTemporaryFile(mode="wb", delete=False, suffix=".jsonl") as tmp:
            tmp.write(data)
            tmp_path = tmp.name

        lines = data.decode("utf-8").strip().splitlines()
        if len(lines) < 10:
            raise ValueError("Need at least 10 training examples for DPO fine-tuning")

        self.logger.info(
            "Downloaded dataset from blob",
            context={"records": len(lines), "tempFile": tmp_path},
        )
        return tmp_path, len(lines)

    def preprocess_dataset(self, source_path: str) -> tuple[str, int]:
        """Create a schema-compliant JSONL file for DPO training."""
        sanitized_records: List[dict] = []
        with open(source_path, "r", encoding="utf-8") as handle:
            for line_number, line in enumerate(handle, start=1):
                line = line.strip()
                if not line:
                    continue
                try:
                    record = json.loads(line)
                except json.JSONDecodeError:
                    self.logger.warning(
                        "Skipping invalid JSON line",
                        context={"line": line_number},
                    )
                    continue

                input_section = record.get("input", {}) or {}
                messages = input_section.get("messages", []) or []
                tools = input_section.get("tools", []) or []
                parallel = bool(input_section.get("parallel_tool_calls", True))

                metadata = record.get("metadata", {}) or {}
                country = metadata.get("country")
                if country:
                    country_note = f"COUNTRY CONTEXT: {country.upper()}"
                    system_msg = next((m for m in messages if m.get("role") == "system"), None)
                    if system_msg:
                        if country_note not in system_msg.get("content", ""):
                            system_msg["content"] = (system_msg.get("content", "") + f"\n\n{country_note}").strip()
                    else:
                        messages.insert(0, {"role": "system", "content": country_note})

                preferred_raw = record.get("preferred_output", []) or []
                non_preferred_raw = record.get("non_preferred_output", []) or []

                preferred_messages = [msg for msg in preferred_raw if msg.get("role") in {"assistant", "tool"}]
                non_preferred_messages = [msg for msg in non_preferred_raw if msg.get("role") in {"assistant", "tool"}]

                if not messages or not preferred_messages or not non_preferred_messages:
                    self.logger.warning(
                        "Skipping record missing required sections",
                        context={"line": line_number},
                    )
                    continue

                # Azure DPO format expects flat arrays of message objects
                input_payload = {"messages": messages}
                if tools:
                    input_payload["tools"] = tools
                    input_payload["parallel_tool_calls"] = parallel

                sanitized_records.append(
                    {
                        "input": input_payload,
                        "preferred_output": preferred_messages,
                        "non_preferred_output": non_preferred_messages,
                    }
                )

        if not sanitized_records:
            raise ValueError("No valid records after preprocessing")

        with tempfile.NamedTemporaryFile(mode="w", delete=False, suffix=".jsonl", encoding="utf-8") as tmp:
            for record in sanitized_records:
                tmp.write(json.dumps(record, ensure_ascii=False) + "\n")
            sanitized_path = tmp.name

        self.logger.info(
            "Preprocessed dataset for DPO schema",
            context={"records": len(sanitized_records), "tempFile": sanitized_path},
        )
        return sanitized_path, len(sanitized_records)

    # -------------------------------------------------------------------------
    # Azure OpenAI helpers
    # -------------------------------------------------------------------------
    def upload_training_file(self, file_path: str) -> str:
        url = f"{self.endpoint}/openai/files?api-version={self.api_version}"
        self.logger.info("Uploading training file to Azure OpenAI")

        with open(file_path, "rb") as handle:
            files = {"file": (os.path.basename(file_path), handle, "application/jsonl")}
            data = {"purpose": "fine-tune"}
            response = self.session.post(url, files=files, data=data, timeout=60)

        if response.status_code != 201:
            raise RuntimeError(f"File upload failed: {response.status_code} - {response.text}")

        file_id = response.json().get("id")
        self.logger.info("Uploaded training file", context={"fileId": file_id})
        return file_id

    def wait_for_file_processing(self, file_id: str) -> None:
        url = f"{self.endpoint}/openai/files/{file_id}?api-version={self.api_version}"
        self.logger.info("Waiting for file processing", context={"fileId": file_id})

        for attempt in range(1, self.file_wait_attempts + 1):
            response = self.session.get(url, timeout=15)
            if response.status_code != 200:
                raise RuntimeError(f"File status check failed: {response.status_code} - {response.text}")

            payload = response.json()
            status = payload.get("status")
            self.logger.info(
                "File processing status",
                context={"fileId": file_id, "status": status, "attempt": attempt},
            )

            if status in {"processed", "succeeded"}:
                return
            if status == "error":
                raise RuntimeError(f"File processing error: {payload.get('status_details')}")

            time.sleep(2)

        raise TimeoutError("File processing did not complete in time")

    def submit_dpo_job(self, file_id: str) -> str:
        url = f"{self.endpoint}/openai/fine_tuning/jobs?api-version={self.api_version}"
        headers = {"Content-Type": "application/json", "task_type": "chat"}
        payload = {
            "model": self.base_model,
            "training_file": file_id,
            "suffix": f"dpo-{datetime.utcnow().strftime('%Y%m%d')}",
            "method": {
                "type": "dpo",
                "dpo": {
                    "beta": Config.DPO_BETA,
                    "l2_multiplier": Config.DPO_L2_MULTIPLIER,
                },
            },
        }

        self.logger.info(
            "Submitting DPO fine-tuning job",
            context={"model": self.base_model, "fileId": file_id},
        )
        response = self.session.post(url, headers=headers, json=payload, timeout=60)
        if response.status_code not in {200, 201}:
            raise RuntimeError(f"Fine-tune job submission failed: {response.status_code} - {response.text}")

        job_id = response.json().get("id")
        self.logger.info("DPO job submitted", context={"jobId": job_id})
        return job_id

    def monitor_job(self, job_id: str) -> str:
        url = f"{self.endpoint}/openai/fine_tuning/jobs/{job_id}?api-version={self.api_version}"
        self.logger.info("Monitoring fine-tune job", context={"jobId": job_id})

        while True:
            response = self.session.get(url, timeout=30)
            if response.status_code != 200:
                raise RuntimeError(f"Job status check failed: {response.status_code} - {response.text}")

            job = response.json()
            status = job.get("status")
            self.logger.info(
                "Fine-tune status",
                context={"jobId": job_id, "status": status},
            )

            if status == "succeeded":
                model_name = job.get("fine_tuned_model")
                if not model_name:
                    raise RuntimeError("Fine-tune succeeded but fine_tuned_model missing in response")
                return model_name

            if status in {"failed", "cancelled"}:
                raise RuntimeError(f"Fine-tune job {status}: {job.get('error')}")

            time.sleep(self.poll_interval_seconds)

    def cleanup_old_files(self) -> None:
        url = f"{self.endpoint}/openai/files?api-version={self.api_version}"
        response = self.session.get(url, timeout=30)
        if response.status_code != 200:
            self.logger.warning("Unable to list files for cleanup", context={"status": response.status_code})
            return

        cutoff = datetime.utcnow() - timedelta(days=self.retention_days)
        files: List[dict] = response.json().get("data", [])
        deleted = 0
        for file_info in files:
            created = datetime.utcfromtimestamp(file_info.get("created_at", 0))
            purpose = file_info.get("purpose")
            file_id = file_info.get("id")
            if purpose not in {"fine-tune", "fine-tune-results"}:
                continue
            if created >= cutoff:
                continue

            delete_url = f"{self.endpoint}/openai/files/{file_id}?api-version={self.api_version}"
            delete_response = self.session.delete(delete_url, timeout=15)
            if delete_response.status_code == 200:
                deleted += 1
                self.logger.info("Deleted old training file", context={"fileId": file_id})
            else:
                self.logger.warning(
                    "Failed to delete training file",
                    context={"fileId": file_id, "status": delete_response.status_code},
                )

        self.logger.info("File cleanup complete", context={"deleted": deleted})

    def update_deployment(self, model_name: str) -> None:
        if not self.deployment_name:
            raise ValueError("Deployment name not configured")

        url = f"{self.endpoint}/openai/deployments/{self.deployment_name}?api-version={self.api_version}"
        headers = {"Content-Type": "application/json"}
        payload = {"model": model_name}

        self.logger.info(
            "Updating Azure OpenAI deployment",
            context={"deployment": self.deployment_name, "model": model_name},
        )

        response = self.session.put(url, headers=headers, json=payload, timeout=60)
        if response.status_code not in {200, 201}:
            raise RuntimeError(
                f"Deployment update failed: {response.status_code} - {response.text}"
            )

    # -------------------------------------------------------------------------
    # Orchestration
    # -------------------------------------------------------------------------
    def run(self) -> str:
        dataset_path = None
        total_start = time.perf_counter()
        finetune_duration = None
        deployment_duration = None
        try:
            dataset_path, _ = self.download_dataset()
            dataset_path, record_count = self.preprocess_dataset(dataset_path)
            file_id = self.upload_training_file(dataset_path)
            self.wait_for_file_processing(file_id)
            job_id = self.submit_dpo_job(file_id)
            finetune_start = time.perf_counter()
            model_name = self.monitor_job(job_id)
            finetune_duration = time.perf_counter() - finetune_start

            deployment_start = time.perf_counter()
            self.update_deployment(model_name)
            deployment_duration = time.perf_counter() - deployment_start
            self.cleanup_old_files()

            self.logger.info(
                "Fine-tuning workflow complete",
                context={
                    "records": record_count,
                    "fileId": file_id,
                    "jobId": job_id,
                    "model": model_name,
                    "deployment": self.deployment_name,
                    "finetuneSeconds": round(finetune_duration or 0, 2),
                    "deploymentSeconds": round(deployment_duration or 0, 2),
                    "totalSeconds": round(time.perf_counter() - total_start, 2),
                },
            )
            total_seconds = time.perf_counter() - total_start
            print(
                "✅ Fine-tuning complete:\n"
                f"   • Model: {model_name}\n"
                f"   • Deployment: {self.deployment_name}\n"
                f"   • Records: {record_count}\n"
                f"   • Fine-tune duration: {self._format_duration(finetune_duration)}\n"
                f"   • Deployment duration: {self._format_duration(deployment_duration)}\n"
                f"   • Total runtime: {self._format_duration(total_seconds)}"
            )
            return model_name
        finally:
            if dataset_path and os.path.exists(dataset_path):
                try:
                    os.remove(dataset_path)
                except OSError:
                    self.logger.warning("Failed to delete temporary dataset file", context={"file": dataset_path})

    @staticmethod
    def _format_duration(duration: float | None) -> str:
        if duration is None:
            return "n/a"
        minutes, seconds = divmod(int(duration), 60)
        if minutes:
            return f"{minutes}m {seconds}s"
        return f"{seconds}s"


def main() -> None:
    runner = DPOFineTuneRunner()
    runner.run()


if __name__ == "__main__":
    main()
