"""
Document Handler for ICF documents.
- Text extraction via Azure Document Intelligence
- Track changes with FIXED cross-run text matching
- Comments with regulatory reasoning
- Section-based deletion using section_id with TOC skipping
"""

import os
import zipfile
import shutil
from typing import List, Dict, Tuple
from datetime import datetime
from copy import deepcopy

from docx import Document
from lxml import etree
from dotenv import load_dotenv

try:
    from azure.ai.formrecognizer import DocumentAnalysisClient
    from azure.core.credentials import AzureKeyCredential
    AZURE_DI_AVAILABLE = True
except ImportError:
    AZURE_DI_AVAILABLE = False

load_dotenv()

# XML Namespaces
W_NS = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
W = '{%s}' % W_NS
RELS_NS = 'http://schemas.openxmlformats.org/package/2006/relationships'
CT_NS = 'http://schemas.openxmlformats.org/package/2006/content-types'


class DocumentHandler:
    """Handles ICF document extraction and track changes."""
    
    def __init__(self):
        self.azure_client = None
        self._init_azure_client()
        # Cache for section mappings (section_id -> heading text)
        self._section_cache: Dict[str, str] = {}
    
    def _init_azure_client(self):
        """Initialize Azure Document Intelligence."""
        if not AZURE_DI_AVAILABLE:
            return
        
        endpoint = os.getenv("AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT")
        key = os.getenv("AZURE_DOCUMENT_INTELLIGENCE_API_KEY")
        
        if endpoint and key:
            try:
                self.azure_client = DocumentAnalysisClient(
                    endpoint=endpoint,
                    credential=AzureKeyCredential(key)
                )
                print("✅ Azure Document Intelligence initialized")
            except Exception as e:
                print(f"⚠️ Azure DI init failed: {e}")
    
    def extract_text(self, docx_path: str) -> str:
        """Extract text from document."""
        if self.azure_client:
            try:
                with open(docx_path, 'rb') as f:
                    poller = self.azure_client.begin_analyze_document("prebuilt-read", f.read())
                    result = poller.result()
                    lines = []
                    for page in result.pages:
                        for line in page.lines:
                            lines.append(line.content)
                    text = "\n".join(lines)
                    if text:
                        return text
            except Exception as e:
                print(f"⚠️ Azure extraction failed: {e}")
        
        return self._extract_with_docx(docx_path)
    
    def _extract_with_docx(self, docx_path: str) -> str:
        """Extract text using python-docx."""
        doc = Document(docx_path)
        parts = []
        
        for para in doc.paragraphs:
            if para.text.strip():
                parts.append(para.text)
        
        for table in doc.tables:
            for row in table.rows:
                row_text = ' | '.join([c.text.strip() for c in row.cells if c.text.strip()])
                if row_text:
                    parts.append(row_text)
        
        return '\n'.join(parts)
    
    def set_section_cache(self, section_cache: Dict[str, str]):
        """Set section cache from ingestion agent."""
        self._section_cache = section_cache
        print(f"  ✓ Document handler section cache set: {len(section_cache)} sections")

    def _get_max_existing_ids(self, root) -> Tuple[int, int]:
        """
        Scan document.xml for existing revision and comment IDs.
        Returns (max_revision_id, max_comment_id) to avoid duplicates.
        """
        max_revision_id = 0
        max_comment_id = 0
        
        # Find max revision IDs from w:ins and w:del elements
        for elem in root.iter():
            # Check insertion elements
            if elem.tag == W + 'ins':
                rev_id = elem.get(W + 'id')
                if rev_id and rev_id.isdigit():
                    max_revision_id = max(max_revision_id, int(rev_id))
            
            # Check deletion elements
            if elem.tag == W + 'del':
                rev_id = elem.get(W + 'id')
                if rev_id and rev_id.isdigit():
                    max_revision_id = max(max_revision_id, int(rev_id))
            
            # Check comment range starts/ends
            if elem.tag in [W + 'commentRangeStart', W + 'commentRangeEnd', W + 'commentReference']:
                cmt_id = elem.get(W + 'id')
                if cmt_id and cmt_id.isdigit():
                    max_comment_id = max(max_comment_id, int(cmt_id))
        
        return max_revision_id, max_comment_id
    
    def create_tracked_changes_document(
        self,
        template_path: str,
        changes: List[Dict],
        output_path: str
    ) -> str:
        """Create document with track changes."""
        temp_dir = output_path + "_temp"
        if os.path.exists(temp_dir):
            shutil.rmtree(temp_dir)
        
        with zipfile.ZipFile(template_path, 'r') as zip_ref:
            zip_ref.extractall(temp_dir)
        
        doc_xml_path = os.path.join(temp_dir, "word", "document.xml")
        parser = etree.XMLParser(remove_blank_text=False)
        tree = etree.parse(doc_xml_path, parser)
        root = tree.getroot()
        
        # Get max existing IDs to avoid duplicates when processing already-modified documents
        max_rev, max_cmt = self._get_max_existing_ids(root)
        revision_id = max_rev + 1
        comment_id = max_cmt + 1
        
        if max_rev > 0 or max_cmt > 0:
            print(f"  ℹ️ Found existing revisions (max_id={max_rev}) and comments (max_id={max_cmt})")

        comments_list = []
        author = "ICF-Gen-Agent"
        date_str = datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
        
        applied_count = 0
        
        for change in changes:
            change_type = change.get('type', 'replace').lower()
            
            if change_type == 'replace':
                result = self._process_replacement(
                    root, change, author, date_str,
                    revision_id, comment_id, comments_list
                )
                if result[0] > revision_id:
                    applied_count += 1
                revision_id, comment_id = result
            elif change_type == 'add':
                result = self._process_addition(
                    root, change, author, date_str,
                    revision_id, comment_id, comments_list
                )
                if result[0] > revision_id:
                    applied_count += 1
                revision_id, comment_id = result
            elif change_type == 'delete':
                result = self._process_deletion(
                    root, change, author, date_str,
                    revision_id, comment_id, comments_list
                )
                if result[0] > revision_id:
                    applied_count += 1
                revision_id, comment_id = result
            elif change_type == 'delete_section':
                result = self._process_section_deletion(
                    root, change, author, date_str,
                    revision_id, comment_id, comments_list
                )
                if result[0] > revision_id:
                    applied_count += 1
                revision_id, comment_id = result
        
        print(f"✅ Applied {applied_count}/{len(changes)} changes")
        
        with open(doc_xml_path, 'wb') as f:
            tree.write(f, xml_declaration=True, encoding='UTF-8', standalone='yes')
        
        if comments_list:
            self._create_comments_file(temp_dir, comments_list)
            self._update_content_types(os.path.join(temp_dir, "[Content_Types].xml"))
            self._update_document_rels(os.path.join(temp_dir, "word", "_rels", "document.xml.rels"))
        
        settings_path = os.path.join(temp_dir, "word", "settings.xml")
        if os.path.exists(settings_path):
            self._enable_track_changes(settings_path)
        
        with zipfile.ZipFile(output_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for root_dir, dirs, files in os.walk(temp_dir):
                for file in files:
                    file_path = os.path.join(root_dir, file)
                    arcname = os.path.relpath(file_path, temp_dir)
                    zipf.write(file_path, arcname)
        
        shutil.rmtree(temp_dir)
        return output_path
    
    def _process_replacement(
        self, root, change: Dict, author: str, date_str: str,
        revision_id: int, comment_id: int, comments_list: List
    ) -> Tuple[int, int]:
        """Process replacement - handles text across multiple runs."""
        original = change.get('original', '')
        new_text = change.get('new_text', '')
        reason = change.get('reason', '')
        source = change.get('source', '')
        
        if not original or not new_text:
            return revision_id, comment_id
        
        original_normalized = ' '.join(original.split())
        
        for para in root.iter(W + 'p'):
            runs = list(para.iter(W + 'r'))
            
            run_texts = []
            run_elements = []
            for run in runs:
                t_elem = run.find(W + 't')
                if t_elem is not None and t_elem.text:
                    run_texts.append(t_elem.text)
                    run_elements.append(run)
                else:
                    run_texts.append('')
                    run_elements.append(run)
            
            para_text = ''.join(run_texts)
            para_text_normalized = ' '.join(para_text.split())
            
            if original in para_text:
                match_start = para_text.find(original)
                match_end = match_start + len(original)
            elif original_normalized in para_text_normalized:
                match_start = para_text.lower().find(original_normalized.lower()[:20])
                if match_start == -1:
                    continue
                match_end = match_start + len(original)
            else:
                continue
            
            char_pos = 0
            start_run_idx = None
            end_run_idx = None
            start_offset = 0
            end_offset = 0
            
            for idx, text in enumerate(run_texts):
                run_start = char_pos
                run_end = char_pos + len(text)
                
                if start_run_idx is None and run_end > match_start:
                    start_run_idx = idx
                    start_offset = match_start - run_start
                
                if end_run_idx is None and run_end >= match_end:
                    end_run_idx = idx
                    end_offset = match_end - run_start
                    break
                
                char_pos = run_end
            
            if start_run_idx is None or end_run_idx is None:
                continue
            
            first_run = run_elements[start_run_idx]
            rPr = first_run.find(W + 'rPr')
            rPr_copy = deepcopy(rPr) if rPr is not None else None
            
            parent = first_run.getparent()
            first_run_index = list(parent).index(first_run)
            
            before_text = run_texts[start_run_idx][:start_offset]
            after_text = run_texts[end_run_idx][end_offset:] if end_run_idx < len(run_texts) else ''
            
            new_elements = []
            
            if before_text:
                before_run = self._create_text_run(before_text, rPr_copy)
                new_elements.append(before_run)
            
            comment_start = etree.Element(W + 'commentRangeStart')
            comment_start.set(W + 'id', str(comment_id))
            new_elements.append(comment_start)
            
            del_elem = self._create_deletion(original, revision_id, author, date_str)
            new_elements.append(del_elem)
            revision_id += 1
            
            ins_elem = self._create_insertion(new_text, revision_id, author, date_str)
            new_elements.append(ins_elem)
            revision_id += 1
            
            comment_end = etree.Element(W + 'commentRangeEnd')
            comment_end.set(W + 'id', str(comment_id))
            new_elements.append(comment_end)
            
            comment_ref_run = etree.Element(W + 'r')
            comment_ref = etree.SubElement(comment_ref_run, W + 'commentReference')
            comment_ref.set(W + 'id', str(comment_id))
            new_elements.append(comment_ref_run)
            
            if after_text:
                after_run = self._create_text_run(after_text, rPr_copy)
                new_elements.append(after_run)
            
            comment_text = f"REPLACE: '{original[:50]}...' → '{new_text[:50]}...'\n\nReason: {reason}\nSource: {source}"
            comments_list.append({
                'id': comment_id,
                'author': author,
                'date': date_str,
                'initials': 'USA',
                'text': comment_text
            })
            comment_id += 1
            
            for idx in range(start_run_idx, end_run_idx + 1):
                if idx < len(run_elements):
                    try:
                        parent.remove(run_elements[idx])
                    except:
                        pass
            
            for i, elem in enumerate(new_elements):
                parent.insert(first_run_index + i, elem)
            
            return revision_id, comment_id
        
        return revision_id, comment_id
    
    def _process_addition(
        self, root, change: Dict, author: str, date_str: str,
        revision_id: int, comment_id: int, comments_list: List
    ) -> Tuple[int, int]:
        """Process text addition."""
        new_text = change.get('new_text', '')
        location = change.get('location', '')
        reason = change.get('reason', '')
        source = change.get('source', '')
        
        if not new_text:
            return revision_id, comment_id
        
        body = root.find('.//' + W + 'body')
        if body is None:
            return revision_id, comment_id
        
        paragraphs = list(body.iter(W + 'p'))
        target_idx = None
        insert_after = True
        
        if location.startswith('AFTER:'):
            search_text = location[6:].strip()
            insert_after = True
        elif location.startswith('BEFORE:'):
            search_text = location[7:].strip()
            insert_after = False
        else:
            search_text = location
        
        for idx, para in enumerate(paragraphs):
            para_text = ''.join([t.text or '' for t in para.iter(W + 't')])
            if search_text and search_text in para_text:
                target_idx = idx
                break
        
        if target_idx is None:
            target_idx = len(paragraphs) - 1
            insert_after = True
        
        new_para = etree.Element(W + 'p')
        
        comment_start = etree.SubElement(new_para, W + 'commentRangeStart')
        comment_start.set(W + 'id', str(comment_id))
        
        ins_elem = self._create_insertion(new_text, revision_id, author, date_str)
        new_para.append(ins_elem)
        revision_id += 1
        
        comment_end = etree.SubElement(new_para, W + 'commentRangeEnd')
        comment_end.set(W + 'id', str(comment_id))
        
        comment_ref_run = etree.SubElement(new_para, W + 'r')
        comment_ref = etree.SubElement(comment_ref_run, W + 'commentReference')
        comment_ref.set(W + 'id', str(comment_id))
        
        comment_text = f"ADD: '{new_text[:100]}...'\n\nReason: {reason}\nSource: {source}"
        comments_list.append({
            'id': comment_id,
            'author': author,
            'date': date_str,
            'initials': 'USA',
            'text': comment_text
        })
        comment_id += 1
        
        if target_idx is not None and target_idx < len(paragraphs):
            target_para = paragraphs[target_idx]
            parent = target_para.getparent()
            para_index = list(parent).index(target_para)
            
            if insert_after:
                parent.insert(para_index + 1, new_para)
            else:
                parent.insert(para_index, new_para)
        
        return revision_id, comment_id
    
    def _process_deletion(
        self, root, change: Dict, author: str, date_str: str,
        revision_id: int, comment_id: int, comments_list: List
    ) -> Tuple[int, int]:
        """Process text deletion."""
        original = change.get('original', '')
        reason = change.get('reason', '')
        source = change.get('source', '')
        
        if not original:
            return revision_id, comment_id
        
        for para in root.iter(W + 'p'):
            para_text = ''.join([t.text or '' for t in para.iter(W + 't')])
            
            if original not in para_text:
                continue
            
            runs = list(para.iter(W + 'r'))
            for run in runs:
                t_elem = run.find(W + 't')
                if t_elem is not None and t_elem.text and original in t_elem.text:
                    parent = run.getparent()
                    run_idx = list(parent).index(run)
                    
                    comment_start = etree.Element(W + 'commentRangeStart')
                    comment_start.set(W + 'id', str(comment_id))
                    parent.insert(run_idx, comment_start)
                    
                    del_elem = self._create_deletion(original, revision_id, author, date_str)
                    parent.insert(run_idx + 1, del_elem)
                    revision_id += 1
                    
                    remaining_text = t_elem.text.replace(original, '', 1)
                    if remaining_text:
                        t_elem.text = remaining_text
                    else:
                        try:
                            parent.remove(run)
                        except:
                            pass
                    
                    comment_end = etree.Element(W + 'commentRangeEnd')
                    comment_end.set(W + 'id', str(comment_id))
                    parent.insert(run_idx + 2, comment_end)
                    
                    comment_ref_run = etree.Element(W + 'r')
                    comment_ref = etree.SubElement(comment_ref_run, W + 'commentReference')
                    comment_ref.set(W + 'id', str(comment_id))
                    parent.insert(run_idx + 3, comment_ref_run)
                    
                    comment_text = f"DELETE: '{original[:100]}...'\n\nReason: {reason}\nSource: {source}"
                    comments_list.append({
                        'id': comment_id,
                        'author': author,
                        'date': date_str,
                        'initials': 'USA',
                        'text': comment_text
                    })
                    comment_id += 1
                    
                    return revision_id, comment_id
        
        return revision_id, comment_id
    
    def _is_heading_paragraph(self, para, para_text: str) -> bool:
        """Check if a paragraph is a heading based on formatting."""
        if not para_text or len(para_text) > 200:
            return False
        
        # Check for heading style
        pPr = para.find(W + 'pPr')
        if pPr is not None:
            pStyle = pPr.find(W + 'pStyle')
            if pStyle is not None:
                style_val = pStyle.get(W + 'val', '').lower()
                if 'heading' in style_val or 'title' in style_val:
                    return True
        
        # Check if text is bold
        runs = list(para.iter(W + 'r'))
        bold_count = 0
        total_text_runs = 0
        
        for run in runs:
            t_elem = run.find(W + 't')
            if t_elem is not None and t_elem.text and t_elem.text.strip():
                total_text_runs += 1
                rPr = run.find(W + 'rPr')
                if rPr is not None:
                    bold = rPr.find(W + 'b')
                    if bold is not None:
                        bold_count += 1
        
        if total_text_runs > 0 and bold_count >= total_text_runs * 0.5:
            if len(para_text) < 150:
                return True
        
        # Check for numbered heading pattern
        import re
        if re.match(r'^\d+\.?\d*[\.\)]?\s+', para_text):
            return True
        
        # Check for ALL CAPS short text
        if para_text.isupper() and len(para_text) < 100:
            return True
        
        # Check for question headings (common in ICF)
        if para_text.endswith('?') and len(para_text) < 150:
            return True
        
        return False
    
    def _process_section_deletion(
        self, root, change: Dict, author: str, date_str: str,
        revision_id: int, comment_id: int, comments_list: List
    ) -> Tuple[int, int]:
        """Process section deletion - deletes entire section by heading, skipping TOC."""
        section_id = change.get('section_id', '')
        section_heading = change.get('section_heading', '')
        reason = change.get('reason', '')
        source = change.get('source', '')
        
        # Get section heading from cache if not provided
        if not section_heading and section_id:
            section_heading = self._section_cache.get(section_id, '')
        
        if not section_heading:
            print(f"⚠️ Cannot delete section: no heading for {section_id}")
            return revision_id, comment_id
        
        section_heading_lower = section_heading.strip().lower()
        
        body = root.find('.//' + W + 'body')
        if body is None:
            return revision_id, comment_id
        
        paragraphs = list(body.iter(W + 'p'))
        section_start_idx = None
        section_end_idx = None
        
        # Skip first 20 paragraphs to avoid TOC matches
        min_paragraph_idx = 20
        
        for idx, para in enumerate(paragraphs):
            if idx < min_paragraph_idx:
                continue
            
            para_text = ''.join([t.text or '' for t in para.iter(W + 't')]).strip()
            para_text_lower = para_text.lower()
            
            # Stricter matching to avoid TOC duplicates
            if (section_heading_lower == para_text_lower or 
                (len(section_heading_lower) > 10 and 
                 section_heading_lower in para_text_lower and 
                 len(para_text) < len(section_heading) * 1.5)):
                
                section_start_idx = idx
                
                # Find the next section heading
                for next_idx in range(idx + 1, len(paragraphs)):
                    next_para = paragraphs[next_idx]
                    next_text = ''.join([t.text or '' for t in next_para.iter(W + 't')]).strip()
                    
                    if next_text and self._is_heading_paragraph(next_para, next_text):
                        section_end_idx = next_idx
                        break
                
                if section_end_idx is None:
                    section_end_idx = len(paragraphs)
                
                break
        
        if section_start_idx is None:
            print(f"⚠️ Section not found (after TOC): {section_heading}")
            return revision_id, comment_id
        
        paragraphs_to_delete = paragraphs[section_start_idx:section_end_idx]
        
        if not paragraphs_to_delete:
            return revision_id, comment_id
        
        # Add comment at section start
        first_para = paragraphs_to_delete[0]
        comment_start = etree.Element(W + 'commentRangeStart')
        comment_start.set(W + 'id', str(comment_id))
        first_para.insert(0, comment_start)
        
        # Mark each paragraph for deletion
        for para in paragraphs_to_delete:
            runs = list(para.iter(W + 'r'))
            
            for run in runs:
                t_elem = run.find(W + 't')
                if t_elem is not None and t_elem.text:
                    text = t_elem.text
                    
                    del_elem = self._create_deletion(text, revision_id, author, date_str)
                    
                    run_parent = run.getparent()
                    run_idx = list(run_parent).index(run)
                    run_parent.remove(run)
                    run_parent.insert(run_idx, del_elem)
                    
                    revision_id += 1
        
        # Add comment end at last paragraph
        last_para = paragraphs_to_delete[-1]
        comment_end = etree.Element(W + 'commentRangeEnd')
        comment_end.set(W + 'id', str(comment_id))
        last_para.append(comment_end)
        
        comment_ref_run = etree.Element(W + 'r')
        comment_ref = etree.SubElement(comment_ref_run, W + 'commentReference')
        comment_ref.set(W + 'id', str(comment_id))
        last_para.append(comment_ref_run)
        
        comment_text = f"DELETE SECTION: '{section_heading}'\n\nReason: {reason}\nSource: {source}"
        comments_list.append({
            'id': comment_id,
            'author': author,
            'date': date_str,
            'initials': 'USA',
            'text': comment_text
        })
        comment_id += 1
        
        print(f"  ✓ Marked section for deletion: {section_heading} ({len(paragraphs_to_delete)} paragraphs)")
        
        return revision_id, comment_id
    
    # ==================== HELPER METHODS ====================
    
    def _create_text_run(self, text: str, rPr=None):
        """Create a text run element."""
        run = etree.Element(W + 'r')
        if rPr is not None:
            run.append(deepcopy(rPr))
        t = etree.SubElement(run, W + 't')
        t.set('{http://www.w3.org/XML/1998/namespace}space', 'preserve')
        t.text = text
        return run
    
    def _create_deletion(self, text: str, revision_id: int, author: str, date_str: str):
        """Create deletion element."""
        del_elem = etree.Element(W + 'del')
        del_elem.set(W + 'id', str(revision_id))
        del_elem.set(W + 'author', author)
        del_elem.set(W + 'date', date_str)
        
        run = etree.SubElement(del_elem, W + 'r')
        del_text = etree.SubElement(run, W + 'delText')
        del_text.set('{http://www.w3.org/XML/1998/namespace}space', 'preserve')
        del_text.text = text
        
        return del_elem
    
    def _create_insertion(self, text: str, revision_id: int, author: str, date_str: str):
        """Create insertion element."""
        ins_elem = etree.Element(W + 'ins')
        ins_elem.set(W + 'id', str(revision_id))
        ins_elem.set(W + 'author', author)
        ins_elem.set(W + 'date', date_str)
        
        run = etree.SubElement(ins_elem, W + 'r')
        t = etree.SubElement(run, W + 't')
        t.set('{http://www.w3.org/XML/1998/namespace}space', 'preserve')
        t.text = text
        
        return ins_elem
    
    def _create_comments_file(self, temp_dir: str, comments: List[Dict]):
        """Create or append to comments.xml file."""
        nsmap = {
            'w': W_NS,
            'r': RELS_NS
        }
        
        comments_path = os.path.join(temp_dir, "word", "comments.xml")
        
        # Check if comments.xml already exists (from previous agent)
        if os.path.exists(comments_path):
            # Load existing comments and append new ones
            parser = etree.XMLParser(remove_blank_text=False)
            tree = etree.parse(comments_path, parser)
            comments_root = tree.getroot()
        else:
            # Create new comments file
            comments_root = etree.Element(W + 'comments', nsmap=nsmap)
        
        # Add new comments
        for comment in comments:
            comment_elem = etree.SubElement(comments_root, W + 'comment')
            comment_elem.set(W + 'id', str(comment['id']))
            comment_elem.set(W + 'author', comment['author'])
            comment_elem.set(W + 'date', comment['date'])
            comment_elem.set(W + 'initials', comment['initials'])
            
            para = etree.SubElement(comment_elem, W + 'p')
            run = etree.SubElement(para, W + 'r')
            t = etree.SubElement(run, W + 't')
            t.text = comment['text']
        
        with open(comments_path, 'wb') as f:
            tree = etree.ElementTree(comments_root)
            tree.write(f, xml_declaration=True, encoding='UTF-8', standalone='yes')
    
    def _update_content_types(self, content_types_path: str):
        """Add comments content type."""
        tree = etree.parse(content_types_path)
        root = tree.getroot()
        
        comments_override = f'/word/comments.xml'
        exists = False
        for elem in root:
            part_name = elem.get('PartName', '')
            if part_name == comments_override:
                exists = True
                break
        
        if not exists:
            override = etree.SubElement(root, 'Override')
            override.set('PartName', comments_override)
            override.set('ContentType', 'application/vnd.openxmlformats-officedocument.wordprocessingml.comments+xml')
        
        with open(content_types_path, 'wb') as f:
            tree.write(f, xml_declaration=True, encoding='UTF-8', standalone='yes')
    
    def _update_document_rels(self, rels_path: str):
        """Add comments relationship."""
        if not os.path.exists(rels_path):
            return
        
        tree = etree.parse(rels_path)
        root = tree.getroot()
        
        max_id = 0
        for elem in root:
            rel_id = elem.get('Id', '')
            if rel_id.startswith('rId'):
                try:
                    num = int(rel_id[3:])
                    max_id = max(max_id, num)
                except:
                    pass
        
        new_id = f'rId{max_id + 1}'
        
        exists = False
        for elem in root:
            target = elem.get('Target', '')
            if 'comments.xml' in target:
                exists = True
                break
        
        if not exists:
            rel = etree.SubElement(root, 'Relationship')
            rel.set('Id', new_id)
            rel.set('Type', 'http://schemas.openxmlformats.org/officeDocument/2006/relationships/comments')
            rel.set('Target', 'comments.xml')
        
        with open(rels_path, 'wb') as f:
            tree.write(f, xml_declaration=True, encoding='UTF-8', standalone='yes')
    
    def _enable_track_changes(self, settings_path: str):
        """Enable track changes in document settings."""
        tree = etree.parse(settings_path)
        root = tree.getroot()
        
        track_revisions = root.find('.//' + W + 'trackRevisions')
        if track_revisions is None:
            track_revisions = etree.SubElement(root, W + 'trackRevisions')
        
        with open(settings_path, 'wb') as f:
            tree.write(f, xml_declaration=True, encoding='UTF-8', standalone='yes')