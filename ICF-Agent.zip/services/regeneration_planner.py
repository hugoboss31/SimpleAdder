"""
Regeneration Planner - Builds deterministic Change Plan from learning artifacts (Story 827605).
Queries icf_learning_artifacts, filters by scope, outputs plannedChanges with evidenceChunkIds.
"""

import os
import json
from typing import Dict, Any, List, Optional
from datetime import datetime

from config import Config
from services.app_insights import get_logger, track_event, track_exception

try:
    from azure.search.documents import SearchClient
    from azure.search.documents.models import VectorizedQuery
    from azure.core.credentials import AzureKeyCredential
    AZURE_SEARCH_AVAILABLE = True
except ImportError:
    AZURE_SEARCH_AVAILABLE = False


def _get_publishing_rules() -> Dict[str, Any]:
    import os
    max_diff = os.getenv("MAX_DIFF_PERCENT", "5")
    max_sections = os.getenv("MAX_SECTIONS_CHANGED", "10")
    return {
        "maxDiffPercent": float(max_diff),
        "maxSectionsChanged": int(max_sections),
    }


class RegenerationPlanner:
    """
    Converts learned intents/instructions from Azure AI Search into a
    deterministic, bounded, evidence-aware Regeneration Change Plan.
    """

    def __init__(self, country: str):
        self.country = country.lower().replace(" ", "-").replace("_", "-")
        self.index_name = f"icf-learning-artifacts-{self.country}"
        self.logger = get_logger("regeneration_planner")
        self._search_client = None
        self._init_search_client()

    def _init_search_client(self) -> None:
        if not AZURE_SEARCH_AVAILABLE:
            return
        try:
            self._search_client = SearchClient(
                endpoint=Config.get_search_endpoint(),
                index_name=self.index_name,
                credential=Config.get_search_credential(),
            )
        except Exception as e:
            self.logger.warning(f"Search client init failed: {e}")

    def generate_plan(
        self,
        icf_case_id: str,
        base_version_no: int,
        planned_version_no: int,
        allowed_sections: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """
        Generate Regeneration Change Plan from learning artifacts.

        Returns plan dict with plannedChanges, rejectedCandidates, summary, constraints.
        """
        constraints = _get_publishing_rules()
        plan = {
            "icfCaseId": icf_case_id,
            "baseVersionNo": base_version_no,
            "plannedVersionNo": planned_version_no,
            "constraints": constraints,
            "plannedChanges": [],
            "rejectedCandidates": [],
            "summary": {
                "totalCandidates": 0,
                "approvedChanges": 0,
                "rejectedChanges": 0,
                "estimatedDiffPercent": 0.0,
                "estimatedSectionsChanged": 0,
            },
        }

        if not self._search_client:
            self.logger.warning("Search client not available")
            return plan

        try:
            # Query: icf_case_id eq X and is_superseded eq false
            filter_expr = f"icf_case_id eq '{icf_case_id}' and is_superseded eq false"
            results = self._search_client.search(
                search_text="*",
                filter=filter_expr,
                select=["id", "section_type", "ai_output", "human_output", "intent", "confidence", "priority", "evidence_ids"],
                top=100,
            )

            candidates = list(results)
            plan["summary"]["totalCandidates"] = len(candidates)

            planned = []
            rejected = []
            sections_set = set()

            for i, doc in enumerate(candidates):
                section_key = doc.get("section_type", "unknown")
                if allowed_sections and section_key not in allowed_sections:
                    rejected.append({
                        "sourceArtifactId": doc.get("id", f"art-{i}"),
                        "reason": "Section not in allowed scope",
                    })
                    continue

                evidence_ids = doc.get("evidence_ids") or []
                if not evidence_ids:
                    rejected.append({
                        "sourceArtifactId": doc.get("id", f"art-{i}"),
                        "reason": "No evidence chunk IDs",
                    })
                    continue

                confidence = doc.get("confidence") or 0.0
                if confidence < 0.6:
                    rejected.append({
                        "sourceArtifactId": doc.get("id", f"art-{i}"),
                        "reason": "Confidence below threshold",
                    })
                    continue

                change = {
                    "changeId": f"chg-{len(planned) + 1:03d}",
                    "sectionKey": section_key,
                    "changeType": "modify",
                    "changeSource": "LEARNING_ARTIFACT",
                    "intentType": doc.get("intent", "clarify")[:50],
                    "instructionText": (doc.get("human_output") or doc.get("ai_output", ""))[:200],
                    "priority": doc.get("priority", 3),
                    "confidence": confidence,
                    "evidenceRequired": True,
                    "evidenceChunkIds": evidence_ids,
                }
                planned.append(change)
                sections_set.add(section_key)

            plan["plannedChanges"] = planned
            plan["rejectedCandidates"] = rejected
            plan["summary"]["approvedChanges"] = len(planned)
            plan["summary"]["rejectedChanges"] = len(rejected)
            plan["summary"]["estimatedSectionsChanged"] = len(sections_set)
            # Rough diff estimate: assume ~50 words per change
            total_words = len(planned) * 50
            plan["summary"]["estimatedDiffPercent"] = round(min(total_words / 5000 * 100, 100.0), 2)

            track_event("RegenerationPlanGenerated", {
                "icf_case_id": icf_case_id,
                "approved": str(len(planned)),
                "rejected": str(len(rejected)),
                "sections": str(len(sections_set)),
            })

        except Exception as e:
            self.logger.error(f"Plan generation failed: {e}")
            track_exception(e, {"pipeline": "regeneration_planner"})

        return plan

    def upload_plan(
        self,
        plan: Dict[str, Any],
        icf_case_id: str,
        planned_version_no: int,
    ) -> Optional[str]:
        """Upload plan JSON to Blob: cases/{icfCaseId}/artifacts/regen_plan_v{plannedVersionNo}.json"""
        try:
            from azure.storage.blob import BlobServiceClient, ContentSettings
        except ImportError:
            return None

        conn_str = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
        container = os.getenv("AZURE_STORAGE_CONTAINER_NAME", "icf-country-dev")
        if not conn_str:
            return None

        blob_path = f"cases/{icf_case_id}/artifacts/regen_plan_v{planned_version_no}.json"
        try:
            blob_service = BlobServiceClient.from_connection_string(conn_str)
            blob_client = blob_service.get_blob_client(container=container, blob=blob_path)
            blob_client.upload_blob(
                json.dumps(plan, indent=2, default=str),
                overwrite=True,
                content_settings=ContentSettings(content_type="application/json"),
            )
            self.logger.info(f"  ✓ Uploaded regeneration plan: {blob_path}")
            return blob_client.url
        except Exception as e:
            self.logger.error(f"Plan upload failed: {e}")
            return None
