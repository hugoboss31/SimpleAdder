"""
Deterministic parser for track changes and comments in reviewed DOCX files.
Uses python-docx for base document access and lxml for revision markup.
"""

import zipfile
from typing import Dict, List, Optional, Any

from docx import Document

try:
    from lxml import etree
    LXML_AVAILABLE = True
except ImportError:
    LXML_AVAILABLE = False

from models.models import AGENT_AUTHORS
from services.comment_extractor import CommentExtractor
from services.reviewed_section_parser import SectionParser

W_NS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
W = "{" + W_NS + "}"


class DeterministicReviewParser:
    """Deterministic extraction of track changes and comments."""

    def __init__(self):
        self.comment_extractor = CommentExtractor()
        self.section_parser = SectionParser()

    def parse_reviewed_docx(
        self,
        docx_path: str,
        doc_tree: Optional[Any] = None,
        section_map: Optional[Dict[int, Dict[str, str]]] = None,
        include_agent_changes: bool = False,
        include_agent_comments: bool = False
    ) -> Dict[str, List[Dict[str, Any]]]:
        """
        Parse reviewed DOCX into normalized JSON with track changes and comments.

        Args:
            docx_path: Path to reviewed DOCX
            doc_tree: Optional DocumentTree (pre-parsed)
            section_map: Optional paragraph_index -> {section_id, section_title}
            include_agent_changes: Include agent track changes if True
            include_agent_comments: Include agent comments if True

        Returns:
            Dict with trackChanges and comments arrays
        """
        self._ensure_doc_access(docx_path)

        if section_map is None:
            if doc_tree is None:
                try:
                    doc_tree = self.section_parser.parse_reviewed_document(docx_path)
                except Exception:
                    doc_tree = None

            if doc_tree is not None:
                section_map = self.section_parser.build_paragraph_to_section_map(doc_tree)

        track_changes = self._parse_track_changes(
            docx_path,
            section_map=section_map,
            include_agent_changes=include_agent_changes
        )
        comments = self._parse_comments(
            docx_path,
            section_map=section_map,
            include_agent_comments=include_agent_comments
        )

        return {
            "trackChanges": track_changes,
            "comments": comments
        }

    def _ensure_doc_access(self, docx_path: str) -> None:
        """Open document via python-docx to verify access."""
        try:
            Document(docx_path)
        except Exception:
            pass

    def _parse_comments(
        self,
        docx_path: str,
        section_map: Optional[Dict[int, Dict[str, str]]] = None,
        include_agent_comments: bool = False
    ) -> List[Dict[str, Any]]:
        """Parse comments with author/date/anchor text and section mapping."""
        comments = self.comment_extractor.extract_comments(docx_path)

        if not include_agent_comments:
            comments = [c for c in comments if c.is_client]

        if section_map:
            comments = self.comment_extractor.link_comments_to_sections(comments, section_map)

        normalized = []
        for comment in comments:
            normalized.append({
                "text": comment.text or "",
                "sectionKey": comment.section_id or "",
                "priorityHint": self._infer_priority(comment.text or ""),
                "author": comment.author or "",
                "date": comment.date or "",
                "anchorText": comment.linked_text or ""
            })

        return normalized

    def _parse_track_changes(
        self,
        docx_path: str,
        section_map: Optional[Dict[int, Dict[str, str]]] = None,
        include_agent_changes: bool = False
    ) -> List[Dict[str, Any]]:
        """Parse track changes from document.xml using OpenXML."""
        if not LXML_AVAILABLE:
            return []

        changes: List[Dict[str, Any]] = []

        try:
            with zipfile.ZipFile(docx_path, "r") as zf:
                if "word/document.xml" not in zf.namelist():
                    return changes

                with zf.open("word/document.xml") as f:
                    tree = etree.parse(f)
                    root = tree.getroot()
        except Exception:
            return changes

        paragraphs = list(root.iter(W + "p"))
        for para_idx, para in enumerate(paragraphs):
            section_key = self._resolve_section_key(section_map, para_idx)

            for ins in para.iter(W + "ins"):
                text = self._get_element_text(ins)
                if not text.strip():
                    continue

                author = ins.get(W + "author", "Unknown")
                if (not include_agent_changes) and author in AGENT_AUTHORS:
                    continue

                changes.append({
                    "type": "insert",
                    "before": "",
                    "after": text,
                    "sectionKey": section_key
                })

            for dele in para.iter(W + "del"):
                text = self._get_del_text(dele)
                if not text.strip():
                    continue

                author = dele.get(W + "author", "Unknown")
                if (not include_agent_changes) and author in AGENT_AUTHORS:
                    continue

                changes.append({
                    "type": "delete",
                    "before": text,
                    "after": "",
                    "sectionKey": section_key
                })

        return changes

    def _resolve_section_key(
        self,
        section_map: Optional[Dict[int, Dict[str, str]]],
        para_idx: int
    ) -> str:
        """Resolve section_id for a paragraph index using start indices."""
        if not section_map:
            return ""

        best_start = -1
        best_section = None

        for start_idx, section_info in section_map.items():
            if start_idx <= para_idx and start_idx > best_start:
                best_start = start_idx
                best_section = section_info

        if best_section is None:
            return ""

        if isinstance(best_section, dict):
            return best_section.get("section_id", "") or ""

        if isinstance(best_section, str):
            return best_section

        return ""

    def _get_element_text(self, elem) -> str:
        texts = []
        for t in elem.iter(W + "t"):
            if t.text:
                texts.append(t.text)
        return "".join(texts)

    def _get_del_text(self, elem) -> str:
        texts = []
        for t in elem.iter(W + "delText"):
            if t.text:
                texts.append(t.text)
        return "".join(texts)

    def _infer_priority(self, text: str) -> int:
        """Deterministic priority hint based on keywords."""
        lowered = text.lower()

        high_keywords = ["urgent", "immediately", "critical", "must", "required", "mandatory"]
        medium_keywords = ["should", "please", "consider", "recommend"]

        if any(k in lowered for k in high_keywords):
            return 5
        if any(k in lowered for k in medium_keywords):
            return 4
        return 3
