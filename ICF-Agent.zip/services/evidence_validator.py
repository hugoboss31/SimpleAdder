"""
Evidence Validator Agent - Anti-hallucination gate (Story 827628).
Validates proposed changes have evidenceChunkIds, retrievable, relevance >= threshold.
Produces evidence_report.json for audit.
"""

import os
import json
from datetime import datetime
from typing import Dict, Any, List, Optional

from services.app_insights import get_logger, track_event, track_exception


class EvidenceValidatorAgent:
    """
    Enforces evidence-first regeneration.
    Rejects changes without evidence or below relevance threshold.
    """

    def __init__(self, country: str = "usa"):
        self.country = country.lower().replace(" ", "-").replace("_", "-")
        self.logger = get_logger("evidence_validator")

    def validate(
        self,
        proposed_changes: List[Dict[str, Any]],
        min_relevance: float = 0.70,
        allowed_sources: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """
        Validate proposed changes have evidence.
        Returns: validatedCount, rejectedCount, noEvidenceCount, avgRelevance, rejectedReasons, validatedChanges, rejectedChanges.
        """
        allowed_sources = allowed_sources or ["icf_country_cp", "icf_country_regulatory", "icf_learning_artifacts"]
        validated: List[Dict[str, Any]] = []
        rejected: List[Dict[str, Any]] = []
        rejected_reasons: List[str] = []
        relevances: List[float] = []
        no_evidence_count = 0

        for ch in proposed_changes:
            evidence_ids = ch.get("evidenceChunkIds") or ch.get("evidence_ids") or []
            if not evidence_ids:
                no_evidence_count += 1
                rejected.append(ch)
                rejected_reasons.append("NO_EVIDENCE")
                continue

            sources = ch.get("evidenceSources") or ch.get("evidence_sources") or []
            if sources and not all(src in allowed_sources for src in sources):
                rejected.append(ch)
                rejected_reasons.append("SOURCE_NOT_ALLOWED")
                continue

            rel = ch.get("evidence_relevance", ch.get("evidenceRelevance", 0.0))
            if rel < min_relevance:
                rejected.append(ch)
                rejected_reasons.append("RELEVANCE_BELOW_THRESHOLD")
                continue
            if rel:
                relevances.append(rel)

            validated.append(ch)

        avg_relevance = sum(relevances) / len(relevances) if relevances else 0.0

        report = {
            "validatedCount": len(validated),
            "rejectedCount": len(rejected),
            "noEvidenceCount": no_evidence_count,
            "avgRelevance": round(avg_relevance, 2),
            "rejectedReasons": rejected_reasons,
            "validatedChanges": [
                {
                    "changeId": c.get("changeId"),
                    "sectionKey": c.get("sectionKey") or c.get("sectionId"),
                    "sectionTitle": c.get("sectionTitle"),
                    "evidenceChunkIds": c.get("evidenceChunkIds") or c.get("evidence_ids") or [],
                    "evidenceRelevance": round(c.get("evidence_relevance", c.get("evidenceRelevance", 0.0)), 4),
                }
                for c in validated
            ],
            "rejectedChanges": [
                {
                    "changeId": c.get("changeId"),
                    "sectionKey": c.get("sectionKey") or c.get("sectionId"),
                    "sectionTitle": c.get("sectionTitle"),
                    "reason": r,
                }
                for c, r in zip(rejected, rejected_reasons)
            ],
            "generatedAt": datetime.utcnow().isoformat(),
        }

        track_event("EvidenceValidationCompleted", {
            "validated": str(len(validated)),
            "rejected": str(len(rejected)),
            "noEvidence": str(no_evidence_count),
        })

        return report

    def upload_report(
        self,
        report: Dict[str, Any],
        icf_case_id: str,
        version_no: int,
    ) -> Optional[str]:
        """Upload evidence_report.json to Blob."""
        try:
            from azure.storage.blob import BlobServiceClient, ContentSettings
        except ImportError:
            return None

        conn_str = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
        container = os.getenv("AZURE_STORAGE_CONTAINER_NAME", "icf-country-dev")
        if not conn_str:
            return None

        base_path = f"cases/{icf_case_id}/versions/v{version_no}"
        uploads: Dict[str, str] = {}
        try:
            blob_service = BlobServiceClient.from_connection_string(conn_str)
            for filename, payload in [
                ("evidence_validation.json", report),
                ("validated_changes.json", report.get("validatedChanges", [])),
                ("rejected_changes.json", report.get("rejectedChanges", [])),
            ]:
                blob_path = f"{base_path}/{filename}"
                blob_client = blob_service.get_blob_client(container=container, blob=blob_path)
                blob_client.upload_blob(
                    json.dumps(payload, indent=2, default=str),
                    overwrite=True,
                    content_settings=ContentSettings(content_type="application/json"),
                )
                uploads[filename] = blob_client.url
                self.logger.info(f"  ✓ Uploaded evidence artifact: {blob_path}")
            report["artifactUrls"] = uploads
            return uploads.get("evidence_validation.json")
        except Exception as e:
            self.logger.error(f"Evidence report upload failed: {e}")
            return None
