"""
QA Knowledge Loader.
Loads checklist documents from Azure Blob for QA Agent verification.
Also supports Azure AI Search querying with doctypeid filtering.
Parses Word documents from knowledge_base/{country}/ into QARequirementRecords.
"""

import os
import re
from typing import List, Dict, Optional, Iterable, Tuple
from dataclasses import dataclass, field
from io import BytesIO

from azure.storage.blob import BlobServiceClient
from azure.search.documents import SearchClient
from azure.search.documents.models import VectorizedQuery
from azure.core.credentials import AzureKeyCredential
from docx import Document
from openai import AzureOpenAI
from dotenv import load_dotenv
from config import Config

load_dotenv()


@dataclass
class QARequirementRecord:
    """Represents a single checklist requirement for QA verification."""
    req_id: str
    checklist_type: str
    category: str
    requirement_text: str
    expected_clause: str = ""
    source_index: str = ""
    regulation_ref: str = ""
    scope_tags: List[str] = field(default_factory=list)
    severity: str = "required"
    status: str = "pending"
    evidence: str = ""
    embedding: Optional[List[float]] = None


class QAKnowledgeLoader:
    """
    Loads and parses QA checklists from Azure Blob storage.
    Also queries Azure AI Search with doctypeid filtering.
    Uses doctypeid for filtering: 1 = ICF, 4 = Review Checklist (RC)
    Searches in knowledge_base/{country}/ for files with 'checklist' in the name.
    Extracts table-based requirements into structured QARequirementRecords.
    """
    
    # Document Type IDs (matches database)
    DOCTYPE_ICF = 1       # ICF - Informed Consent Form
    DOCTYPE_CHECKLIST = 4 # RC - Review Checklist
    
    REGULATION_PATTERNS = [
        r'\[([^\]]+)\]',
        r'(\d+\s*CFR\s*[\d\.]+(?:\([a-z0-9]+\))?)',
        r'(ICH\s*(?:E6|GCP)\s*[\d\.]+)',
        r'((?:Article|Section)\s*\d+[\.\d]*)',
    ]
    
    def __init__(self, country: str, index_names: Optional[List[str]] = None):
        """
        Initialize QA Knowledge Loader for a specific country.
        
        Args:
            country: Country code (e.g., 'usa', 'canada', 'uk')
        """
        self.country = country.lower().replace(' ', '-').replace('_', '-')
        self.index_name = f"icf-index-{self.country}"
        self.index_names = index_names or [self.index_name]
        self.blob_service_client = None
        self.container_name = os.getenv("AZURE_STORAGE_CONTAINER_NAME", "icf-country-dev")
        self._search_clients: List[Tuple[str, SearchClient]] = []
        self.search_client: Optional[SearchClient] = None
        
        # Initialize Azure OpenAI for embeddings
        self.openai = AzureOpenAI(
            api_key=os.getenv("AZURE_OPENAI_API_KEY"),
            api_version=os.getenv("AZURE_OPENAI_API_VERSION"),
            azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT")
        )
        self.embedding_model = os.getenv("EMBEDDINGS_MODEL_DEPLOYMENT")
        
        # Azure AI Search clients are created lazily in _iter_search_clients()
        
        self._init_blob_client()

    def _iter_search_clients(self) -> Iterable[Tuple[str, SearchClient]]:
        """Iterate over all configured Azure AI Search clients (multi-index)."""
        if self._search_clients:
            for item in self._search_clients:
                yield item
            return

        try:
            endpoint = Config.get_search_endpoint()
            credential = Config.get_search_credential()
        except Exception:
            return

        for idx_name in self.index_names:
            try:
                client = SearchClient(
                    endpoint=endpoint,
                    index_name=idx_name,
                    credential=credential,
                )
                self._search_clients.append((idx_name, client))
                if idx_name == self.index_name and self.search_client is None:
                    self.search_client = client
            except Exception:
                continue

        for item in self._search_clients:
            yield item
        
    def _init_blob_client(self):
        """Initialize Azure Blob Storage client."""
        connection_string = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
        if connection_string:
            self.blob_service_client = BlobServiceClient.from_connection_string(connection_string)
            print(f"✅ QA Knowledge Loader initialized for {self.country.upper()} (Index: {self.index_name})")
        else:
            print("⚠️ QA Knowledge Loader: No Azure connection string found")
    
    def _get_blob_prefix(self) -> str:
        """Get blob storage prefix for this country (using original folder name)."""
        try:
            from services.indexer import MultiCountryIndexer
            indexer = MultiCountryIndexer()
            mapping = indexer.get_country_mapping()
            original_folder = mapping.get(self.country, self.country)
            return f"knowledge_base/{original_folder}/"
        except:
            return f"knowledge_base/{self.country}/"

    def _get_blob_prefixes(self) -> List[str]:
        """Get all candidate blob prefixes for this country."""
        prefixes = []
        primary = self._get_blob_prefix()
        raw_country = self.country.replace("-", " ")
        variants = {
            raw_country.lower().replace(" ", "-"),
            raw_country.upper().replace(" ", "-"),
            raw_country.title().replace(" ", "-"),
            raw_country.lower().replace(" ", ""),
            raw_country.upper().replace(" ", ""),
        }

        source = os.getenv("QA_CHECKLIST_BLOB_ROOT", "both").strip().lower()
        if source in ("feedbacks", "feedback"):
            for v in variants:
                prefixes.append(f"feedbacks/{v}/")
        elif source in ("knowledge_base", "kb"):
            prefixes.append(primary)
            for v in variants:
                prefixes.append(f"knowledge_base/{v}/")
        else:
            for v in variants:
                prefixes.append(f"feedbacks/{v}/")
            prefixes.append(primary)
            for v in variants:
                prefixes.append(f"knowledge_base/{v}/")

        seen = set()
        deduped = []
        for p in prefixes:
            if p not in seen:
                seen.add(p)
                deduped.append(p)
        return deduped
    
    def _embed(self, text: str) -> List[float]:
        """Generate embedding for text with caching."""
        from utils import cache
        
        cached = cache.get_embedding(text)
        if cached:
            return cached
        
        try:
            resp = self.openai.embeddings.create(model=self.embedding_model, input=text[:8000])
            embedding = resp.data[0].embedding
            cache.set_embedding(text, embedding)
            return embedding
        except Exception as e:
            print(f"⚠️ Embedding error: {e}")
            return [0.0] * 1536

    # =========================================================================
    # AZURE AI SEARCH QUERIES (uses doctypeid)
    # =========================================================================
    
    def query(self, query_text: str, top_k: int = 10, filter_expr: str = None) -> List[Dict]:
        """
        Query Azure AI Search for QA requirements using hybrid search.
        Filters by doctypeid = 1 (ICF) OR doctypeid = 4 (Review Checklist).
        
        Args:
            query_text: The search query
            top_k: Number of results to return
            filter_expr: Optional additional OData filter expression
        """
        aggregated: List[Dict] = []
        try:
            vector_query = VectorizedQuery(
                vector=self._embed(query_text),
                k_nearest_neighbors=top_k,
                fields="contentVector",
            )

            base_filter = f"(doctypeid eq {self.DOCTYPE_ICF} or doctypeid eq {self.DOCTYPE_CHECKLIST})"
            if filter_expr:
                base_filter = f"({base_filter}) and ({filter_expr})"

            for idx_name, client in self._iter_search_clients():
                try:
                    results = client.search(
                        search_text=query_text,
                        vector_queries=[vector_query],
                        top=top_k,
                        filter=base_filter,
                        select=[
                            "id",
                            "content",
                            "topic",
                            "section_type",
                            "is_required",
                            "source_file",
                            "doctypeid",
                            "countryid",
                        ],
                    )
                    for r in results:
                        aggregated.append({
                            "id": r.get("id", ""),
                            "content": r.get("content", ""),
                            "topic": r.get("topic", ""),
                            "section_type": r.get("section_type", ""),
                            "is_required": r.get("is_required", False),
                            "source_file": r.get("source_file", ""),
                            "doctypeid": r.get("doctypeid", 0),
                            "countryid": r.get("countryid", 0),
                            "score": r.get("@search.score", 0.0),
                            "source_index": idx_name,
                        })
                except Exception:
                    continue
        except Exception as e:
            print(f"⚠️ Query error: {e}")
            return []

        return aggregated
    
    def query_checklist(self, query_text: str, top_k: int = 10) -> List[Dict]:
        """Query checklist requirements from Azure AI Search (for QA Agent)."""
        return self.query(query_text, top_k=top_k)
    
    def query_by_topic(self, topic: str, top_k: int = 10) -> List[Dict]:
        """Query checklist requirements by topic name."""
        filter_expr = f"topic eq '{topic}'"
        return self.query(topic, top_k=top_k, filter_expr=filter_expr)
    
    def get_indexed_document_count(self, doctypeid: Optional[int] = None) -> int:
        """Get count of QA-relevant documents in Azure AI Search index."""
        total = 0
        if doctypeid:
            filter_expr = f"doctypeid eq {doctypeid}"
        else:
            filter_expr = f"(doctypeid eq {self.DOCTYPE_ICF} or doctypeid eq {self.DOCTYPE_CHECKLIST})"

        try:
            for _idx_name, client in self._iter_search_clients():
                try:
                    results = client.search("*", top=0, include_total_count=True, filter=filter_expr)
                    total += results.get_count() or 0
                except Exception:
                    continue
        except Exception:
            return 0
        return total
    
    def get_all_indexed_requirements(self) -> List[Dict]:
        """Get all indexed QA requirements from Azure AI Search."""
        aggregated: List[Dict] = []
        seen: set = set()
        filter_expr = f"(doctypeid eq {self.DOCTYPE_ICF} or doctypeid eq {self.DOCTYPE_CHECKLIST})"
        try:
            for idx_name, client in self._iter_search_clients():
                try:
                    results = client.search(
                        "*",
                        top=1000,
                        filter=filter_expr,
                        select=[
                            "id",
                            "content",
                            "topic",
                            "section_type",
                            "is_required",
                            "source_file",
                            "doctypeid",
                            "countryid",
                        ],
                    )
                    for r in results:
                        doc = dict(r)
                        doc["source_index"] = idx_name
                        key = (idx_name, doc.get("id"))
                        if key in seen:
                            continue
                        seen.add(key)
                        aggregated.append(doc)
                except Exception:
                    continue
        except Exception:
            return []
        return aggregated

    # =========================================================================
    # BLOB STORAGE PARSING (existing functionality)
    # =========================================================================
    
    def _is_checklist_file(self, filename: str) -> bool:
        """Check if file is a checklist document (case-insensitive)."""
        filename_lower = filename.lower()
        return "checklist" in filename_lower or "review" in filename_lower
    
    def load_checklists_from_blob(self) -> List[QARequirementRecord]:
        """
        Load all checklist documents from Azure Blob for this country.
        Searches for .docx files with 'checklist' or 'review' in the name.
        
        Returns:
            Combined list of QARequirementRecords from all checklists
        """
        all_requirements = []
        
        if not self.blob_service_client:
            print("⚠️ No blob client available")
            return []
        
        try:
            container_client = self.blob_service_client.get_container_client(self.container_name)
            checklist_files = []
            for blob_prefix in self._get_blob_prefixes():
                print(f"🔍 Searching for checklists in: {self.container_name}/{blob_prefix}")
                for blob in container_client.list_blobs(name_starts_with=blob_prefix):
                    filename = blob.name.split("/")[-1]
                    if not filename.endswith('.docx'):
                        continue
                    if self._is_checklist_file(filename):
                        checklist_files.append(blob.name)
                        print(f"  📄 Found checklist: {filename}")
                if checklist_files:
                    break

            if not checklist_files:
                print(f"⚠️ No checklist files found for {self.country.upper()}")
                return []
            
            for blob_path in checklist_files:
                filename = blob_path.split("/")[-1]
                checklist_type = self._infer_checklist_type(filename)
                
                reqs = self._load_and_parse_checklist(blob_path, checklist_type)
                all_requirements.extend(reqs)
                print(f"✅ Loaded {len(reqs)} requirements from {filename}")
                
        except Exception as e:
            print(f"⚠️ Error loading checklists: {e}")
        
        print(f"✅ Total: {len(all_requirements)} QA requirements loaded for {self.country.upper()}")
        return all_requirements
    
    def _infer_checklist_type(self, filename: str) -> str:
        """Infer checklist type from filename."""
        filename_lower = filename.lower()
        
        if "privacy" in filename_lower or "data" in filename_lower:
            return "DATA_PROTECTION"
        elif "ethics" in filename_lower:
            return "ETHICS"
        elif "regulatory" in filename_lower:
            return "REGULATORY"
        elif "icf" in filename_lower:
            return "ICF_REVIEW"
        else:
            name_part = filename.replace(".docx", "").replace("_", " ").replace("-", " ")
            return name_part.upper()[:20]
    
    def load_checklists_from_local(
        self,
        checklist_paths: List[str] = None
    ) -> List[QARequirementRecord]:
        """
        Load checklists from local file paths.
        
        Args:
            checklist_paths: List of local file paths to checklist documents
            
        Returns:
            Combined list of QARequirementRecords from all checklists
        """
        all_requirements = []
        
        if not checklist_paths:
            local_path = os.path.join("knowledge_base", self.country)
            if os.path.exists(local_path):
                checklist_paths = [
                    os.path.join(local_path, f) 
                    for f in os.listdir(local_path) 
                    if f.endswith('.docx') and self._is_checklist_file(f)
                ]
        
        for path in (checklist_paths or []):
            filename = os.path.basename(path)
            checklist_type = self._infer_checklist_type(filename)
            
            reqs = self._parse_checklist_document(path, checklist_type)
            all_requirements.extend(reqs)
            print(f"✅ Loaded {len(reqs)} requirements from {filename}")
        
        return all_requirements
    
    def _load_and_parse_checklist(
        self,
        blob_path: str,
        checklist_type: str
    ) -> List[QARequirementRecord]:
        """Load checklist from Azure Blob and parse it."""
        if not self.blob_service_client:
            return []
        
        try:
            container_client = self.blob_service_client.get_container_client(self.container_name)
            blob_client = container_client.get_blob_client(blob_path)
            
            blob_data = blob_client.download_blob().readall()
            doc = Document(BytesIO(blob_data))
            
            return self._parse_document_tables(doc, checklist_type)
            
        except Exception as e:
            print(f"⚠️ Error loading {blob_path}: {e}")
            return []
    
    def _parse_checklist_document(
        self,
        file_path: str,
        checklist_type: str
    ) -> List[QARequirementRecord]:
        """Parse checklist from local file path."""
        try:
            doc = Document(file_path)
            return self._parse_document_tables(doc, checklist_type)
        except Exception as e:
            print(f"⚠️ Error parsing {file_path}: {e}")
            return []
    
    def _parse_document_tables(
        self,
        doc: Document,
        checklist_type: str
    ) -> List[QARequirementRecord]:
        """
        Parse Word document tables into QARequirementRecords.
        Handles various table formats.
        """
        requirements = []
        req_counter = 1
        current_category = "General"
        
        for table in doc.tables:
            for row_idx, row in enumerate(table.rows):
                cells = [cell.text.strip() for cell in row.cells]
                
                if self._is_header_row(cells):
                    header_text = ' '.join(cells)
                    current_category = self._extract_category(header_text)
                    continue
                
                requirement = self._extract_requirement_from_row(
                    cells, checklist_type, current_category, req_counter
                )
                
                if requirement:
                    requirements.append(requirement)
                    req_counter += 1
        
        paragraph_reqs = self._parse_paragraphs(doc, checklist_type, req_counter)
        requirements.extend(paragraph_reqs)
        
        return requirements
    
    def _is_header_row(self, cells: List[str]) -> bool:
        """Check if row is a header row."""
        header_keywords = [
            'acceptable', 'inadequate', 'not acceptable', 'not applicable',
            'implementation', 'criteria', 'review', 'requirement', 'status'
        ]
        combined = ' '.join(cells).lower()
        return any(kw in combined for kw in header_keywords) and len(combined) < 200
    
    def _extract_category(self, header_text: str) -> str:
        """Extract category from header text."""
        category_patterns = [
            ('Core Elements', 'Core Elements'),
            ('Required Statements', 'Required Statements'),
            ('Review Criteria', 'Review Criteria'),
            ('Country', 'Country Specific'),
            ('Site Specific', 'Site Specific'),
            ('Data Protection', 'Data Protection'),
            ('Privacy', 'Privacy'),
            ('Regulatory', 'Regulatory'),
            ('Ethics', 'Ethics'),
            ('Consent', 'Consent Elements'),
        ]
        
        header_lower = header_text.lower()
        for pattern, category in category_patterns:
            if pattern.lower() in header_lower:
                return category
        
        return "General"
    
    def _extract_requirement_from_row(
        self,
        cells: List[str],
        checklist_type: str,
        category: str,
        counter: int
    ) -> Optional[QARequirementRecord]:
        """Extract a single requirement from a table row."""
        if not cells or all(not c for c in cells):
            return None
        
        skip_terms = ['acceptable', 'not acceptable', 'inadequate', 'yes', 'no', 'n/a']
        content_cells = [
            c for c in cells 
            if len(c) > 20 and c.lower() not in skip_terms
        ]
        
        if not content_cells:
            return None
        
        requirement_text = max(content_cells, key=len)
        
        if len(requirement_text) < 15:
            return None
        
        regulation_ref = self._extract_regulation_ref(requirement_text)
        scope_tags = self._generate_scope_tags(requirement_text)
        
        severity = "required"
        if any(word in requirement_text.lower() for word in ['optional', 'may', 'recommended', 'should consider']):
            severity = "recommended"
        
        req_id = f"{checklist_type}-{counter:03d}"
        
        return QARequirementRecord(
            req_id=req_id,
            checklist_type=checklist_type,
            category=category,
            requirement_text=requirement_text,
            expected_clause=requirement_text,
            source_index="blob",
            regulation_ref=regulation_ref,
            scope_tags=scope_tags,
            severity=severity
        )
    
    def _extract_regulation_ref(self, text: str) -> str:
        """Extract regulation references from text."""
        for pattern in self.REGULATION_PATTERNS:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                return match.group(1)
        return ""
    
    def _generate_scope_tags(self, text: str) -> List[str]:
        """Generate scope tags for matching requirements to sections (country-agnostic)."""
        tags = []
        text_lower = text.lower()
        
        tag_patterns = {
            'data_protection': ['privacy', 'confidential', 'data protection', 'personal data', 'personal information'],
            'authorization': ['authorization', 'authorisation', 'permission'],
            'withdrawal': ['withdraw', 'revoke', 'discontinue', 'stop participation'],
            'disclosure': ['disclosure', 'disclose'],
            'consent': ['consent', 'agree', 'signature'],
            'risks': ['risk', 'side effect', 'adverse', 'harm', 'danger'],
            'benefits': ['benefit', 'advantage'],
            'compensation': ['compensation', 'payment', 'reimburse', 'expense'],
            'injury': ['injury', 'harm', 'medical care'],
            'contact': ['contact', 'phone', 'call', 'question', 'emergency'],
            'voluntary': ['voluntary', 'free', 'choice', 'refuse'],
            'purpose': ['purpose', 'objective', 'aim', 'why'],
            'procedures': ['procedure', 'treatment', 'intervention', 'visit'],
            'alternatives': ['alternative', 'other treatment', 'other option'],
            'samples': ['blood', 'sample', 'genetic', 'tissue', 'specimen', 'biobank'],
            'pregnancy': ['pregnant', 'contraception', 'fertility'],
        }
        
        for tag, keywords in tag_patterns.items():
            if any(kw in text_lower for kw in keywords):
                tags.append(tag)
        
        return tags
    
    def _parse_paragraphs(
        self,
        doc: Document,
        checklist_type: str,
        start_counter: int
    ) -> List[QARequirementRecord]:
        """Parse paragraphs for requirements not in tables."""
        requirements = []
        counter = start_counter
        
        for para in doc.paragraphs:
            text = para.text.strip()
            
            if len(text) < 50:
                continue
            
            if text.startswith(('•', '-', '*', '○')) or re.match(r'^\d+[\.\)]\s', text):
                regulation_ref = self._extract_regulation_ref(text)
                scope_tags = self._generate_scope_tags(text)
                
                req_id = f"{checklist_type}-{counter:03d}"
                
                requirements.append(QARequirementRecord(
                    req_id=req_id,
                    checklist_type=checklist_type,
                    category="Document Requirements",
                    requirement_text=text,
                    expected_clause=text,
                    source_index="blob",
                    regulation_ref=regulation_ref,
                    scope_tags=scope_tags,
                    severity="required"
                ))
                counter += 1
        
        return requirements
    
    def get_requirements_by_scope(self, scope_tag: str) -> List[QARequirementRecord]:
        """Get all requirements matching a specific scope tag."""
        all_reqs = self.load_checklists_from_blob()
        return [req for req in all_reqs if scope_tag in req.scope_tags]
    
    def get_requirements_count(self) -> Dict[str, int]:
        """Get count of requirements by checklist type."""
        all_reqs = self.load_checklists_from_blob()
        counts = {}
        for req in all_reqs:
            counts[req.checklist_type] = counts.get(req.checklist_type, 0) + 1
        return counts
    
    def check_sync_status(self) -> Dict:
        """Check status of QA knowledge in Azure AI Search."""
        try:
            total_count = self.get_indexed_document_count()
            icf_count = self.get_indexed_document_count(doctypeid=self.DOCTYPE_ICF)
            rc_count = self.get_indexed_document_count(doctypeid=self.DOCTYPE_CHECKLIST)
            return {
                "country": self.country,
                "index_name": self.index_name,
                "index_names": list(self.index_names),
                "total_qa_documents": total_count,
                "icf_docs": icf_count,
                "checklist_docs": rc_count,
                "is_ready": total_count > 0
            }
        except Exception as e:
            return {"error": str(e)}