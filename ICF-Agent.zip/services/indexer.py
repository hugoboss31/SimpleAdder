"""
Multi-Country Indexer for ICF Knowledge Base.
Creates per-country Azure AI Search indexes from blob storage.
Classifies documents by filename: 'customization' → doctypeid=3, 'checklist' → doctypeid=4.
Supports XLSX, DOCX, PDF extraction using Python libraries (openpyxl, python-docx, pdfplumber).
"""

import os
import re
import hashlib
import json
import time
from typing import List, Dict, Tuple, Optional
from datetime import datetime
from io import BytesIO
from dotenv import load_dotenv

from utils.logger import get_logger

logger = get_logger("indexer")

from azure.storage.blob import BlobServiceClient
from azure.search.documents import SearchClient
from azure.search.documents.indexes import SearchIndexClient
from azure.search.documents.indexes.models import (
    SearchIndex, SearchField, SearchFieldDataType,
    VectorSearch, HnswAlgorithmConfiguration, VectorSearchProfile
)
from azure.core.credentials import AzureKeyCredential
from openai import AzureOpenAI
from config import Config
from services.client_manager import client_manager

import openpyxl
from docx import Document as DocxDocument
import pdfplumber

load_dotenv()


class MultiCountryIndexer:
    """Indexes knowledge base documents for multiple countries."""
    
    SUPPORTED_EXTENSIONS = ('.xlsx', '.xls', '.docx', '.pdf')
    
    SECTION_KEYWORDS = {
        'compensation': ['compensation', 'payment', 'reimburse', 'expense', 'cost'],
        'injury_compensation': ['insurance', 'indemnity', 'liability', 'injury'],
        'data_protection': ['confidential', 'privacy', 'data protection', 'personal data'],
        'contacts': ['contact', 'phone', 'call', 'question', 'emergency'],
        'risks': ['risk', 'side effect', 'adverse', 'discomfort'],
        'benefits': ['benefit', 'advantage'],
        'withdrawal': ['voluntary', 'withdraw', 'refuse', 'stop', 'discontinue'],
        'samples': ['blood', 'sample', 'genetic', 'dna', 'biobank', 'tissue'],
        'pregnancy': ['pregnant', 'contraception', 'birth control', 'fertility'],
        'study_purpose': ['purpose', 'objective', 'aim', 'goal'],
        'procedures': ['procedure', 'treatment', 'intervention', 'visit'],
        'alternatives': ['alternative', 'other treatment', 'other option'],
        'consent': ['consent', 'signature', 'agree', 'authorize'],
    }
    
    # Document Type ID mapping (matches database: id | code | description)
    # 1 = ICF, 2 = CSR, 3 = CP (Customization Plan), 4 = RC (Review Checklist)
    DOCTYPE_ID_MAP = {
        "icf": 1,
        "csr": 2,
        "customization": 3, "customisation": 3, "cp": 3,
        "checklist": 4, "review": 4, "rc": 4,
    }
    
    def __init__(self):
        # Use shared client manager for connection pooling
        self.openai = client_manager.openai_client
        self.embedding_model = os.getenv("EMBEDDINGS_MODEL_DEPLOYMENT")
        self.blob_service = client_manager.blob_service_client
        self.container_name = os.getenv("AZURE_STORAGE_CONTAINER_NAME", "icf-country-dev")
        self.index_client = client_manager.search_index_client
        logger.info("MultiCountryIndexer initialized (using Python extraction libraries with connection pooling)")

    # =========================================================================
    # ID MAPPING HELPERS
    # =========================================================================
    
    def _get_doctypeid(self, filename: str) -> int:
        """Get doctypeid from filename. Default is 3 (Customization Plan)."""
        lower = filename.lower()
        if any(k in lower for k in ['customization', 'customisation']):
            return 3  # CP - Customization Plan
        elif any(k in lower for k in ['checklist', 'review']):
            return 4  # RC - Review Checklist
        elif 'csr' in lower or 'regulatory' in lower:
            return 2  # CSR - Country Specific Regulatory
        elif 'icf' in lower and 'customization' not in lower:
            return 1  # ICF - Informed Consent Form
        return 3  # Default to Customization Plan

    def _get_doc_type_string(self, doctypeid: int) -> str:
        """Map doctypeid to doc_type string for consistency in indexing.
        Ensures the indexed doc_type field matches the doctypeid mapping.
        """
        doctype_mapping = {
            1: "icf",
            2: "regulatory",
            3: "customization",
            4: "checklist"
        }
        return doctype_mapping.get(doctypeid, "customization")

    def _get_countryid(self, country_name: str) -> int:
        """Get countryid from country name. Matches database mapping."""
        mapping = {
            "global": 1,
            "usa": 2,
            "canada": 3,
            "taiwan": 4,
            "argentina": 5,
            "france": 6,
        }
        normalized = country_name.lower().replace(' ', '-').replace('_', '-')
        return mapping.get(normalized, 0)

    # =========================================================================
    # HELPER METHODS
    # =========================================================================    
    
    def _get_index_name(self, country: str) -> str:
        return f"icf-index-{country.lower().replace(' ', '-').replace('_', '-')}"
    
    def _get_search_client(self, country: str) -> SearchClient:
        """Get SearchClient for country-specific index using shared client manager."""
        index_name = self._get_index_name(country)
        return client_manager.get_search_client(index_name)
    
    def _classify_doc_type(self, filename: str) -> str:
        """Legacy: Returns string doc_type for backwards compatibility."""
        lower = filename.lower()
        if any(k in lower for k in ['customization', 'customisation']):
            return 'customization'
        elif any(k in lower for k in ['checklist', 'review']):
            return 'checklist'
        return 'customization'
    
    def _classify_section(self, content: str) -> str:
        lower = content.lower()
        for section, keywords in self.SECTION_KEYWORDS.items():
            if any(kw in lower for kw in keywords):
                return section
        return 'general'
    
    def _sanitize_id(self, doc_id: str) -> str:
        return re.sub(r'[^a-zA-Z0-9_-]', '_', doc_id)[:128]
    
    def _embed(self, text: str) -> List[float]:
        try:
            resp = self.openai.embeddings.create(model=self.embedding_model, input=text[:8000])
            return resp.data[0].embedding
        except Exception as e:
            logger.warning(f"⚠️ Embedding error: {e}")
            return [0.0] * 1536

    # =========================================================================
    # BLOB OPERATIONS
    # =========================================================================
    
    def get_available_countries(self) -> List[str]:
        """Detect countries either under knowledge_base/{country}/ or directly at container root."""

        def _maybe_add_country(folder_name: str):
            normalized = folder_name.lower().replace(' ', '-').replace('_', '-')
            if not normalized or normalized in ["knowledge_base", "cases", "output", "learning", "temp", "temp_blob_downloads"]:
                return
            if self._get_countryid(normalized) > 0:
                countries.add(folder_name)

        countries: set[str] = set()
        try:
            container = self.blob_service.get_container_client(self.container_name)

            # Root layout: {country}/... (e.g., icf-country-dev/usa/...)
            for blob in container.list_blobs():
                parts = blob.name.split("/")
                if not parts:
                    continue
                _maybe_add_country(parts[0])

        except Exception as e:
            logger.warning(f"⚠️ Error discovering countries: {e}")
        return sorted(list(countries))
    
    def get_country_mapping(self) -> Dict[str, str]:
        """Returns mapping of sanitized country name to original blob folder name."""
        mapping = {}
        for country in self.get_available_countries():
            sanitized = country.lower().replace(' ', '-').replace('_', '-')
            mapping[sanitized] = country
        return mapping
    
    def _download_blob(self, blob_path: str) -> bytes:
        return self.blob_service.get_blob_client(self.container_name, blob_path).download_blob().readall()
    
    def _get_manifest_path(self, country: str) -> str:
        return f"knowledge_base/{country}/.manifest.json"
    
    def _get_blob_files(self, country: str) -> Dict[str, Dict]:
        """Get current files and their hashes from blob."""
        files = {}
        container = self.blob_service.get_container_client(self.container_name)
        
        for blob in container.list_blobs(name_starts_with=f"knowledge_base/{country}/"):
            filename = blob.name.split("/")[-1]
            if not filename or not filename.endswith(self.SUPPORTED_EXTENSIONS):
                continue
            
            file_bytes = self._download_blob(blob.name)
            files[filename] = {
                "hash": hashlib.md5(file_bytes).hexdigest(),
                "blob_path": blob.name,
                "size": len(file_bytes)
            }
        return files
    
    def _get_stored_manifest(self, country: str) -> Dict:
        """Get stored manifest from blob."""
        try:
            manifest_path = self._get_manifest_path(country)
            data = self._download_blob(manifest_path)
            return json.loads(data.decode('utf-8'))
        except:
            return {}
    
    def _store_manifest(self, country: str, manifest: Dict):
        """Store manifest in blob."""
        try:
            manifest_path = self._get_manifest_path(country)
            blob_client = self.blob_service.get_blob_client(self.container_name, manifest_path)
            blob_client.upload_blob(json.dumps(manifest, indent=2), overwrite=True)
            logger.info(f"  ✅ Stored manifest for {country}")
        except Exception as e:
            logger.warning(f"  ⚠️ Error storing manifest: {e}")

    # =========================================================================
    # INDEX OPERATIONS
    # =========================================================================
    
    def _create_index(self, country: str) -> str:
        index_name = self._get_index_name(country)
        try:
            self.index_client.get_index(index_name)
            logger.info(f"  ✅ Index '{index_name}' exists")
            return index_name
        except:
            pass
        
        fields = [
            SearchField(name="id", type=SearchFieldDataType.String, key=True),
            SearchField(name="content", type=SearchFieldDataType.String, searchable=True),
            SearchField(name="contentVector", type=SearchFieldDataType.Collection(SearchFieldDataType.Single),
                        searchable=True, vector_search_dimensions=1536, vector_search_profile_name="vector-profile"),
            # NEW: Integer IDs (primary)
            SearchField(name="countryid", type=SearchFieldDataType.Int32, filterable=True, sortable=True),
            SearchField(name="doctypeid", type=SearchFieldDataType.Int32, filterable=True, sortable=True),
            # Legacy: String fields (kept for backwards compatibility)
            SearchField(name="country_code", type=SearchFieldDataType.String, filterable=True),
            SearchField(name="doc_type", type=SearchFieldDataType.String, filterable=True),
            # Other fields
            SearchField(name="topic", type=SearchFieldDataType.String, filterable=True, searchable=True),
            SearchField(name="section_type", type=SearchFieldDataType.String, filterable=True),
            SearchField(name="source_file", type=SearchFieldDataType.String, filterable=True),
            SearchField(name="sheet_name", type=SearchFieldDataType.String, filterable=True),
            SearchField(name="is_required", type=SearchFieldDataType.Boolean, filterable=True),
        ]
        
        index = SearchIndex(
            name=index_name, 
            fields=fields,
            vector_search=VectorSearch(
                algorithms=[HnswAlgorithmConfiguration(name="hnsw-algo")],
                profiles=[VectorSearchProfile(name="vector-profile", algorithm_configuration_name="hnsw-algo")]
            )
        )
        self.index_client.create_index(index)
        logger.info(f"  ✅ Created index '{index_name}'")
        return index_name
    
    def delete_index(self, country: str) -> bool:
        """Delete index for a country (useful for schema changes)."""
        index_name = self._get_index_name(country)
        try:
            self.index_client.delete_index(index_name)
            logger.info(f"  🗑️ Deleted index '{index_name}'")
            return True
        except Exception as e:
            logger.warning(f"  ⚠️ Could not delete index: {e}")
            return False

    # =========================================================================
    # DOCUMENT EXTRACTION (Python Libraries)
    # =========================================================================
    
    def _extract_xlsx(self, file_bytes: bytes, filename: str) -> List[Dict]:
        """Extract content from XLSX using openpyxl."""
        extracted = []
        try:
            wb = openpyxl.load_workbook(BytesIO(file_bytes), data_only=True)
            
            for sheet_name in wb.sheetnames:
                ws = wb[sheet_name]
                logger.info(f"      📊 Sheet: {sheet_name} ({ws.max_row} rows)")
                
                current_topic = None
                for row in ws.iter_rows(max_row=500):
                    if len(row) < 2:
                        continue
                    
                    col_a = str(row[0].value or "").strip()
                    col_b = str(row[1].value or "").strip()
                    
                    if not col_a and not col_b:
                        continue
                    
                    skip_headers = ["ICF = Informed Consent Form", "PIS = Patient Information Sheet"]
                    if any(h in col_a or h in col_b for h in skip_headers):
                        continue
                    
                    if col_a.lower() in ["usa", "canada", "argentina", "united states"]:
                        continue
                    
                    if col_a and col_a.lower() not in ["nan", "none"] and len(col_a) < 200:
                        current_topic = col_a
                    
                    if col_b and col_b.lower() not in ["nan", "none"] and len(col_b) > 5:
                        extracted.append({
                            "topic": current_topic or "General",
                            "content": col_b,
                            "sheet_name": sheet_name
                        })
                    elif col_a and not col_b and len(col_a) > 50:
                        extracted.append({
                            "topic": "General",
                            "content": col_a,
                            "sheet_name": sheet_name
                        })
            
            wb.close()
        except Exception as e:
            logger.warning(f"      ⚠️ XLSX extraction error: {e}")
        
        return extracted
    
    def _extract_docx(self, file_bytes: bytes, filename: str) -> List[Dict]:
        """Extract content from DOCX using python-docx."""
        extracted = []
        try:
            doc = DocxDocument(BytesIO(file_bytes))
            
            current_heading = "General"
            content_buffer = []
            
            for para in doc.paragraphs:
                text = para.text.strip()
                if not text:
                    continue
                
                if para.style and para.style.name.startswith('Heading'):
                    if content_buffer:
                        combined = " ".join(content_buffer)
                        if len(combined) > 10:
                            extracted.append({
                                "topic": current_heading,
                                "content": combined,
                                "sheet_name": "Document"
                            })
                        content_buffer = []
                    current_heading = text
                else:
                    content_buffer.append(text)
            
            if content_buffer:
                combined = " ".join(content_buffer)
                if len(combined) > 10:
                    extracted.append({
                        "topic": current_heading,
                        "content": combined,
                        "sheet_name": "Document"
                    })
            
            for table_idx, table in enumerate(doc.tables):
                current_topic = None
                for row in table.rows:
                    cells = [cell.text.strip() for cell in row.cells]
                    if len(cells) >= 2:
                        col_a, col_b = cells[0], cells[1]
                        
                        if col_a and len(col_a) < 200:
                            current_topic = col_a
                        
                        if col_b and len(col_b) > 5:
                            extracted.append({
                                "topic": current_topic or "General",
                                "content": col_b,
                                "sheet_name": f"Table {table_idx + 1}"
                            })
            
            logger.info(f"      📝 DOCX: {len(doc.paragraphs)} paragraphs, {len(doc.tables)} tables")
            
        except Exception as e:
            logger.warning(f"      ⚠️ DOCX extraction error: {e}")
        
        return extracted
    
    def _extract_pdf(self, file_bytes: bytes, filename: str) -> List[Dict]:
        """Extract content from PDF using pdfplumber."""
        extracted = []
        try:
            with pdfplumber.open(BytesIO(file_bytes)) as pdf:
                logger.info(f"      📄 PDF: {len(pdf.pages)} pages")
                
                for page_num, page in enumerate(pdf.pages):
                    text = page.extract_text()
                    if text and len(text.strip()) > 20:
                        paragraphs = [p.strip() for p in text.split('\n\n') if p.strip()]
                        for para in paragraphs:
                            if len(para) > 20:
                                extracted.append({
                                    "topic": f"Page {page_num + 1}",
                                    "content": para,
                                    "sheet_name": f"Page {page_num + 1}"
                                })
                    
                    tables = page.extract_tables()
                    for table_idx, table in enumerate(tables):
                        current_topic = None
                        for row in table:
                            if row and len(row) >= 2:
                                col_a = str(row[0] or "").strip()
                                col_b = str(row[1] or "").strip()
                                
                                if col_a and len(col_a) < 200:
                                    current_topic = col_a
                                
                                if col_b and len(col_b) > 5:
                                    extracted.append({
                                        "topic": current_topic or "General",
                                        "content": col_b,
                                        "sheet_name": f"Page {page_num + 1} Table {table_idx + 1}"
                                    })
                                    
        except Exception as e:
            logger.warning(f"      ⚠️ PDF extraction error: {e}")
        
        return extracted
    
    def _extract_content(self, file_bytes: bytes, filename: str) -> List[Dict]:
        """Route extraction to appropriate method based on file type."""
        logger.info(f"    🔍 Extracting: {filename}")
        
        lower_name = filename.lower()
        
        if lower_name.endswith(('.xlsx', '.xls')):
            return self._extract_xlsx(file_bytes, filename)
        elif lower_name.endswith('.docx'):
            return self._extract_docx(file_bytes, filename)
        elif lower_name.endswith('.pdf'):
            return self._extract_pdf(file_bytes, filename)
        else:
            logger.warning(f"      ⚠️ Unsupported file type: {filename}")
            return []

    # =========================================================================
    # INDEXING PIPELINE
    # =========================================================================
    
    def index_document(self, blob_url: str, countryid: int, doctypeid: int, 
                       country_name: str) -> Dict:
        """
        Index a single document from blob URL.
        Called by FastAPI when Node.js uploads a document.
        
        Args:
            blob_url: Full blob URL or blob path
            countryid: Country ID from database (2=USA, 3=Canada, etc.)
            doctypeid: Document type ID (2=CSR, 3=CP, 4=RC, etc.)
            country_name: Country name for index selection
        
        Returns:
            Stats dict with indexed count
        """
        stats = {"countryid": countryid, "doctypeid": doctypeid, "indexed": 0, "errors": 0}
        
        # Log original URL
        logger.info(f"[INDEXER URL TRACE] Original blob_url: '{blob_url}'")
        logger.info(f"[INDEXER URL TRACE] Original repr: {repr(blob_url)}")
        logger.info(f"[INDEXER URL TRACE] Original length: {len(blob_url)}")
        
        # Clean the URL - strip whitespace and quotes
        # Also decode URL-encoded characters (e.g., %22 for quotes)
        from urllib.parse import unquote
        blob_url = unquote(blob_url.strip()).strip('"').strip("'")
        
        # Log cleaned URL
        logger.info(f"[INDEXER URL TRACE] After cleaning: '{blob_url}'")
        logger.info(f"[INDEXER URL TRACE] After cleaning repr: {repr(blob_url)}")
        logger.info(f"[INDEXER URL TRACE] After cleaning length: {len(blob_url)}")
        
        # Extract blob path from URL if needed
        blob_path = blob_url
        if blob_url.startswith("http"):
            parts = blob_url.split("/")
            logger.info(f"[INDEXER URL TRACE] URL parts: {parts}")
            for i, part in enumerate(parts):
                if "blob.core.windows.net" in part and i + 2 < len(parts):
                    blob_path = "/".join(parts[i + 2:])
                    logger.info(f"[INDEXER URL TRACE] Extracted blob_path: '{blob_path}'")
                    break
        
        filename = blob_path.split("/")[-1]
        logger.info(f"[INDEXER URL TRACE] Final filename: '{filename}'")
        logger.info(f"📄 Indexing document: {filename} (countryid={countryid}, doctypeid={doctypeid})")
        
        try:
            file_bytes = self._download_blob(blob_path)
            extracted = self._extract_content(file_bytes, filename)
            
            if not extracted:
                logger.warning(f"  ⚠️ No content extracted from {filename}")
                return stats
            
            # Create/verify index and get search client
            self._create_index(country_name)
            search_client = self._get_search_client(country_name)
            
            # Create documents
            documents = []
            country_code = country_name.lower().replace(' ', '_')
            
            for idx, item in enumerate(extracted):
                content = f"[{item['topic']}] {item['content']}"
                doc_id = self._sanitize_id(f"{country_code}_{filename}_{idx}_{hashlib.md5(content.encode()).hexdigest()[:8]}")
                
                documents.append({
                    "id": doc_id,
                    "content": content,
                    "contentVector": self._embed(content),
                    "countryid": countryid,
                    "doctypeid": doctypeid,
                    "country_code": country_code,
                    "doc_type": self._get_doc_type_string(doctypeid),
                    "topic": item["topic"],
                    "section_type": self._classify_section(content),
                    "source_file": filename,
                    "sheet_name": item.get("sheet_name", ""),
                    "is_required": "required" in content.lower() or "must" in content.lower()
                })
            
            # Upload
            batch_size = 100
            for i in range(0, len(documents), batch_size):
                batch = documents[i:i+batch_size]
                search_client.upload_documents(batch)
            
            stats["indexed"] = len(documents)
            logger.info(f"  ✅ Indexed {len(documents)} items from {filename}")
            
        except Exception as e:
            logger.error(f"  ❌ Error: {e}")
            stats["errors"] = 1
        
        return stats

    def index_country(self, country: str, force: bool = False) -> Dict:
        """Index all documents for a country with incremental updates."""
        logger.info(f"\n{'='*60}")
        logger.info(f"📁 INDEXING: {country}")
        logger.info(f"{'='*60}")
        
        stats = {"country": country, "added": 0, "updated": 0, "deleted": 0, "unchanged": 0, "errors": 0}
        
        current_files = self._get_blob_files(country)
        if not current_files:
            logger.warning(f"  ⚠️ No files found for {country}")
            return stats
        
        logger.info(f"  📂 Found {len(current_files)} files")
        
        stored_manifest = self._get_stored_manifest(country)
        stored_files = stored_manifest.get("files", {})
        
        files_to_add = []
        files_to_update = []
        files_to_delete = []
        
        for filename, info in current_files.items():
            if filename not in stored_files:
                files_to_add.append(filename)
            elif info["hash"] != stored_files[filename].get("hash"):
                files_to_update.append(filename)
            else:
                stats["unchanged"] += 1
        
        for filename in stored_files:
            if filename not in current_files:
                files_to_delete.append(filename)
        
        if not force and not files_to_add and not files_to_update and not files_to_delete:
            logger.info(f"  ✅ No changes detected. Use --force to re-index.")
            return stats
        
        logger.info(f"  📊 Changes: +{len(files_to_add)} new, ~{len(files_to_update)} updated, -{len(files_to_delete)} deleted")
        
        # Delete existing index if force (to apply schema changes)
        if force:
            self.delete_index(country)
        
        index_name = self._create_index(country)
        search_client = self._get_search_client(country)
        
        files_to_process = files_to_add + files_to_update
        if force:
            files_to_process = list(current_files.keys())
        
        country_code = country.lower().replace(' ', '_')
        countryid = self._get_countryid(country)
        
        for filename in files_to_process:
            try:
                blob_path = current_files[filename]["blob_path"]
                file_bytes = self._download_blob(blob_path)
                
                extracted = self._extract_content(file_bytes, filename)
                logger.info(f"    ✅ Extracted {len(extracted)} items from {filename}")
                
                if not extracted:
                    continue
                
                doc_type = self._classify_doc_type(filename)
                doctypeid = self._get_doctypeid(filename)
                
                if filename in files_to_update and not force:
                    try:
                        old_docs = list(search_client.search(f"source_file eq '{filename}'", top=1000, select=["id"]))
                        if old_docs:
                            search_client.delete_documents([{"id": d["id"]} for d in old_docs])
                            logger.info(f"    🗑️ Deleted {len(old_docs)} old documents")
                    except:
                        pass
                
                documents = []
                for idx, item in enumerate(extracted):
                    content = f"[{item['topic']}] {item['content']}"
                    doc_id = self._sanitize_id(f"{country_code}_{filename}_{idx}_{hashlib.md5(content.encode()).hexdigest()[:8]}")
                    
                    documents.append({
                        "id": doc_id,
                        "content": content,
                        "contentVector": self._embed(content),
                        "countryid": countryid,
                        "doctypeid": doctypeid,
                        "country_code": country_code,
                        "doc_type": self._get_doc_type_string(doctypeid),
                        "topic": item["topic"],
                        "section_type": self._classify_section(content),
                        "source_file": filename,
                        "sheet_name": item.get("sheet_name", ""),
                        "is_required": "required" in content.lower() or "must" in content.lower()
                    })
                
                batch_size = 100
                for i in range(0, len(documents), batch_size):
                    batch = documents[i:i+batch_size]
                    search_client.upload_documents(batch)
                    logger.info(f"    📤 Uploaded batch {i//batch_size + 1}/{(len(documents)-1)//batch_size + 1}")
                
                if filename in files_to_add or force:
                    stats["added"] += 1
                else:
                    stats["updated"] += 1
                    
            except Exception as e:
                logger.error(f"    ❌ Error processing {filename}: {e}")
                stats["errors"] += 1
        
        for filename in files_to_delete:
            try:
                old_docs = list(search_client.search(f"source_file eq '{filename}'", top=1000, select=["id"]))
                if old_docs:
                    search_client.delete_documents([{"id": d["id"]} for d in old_docs])
                    logger.info(f"    🗑️ Deleted {len(old_docs)} documents from {filename}")
                stats["deleted"] += 1
            except Exception as e:
                logger.warning(f"    ⚠️ Error deleting {filename}: {e}")
        
        new_manifest = {
            "country": country,
            "last_indexed": datetime.utcnow().isoformat(),
            "files": current_files
        }
        self._store_manifest(country, new_manifest)
        
        logger.info(f"  ⏳ Waiting for index refresh...")
        time.sleep(3)
        
        try:
            total = search_client.search("*", top=0, include_total_count=True).get_count()
            logger.info(f"  ✅ Index '{index_name}' now has {total} documents")
        except Exception as e:
            logger.warning(f"  ⚠️ Verification error: {e}")
        
        return stats
    
    def index_all_countries(self, force: bool = False) -> List[Dict]:
        """Index all countries found in blob storage."""
        countries = self.get_available_countries()
        logger.info(f"\n🌍 Found {len(countries)} countries: {', '.join(countries)}")
        
        results = []
        for country in countries:
            stats = self.index_country(country, force=force)
            results.append(stats)
        
        return results

    def remove_document(self, blob_url: str, countryid: int, doctypeid: int, country_name: str) -> Dict:
        """
        Remove document from country-specific index by blob URL.
        Uses both source_file and doctypeid filters for precise deletion.
        Returns stats about deleted documents.
        """
        country_code = country_name 
        if not country_code:
            raise ValueError(f"Unknown countryid: {countryid}")
        
        country_code = country_code.lower().replace(' ', '-').replace('_', '-')
        index_name = self._get_index_name(country_code)
        
        # Extract filename from blob URL
        filename = blob_url.split("/")[-1]
        
        logger.info(f"\n🗑️ Removing document from index: {index_name}")
        logger.info(f"   File: {filename}")
        logger.info(f"   Country: {country_code.upper()} (countryid={countryid})")
        logger.info(f"   Document Type: {doctypeid}")
        
        try:
            # Ensure index exists
            try:
                self.index_client.get_index(index_name)
            except:
                return {
                    "success": True,
                    "message": f"Index {index_name} does not exist - nothing to delete",
                    "deleted": 0
                }
            
            # Search for documents with this source file
            search_client = SearchClient(
                endpoint=Config.get_search_endpoint(),
                index_name=index_name,
                credential=Config.get_search_credential()
            )
            
            # Find all documents from this file with matching doctypeid
            old_docs = list(search_client.search(
                search_text="*",
                filter=f"source_file eq '{filename}' and doctypeid eq {doctypeid}",
                top=1000,
                select=["id"]
            ))
            
            if old_docs:
                # Delete documents
                search_client.delete_documents([{"id": d["id"]} for d in old_docs])
                logger.info(f"   ✅ Deleted {len(old_docs)} documents")
                
                return {
                    "success": True,
                    "message": f"Removed {len(old_docs)} documents from {index_name}",
                    "deleted": len(old_docs),
                    "filename": filename,
                    "index_name": index_name
                }
            else:
                logger.info(f"   ℹ️ No documents found for {filename}")
                return {
                    "success": True,
                    "message": f"No documents found for {filename} in {index_name}",
                    "deleted": 0,
                    "filename": filename,
                    "index_name": index_name
                }
        
        except Exception as e:
            logger.error(f"   ❌ Error removing document: {e}")
            raise Exception(f"Failed to remove document: {str(e)}")
        
    def delete_global_icf_sections(
            self,
            document_id: str,
            index_name: str = None
        ) -> Tuple[int, str, str]:
            """
            Delete all indexed ICF sections for a given document_id from a global index.

            Args:
                document_id: The document_id to match in Azure AI Search.
                index_name: The index name to delete from (defaults to ENV or 'icf-sections-index').

            Returns:
                (deleted_count, message, final_index_name)
            """
            final_index_name = index_name or os.getenv("ICF_SECTIONS_INDEX_NAME", "icf-sections-index")

            # Get a SearchClient for the global icf sections index
            client = client_manager.get_search_client(final_index_name)

            # Build filter
            odata_filter = f"document_id eq '{document_id}'"

            # Page size & batching
            page_size = 1000
            ids_to_delete: List[Dict[str, str]] = []

            try:
                # Get total count (if available)
                try:
                    count_result = client.search(
                        search_text="",
                        filter=odata_filter,
                        top=0,
                        include_total_count=True
                    )
                    total = count_result.get_count() or 0
                except Exception:
                    # Fallback if count not supported
                    total = None

                if total is None:
                    # No count path: iterate and collect
                    results = client.search(
                        search_text="",
                        filter=odata_filter,
                        select=["id"]
                    )
                    for item in results:
                        if "id" in item:
                            ids_to_delete.append({"id": item["id"]})
                else:
                    # Use skip-based pagination to collect all ids
                    for skip in range(0, total, page_size):
                        results = client.search(
                            search_text="",
                            filter=odata_filter,
                            top=page_size,
                            skip=skip,
                            select=["id"]
                        )
                        for item in results:
                            if "id" in item:
                                ids_to_delete.append({"id": item["id"]})

                if not ids_to_delete:
                    return 0, f"No documents found for document_id {document_id}", final_index_name

                # Delete in batches (Azure SDK supports list of dicts with 'id')
                for i in range(0, len(ids_to_delete), page_size):
                    batch = ids_to_delete[i : i + page_size]
                    client.delete_documents(documents=batch)

                deleted = len(ids_to_delete)
                return deleted, (
                    f"Deleted {deleted} indexed sections for document {document_id}"
                ), final_index_name

            except Exception as e:
                # Bubble the exception up so FastAPI handler can return HTTP 500
                raise e
    
# =============================================================================
# CLI ENTRY POINT
# =============================================================================

def main():
    import argparse
    
    parser = argparse.ArgumentParser(description="Index ICF knowledge base documents")
    parser.add_argument("--country", type=str, help="Specific country to index")
    parser.add_argument("--force", action="store_true", help="Force re-index all files (deletes and recreates index)")
    parser.add_argument("--list", action="store_true", help="List available countries")
    args = parser.parse_args()
    
    indexer = MultiCountryIndexer()
    
    if args.list:
        countries = indexer.get_available_countries()
        logger.info(f"\n📂 Available countries ({len(countries)}):")
        for c in countries:
            countryid = indexer._get_countryid(c)
            logger.info(f"  • {c} (countryid={countryid})")
        return
    
    if args.country:
        indexer.index_country(args.country, force=args.force)
    else:
        indexer.index_all_countries(force=args.force)


if __name__ == "__main__":
    main()