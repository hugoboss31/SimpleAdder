"""
Learn Pipeline Service.
All-in-one pipeline for: Semantic Extraction, Evidence Gate, Learning Artifact Indexing, Publishing Gate.
Includes automatic index creation for new countries.
Reuses existing GeneratorKnowledgeStore for RAG queries.
"""

import json
import os
import re
import uuid
import threading
from typing import List, Dict, Tuple, Optional, Any
from datetime import datetime

try:
    from lxml import etree
    LXML_AVAILABLE = True
except ImportError:
    LXML_AVAILABLE = False

try:
    from openai import AzureOpenAI
    OPENAI_AVAILABLE = True
except ImportError:
    OPENAI_AVAILABLE = False

try:
    from azure.search.documents import SearchClient
    from azure.search.documents.indexes import SearchIndexClient
    from azure.search.documents.indexes.models import (
        SearchIndex, SimpleField, SearchableField, SearchFieldDataType,
        VectorSearch, HnswAlgorithmConfiguration, VectorSearchProfile,
        SearchField
    )
    from azure.core.credentials import AzureKeyCredential
    AZURE_SEARCH_AVAILABLE = True
except ImportError:
    AZURE_SEARCH_AVAILABLE = False

from models.learning_models import (
    RawDelta, SemanticChange, DPOPreferencePair,
    PublishingMetrics, PublishingGateResult, PUBLISHING_RULES, CHANGE_TYPES
)
from models.models import AGENT_AUTHORS, SemanticIntent, RegenerationInstruction
from config import Config
from services.generator_knowledge_store import GeneratorKnowledgeStore
from services.app_insights import get_logger, track_event, track_exception

W_NS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
W = "{" + W_NS + "}"

# Module-level lock registry for thread-safe index creation
_index_creation_locks: Dict[str, threading.Lock] = {}
_index_creation_lock = threading.Lock()


class LearnPipeline:
    """
    Complete learning pipeline.
    
    Stages:
    1. Semantic Extraction - Parse track changes, classify intents
    2. Evidence Gate - Validate changes against RAG
    3. LLM Edit Enhancement - Query past corrections for context
    4. Learning Artifact Indexing - Store Learn Pipeline pairs
    5. Publishing Gate - Validate before publish
    
    Features:
    - Automatic index creation for new countries
    - Thread-safe with per-country locking
    - Reuses existing RAG store
    """
    
    EMBEDDING_DIMENSIONS = 1536  # text-embedding-ada-002
    
    def __init__(self, country: str):
        self.country = country.lower().replace(' ', '-').replace('_', '-')
        self.learning_index_name = f"icf-learning-artifacts-{self.country}"
        
        self.rag_store: Optional[GeneratorKnowledgeStore] = None
        self.openai_client = None
        self.search_client = None
        self.index_client = None
        
        self.embedding_deployment = os.getenv("EMBEDDINGS_MODEL_DEPLOYMENT", "text-embedding-3-small")
        self.deployment_name = os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME", "gpt-4o")
        
        self.logger = get_logger("learning_artifacts")
        
        self._init_rag_store()
        self._init_openai()
        self._init_search_client()
        
        # Fetch dynamic values from index for evidence gates
        self.valid_doctypeids = self._fetch_unique_doctypeids()
        self.valid_section_types = self._fetch_unique_section_types()
        
        self.logger.info(f"✅ Learn Pipeline initialized for {self.country.upper()}")
    
    def _fetch_unique_doctypeids(self) -> List[int]:
        """Fetch unique doctypeids from the country index."""
        if not self.rag_store or not self.rag_store.search_client:
            return []
        
        try:
            results = self.rag_store.search_client.search(
                search_text="*",
                select=["doctypeid"],
                top=1000
            )
            doctypeids = set()
            for r in results:
                doctype = r.get("doctypeid")
                if doctype is not None:
                    doctypeids.add(int(doctype))
            
            if doctypeids:
                self.logger.info(f"  ✓ Fetched valid doctypeids: {sorted(doctypeids)}")
            return list(doctypeids)
        except Exception as e:
            self.logger.warning(f"  ⚠️ Could not fetch doctypeids: {e}")
            return []
    
    def _fetch_unique_section_types(self) -> List[str]:
        """Fetch unique section_type values from the country index."""
        if not self.rag_store or not self.rag_store.search_client:
            return []
        
        try:
            results = self.rag_store.search_client.search(
                search_text="*",
                select=["section_type"],
                top=1000
            )
            section_types = set()
            for r in results:
                section_type = r.get("section_type")
                if section_type:
                    section_types.add(section_type.lower())
            
            if section_types:
                self.logger.info(f"  ✓ Fetched valid section_types: {sorted(section_types)}")
            return list(section_types)
        except Exception as e:
            self.logger.warning(f"  ⚠️ Could not fetch section_types: {e}")
            return []
    
    def _init_rag_store(self):
        """Initialize RAG store for evidence queries."""
        try:
            self.rag_store = GeneratorKnowledgeStore(
                country=self.country,
                auto_sync=False
            )
            self.logger.info(f"  ✓ RAG store ready (icf-index-{self.country})")
        except Exception as e:
            self.logger.warning(f"  ⚠️ RAG store init failed: {e}")
    
    def _init_openai(self):
        """Initialize Azure OpenAI for classification and embeddings."""
        if not OPENAI_AVAILABLE:
            return
        
        api_key = os.getenv("AZURE_OPENAI_API_KEY")
        endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
        
        if api_key and endpoint:
            try:
                self.openai_client = AzureOpenAI(
                    api_key=api_key,
                    api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2025-01-01-preview"),
                    azure_endpoint=endpoint
                )
                self.logger.info("  ✓ OpenAI ready for classification")
            except Exception as e:
                self.logger.warning(f"  ⚠️ OpenAI init failed: {e}")
    
    def _init_search_client(self):
        """Initialize Azure AI Search client and ensure index exists."""
        if not AZURE_SEARCH_AVAILABLE:
            self.logger.warning("  ⚠️ Azure Search SDK not available")
            return

        try:
            endpoint = Config.get_search_endpoint()
            credential = Config.get_search_credential()
        except Exception as e:
            self.logger.warning(f"  ⚠️ Azure Search credentials not configured: {e}")
            return

        try:
            # Initialize index client for management operations
            self.index_client = SearchIndexClient(
                endpoint=endpoint,
                credential=credential
            )
            
            # Ensure index exists (lazy creation)
            self._ensure_index_exists()
            
            # Now create search client for document operations
            self.search_client = SearchClient(
                endpoint=endpoint,
                index_name=self.learning_index_name,
                credential=credential
            )
            self.logger.info(f"  ✓ Search client ready ({self.learning_index_name})")
            
        except Exception as e:
            self.logger.warning(f"  ⚠️ Search client init failed: {e}")
            self.search_client = None
    
    def _ensure_index_exists(self):
        """
        Lazily create learning artifacts index if it doesn't exist.
        Thread-safe with per-country locking to handle concurrent requests.
        """
        global _index_creation_locks
        
        if not self.index_client:
            return
        
        # Get or create lock for this country
        with _index_creation_lock:
            if self.country not in _index_creation_locks:
                _index_creation_locks[self.country] = threading.Lock()
            country_lock = _index_creation_locks[self.country]
        
        # Acquire country-specific lock to prevent race conditions
        with country_lock:
            # Check if index already exists
            try:
                self.index_client.get_index(self.learning_index_name)
                return  # Index exists, nothing to do
            except Exception:
                pass  # Index doesn't exist, create it
            
            # Create index with schema
            self.logger.info(f"  📚 Auto-creating index: {self.learning_index_name}")
            
            fields = [
                SimpleField(
                    name="id",
                    type=SearchFieldDataType.String,
                    key=True,
                    filterable=True
                ),
                SimpleField(
                    name="country",
                    type=SearchFieldDataType.String,
                    filterable=True,
                    facetable=True
                ),
                SearchableField(
                    name="section_type",
                    type=SearchFieldDataType.String,
                    filterable=True,
                    facetable=True
                ),
                SearchableField(
                    name="ai_output",
                    type=SearchFieldDataType.String,
                    analyzer_name="en.microsoft"
                ),
                SearchableField(
                    name="human_output",
                    type=SearchFieldDataType.String,
                    analyzer_name="en.microsoft"
                ),
                SearchableField(
                    name="context",
                    type=SearchFieldDataType.String,
                    analyzer_name="en.microsoft"
                ),
                SearchableField(
                    name="intent",
                    type=SearchFieldDataType.String,
                    analyzer_name="en.microsoft"
                ),
                SimpleField(
                    name="confidence",
                    type=SearchFieldDataType.Double,
                    filterable=True,
                    sortable=True
                ),
                SimpleField(
                    name="source_document_id",
                    type=SearchFieldDataType.String,
                    filterable=True
                ),
                SimpleField(
                    name="evidence_ids",
                    type=SearchFieldDataType.Collection(SearchFieldDataType.String),
                    filterable=True
                ),
                SimpleField(
                    name="version",
                    type=SearchFieldDataType.Int32,
                    filterable=True,
                    sortable=True
                ),
                SimpleField(
                    name="priority",
                    type=SearchFieldDataType.Int32,
                    filterable=True,
                    sortable=True
                ),
                SimpleField(
                    name="icf_case_id",
                    type=SearchFieldDataType.String,
                    filterable=True
                ),
                SimpleField(
                    name="iteration_id",
                    type=SearchFieldDataType.Int32,
                    filterable=True,
                    sortable=True
                ),
                SimpleField(
                    name="is_superseded",
                    type=SearchFieldDataType.Boolean,
                    filterable=True
                ),
                SimpleField(
                    name="superseded_by",
                    type=SearchFieldDataType.String,
                    filterable=True
                ),
                SimpleField(
                    name="created_at",
                    type=SearchFieldDataType.String,
                    filterable=True,
                    sortable=True
                ),
                SearchField(
                    name="embedding",
                    type=SearchFieldDataType.Collection(SearchFieldDataType.Single),
                    searchable=True,
                    vector_search_dimensions=self.EMBEDDING_DIMENSIONS,
                    vector_search_profile_name="learning-vector-profile"
                )
            ]
            
            vector_search = VectorSearch(
                algorithms=[
                    HnswAlgorithmConfiguration(
                        name="learning-hnsw-config",
                        parameters={
                            "m": 4,
                            "efConstruction": 400,
                            "efSearch": 500,
                            "metric": "cosine"
                        }
                    )
                ],
                profiles=[
                    VectorSearchProfile(
                        name="learning-vector-profile",
                        algorithm_configuration_name="learning-hnsw-config"
                    )
                ]
            )
            
            index = SearchIndex(
                name=self.learning_index_name,
                fields=fields,
                vector_search=vector_search
            )
            
            try:
                self.index_client.create_or_update_index(index)
                self.logger.info(f"  ✅ Index '{self.learning_index_name}' created automatically")
            except Exception as e:
                self.logger.error(f"  ❌ Auto-create index failed: {e}")
                raise

    # =========================================================================
    # STAGE 1: Semantic Extraction
    # =========================================================================
    
    def extract_semantic_changes(
        self,
        reviewed_path: str,
        section_map: Optional[Dict[str, str]] = None,
        comments: List[Dict] = None,
        base_doc_path: Optional[str] = None
    ) -> List[SemanticChange]:
        """
        Extract semantic changes from reviewed document using LLM analysis.
        Handles THREE client feedback scenarios:
        1. Comments only (with linked_text)
        2. Track changes only
        3. Both comments AND track changes
        Uses LLM to understand semantic intent and create proper pairs.
        Internally produces SemanticIntent (track changes) and RegenerationInstruction (comments).
        """
        if not LXML_AVAILABLE:
            self.logger.warning("  ⚠️ lxml not available for semantic extraction")
            return []
        
        self.logger.info("\n📊 SEMANTIC EXTRACTION (CLIENT CHANGES ONLY)")
        if base_doc_path:
            self.logger.info(f"  ✓ Base document provided for comparison: {os.path.basename(base_doc_path)}")
        
        raw_deltas = self._parse_track_changes(reviewed_path)
        self.logger.info(f"  ✓ Extracted {len(raw_deltas)} client track changes")
        
        client_comments_for_learning = []
        if comments:
            for c in comments:
                linked = c.get('linked_text', c.get('highlighted_text', ''))
                comment_text = c.get('text', c.get('comment_text', ''))
                if linked and comment_text:
                    client_comments_for_learning.append(c)
            self.logger.info(f"  ✓ Found {len(client_comments_for_learning)} client comments with linked text")
        
        self.logger.info(f"\n  🔍 Processing sources for learning:")
        self.logger.info(f"      - Client track changes: {len(raw_deltas)}")
        self.logger.info(f"      - Client comments with linked_text: {len(client_comments_for_learning)}")
        if client_comments_for_learning:
            for i, c in enumerate(client_comments_for_learning[:3]):
                self.logger.info(f"      [{i+1}] \"{c.get('text', '')[:40]}...\" → linked: \"{c.get('linked_text', '')[:40]}...\"")
        
        if not raw_deltas and not client_comments_for_learning:
            self.logger.info("  ℹ️ No semantic changes found (no client track changes or comments with linked text)")
            return []
        
        semantic_changes = []
        self._last_semantic_intents = []
        self._last_regeneration_instructions = []
        
        if raw_deltas:
            intents = self._extract_semantic_intents_with_llm(raw_deltas)
            self._last_semantic_intents = intents
            self.logger.info(f"  ✓ LLM extracted {len(intents)} SemanticIntents from track changes")
            for i, si in enumerate(intents):
                ai_out = si.original_text.strip()
                if not ai_out:
                    continue
                change = SemanticChange(
                    change_id=f"SC-{len(semantic_changes):04d}",
                    source="track_change",
                    section_id="",
                    section_title=si.section_title or "Unknown",
                    change_type=self._infer_change_type_from_text(ai_out, si.corrected_text),
                    original_text=ai_out,
                    modified_text=si.corrected_text,
                    intent=si.intent,
                    confidence=si.confidence,
                    priority=getattr(si, 'priority', 3),
                    is_learning_candidate=True
                )
                semantic_changes.append(change)
        
        if client_comments_for_learning:
            instructions = self._extract_regeneration_instructions_with_llm(client_comments_for_learning)
            self._last_regeneration_instructions = instructions
            self.logger.info(f"  ✓ LLM extracted {len(instructions)} RegenerationInstructions from comments")
            for ri in instructions:
                linked = ri.linked_text.strip()
                if not linked:
                    continue
                change = SemanticChange(
                    change_id=f"SC-{len(semantic_changes):04d}",
                    source="comment",
                    section_id="",
                    section_title=ri.section_title or "Unknown",
                    change_type=self._infer_change_type_from_text(linked, ri.instruction),
                    original_text=linked,
                    modified_text=ri.instruction,
                    intent=ri.instruction,
                    confidence=ri.confidence,
                    priority=getattr(ri, 'priority', 3),
                    is_learning_candidate=True
                )
                semantic_changes.append(change)
        
        self.logger.info(f"  ✓ Created {len(semantic_changes)} semantic changes for learning")
        return semantic_changes
    
    def _extract_semantic_intents_with_llm(self, deltas: List[RawDelta]) -> List[SemanticIntent]:
        """
        Use LLM to analyze track changes and produce SemanticIntent objects.
        Each SemanticIntent captures what the client changed and why.
        """
        if not self.openai_client:
            self.logger.warning("  ⚠️ OpenAI not available for SemanticIntent extraction")
            return []
        
        if not deltas:
            return []
        
        changes_text = []
        for i, d in enumerate(deltas[:50]):
            if d.change_type == "DELETE":
                changes_text.append(f"  [{i+1}] DELETED: \"{d.original_text[:200]}\"")
            elif d.change_type == "INSERT":
                changes_text.append(f"  [{i+1}] INSERTED: \"{d.modified_text[:200]}\"")
        
        prompt = f"""Analyze these client track changes from an ICF (Informed Consent Form) document.
Your task is to extract SemanticIntents: what the client changed (deleted/inserted) and the semantic reason.

TRACK CHANGES (deletions and insertions by the client):
{chr(10).join(changes_text)}

For each meaningful correction, extract:
1. section_key: Best-guess section key (e.g., "informed_consent", "risks_benefits", "confidentiality")
2. section_title: The section heading or topic
3. original_text: The original AI text that was deleted by the client
4. corrected_text: The client's replacement text (inserted). Empty string if pure deletion.
5. intent: The semantic reason for this change (e.g., "Use regulatory term 'drug' instead of 'medicine'")
6. change_type: One of: terminology_replacement, content_removal, legal_strengthening, tone_adjustment, structural_change, content_addition
7. priority: Integer 1-5 (1=highest/critical, 5=lowest/nice-to-have). Use 1 for regulatory/compliance fixes, 2 for legal clarity, 3 for standard improvements, 4-5 for minor refinements.

RULES:
- Pair deletions with nearby insertions if semantically related
- Skip study-specific data (dates, doses, protocol numbers, site names)
- Deduplicate: same correction appearing multiple times = include only once
- For pure deletions with no matching insertion: corrected_text = ""

Return JSON:
{{
  "intents": [
    {{"section_key": "...", "section_title": "...", "original_text": "...", "corrected_text": "...", "intent": "...", "change_type": "...", "priority": 3}}
  ]
}}
Return {{"intents": []}} ONLY if no valid intents found."""

        try:
            import json
            response = self.openai_client.chat.completions.create(
                model=self.deployment_name,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.1,
                response_format={"type": "json_object"}
            )
            
            raw_content = response.choices[0].message.content
            self.logger.info(f"\n  🔍 SemanticIntent LLM response:\n{raw_content[:800]}\n")
            result = json.loads(raw_content)
            
            raw_intents = result.get("intents", []) if isinstance(result, dict) else result if isinstance(result, list) else []
            
            intents = []
            for i, item in enumerate(raw_intents):
                prio = item.get("priority", 3)
                if not isinstance(prio, int) or prio < 1 or prio > 5:
                    prio = 3
                si = SemanticIntent(
                    intent_id=f"SI-{i:04d}",
                    section_key=item.get("section_key", ""),
                    section_title=item.get("section_title", "Unknown"),
                    original_text=item.get("original_text", ""),
                    corrected_text=item.get("corrected_text", ""),
                    intent=item.get("intent", "Client correction"),
                    change_type=item.get("change_type", "modification"),
                    confidence=0.9,
                    priority=prio,
                    source="track_change"
                )
                intents.append(si)
            
            return intents
            
        except Exception as e:
            self.logger.error(f"  ⚠️ SemanticIntent LLM extraction failed: {e}")
            track_exception(e, {"pipeline": "learning_artifacts", "stage": "semantic_intent_extraction"})
            return []
    
    def _extract_regeneration_instructions_with_llm(self, comments: List[Dict]) -> List[RegenerationInstruction]:
        """
        Use LLM to analyze client comments and produce RegenerationInstruction objects.
        Each RegenerationInstruction captures what the client wants done based on their comment.
        """
        if not self.openai_client:
            self.logger.warning("  ⚠️ OpenAI not available for RegenerationInstruction extraction")
            return []
        
        if not comments:
            return []
        
        comments_context = []
        for i, c in enumerate(comments[:50]):
            comment_text = c.get('text', c.get('comment_text', ''))
            linked_text = c.get('linked_text', c.get('highlighted_text', ''))[:200]
            section = c.get('section_heading', c.get('section', 'Unknown Section'))
            
            entry = f"  COMMENT #{i+1}:\n"
            entry += f"    Section: \"{section}\"\n"
            entry += f"    Client said: \"{comment_text}\"\n"
            entry += f"    Highlighted text: \"{linked_text}\"\n"
            comments_context.append(entry)
        
        prompt = f"""Analyze these client comments from an ICF (Informed Consent Form) document.
Your task is to extract RegenerationInstructions: what the client wants done based on each comment.

CLIENT COMMENTS WITH CONTEXT:
{chr(10).join(comments_context)}

For each comment that contains an actionable instruction, extract:
1. section_key: Best-guess section key (e.g., "informed_consent", "risks_benefits", "confidentiality")
2. section_title: The section heading or topic
3. comment_text: The client's comment text
4. linked_text: The text the comment was attached to (highlighted text)
5. instruction: What the client wants done (your interpretation of the comment)
6. action: One of: MODIFY, ADD, DELETE, CLARIFY
7. priority: Integer 1-5 (1=highest/critical, 5=lowest/nice-to-have). Use 1 for regulatory/compliance, 2 for legal clarity, 3 for standard, 4-5 for minor.

RULES:
- Use the highlighted/linked text and comment together to understand intent
- For "Remove this" type comments: action = DELETE, instruction = why removal makes sense
- For "Change X to Y" comments: action = MODIFY, instruction = the specific change wanted
- For "Add ..." comments: action = ADD, instruction = what to add
- Skip study-specific data (dates, doses, protocol numbers, site names)
- Deduplicate: same instruction appearing multiple times = include only once

Return JSON:
{{
  "instructions": [
    {{"section_key": "...", "section_title": "...", "comment_text": "...", "linked_text": "...", "instruction": "...", "action": "...", "priority": 3}}
  ]
}}
Return {{"instructions": []}} ONLY if no actionable instructions found."""

        try:
            import json
            response = self.openai_client.chat.completions.create(
                model=self.deployment_name,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.1,
                response_format={"type": "json_object"}
            )
            
            raw_content = response.choices[0].message.content
            self.logger.info(f"\n  🔍 RegenerationInstruction LLM response:\n{raw_content[:800]}\n")
            result = json.loads(raw_content)
            
            raw_instructions = result.get("instructions", []) if isinstance(result, dict) else result if isinstance(result, list) else []
            
            instructions = []
            for i, item in enumerate(raw_instructions):
                prio = item.get("priority", 3)
                if not isinstance(prio, int) or prio < 1 or prio > 5:
                    prio = 3
                ri = RegenerationInstruction(
                    instruction_id=f"RI-{i:04d}",
                    section_key=item.get("section_key", ""),
                    section_title=item.get("section_title", "Unknown"),
                    comment_text=item.get("comment_text", ""),
                    linked_text=item.get("linked_text", ""),
                    instruction=item.get("instruction", ""),
                    action=item.get("action", "MODIFY"),
                    confidence=0.9,
                    priority=prio,
                    source="comment"
                )
                instructions.append(ri)
            
            return instructions
            
        except Exception as e:
            self.logger.error(f"  ⚠️ RegenerationInstruction LLM extraction failed: {e}")
            track_exception(e, {"pipeline": "learning_artifacts", "stage": "regeneration_instruction_extraction"})
            return []
    
    def _extract_semantic_pairs_with_llm(
        self, 
        deltas: List[RawDelta],
        comments: List[Dict] = None
    ) -> List[Dict]:
        """
        LEGACY: Use LLM to analyze all track changes and comments together.
        Kept for backward compatibility with run_full_pipeline.
        New code should use _extract_semantic_intents_with_llm and _extract_regeneration_instructions_with_llm.
        """
        if not self.openai_client:
            self.logger.warning("  ⚠️ OpenAI not available, falling back to mechanical pairing")
            return self._fallback_mechanical_pairing(deltas)
        
        if not deltas and not comments:
            return []
        
        changes_text = []
        for i, d in enumerate(deltas[:50]):
            if d.change_type == "DELETE":
                changes_text.append(f"  [{i+1}] DELETED: \"{d.original_text[:200]}\"")
            elif d.change_type == "INSERT":
                changes_text.append(f"  [{i+1}] INSERTED: \"{d.modified_text[:200]}\"")

        comments_context = []
        if comments:
            for i, c in enumerate(comments[:50]):
                comment_text = c.get('text', c.get('comment_text', ''))
                linked_text = c.get('linked_text', c.get('highlighted_text', ''))[:200]
                section = c.get('section_heading', c.get('section', 'Unknown Section'))
                
                entry = f"  COMMENT #{i+1}:\n"
                entry += f"    Section: \"{section}\"\n"
                entry += f"    Client said: \"{comment_text}\"\n"
                entry += f"    Highlighted text: \"{linked_text}\"\n"
                comments_context.append(entry)
        
        prompt = f"""Analyze this client-reviewed ICF (Informed Consent Form) document.
Your task is to extract ALL semantic correction pairs showing what the client wants changed.
TRACK CHANGES (deletions and insertions):
{chr(10).join(changes_text) if changes_text else "  (No track changes found)"}
CLIENT COMMENTS WITH CONTEXT:
{chr(10).join(comments_context) if comments_context else "  (No comments found)"}
For each meaningful correction, extract:
1. section: The section heading or topic
2. ai_output: The original AI text (what was there before / what client wants removed)
3. human_output: What the client wants instead (the correction / replacement)
4. intent: The semantic reason for this change
RULES:
- Pair track change deletions with nearby insertions if semantically related
- Skip study-specific data (dates, doses, protocol numbers, site names)
- Deduplicate: same correction appearing multiple times = include only once

Return JSON:
{{
  "pairs": [
    {{"section": "...", "ai_output": "...", "human_output": "...", "intent": "..."}}
  ]
}}
Return {{"pairs": []}} ONLY if no valid pairs found."""

        try:
            import json
            response = self.openai_client.chat.completions.create(
                model=self.deployment_name,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.1,
                response_format={"type": "json_object"}
            )
            
            raw_content = response.choices[0].message.content
            result = json.loads(raw_content)
            
            if isinstance(result, list):
                pairs = result
            elif isinstance(result, dict):
                if "pairs" in result:
                    pairs = result["pairs"]
                elif "corrections" in result:
                    pairs = result["corrections"]
                elif "data" in result:
                    pairs = result["data"]
                elif "ai_output" in result:
                    pairs = [result]
                else:
                    pairs = []
            else:
                pairs = []
            
            self.logger.info(f"  ✓ LLM extracted {len(pairs)} semantic pairs")
            return pairs
            
        except Exception as e:
            self.logger.warning(f"  ⚠️ LLM extraction failed: {e}, falling back to mechanical pairing")
            return self._fallback_mechanical_pairing(deltas)
    
    def _fallback_mechanical_pairing(self, deltas: List[RawDelta]) -> List[Dict]:
        """Fallback mechanical pairing when LLM unavailable."""
        by_para: Dict[str, List[RawDelta]] = {}
        for d in deltas:
            para = d.paragraph_id or "unknown"
            if para not in by_para:
                by_para[para] = []
            by_para[para].append(d)
        
        pairs = []
        seen = set()
        
        for para_id, para_deltas in by_para.items():
            deletes = [d for d in para_deltas if d.change_type == "DELETE"]
            inserts = [d for d in para_deltas if d.change_type == "INSERT"]
            
            used_inserts = set()
            
            for dele in deletes:
                dele_len = len(dele.original_text.strip())
                best_insert = None
                best_ratio = float('inf')
                
                for ins in inserts:
                    if ins.delta_id in used_inserts:
                        continue
                    
                    ins_len = len(ins.modified_text.strip())
                    if dele_len == 0 or ins_len == 0:
                        continue
                    
                    ratio = max(dele_len, ins_len) / max(min(dele_len, ins_len), 1)
                    if ratio <= 10 and ratio < best_ratio:
                        best_insert = ins
                        best_ratio = ratio
                
                if best_insert:
                    pair_key = (dele.original_text.strip().lower(), best_insert.modified_text.strip().lower())
                    if pair_key not in seen:
                        seen.add(pair_key)
                        used_inserts.add(best_insert.delta_id)
                        pairs.append({
                            "section": "Unknown",
                            "ai_output": dele.original_text,
                            "human_output": best_insert.modified_text,
                            "intent": "Client correction"
                        })
        
        return pairs
    
    def _infer_change_type_from_text(self, original: str, modified: str) -> str:
        """Infer change type from text content."""
        orig_words = len(original.split())
        mod_words = len(modified.split())
        
        if orig_words <= 3 and mod_words <= 3:
            return "terminology_replacement"
        
        legal_keywords = ["shall", "must", "required", "mandatory", "obligation", "comply"]
        if any(kw in modified.lower() for kw in legal_keywords):
            return "legal_strengthening"
        
        tone_keywords = ["may", "can", "voluntary", "choose", "right to", "option"]
        if any(kw in modified.lower() for kw in tone_keywords):
            return "tone_adjustment"
        
        return "structural_change"
    
    def _parse_track_changes(self, docx_path: str) -> List[RawDelta]:
        """Parse track changes from DOCX using OpenXML. Only extracts CLIENT changes (filters out agent changes)."""
        import zipfile
        
        deltas = []
        
        try:
            with zipfile.ZipFile(docx_path, 'r') as zf:
                if 'word/document.xml' not in zf.namelist():
                    return deltas
                
                with zf.open('word/document.xml') as f:
                    tree = etree.parse(f)
                    root = tree.getroot()
            
            delta_idx = 0
            agent_filtered = 0
            
            # Extract insertions - CLIENT ONLY
            for ins in root.iter(W + 'ins'):
                text = self._get_element_text(ins)
                if text.strip():
                    author = ins.get(W + 'author', 'Unknown')
                    
                    # Filter out agent authors
                    if author in AGENT_AUTHORS:
                        agent_filtered += 1
                        continue
                    
                    date = ins.get(W + 'date', '')
                    para_id = self._get_parent_para_id(ins)
                    
                    deltas.append(RawDelta(
                        delta_id=f"D-{delta_idx:04d}",
                        change_type="INSERT",
                        original_text="",
                        modified_text=text,
                        paragraph_id=para_id,
                        author=author,
                        date=date
                    ))
                    delta_idx += 1
            
            # Extract deletions - CLIENT ONLY
            for dele in root.iter(W + 'del'):
                text = self._get_del_text(dele)
                if text.strip():
                    author = dele.get(W + 'author', 'Unknown')
                    
                    # Filter out agent authors
                    if author in AGENT_AUTHORS:
                        agent_filtered += 1
                        continue
                    
                    date = dele.get(W + 'date', '')
                    para_id = self._get_parent_para_id(dele)
                    
                    deltas.append(RawDelta(
                        delta_id=f"D-{delta_idx:04d}",
                        change_type="DELETE",
                        original_text=text,
                        modified_text="",
                        paragraph_id=para_id,
                        author=author,
                        date=date
                    ))
                    delta_idx += 1
            
            if agent_filtered > 0:
                self.logger.info(f"  ✓ Filtered out {agent_filtered} agent track changes")
            
        except Exception as e:
            self.logger.error(f"  ⚠️ Track change parsing error: {e}")
        
        return deltas
    
    def _get_element_text(self, elem) -> str:
        """Get text content from an element."""
        texts = []
        for t in elem.iter(W + 't'):
            if t.text:
                texts.append(t.text)
        return ''.join(texts)
    
    def _get_del_text(self, elem) -> str:
        """Get deleted text from a del element."""
        texts = []
        for dt in elem.iter(W + 'delText'):
            if dt.text:
                texts.append(dt.text)
        return ''.join(texts)
    
    def _get_parent_para_id(self, elem) -> str:
        """Get paragraph ID from parent chain."""
        parent = elem.getparent()
        para_idx = 0
        while parent is not None:
            if parent.tag == W + 'p':
                para_id = parent.get(W + 'paraId', '')
                if para_id:
                    return para_id
                return f"p-{para_idx}"
            parent = parent.getparent()
            para_idx += 1
        return "p-unknown"
    
    def _classify_delta(
        self,
        delta: RawDelta,
        section_map: Optional[Dict[str, str]] = None
    ) -> Optional[SemanticChange]:
        """Classify a raw delta into a semantic change with intent."""
        
        text_to_analyze = delta.modified_text or delta.original_text
        if not text_to_analyze.strip():
            return None
        
        # Infer change type and intent
        change_type = self._infer_change_type(delta)
        intent = self._infer_intent(delta, change_type)
        confidence = self._calculate_confidence(delta)
        
        # Determine if this is a learning candidate
        is_learning = (
            confidence >= PUBLISHING_RULES["min_confidence"] and
            not self._is_study_specific(text_to_analyze)
        )
        
        # Get section info from map
        section_title = ""
        section_id = delta.section_id or ""
        if section_map and delta.paragraph_id in section_map:
            section_title = section_map[delta.paragraph_id]
        
        return SemanticChange(
            change_id=delta.delta_id,
            source="track_change",
            section_id=section_id,
            section_title=section_title,
            change_type=change_type,
            original_text=delta.original_text,
            modified_text=delta.modified_text,
            intent=intent,
            confidence=confidence,
            is_learning_candidate=is_learning
        )
    
    def _infer_change_type(self, delta: RawDelta) -> str:
        """Infer the type of semantic change based on content analysis."""
        orig = delta.original_text.lower()
        mod = delta.modified_text.lower()
        
        # Pure insertion
        if delta.change_type == "INSERT" and not delta.original_text:
            return "content_addition"
        
        # Pure deletion
        if delta.change_type == "DELETE" and not delta.modified_text:
            return "content_removal"
        
        # Word-level replacement (terminology)
        orig_words = set(orig.split())
        mod_words = set(mod.split())
        if len(orig_words) <= 3 and len(mod_words) <= 3:
            return "terminology_replacement"
        
        # Legal strengthening keywords
        legal_keywords = ["shall", "must", "required", "mandatory", "obligation", "comply"]
        if any(kw in mod for kw in legal_keywords):
            return "legal_strengthening"
        
        # Tone adjustment keywords
        tone_keywords = ["may", "can", "voluntary", "choose", "right to", "option"]
        if any(kw in mod for kw in tone_keywords):
            return "tone_adjustment"
        
        return "structural_change"
    
    def _infer_intent(self, delta: RawDelta, change_type: str) -> str:
        """Infer the intent behind the change."""
        intent_map = {
            "terminology_replacement": "Use regulatory-compliant terminology",
            "legal_strengthening": "Strengthen legal language for compliance",
            "tone_adjustment": "Adjust tone for clarity and consent emphasis",
            "content_addition": "Add required regulatory content",
            "content_removal": "Remove non-compliant or unnecessary content",
            "structural_change": "Restructure for regulatory compliance"
        }
        return intent_map.get(change_type, "General edit")
    
    def _calculate_confidence(self, delta: RawDelta) -> float:
        """Calculate confidence score for a change."""
        base_confidence = 0.80
        
        # Higher confidence for human (non-agent) edits
        if delta.author and "ICF-Regen-Agent" not in delta.author:
            base_confidence = 0.95
        
        # Slightly lower confidence for very long changes
        text_len = len(delta.modified_text or delta.original_text)
        if text_len > 200:
            base_confidence -= 0.05
        
        return min(1.0, max(0.0, base_confidence))
    
    def _is_study_specific(self, text: str) -> bool:
        """Check if text contains study-specific data (not generalizable for learning)."""
        study_patterns = [
            r'\d{1,2}/\d{1,2}/\d{2,4}',  # Dates
            r'\d+\s*(mg|ml|kg)',  # Doses
            r'NCT\d+',  # Clinical trial IDs
            r'Protocol\s+\w+-\d+',  # Protocol numbers
            r'Site\s+\d+',  # Site numbers
        ]
        
        for pattern in study_patterns:
            if re.search(pattern, text, re.IGNORECASE):
                return True
        
        return False
    
    def map_to_evidence(
        self,
        changes: List[SemanticChange],
        relevance_threshold: float = 0.0
    ) -> List[SemanticChange]:
        """
        Map each semantic change to RAG evidence chunks from icf-index-{country}.
        Applies 5 hard gates:
        1. evidence_chunk_ids required
        2. chunks exist in KB
        3. relevance >= threshold
        4. source whitelist (doctypeid from index)
        5. section scope matching (section_type from index)
        """
        self.logger.info(f"\n🔗 EVIDENCE MAPPING (threshold >= {relevance_threshold})")
        self.logger.info(f"   Valid doctypeids: {self.valid_doctypeids}")
        self.logger.info(f"   Valid section_types: {self.valid_section_types}")
        
        if not self.rag_store:
            self.logger.warning("  ⚠️ RAG store not available, skipping evidence mapping")
            return changes
        
        mapped_count = 0
        whitelist_rejected = 0
        scope_rejected = 0
        
        for change in changes:
            query_text = f"{change.section_title}: {change.modified_text}"
            
            try:
                results = self.rag_store.query_regulations(
                    query_text=query_text[:500],
                    top_k=5
                )
                
                evidence_ids = []
                for r in results:
                    # Gate 3: relevance threshold
                    score = r.get("@search.score", r.get("score", 0))
                    if score < relevance_threshold:
                        continue
                    
                    # Gate 4: source whitelist (doctypeid must exist in index)
                    doctypeid = r.get("doctypeid", 0)
                    if self.valid_doctypeids and doctypeid not in self.valid_doctypeids:
                        whitelist_rejected += 1
                        continue
                    
                    # Gate 5: section scope matching
                    evidence_section = r.get("section_type", "").lower()
                    change_section = (change.section_title or "").lower()
                    if evidence_section and evidence_section != "general" and self.valid_section_types:
                        if evidence_section not in change_section and change_section not in evidence_section:
                            has_match = any(
                                st in evidence_section and st in change_section 
                                for st in self.valid_section_types
                            )
                            if not has_match:
                                scope_rejected += 1
                                continue
                    
                    # Gates 1 & 2: chunk exists with valid ID
                    chunk_id = r.get("id", r.get("req_id", ""))
                    if chunk_id:
                        evidence_ids.append(chunk_id)
                
                if evidence_ids:
                    change.rag_ids_used = evidence_ids
                    change.evidence_found = True
                    mapped_count += 1
                else:
                    change.evidence_found = False
                    
            except Exception as e:
                self.logger.warning(f"  ⚠️ Evidence query failed for {change.change_id}: {e}")
                change.evidence_found = False
        
        self.logger.info(f"  ✓ Mapped {mapped_count}/{len(changes)} changes to evidence (>= {relevance_threshold})")
        if whitelist_rejected > 0:
            self.logger.info(f"  ✓ Rejected {whitelist_rejected} evidence chunks (source whitelist)")
        if scope_rejected > 0:
            self.logger.info(f"  ✓ Rejected {scope_rejected} evidence chunks (section scope)")
        return changes

    # =========================================================================
    # STAGE 2: Evidence Gate
    # =========================================================================
    
    def validate_evidence(
        self,
        changes: List[SemanticChange]
    ) -> Tuple[List[SemanticChange], Dict[str, Any]]:
        """Validate each change has supporting evidence from the RAG knowledge base."""
        self.logger.info("\n🔒 EVIDENCE GATE")

        if not changes:
            return [], {
                "validatedCount": 0,
                "rejectedCount": 0,
                "noEvidenceCount": 0,
                "avgRelevance": 0.0,
                "validatedChanges": [],
                "rejectedChanges": [],
                "generatedAt": datetime.utcnow().isoformat(),
            }

        if not self.rag_store:
            self.logger.warning("  ❌ RAG store not available - rejecting all changes until evidence can be verified")
            rejected = [
                self._serialize_validation_change(change, reason="RAG_UNAVAILABLE")
                for change in changes
            ]
            report = {
                "validatedCount": 0,
                "rejectedCount": len(rejected),
                "noEvidenceCount": len(rejected),
                "avgRelevance": 0.0,
                "validatedChanges": [],
                "rejectedChanges": rejected,
                "generatedAt": datetime.utcnow().isoformat(),
            }
            return [], report

        validated: List[SemanticChange] = []
        validated_details: List[Dict[str, Any]] = []
        rejected_details: List[Dict[str, Any]] = []
        relevances: List[float] = []
        no_evidence_count = 0

        for change in changes:
            query_text = f"{change.section_title}: {change.modified_text or change.original_text}"
            rag_ids: List[str] = []
            top_relevance = 0.0
            rejection_reason: Optional[str] = None

            try:
                results = self.rag_store.query_regulations(
                    query_text=query_text[:500],
                    top_k=2
                )

                if results:
                    rag_ids = [r.get("id", "") for r in results[:2] if r.get("id")]
                    scores = [r.get("score") for r in results if isinstance(r.get("score"), (int, float))]
                    top_relevance = max(scores) if scores else 0.0
            except Exception as e:
                rejection_reason = "EVIDENCE_QUERY_FAILED"
                self.logger.warning(f"  ⚠️ Evidence query failed for {change.change_id}: {e}")

            if rag_ids:
                change.evidence_found = True
                change.rag_ids_used = rag_ids
                change.rag_reference = rag_ids[0]
                change.evidence_relevance = top_relevance
                validated.append(change)
                validated_entry = self._serialize_validation_change(
                    change,
                    rag_ids=rag_ids,
                    evidence_relevance=top_relevance
                )
                validated_details.append(validated_entry)
                if top_relevance:
                    relevances.append(top_relevance)
            else:
                change.evidence_found = False
                no_evidence_count += 1
                rejected_details.append(
                    self._serialize_validation_change(change, reason=rejection_reason or "NO_EVIDENCE")
                )

        avg_relevance = sum(relevances) / len(relevances) if relevances else 0.0
        report = {
            "validatedCount": len(validated_details),
            "rejectedCount": len(rejected_details),
            "noEvidenceCount": no_evidence_count,
            "avgRelevance": round(avg_relevance, 2),
            "validatedChanges": validated_details,
            "rejectedChanges": rejected_details,
            "generatedAt": datetime.utcnow().isoformat(),
        }

        self.logger.info(f"  ✓ Validated: {len(validated)}/{len(changes)}")
        self.logger.info(f"  ✓ No evidence: {no_evidence_count}")

        return validated, report

    def _serialize_validation_change(
        self,
        change: SemanticChange,
        rag_ids: Optional[List[str]] = None,
        evidence_relevance: Optional[float] = None,
        reason: Optional[str] = None
    ) -> Dict[str, Any]:
        entry = {
            "changeId": change.change_id,
            "sectionId": change.section_id,
            "sectionTitle": change.section_title,
            "changeType": change.change_type,
            "intent": change.intent,
            "priority": change.priority,
            "confidence": round(change.confidence, 4),
            "source": change.source,
        }
        if rag_ids:
            entry["evidenceChunkIds"] = rag_ids
        if evidence_relevance is not None:
            entry["evidenceRelevance"] = round(evidence_relevance or 0.0, 4)
        if reason:
            entry["reason"] = reason
        return entry

    def _persist_validation_artifacts(
        self,
        icf_case_id: Optional[str],
        version: int,
        report: Dict[str, Any],
        country: Optional[str] = None
    ) -> Dict[str, str]:
        if not icf_case_id:
            return {}

        try:
            from azure.storage.blob import BlobServiceClient, ContentSettings  # type: ignore
        except ImportError:
            self.logger.warning("  ⚠️ Azure Blob SDK not available, skipping evidence artifact upload")
            return {}

        conn_str = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
        container = os.getenv("AZURE_STORAGE_CONTAINER_NAME", "icf-country-dev")
        if not conn_str:
            self.logger.warning("  ⚠️ Azure Storage connection string not configured for evidence artifacts")
            return {}

        try:
            blob_service = BlobServiceClient.from_connection_string(conn_str)
        except Exception as exc:
            self.logger.warning(f"  ⚠️ Unable to init BlobServiceClient: {exc}")
            return {}

        country_segment = (country or self.country or "").strip().lower()
        base_path = f"cases/{icf_case_id}"
        if country_segment:
            base_path += f"/{country_segment}"
        base_path += f"/versions/v{version}"
        uploads = {}
        artifacts = [
            ("evidence_validation.json", report),
            ("validated_changes.json", report.get("validatedChanges", [])),
            ("rejected_changes.json", report.get("rejectedChanges", []))
        ]

        for filename, payload in artifacts:
            blob_path = f"{base_path}/{filename}"
            try:
                blob_client = blob_service.get_blob_client(container=container, blob=blob_path)
                blob_client.upload_blob(
                    json.dumps(payload, indent=2, default=str),
                    overwrite=True,
                    content_settings=ContentSettings(content_type="application/json")
                )
                uploads[filename] = blob_client.url
                self.logger.info(f"  ✓ Uploaded evidence artifact: {blob_path}")
            except Exception as exc:
                self.logger.warning(f"  ⚠️ Failed to upload {blob_path}: {exc}")

        return uploads

    # =========================================================================
    # Budget Trimming (Drop lowest-priority changes when over budget)
    # =========================================================================
    
    def apply_budget_trim(
        self,
        changes: List[SemanticChange],
        original_word_count: int,
        rules: Optional[Dict[str, Any]] = None
    ) -> Tuple[List[SemanticChange], List[SemanticChange], Dict[str, Any]]:
        """
        Trim changes to stay within diff % and sections budget by dropping lowest-priority first.
        Preserves priority 1-2 unless budget still exceeded after dropping all lower-priority.

        Returns:
            (trimmed_changes, dropped_changes, audit_info)
        """
        if not changes:
            return [], [], {"trimmed": False}
        rules = rules or PUBLISHING_RULES
        max_diff = rules.get("max_diff_percent", 5.0)
        max_sections = rules.get("max_sections_changed", 10)

        def _metrics(ch: List[SemanticChange]) -> tuple:
            total_words = sum(len((c.modified_text or c.original_text).split()) for c in ch)
            diff_pct = (total_words / max(original_word_count, 1)) * 100
            section_keys = set((c.section_id or c.section_title or c.change_id) for c in ch)
            return min(diff_pct, 100.0), len(section_keys)

        diff_pct, sec_cnt = _metrics(changes)
        if diff_pct <= max_diff and sec_cnt <= max_sections:
            return changes, [], {"trimmed": False}

        # Sort by priority ascending (1 first); drop from end (lowest priority)
        sorted_changes = sorted(changes, key=lambda c: (c.priority, c.change_id))
        kept = list(sorted_changes)
        dropped = []

        while kept:
            d, s = _metrics(kept)
            if d <= max_diff and s <= max_sections:
                break
            # Remove last (lowest priority)
            removed = kept.pop()
            dropped.append(removed)

        # Audit info
        audit = {
            "trimmed": True,
            "original_count": len(changes),
            "kept_count": len(kept),
            "dropped_count": len(dropped),
            "dropped_priorities": [c.priority for c in dropped],
            "final_diff_percent": _metrics(kept)[0],
            "final_sections_changed": _metrics(kept)[1],
        }
        self.logger.info(
            f"  📉 Budget trim: dropped {len(dropped)} changes (priorities {audit['dropped_priorities']}), "
            f"kept {len(kept)}, diff={audit['final_diff_percent']:.1f}%, sections={audit['final_sections_changed']}"
        )
        track_event("BudgetTrimApplied", audit)
        return kept, dropped, audit

    # =========================================================================
    # STAGE 3: Query Learning Context
    # =========================================================================
    
    def query_learning_context(
        self,
        section_title: str,
        text: str,
        top_k: int = 3
    ) -> List[Dict]:
        """
        Query past corrections for similar sections.
        Returns learning context for enhanced LLM prompts.
        
        Args:
            section_title: Title of the section being edited
            text: Text content to find similar corrections for
            top_k: Number of results to return
        
        Returns:
            List of past correction examples
        """
        if not self.search_client:
            return []
        
        try:
            results = self.search_client.search(
                search_text=f"{section_title} {text[:200]}",
                filter=f"country eq '{self.country}' and is_superseded eq false",
                top=top_k,
                select=["ai_output", "human_output", "section_type", "confidence"]
            )
            
            context = []
            for r in results:
                context.append({
                    "ai_text": r.get("ai_output", ""),
                    "human_text": r.get("human_output", ""),
                    "section_type": r.get("section_type", ""),
                    "confidence": r.get("confidence", 0)
                })
            
            return context
            
        except Exception as e:
            self.logger.warning(f"  ⚠️ Learning context query failed: {e}")
            return []
    
    def build_learning_context_prompt(self, learning_context: List[Dict]) -> str:
        """
        Build a prompt section from learning context for LLM.
        
        Args:
            learning_context: List of past correction examples
        
        Returns:
            Formatted string for inclusion in LLM prompt
        """
        if not learning_context:
            return ""
        
        lines = ["\nLEARNING FROM PAST REVIEWS:"]
        lines.append("The following are corrections that human reviewers made to previously generated documents for this country.")
        lines.append("For each change driven by a past correction, use the artifact ID in the source field like: [LEARNING - ID <artifact_id>]\n")
        for i, ctx in enumerate(learning_context[:5], 1):
            if ctx.get("ai_text") and ctx.get("human_text"):
                artifact_id = ctx.get('id', 'unknown')
                score_info = f" (relevance: {ctx['match_score']})" if ctx.get("match_score") else ""
                lines.append(f"Past Correction #{i} [ID: {artifact_id}] - \"{ctx.get('section_type', 'section')}\"{score_info}:")
                lines.append(f"   AI originally wrote: \"{ctx['ai_text'][:200]}\"")
                lines.append(f"   Human corrected to: \"{ctx['human_text'][:200]}\"")
                if ctx.get("intent"):
                    lines.append(f"   Intent: {ctx['intent'][:100]}")
                lines.append("")
        
        return "\n".join(lines)

    def get_total_artifact_count(self) -> int:
        """
        Return the total number of non-superseded learning artifacts
        stored for this country.
        """
        if not self.search_client:
            return 0
        try:
            results = self.search_client.search(
                search_text="*",
                filter=f"country eq '{self.country}' and is_superseded eq false",
                top=0,
                include_total_count=True
            )
            return results.get_count() or 0
        except Exception as e:
            self.logger.warning(f"  ⚠️ Artifact count query failed: {e}")
            return 0

    # =========================================================================
    # STAGE 3b: Batch Fetch + Multi-Strategy Matching (v2)
    # =========================================================================

    # Minimal stop words for token-overlap scoring
    _STOP_WORDS = frozenset({
        'a', 'an', 'the', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for',
        'of', 'with', 'by', 'from', 'as', 'is', 'was', 'are', 'were', 'be',
        'been', 'being', 'have', 'has', 'had', 'do', 'does', 'did', 'will',
        'would', 'could', 'should', 'may', 'might', 'shall', 'can', 'need',
        'that', 'this', 'these', 'those', 'it', 'its', 'not', 'no', 'nor',
        'if', 'then', 'than', 'so', 'up', 'out', 'about', 'into', 'over',
        'after', 'before', 'between', 'under', 'your', 'you', 'we', 'they',
        'i', 'me', 'my', 'our', 'he', 'she', 'him', 'her', 'his', 'any',
        'all', 'each', 'some', 'such', 'also', 'only', 'more', 'most',
        'other', 'very', 'just', 'now', 'here', 'there', 'when', 'where',
        'how', 'what', 'which', 'who', 'whom', 'why',
    })

    @staticmethod
    def _tokenize(text: str) -> set:
        """Split text into lower-case meaningful tokens (stop words removed)."""
        return set(re.split(r'\W+', text.lower())) - LearnPipeline._STOP_WORDS - {''}

    def fetch_all_country_artifacts(self) -> List[Dict]:
        """
        Fetch ALL non-superseded learning artifacts for this country in one call.
        Returns a list of artifact dicts with all fields needed for matching.
        Handles pagination for >50 results.
        """
        if not self.search_client:
            return []

        all_artifacts = []
        try:
            results = self.search_client.search(
                search_text="*",
                filter=f"country eq '{self.country}' and is_superseded eq false",
                top=1000,
                select=[
                    "id", "section_type", "ai_output", "human_output",
                    "context", "intent", "confidence", "source_document_id",
                    "icf_case_id", "priority"
                ]
            )

            for r in results:
                all_artifacts.append({
                    "id": r.get("id", ""),
                    "section_type": r.get("section_type", ""),
                    "ai_output": r.get("ai_output", ""),
                    "human_output": r.get("human_output", ""),
                    "context": r.get("context", ""),
                    "intent": r.get("intent", ""),
                    "confidence": r.get("confidence", 0),
                    "source_document_id": r.get("source_document_id", ""),
                    "icf_case_id": r.get("icf_case_id", ""),
                    "priority": r.get("priority", 3),
                })

            self.logger.info(f"  📚 Fetched {len(all_artifacts)} learning artifacts for {self.country}")
            return all_artifacts

        except Exception as e:
            self.logger.warning(f"  ⚠️ Batch artifact fetch failed: {e}")
            return []

    def match_artifacts_to_section(
        self,
        section_heading: str,
        section_text: str,
        all_artifacts: List[Dict],
        top_k: int = 5,
        min_score: float = 10.0
    ) -> List[Dict]:
        """
        Multi-strategy local matching of artifacts against a document section.

        Scoring strategies (max 100 points):
          1. section_type ↔ heading token overlap     (max 40)
          2. section_type substring containment        (max 25)
          3. ai_output ↔ section text token overlap    (max 25)
          4. intent keywords ↔ section text overlap    (max 10)

        Returns top_k artifacts above min_score, formatted for build_learning_context_prompt().

        Args:
            section_heading: Heading of the section in the document
            section_text: Full text content of the section
            all_artifacts: Pre-fetched artifact list from fetch_all_country_artifacts()
            top_k: Maximum number of artifacts to return per section
            min_score: Minimum composite score to include (0-100 scale)

        Returns:
            List of matched artifacts sorted by score descending, each with:
            ai_text, human_text, section_type, confidence, match_score
        """
        if not all_artifacts:
            return []

        heading_tokens = self._tokenize(section_heading)
        text_tokens = self._tokenize(section_text[:2000])
        heading_lower = section_heading.lower().strip()

        scored = []
        for artifact in all_artifacts:
            score = 0.0
            section_type = artifact.get("section_type", "")
            section_type_lower = section_type.lower().strip()
            type_tokens = self._tokenize(section_type)

            # ---- Strategy 1: section_type ↔ heading token overlap (max 40) ---
            if type_tokens and heading_tokens:
                overlap = type_tokens & heading_tokens
                score += (len(overlap) / len(type_tokens)) * 40

            # ---- Strategy 2: Substring containment bonus (max 25) -----------
            if section_type_lower and heading_lower:
                if section_type_lower in heading_lower or heading_lower in section_type_lower:
                    score += 25

            # ---- Strategy 3: ai_output ↔ section text overlap (max 25) -----
            ai_output = artifact.get("ai_output", "")
            if ai_output and len(ai_output) > 10:
                ai_tokens = self._tokenize(ai_output)
                if ai_tokens and text_tokens:
                    overlap = ai_tokens & text_tokens
                    score += (len(overlap) / len(ai_tokens)) * 25

            # ---- Strategy 4: intent ↔ section text overlap (max 10) --------
            intent = artifact.get("intent", "")
            intent_tokens = self._tokenize(intent)
            if intent_tokens and text_tokens:
                overlap = intent_tokens & text_tokens
                score += (len(overlap) / len(intent_tokens)) * 10

            if score >= min_score:
                scored.append((score, artifact))

        # Sort by score descending, take top_k
        scored.sort(key=lambda x: x[0], reverse=True)
        top_matches = scored[:top_k]

        # Format for build_learning_context_prompt()
        result = []
        for match_score, artifact in top_matches:
            result.append({
                "id": artifact.get("id", ""),
                "ai_text": artifact.get("ai_output", ""),
                "human_text": artifact.get("human_output", ""),
                "section_type": artifact.get("section_type", ""),
                "confidence": artifact.get("confidence", 0),
                "match_score": round(match_score, 1),
            })

        return result

    # =========================================================================
    # STAGE 4: Index Learning Artifacts
    # =========================================================================
    
    def index_learning_artifacts(
        self,
        changes: List[SemanticChange],
        document_id: str,
        version: int,
        icf_case_id: str = "",
        iteration_id: int = 1
    ) -> int:
        """
        Index learning candidates as Learn Pipeline preference pairs.
        - Only indexes pairs where BOTH ai_output AND human_output have content
        - Deduplicates: same (ai_output, human_output) pair only stored once per document
        - Includes evidence_ids from RAG mapping and intent from LLM
        - Tracks icf_case_id and iteration_id for version conflict resolution
        """
        self.logger.info("\n📚 INDEXING LEARNING ARTIFACTS")
        
        if not self.search_client:
            self.logger.warning("  ⚠️ Search client not available, skipping indexing")
            return 0
        
        # Filter to learning candidates with BOTH ai_output and human_output
        learning_candidates = [
            c for c in changes 
            if c.is_learning_candidate 
            and c.original_text.strip()
            and c.modified_text.strip()
        ]
        
        if not learning_candidates:
            self.logger.info("  ℹ️ No valid Learn Pipeline pairs to index (need both ai_output and human_output)")
            return 0
        
        self.logger.info(f"  ✓ Found {len(learning_candidates)} valid Learn Pipeline pairs")
        
        # Deduplicate within same document using (ai_output, human_output) hash
        seen_pairs: set = set()
        unique_candidates = []
        
        for change in learning_candidates:
            pair_key = (
                change.original_text.strip().lower(),
                change.modified_text.strip().lower()
            )
            
            if pair_key not in seen_pairs:
                seen_pairs.add(pair_key)
                unique_candidates.append(change)
        
        duplicates_removed = len(learning_candidates) - len(unique_candidates)
        if duplicates_removed > 0:
            self.logger.info(f"  ✓ Removed {duplicates_removed} duplicate pairs within document")
        
        self.logger.info(f"  ✓ Indexing {len(unique_candidates)} unique Learn Pipeline pairs")
        
        documents = []
        for change in unique_candidates:
            pair_id = f"{document_id}_{change.change_id}_{uuid.uuid4().hex[:8]}"
            
            section = change.section_title if change.section_title else change.change_type
            
            pair = DPOPreferencePair(
                pair_id=pair_id,
                country=self.country,
                section_type=section,
                ai_output=change.original_text,
                human_output=change.modified_text,
                context=f"{section}: {change.modified_text[:100]}",
                intent=change.intent,
                confidence=change.confidence,
                priority=change.priority,
                source_document_id=document_id,
                evidence_ids=change.rag_ids_used,
                version=version,
                icf_case_id=icf_case_id,
                iteration_id=iteration_id,
                is_superseded=False
            )
            
            if self.openai_client:
                try:
                    embedding = self._generate_embedding(
                        f"{pair.ai_output} -> {pair.human_output} | {pair.intent}"
                    )
                    pair.embedding = embedding
                except Exception as e:
                    self.logger.warning(f"  ⚠️ Embedding failed for {pair_id}: {e}")
            
            documents.append(pair.to_index_doc())
        
        try:
            result = self.search_client.upload_documents(documents=documents)
            indexed = sum(1 for r in result if r.succeeded)
            self.logger.info(f"  ✓ Indexed {indexed}/{len(documents)} unique Learn Pipeline pairs")
            track_event("ArtifactIndexed", {
                "country": self.country,
                "icf_case_id": document_id,
                "iteration_id": str(version),
                "artifacts_indexed": str(indexed),
                "total_candidates": str(len(documents))
            })
            return indexed
        except Exception as e:
            self.logger.error(f"  ⚠️ Indexing failed: {e}")
            track_exception(e, {"pipeline": "learning_artifacts", "stage": "index_learning_artifacts"})
            return 0
    
    def _generate_embedding(self, text: str) -> List[float]:
        """Generate embedding using Azure OpenAI."""
        response = self.openai_client.embeddings.create(
            input=text[:8000],
            model=self.embedding_deployment
        )
        return response.data[0].embedding

    # =========================================================================
    # SUPERSEDING & ARTIFACT UPLOAD
    # =========================================================================

    def mark_previous_artifacts_superseded(
        self,
        icf_case_id: str,
        new_iteration_id: int
    ) -> int:
        """
        Mark all artifacts from previous iterations as superseded.
        Called when a new iteration arrives to handle version conflicts.

        Args:
            icf_case_id: ICF case identifier
            new_iteration_id: The new iteration number (previous ones get superseded)

        Returns:
            Number of artifacts marked as superseded
        """
        self.logger.info(f"\n🔄 SUPERSEDING previous artifacts for case={icf_case_id}, new_iter={new_iteration_id}")

        if not self.search_client:
            self.logger.warning("  ⚠️ Search client not available, skipping superseding")
            return 0

        try:
            results = self.search_client.search(
                search_text="*",
                filter=f"icf_case_id eq '{icf_case_id}' and iteration_id lt {new_iteration_id} and is_superseded eq false",
                top=1000,
                select=["id", "iteration_id"]
            )

            docs_to_update = []
            for r in results:
                docs_to_update.append({
                    "id": r["id"],
                    "is_superseded": True,
                    "superseded_by": f"iter-{new_iteration_id}"
                })

            if not docs_to_update:
                self.logger.info("  ℹ️ No previous artifacts to supersede")
                return 0

            result = self.search_client.merge_documents(documents=docs_to_update)
            superseded = sum(1 for r in result if r.succeeded)
            self.logger.info(f"  ✓ Superseded {superseded} artifacts from previous iterations")
            return superseded

        except Exception as e:
            self.logger.warning(f"  ⚠️ Superseding failed: {e}")
            return 0

    def upload_artifact_json(
        self,
        artifacts_data: Dict[str, Any],
        icf_case_id: str,
        country: str,
        iteration_id: int
    ) -> Optional[str]:
        """
        Upload semantic artifact JSON to Azure Blob Storage.
        Path: cases/{icfCaseId}/{country}/artifacts/iter-{n}_semantic_feedback.json

        Args:
            artifacts_data: Artifact data dict to serialize as JSON
            icf_case_id: ICF case identifier
            country: Country name
            iteration_id: Iteration number

        Returns:
            Blob URL if successful, None otherwise
        """
        import json

        try:
            from azure.storage.blob import BlobServiceClient, ContentSettings
        except ImportError:
            self.logger.warning("  ⚠️ Azure Blob SDK not available for artifact upload")
            return None

        conn_str = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
        container_name = os.getenv("AZURE_STORAGE_CONTAINER_NAME", "icf-country-dev")

        if not conn_str:
            self.logger.warning("  ⚠️ Azure Storage connection string not configured")
            return None

        blob_path = f"cases/{icf_case_id}/{country.lower()}/artifacts/iter-{iteration_id}_semantic_feedback.json"

        try:
            blob_service = BlobServiceClient.from_connection_string(conn_str)
            blob_client = blob_service.get_blob_client(
                container=container_name,
                blob=blob_path
            )

            json_content = json.dumps(artifacts_data, indent=2, default=str)

            content_settings = ContentSettings(content_type='application/json')
            blob_client.upload_blob(
                json_content,
                overwrite=True,
                content_settings=content_settings
            )

            blob_url = blob_client.url
            self.logger.info(f"  ✓ Uploaded artifact JSON: {blob_path}")
            return blob_url

        except Exception as e:
            self.logger.error(f"  ⚠️ Artifact JSON upload failed: {e}")
            return None

    def delete_iteration_artifacts(self, icf_case_id: str, iteration_id: int) -> int:
        """
        Delete all existing artifacts for a specific icf_case_id + iteration_id.
        Prevents duplicates when re-running the same iteration.
        
        Returns:
            Number of documents deleted
        """
        try:
            filter_expr = f"icf_case_id eq '{icf_case_id}' and iteration_id eq {iteration_id}"
            results = self.search_client.search(
                search_text="*",
                filter=filter_expr,
                select=["id"],
                top=1000
            )
            
            ids_to_delete = [doc["id"] for doc in results]
            
            if not ids_to_delete:
                self.logger.info(f"  ℹ️ No existing artifacts for case={icf_case_id} iter={iteration_id}")
                return 0
            
            batch = [{"@search.action": "delete", "id": doc_id} for doc_id in ids_to_delete]
            self.search_client.upload_documents(documents=batch)
            self.logger.info(f"  🗑️ Deleted {len(ids_to_delete)} existing artifacts for case={icf_case_id} iter={iteration_id}")
            return len(ids_to_delete)
            
        except Exception as e:
            self.logger.warning(f"  ⚠️ Error deleting iteration artifacts: {e}")
            return 0

    def run_learn_only_pipeline(
        self,
        reviewed_path: str,
        icf_case_id: str,
        iteration_id: int,
        section_map: Optional[Dict[str, str]] = None,
        comments: List[Dict] = None,
        base_doc_path: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Run Learn-Only pipeline: extract + index artifacts WITHOUT regeneration.

        Stages:
        1. Mark previous iteration artifacts as superseded
        2. Extract semantic changes (track changes + comments)
        3. Map to RAG evidence (5 hard gates)
        4. Index new learning artifacts
        5. Upload artifact JSON to blob

        Args:
            reviewed_path: Path to reviewed DOCX file
            icf_case_id: ICF case identifier
            iteration_id: Feedback iteration number
            section_map: Optional paragraph_id -> section_title mapping
            comments: Client comments with linked_text

        Returns:
            Dict with pipeline results including artifacts, counts, blob_url
        """
        self.logger.info(f"\n{'='*60}")
        self.logger.info(f"📖 LEARN-ONLY PIPELINE: case={icf_case_id} iter={iteration_id}")
        self.logger.info(f"   Country: {self.country.upper()}")
        self.logger.info(f"{'='*60}")
        
        track_event("LearningStarted", {
            "icf_case_id": icf_case_id,
            "country": self.country,
            "iteration_id": str(iteration_id)
        })

        result = {
            "artifacts": [],
            "artifacts_indexed": 0,
            "artifacts_superseded": 0,
            "track_changes_extracted": 0,
            "comments_extracted": 0,
            "intent_count": 0,
            "instruction_count": 0,
            "artifact_blob_url": None,
            "success": False,
            # Evidence gate fields (populated in Stage 4b)
            "validation_report": None,
            "evidence_artifact_urls": {},
            "can_publish": True,
            "publishing_blocked_reasons": [],
            "no_evidence_count": 0,
        }

        # Stage 1a: Delete any existing artifacts for THIS iteration (prevents duplicates on re-run)
        deleted = self.delete_iteration_artifacts(icf_case_id, iteration_id)
        
        # Stage 1b: Supersede previous iteration artifacts
        if iteration_id > 1:
            result["artifacts_superseded"] = self.mark_previous_artifacts_superseded(
                icf_case_id, iteration_id
            )

        # Stage 2: Extract semantic changes (SemanticIntent from track changes + RegenerationInstruction from comments)
        changes = self.extract_semantic_changes(reviewed_path, section_map, comments=comments, base_doc_path=base_doc_path)

        if not changes:
            self.logger.info("  ℹ️ No semantic changes found")
            result["success"] = True
            return result

        # Count sources
        result["track_changes_extracted"] = sum(1 for c in changes if c.source == "track_change")
        result["comments_extracted"] = sum(1 for c in changes if c.source == "comment")
        result["intent_count"] = len(getattr(self, '_last_semantic_intents', []))
        result["instruction_count"] = len(getattr(self, '_last_regeneration_instructions', []))

        # Stage 3: Map to RAG evidence (5 hard gates)
        changes_with_evidence = self.map_to_evidence(changes, relevance_threshold=0.0)

        # Stage 4: Index learning artifacts
        result["artifacts_indexed"] = self.index_learning_artifacts(
            changes_with_evidence,
            document_id=icf_case_id,
            version=iteration_id,
            icf_case_id=icf_case_id,
            iteration_id=iteration_id
        )

        # Stage 4b: Evidence validation + publishing gate
        validated_changes, validation_report = self.validate_evidence(changes_with_evidence)
        country_segment = (self.country or "").strip().lower()
        evidence_artifacts = self._persist_validation_artifacts(
            icf_case_id, iteration_id, validation_report, country=country_segment
        )
        no_evidence_count = validation_report.get("noEvidenceCount", 0)
        metrics = self.calculate_metrics(
            validated_changes, 5000, no_evidence_count, result["artifacts_indexed"]
        )
        gate_result = self.check_publishing_rules(metrics)

        result["validation_report"] = validation_report
        result["evidence_artifact_urls"] = evidence_artifacts
        result["can_publish"] = gate_result.can_publish
        result["publishing_blocked_reasons"] = gate_result.rejection_reasons
        result["no_evidence_count"] = no_evidence_count

        # Build artifact list for callback
        from models.models import SemanticArtifact
        for i, change in enumerate(changes_with_evidence):
            artifact = SemanticArtifact(
                artifact_id=f"{icf_case_id}_iter{iteration_id}_SC-{i:04d}",
                source=change.source,
                section_title=change.section_title,
                change_type=change.change_type,
                ai_output=change.original_text,
                human_output=change.modified_text,
                intent=change.intent,
                priority=change.priority,
                confidence=change.confidence,
                evidence_ids=change.rag_ids_used,
                evidence_relevance=change.evidence_relevance
            )
            result["artifacts"].append(artifact)

        # Stage 5: Upload artifact JSON to blob
        artifacts_data = {
            "icf_case_id": icf_case_id,
            "country": self.country,
            "iteration_id": iteration_id,
            "timestamp": datetime.utcnow().isoformat(),
            "artifacts_count": len(result["artifacts"]),
            "artifacts_superseded": result["artifacts_superseded"],
            "artifacts": [a.model_dump() for a in result["artifacts"]]
        }

        result["artifact_blob_url"] = self.upload_artifact_json(
            artifacts_data, icf_case_id, self.country, iteration_id
        )

        result["success"] = True

        self.logger.info(f"\n{'='*60}")
        self.logger.info(f"📊 LEARN-ONLY COMPLETE")
        self.logger.info(f"   Changes extracted: {len(changes)}")
        self.logger.info(f"   Artifacts indexed: {result['artifacts_indexed']}")
        self.logger.info(f"   Artifacts superseded: {result['artifacts_superseded']}")
        self.logger.info(f"   Blob uploaded: {'✅' if result['artifact_blob_url'] else '❌'}")
        self.logger.info(f"{'='*60}")
        
        track_event("LearningCompleted", {
            "icf_case_id": icf_case_id,
            "country": self.country,
            "iteration_id": str(iteration_id),
            "artifacts_indexed": str(result['artifacts_indexed']),
            "artifacts_superseded": str(result['artifacts_superseded']),
            "changes_extracted": str(len(changes))
        })

        return result

    # =========================================================================
    # STAGE 5: Calculate Metrics
    # =========================================================================
    
    def calculate_metrics(
        self,
        changes: List[SemanticChange],
        original_word_count: int,
        no_evidence_count: int,
        artifacts_indexed: int
    ) -> PublishingMetrics:
        """
        Calculate publishing metrics from changes.
        
        Args:
            changes: List of applied changes
            original_word_count: Word count of original document
            no_evidence_count: Count of changes without evidence
            artifacts_indexed: Count of learning artifacts indexed
        
        Returns:
            PublishingMetrics object
        """
        # Count by type
        added = sum(1 for c in changes if c.change_type == "content_addition")
        removed = sum(1 for c in changes if c.change_type == "content_removal")
        modified = len(changes) - added - removed
        
        # Calculate diff percentage
        total_change_words = sum(
            len((c.modified_text or c.original_text).split())
            for c in changes
        )
        diff_percent = (total_change_words / max(original_word_count, 1)) * 100
        
        # Count unique sections changed
        sections = set(c.section_id for c in changes if c.section_id)
        
        # Calculate average confidence
        confidences = [c.confidence for c in changes]
        avg_conf = sum(confidences) / len(confidences) if confidences else 0.0
        
        return PublishingMetrics(
            diff_percent=min(diff_percent, 100.0),
            sections_changed=len(sections),
            added_count=added,
            removed_count=removed,
            modified_count=modified,
            no_evidence_count=no_evidence_count,
            avg_confidence=avg_conf,
            artifacts_indexed=artifacts_indexed,
            total_changes=len(changes)
        )

    # =========================================================================
    # STAGE 6: Publishing Gate
    # =========================================================================
    
    def check_publishing_rules(
        self,
        metrics: PublishingMetrics
    ) -> PublishingGateResult:
        """
        Validate metrics against publishing rules.
        
        Args:
            metrics: Calculated publishing metrics
        
        Returns:
            PublishingGateResult with can_publish flag and reasons
        """
        self.logger.info("\n🚦 PUBLISHING GATE")
        
        reasons = []
        
        # Rule 1: Evidence required
        if PUBLISHING_RULES["require_evidence"] and metrics.no_evidence_count > 0:
            reasons.append(
                f"REVIEW_REQUIRED: {metrics.no_evidence_count} change(s) missing supporting evidence"
            )
        
        # Rule 2: Max diff percentage
        if metrics.diff_percent > PUBLISHING_RULES["max_diff_percent"]:
            reasons.append(
                f"Diff too large: {metrics.diff_percent:.1f}% (max {PUBLISHING_RULES['max_diff_percent']}%)"
            )
        
        # Rule 3: Max sections changed
        if metrics.sections_changed > PUBLISHING_RULES["max_sections_changed"]:
            reasons.append(
                f"Too many sections modified: {metrics.sections_changed} (max {PUBLISHING_RULES['max_sections_changed']})"
            )
        
        can_publish = len(reasons) == 0
        
        if can_publish:
            self.logger.info("  ✅ PASSED - Document can be published")
        else:
            self.logger.warning("  ❌ BLOCKED - Publishing not allowed:")
            for r in reasons:
                self.logger.warning(f"     - {r}")
        
        return PublishingGateResult(
            can_publish=can_publish,
            rejection_reasons=reasons,
            metrics=metrics
        )

    # =========================================================================
    # FULL PIPELINE
    # =========================================================================
    
    def run_full_pipeline(
            self,
            reviewed_path: str,
            document_id: str,
            version: int,
            original_word_count: int = 5000,
            section_map: Optional[Dict[str, str]] = None,
            comments: List[Dict] = None,
            icf_case_id: Optional[str] = None,
            country: Optional[str] = None
        ) -> PublishingGateResult:
            """
            Run the complete Learn Pipeline.
            
            Args:
                reviewed_path: Path to reviewed DOCX file
                document_id: Unique document identifier
                version: Document version number
                original_word_count: Word count for diff calculation
                section_map: Optional paragraph_id -> section_title mapping
                comments: Client comments with linked_text for learning
            
            Returns:
                PublishingGateResult with can_publish flag, reasons, and metrics
            """
            self.logger.info(f"\n{'='*60}")
            self.logger.info(f"🔄 Learn Pipeline: {document_id} v{version}")
            self.logger.info(f"   Country: {self.country.upper()}")
            self.logger.info(f"{'='*60}")
            
            # Stage 1: Extract semantic changes (client only, LLM-analyzed)
            changes = self.extract_semantic_changes(reviewed_path, section_map, comments=comments)
        
            if not changes:
                self.logger.info("  ℹ️ No semantic changes found")
                metrics = PublishingMetrics()
                return PublishingGateResult(can_publish=True, metrics=metrics)
            
            # Stage 2: Map to RAG evidence (relevance >= 0.7)
            changes_with_evidence = self.map_to_evidence(changes, relevance_threshold=0.0)
            
            case_identifier = icf_case_id or document_id
            country_segment = (country or self.country)

            # Stage 3: Validate evidence gate
            validated_changes, validation_report = self.validate_evidence(changes_with_evidence)
            no_evidence_count = validation_report.get("noEvidenceCount", 0)
            evidence_artifacts = self._persist_validation_artifacts(
                case_identifier,
                version,
                validation_report,
                country=country_segment
            )
            
            # Stage 3b: Budget trim (drop lowest-priority when over budget)
            trimmed_changes, _dropped, _audit = self.apply_budget_trim(
                validated_changes, original_word_count
            )
            validated_changes = trimmed_changes
            
            # Stage 4: Index learning artifacts
            artifacts_indexed = self.index_learning_artifacts(
                validated_changes, document_id, version,
                icf_case_id=case_identifier,
                iteration_id=version
            )
            
            # Stage 5: Calculate metrics
            metrics = self.calculate_metrics(
                validated_changes,
                original_word_count,
                no_evidence_count,
                artifacts_indexed
            )
            
            # Stage 6: Check publishing rules
            result = self.check_publishing_rules(metrics)
            result.validation_report = validation_report
            result.evidence_artifact_urls = evidence_artifacts
            
            self.logger.info(f"\n{'='*60}")
            self.logger.info(f"📊 PIPELINE COMPLETE")
            self.logger.info(f"   Changes: {metrics.total_changes}")
            self.logger.info(f"   Diff: {metrics.diff_percent:.1f}%")
            self.logger.info(f"   Artifacts indexed: {metrics.artifacts_indexed}")
            self.logger.info(f"   Can Publish: {'✅ YES' if result.can_publish else '❌ NO'}")
            self.logger.info(f"{'='*60}")
            
            return result