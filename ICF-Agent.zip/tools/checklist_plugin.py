"""
Semantic Kernel plugin for Checklist Validator to enable dynamic checklist queries by agents.
"""

from typing import Annotated
from semantic_kernel.functions import kernel_function
from tools.checklist_validator import ChecklistValidator
import json


class ChecklistPlugin:
    """
    Semantic Kernel plugin that wraps ChecklistValidator for dynamic checklist queries.
    Allows agents (especially QA agent) to query country-specific checklists during validation.
    """
    
    def __init__(self):
        """Initialize the checklist plugin with ChecklistValidator."""
        self.checklist_validator = ChecklistValidator()
    
    @kernel_function(
        description="Query country-specific checklists (HIPAA for USA, PIPEDA for Canada, country checklists). Use this to dynamically retrieve checklist requirements during validation. Returns checklist items with requirements.",
        name="query_checklist"
    )
    def query_checklist(
        self,
        country: Annotated[str, "Target country code (e.g., 'USA', 'CAN')"],
        checklist_type: Annotated[str, "Type of checklist: 'HIPAA' (USA), 'PIPEDA' (Canada), or 'country' (general country checklist)"],
        query: Annotated[str, "Natural language query describing what to check (e.g., 'data privacy requirements', 'patient consent procedures')"],
        top_k: Annotated[int, "Number of checklist items to retrieve (default: 10, max: 20)"] = 10
    ) -> str:
        """
        Query country-specific checklist using hybrid search.
        
        This function enables dynamic checklist queries - agents can call this during
        validation to retrieve relevant checklist requirements on-demand.
        
        Args:
            country: Target country code
            checklist_type: Type of checklist (HIPAA, PIPEDA, country)
            query: Natural language query describing what to check
            top_k: Number of results to return (default 10, max 20)
            
        Returns:
            JSON-formatted string with checklist items and requirements
        """
        try:
            # Limit top_k to prevent excessive results
            top_k = min(top_k, 20)
            top_k = max(top_k, 1)
            
            # Query checklist validator
            checklist_items = self.checklist_validator.query_checklist(
                country=country,
                checklist_type=checklist_type,
                query=query,
                top_k=top_k
            )
            
            # Format results as JSON string for agent consumption
            result_json = {
                "query": query,
                "country": country,
                "checklist_type": checklist_type,
                "results_count": len(checklist_items),
                "checklist_items": checklist_items
            }
            
            return json.dumps(result_json, indent=2)
            
        except Exception as e:
            error_result = {
                "query": query,
                "country": country,
                "checklist_type": checklist_type,
                "error": str(e),
                "results_count": 0,
                "checklist_items": []
            }
            return json.dumps(error_result)
    
    @kernel_function(
        description="Get available checklist types for a country. Use this to determine which checklists are available for validation (e.g., USA has HIPAA and country checklists, Canada has PIPEDA and country checklists).",
        name="get_checklist_types"
    )
    def get_checklist_types(
        self,
        country: Annotated[str, "Target country code (e.g., 'USA', 'CAN')"]
    ) -> str:
        """
        Get checklist types available for a country.
        
        Args:
            country: Target country code
            
        Returns:
            JSON-formatted string with available checklist types
        """
        try:
            checklist_types = self.checklist_validator.get_checklist_types_for_country(country)
            
            result_json = {
                "country": country,
                "checklist_types": checklist_types
            }
            
            return json.dumps(result_json, indent=2)
            
        except Exception as e:
            error_result = {
                "country": country,
                "error": str(e),
                "checklist_types": []
            }
            return json.dumps(error_result)

