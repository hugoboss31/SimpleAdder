#!/bin/bash
# Bash script for manual deployment to Azure App Service (Linux/Mac)
# Usage: bash .azure/deploy.sh

RESOURCE_GROUP="USE2-HEX-POC-RG001"
APP_SERVICE_NAME="ICF-COUNTRY-AGENT"
SUBSCRIPTION_ID="8aa051f5-1b27-4195-99b6-bb50177a87ea"

echo "========================================"
echo "ICF Agent - Azure App Service Deployment"
echo "========================================"
echo ""

# Check if Azure CLI is installed
if ! command -v az &> /dev/null; then
    echo "❌ Azure CLI not found. Please install it first."
    echo "Download from: https://aka.ms/installazurecli"
    exit 1
fi

# Login check
echo "🔐 Checking Azure login..."
if ! az account show &> /dev/null; then
    echo "Please login to Azure..."
    az login
fi

# Set subscription
echo "📋 Setting subscription..."
az account set --subscription "$SUBSCRIPTION_ID"
echo "✅ Subscription set to: $SUBSCRIPTION_ID"

# Create deployment package
echo ""
echo "📦 Creating deployment package..."
DEPLOY_ZIP="deploy-$(date +%Y%m%d-%H%M%S).zip"

# Create zip excluding unnecessary files
zip -r "$DEPLOY_ZIP" . \
    -x "*.git*" \
    -x "*.venv*" \
    -x "*.env*" \
    -x "__pycache__/*" \
    -x "*.pyc" \
    -x "*.pyo" \
    -x "*.pyd" \
    -x ".pytest_cache/*" \
    -x "*.md" \
    -x "*.log" \
    -x "output/*" \
    -x "logs/*" \
    -x "median/*" \
    -x "uploads/*" \
    -x "venv/*" \
    -x ".git/*" \
    -x ".vscode/*" \
    -x ".idea/*"

if [ $? -eq 0 ]; then
    echo "✅ Deployment package created: $DEPLOY_ZIP"
else
    echo "❌ Error creating deployment package"
    exit 1
fi

# Deploy to App Service
echo ""
echo "🚀 Deploying to Azure App Service..."
echo "   App Service: $APP_SERVICE_NAME"
echo "   Resource Group: $RESOURCE_GROUP"
echo ""

az webapp deployment source config-zip \
    --resource-group "$RESOURCE_GROUP" \
    --name "$APP_SERVICE_NAME" \
    --src "$DEPLOY_ZIP"

if [ $? -eq 0 ]; then
    echo ""
    echo "✅ Deployment completed successfully!"
    echo ""
    echo "🌐 Application URL:"
    APP_URL=$(az webapp show --name "$APP_SERVICE_NAME" --resource-group "$RESOURCE_GROUP" --query defaultHostName -o tsv)
    echo "   https://$APP_URL"
    echo ""
    echo "📚 API Documentation:"
    echo "   https://$APP_URL/docs"
    echo ""
    
    # Cleanup
    rm "$DEPLOY_ZIP"
    echo "🧹 Cleaned up deployment package"
else
    echo ""
    echo "❌ Deployment failed"
    echo "Deployment package kept at: $DEPLOY_ZIP"
    exit 1
fi

echo ""
echo "✨ Done!"

