"""
Checklist Validator for country-specific checklist validation.
Manages checklist documents (HIPAA, PIPEDA, country checklists) and provides querying capabilities.
"""

from typing import List, Dict, Any, Optional
from azure.search.documents import SearchClient
from azure.search.documents.models import VectorizedQuery
from azure.core.credentials import AzureKeyCredential
from openai import AzureOpenAI
from config import config
from utils.country_manager import CountryValidator


class ChecklistValidator:
    """
    Validates ICF documents against country-specific checklists.
    Supports HIPAA (USA), PIPEDA (Canada), and country-specific checklists.
    """
    
    def __init__(self):
        """Initialize the checklist validator."""
        self.search_endpoint = config.get_search_endpoint()
        self.search_key = config.get_search_key()
        self.index_name = config.CHECKLIST_INDEX_NAME
        
        self.openai_endpoint = config.AZURE_OPENAI_ENDPOINT
        self.openai_key = config.AZURE_OPENAI_API_KEY
        self.embedding_deployment = config.EMBEDDINGS_MODEL_DEPLOYMENT
        
        if not all([self.search_endpoint, self.search_key, self.index_name]):
            raise ValueError("AI Search credentials or checklist index not configured")
        
        self.search_client = SearchClient(
            endpoint=self.search_endpoint,
            index_name=self.index_name,
            credential=AzureKeyCredential(self.search_key)
        )
        
        if not self.openai_endpoint or not self.openai_key:
            raise ValueError(
                "OpenAI client is required but not configured. "
                "Please set AZURE_OPENAI_ENDPOINT and AZURE_OPENAI_API_KEY in .env"
            )
        
        self.openai_client = AzureOpenAI(
            azure_endpoint=self.openai_endpoint,
            api_key=self.openai_key,
            api_version=config.AZURE_OPENAI_API_VERSION
        )
    
    def _get_embedding(self, text: str) -> List[float]:
        """Generate embedding vector for text."""
        response = self.openai_client.embeddings.create(
            model=self.embedding_deployment,
            input=text
        )
        return response.data[0].embedding
    
    def query_checklist(
        self,
        country: str,
        checklist_type: str,
        query: str,
        top_k: int = 10
    ) -> List[Dict[str, Any]]:
        """
        Query country-specific checklist using hybrid search.
        
        Args:
            country: Country code (e.g., "USA", "CAN")
            checklist_type: Type of checklist (e.g., "HIPAA", "PIPEDA", "country")
            query: Natural language query describing what to check
            top_k: Number of results to return
            
        Returns:
            List of checklist items with relevance scores
        """
        try:
            # Normalize country
            normalized_country = CountryValidator.normalize(country)
            if not normalized_country:
                raise ValueError(f"Invalid country code: {country}")
            
            # Build semantic query
            semantic_query = f"{query} {normalized_country} {checklist_type} checklist"
            
            # Generate embedding for vector search
            embedding = self._get_embedding(semantic_query)
            
            # Create vector query
            vector_query = VectorizedQuery(
                vector=embedding,
                k_nearest_neighbors=top_k * 2,
                fields="contentVector"  # Assuming same field name as RAG index
            )
            
            # Build filter for country and checklist type
            filter_expr = f"country eq '{normalized_country}' and checklist_type eq '{checklist_type}'"
            
            # Perform hybrid search
            search_options = {
                "search_text": query,  # BM25 keyword search
                "vector_queries": [vector_query],  # Vector semantic search
                "filter": filter_expr,  # Filter by country and checklist type
                "top": top_k,
                "select": ["id", "content", "country", "checklist_type", "checklist_item", "requirements"]
            }
            
            results = self.search_client.search(**search_options)
            
            checklist_items = []
            for result in results:
                checklist_items.append({
                    "id": result.get("id", ""),
                    "content": result.get("content", ""),
                    "checklist_item": result.get("checklist_item", ""),
                    "requirements": result.get("requirements", ""),
                    "country": result.get("country", normalized_country),
                    "checklist_type": result.get("checklist_type", checklist_type),
                    "relevance_score": result.get("@search.score", 0.0)
                })
            
            return checklist_items
            
        except Exception as e:
            print(f"[ERROR] Failed to query checklist: {e}")
            return []
    
    def get_checklist_types_for_country(self, country: str) -> List[str]:
        """
        Get checklist types available for a country.
        
        Args:
            country: Country code
            
        Returns:
            List of checklist types (e.g., ["HIPAA", "country"] for USA)
        """
        return CountryValidator.get_checklist_types(country)
    
    def validate_against_checklist(
        self,
        country: str,
        checklist_type: str,
        content_to_validate: str
    ) -> Dict[str, Any]:
        """
        Validate content against a specific checklist.
        
        Args:
            country: Country code
            checklist_type: Type of checklist (HIPAA, PIPEDA, country)
            content_to_validate: Content to validate
            
        Returns:
            Validation result with compliance status and issues
        """
        # Query relevant checklist items
        checklist_items = self.query_checklist(
            country=country,
            checklist_type=checklist_type,
            query=content_to_validate[:200],  # Use first 200 chars as query
            top_k=5
        )
        
        # For now, return the checklist items found
        # More sophisticated validation logic can be added later
        return {
            "country": country,
            "checklist_type": checklist_type,
            "checklist_items_found": len(checklist_items),
            "items": checklist_items,
            "compliance_status": "pending"  # Would need LLM validation for actual compliance check
        }

