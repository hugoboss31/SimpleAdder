"""
Structured logging utility with JSON output for Application Insights.
Output schema: { timestamp, level, message, correlationId?, service, context? }
Levels: DEBUG, INFO, WARNING, ERROR, CRITICAL
"""

import json
import logging
import os
import sys
from datetime import datetime
from typing import Optional, Dict, Any


class JsonFormatter(logging.Formatter):
    """Format log records as JSON."""

    def __init__(self, service: str = "icf_agent"):
        super().__init__()
        self.service = service

    def format(self, record: logging.LogRecord) -> str:
        entry: Dict[str, Any] = {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "level": record.levelname,
            "message": record.getMessage(),
            "service": self.service,
        }
        if hasattr(record, "correlation_id") and record.correlation_id:
            entry["correlationId"] = record.correlation_id
        if hasattr(record, "context") and record.context:
            entry["context"] = record.context
        return json.dumps(entry)


class PrettyFormatter(logging.Formatter):
    """Human-readable format for local dev."""

    def format(self, record: logging.LogRecord) -> str:
        corr = getattr(record, "correlation_id", None)
        corr_str = f" correlationId={corr}" if corr else ""
        return (
            f"{self.formatTime(record, '%Y-%m-%d %H:%M:%S')} "
            f"[{record.levelname}] [icf_agent] {record.getMessage()}{corr_str}"
        )


def _is_json_format() -> bool:
    return os.getenv("LOG_FORMAT", "json") != "pretty"


class StructuredLogger:
    """Structured JSON logger with correlation ID support."""

    def __init__(self, name: str = "icf_agent", log_level: str = "INFO"):
        self.logger = logging.getLogger(name)
        self.logger.setLevel(getattr(logging, log_level.upper(), logging.INFO))
        self.logger.handlers = []
        handler = logging.StreamHandler(sys.stdout)
        handler.setFormatter(
            JsonFormatter(service=name) if _is_json_format() else PrettyFormatter()
        )
        self.logger.addHandler(handler)
        self._name = name

    def _log_with_context(
        self,
        level: int,
        message: str,
        correlation_id: Optional[str] = None,
        extra: Optional[Dict[str, Any]] = None,
    ):
        extra_data = dict(extra or {})
        if correlation_id:
            extra_data["correlation_id"] = correlation_id
        log_record = self.logger.makeRecord(
            self._name, level, "(unknown)", 0, message, (), None
        )
        for k, v in extra_data.items():
            setattr(log_record, k, v)
        self.logger.handle(log_record)

    def _do_log(
        self,
        level: int,
        message: str,
        correlation_id: Optional[str] = None,
        exc_info=None,
        **kwargs,
    ):
        extra = dict(kwargs) if kwargs else {}
        if correlation_id:
            extra["correlation_id"] = correlation_id
        if exc_info:
            self.logger.log(level, message, exc_info=exc_info, extra=extra)
        else:
            self.logger.log(level, message, extra=extra)

    def info(self, message: str, correlation_id: Optional[str] = None, **kwargs):
        self._do_log(logging.INFO, message, correlation_id, **kwargs)

    def warning(self, message: str, correlation_id: Optional[str] = None, **kwargs):
        self._do_log(logging.WARNING, message, correlation_id, **kwargs)

    def error(self, message: str, correlation_id: Optional[str] = None, **kwargs):
        self._do_log(logging.ERROR, message, correlation_id, **kwargs)

    def debug(self, message: str, correlation_id: Optional[str] = None, **kwargs):
        self._do_log(logging.DEBUG, message, correlation_id, **kwargs)

    def exception(self, message: str, correlation_id: Optional[str] = None, **kwargs):
        self._do_log(
            logging.ERROR, message, correlation_id, exc_info=True, **kwargs
        )


def get_logger(name: str = "icf_agent") -> StructuredLogger:
    """Get or create a structured logger. Respects LOG_LEVEL env."""
    log_level = os.getenv("LOG_LEVEL", "INFO").upper()
    return StructuredLogger(name=name, log_level=log_level)
