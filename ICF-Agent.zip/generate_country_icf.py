"""
Complete ICF generation workflow using iterative section-by-section processing.

This implementation follows the iterative RAG approach that achieved 90%+ usage.
Processes each customization plan item one-by-one with feedback loops.

This module orchestrates:
1. Ingestion Agent - Parse Global ICF and customization plan
2. Section-Matcher Agent - Match customization items to sections (iterative)
3. Generator Agent - Generate changes (iterative)
4. QA Agent - Validate each change (iterative)
5. Writer Agent - Generate final DOCX with all approved changes
"""

import asyncio
from pathlib import Path
from typing import Dict, Any, Optional, List
from datetime import datetime
import json
import os

from agents import IngestionService, SectionMatcherService
from agents.generator_agent import create_generator_agent
from agents.qa_agent import create_qa_agent
from agents.writer_agent import create_writer_agent
from agents.agent_pool import get_agent_pool
from utils.country_manager import CountryValidator
from utils.cache_manager import get_cache_manager
from schemas.icf_schemas import (
    ICFSectionTree, 
    CustomizationPlan, 
    SectionMatchResult, 
    ICFChange,
    ActionType,
    ChangeType
)
from tools import RAGTool, OpenXmlDocxGenerator, DocumentIntelligenceTool, RAGPlugin
from tools.checklist_index_manager import ChecklistIndexManager
from config import config
from semantic_kernel import Kernel
from semantic_kernel.functions import KernelArguments
from semantic_kernel.exceptions.service_exceptions import ServiceResponseException
from openai import AzureOpenAI, RateLimitError  # Keep for legacy functions
from azure.search.documents import SearchClient
from utils.retry_handler import async_retry_with_backoff

# Helper function to invoke agent with retry logic for rate limiting
async def _invoke_agent_with_retry(agent, prompt: str, arguments: KernelArguments, max_retries: int = 3):
    """
    Invoke agent with retry logic for rate limit errors.
    
    Args:
        agent: The agent to invoke
        prompt: Prompt to send to agent
        arguments: Kernel arguments
        max_retries: Maximum number of retries
        
    Returns:
        Response text from agent
        
    Raises:
        Exception: If all retries fail or non-retryable error occurs
    """
    delay = 2.0  # Start with 2 seconds for rate limit retries
    last_exception = None
    
    for attempt in range(max_retries + 1):
        try:
            response_parts = []
            async for response_item in agent.invoke(prompt, arguments=arguments):
                if hasattr(response_item, 'content'):
                    response_parts.append(str(response_item.content))
                else:
                    response_parts.append(str(response_item))
            response_text = " ".join(response_parts)
            
            # Validate response is not empty
            if not response_text or not response_text.strip():
                raise ValueError("Agent returned empty response")
            
            return response_text
            
        except (ServiceResponseException, RateLimitError) as e:
            # Check if it's a rate limit error
            # ServiceResponseException wraps the actual exception, check both
            is_rate_limit = False
            error_str = str(e).lower()
            
            # Check if it's directly a RateLimitError
            if isinstance(e, RateLimitError):
                is_rate_limit = True
            # Check if ServiceResponseException wraps a RateLimitError
            elif isinstance(e, ServiceResponseException) and hasattr(e, '__cause__') and isinstance(e.__cause__, RateLimitError):
                is_rate_limit = True
            # Check error message for rate limit indicators
            elif "rate limit" in error_str or "429" in error_str or "ratelimitreached" in error_str:
                is_rate_limit = True
            
            if is_rate_limit:
                last_exception = e
                if attempt < max_retries:
                    # Exponential backoff for rate limits: 2s, 4s, 8s
                    wait_time = min(delay * (2 ** attempt), 60.0)
                    print(f"[RETRY] Rate limit hit (attempt {attempt + 1}/{max_retries + 1}), waiting {wait_time:.1f}s before retry...")
                    await asyncio.sleep(wait_time)
                    delay = wait_time
                    continue
                else:
                    print(f"[ERROR] Rate limit error after {max_retries + 1} attempts: {e}")
                    raise ValueError(f"Rate limit exceeded after {max_retries + 1} attempts. Please try again later.") from e
            else:
                # Non-rate-limit service exception, re-raise
                raise
        except ValueError as e:
            # Empty response or other value errors - don't retry these
            raise
        except Exception as e:
            last_exception = e
            if attempt < max_retries:
                # For other errors, use shorter delay
                await asyncio.sleep(1.0)
                continue
            raise
    
    # Should not reach here, but just in case
    if last_exception:
        raise last_exception
    raise Exception("Agent invocation failed with unknown error")


# Sections to skip from any modifications
SKIP_SECTIONS = [
    "table of contents",
    "contents",
    "abbreviations",
    "glossary",
    "signature page",
    "signatures",
    "table 1",
    "table 2", 
    "table 3",
    "visit schedule",
    "table"
]


def _should_skip_section(section_title: Optional[str], section_text: Optional[str], location: Optional[str] = None) -> bool:
    """
    Check if a section should be skipped from modifications.
    
    Args:
        section_title: Title of the section
        section_text: Text content of the section
        location: Location string from change (e.g., "Section X - Table of Contents")
        
    Returns:
        True if section should be skipped, False otherwise
    """
    # Normalize to lowercase for comparison
    title_lower = (section_title or "").lower().strip()
    text_lower = (section_text or "").lower().strip()
    location_lower = (location or "").lower().strip()
    
    # Check if any skip pattern matches
    for skip_pattern in SKIP_SECTIONS:
        skip_lower = skip_pattern.lower().strip()
        
        # Check if skip pattern is in title (exact match or contains)
        if title_lower and skip_lower in title_lower:
            return True
        
        # Check if skip pattern is in location (this is critical for "table of contents")
        if location_lower and skip_lower in location_lower:
            return True
        
        # Check if skip pattern appears prominently in text (first 500 chars for better detection)
        if text_lower and skip_lower in text_lower[:500]:
            return True
        
        # Special handling for "table of contents" - check for variations
        if skip_lower == "table of contents":
            # Also check for "contents" alone in title/location if "table" is nearby
            if ("contents" in title_lower and "table" in title_lower) or \
               ("contents" in location_lower and "table" in location_lower) or \
               (title_lower and "table of contents" in title_lower) or \
               (location_lower and "table of contents" in location_lower):
                return True
    
    return False


def _check_rag_index_document_count() -> int:
    """Check document count in RAG index."""
    try:
        from config import config
        search_client = SearchClient(
            endpoint=config.get_search_endpoint(),
            index_name=config.RAG_INDEX_NAME,
            credential=config.get_search_credential()
        )
        result = search_client.search(search_text="*", include_total_count=True, top=0)
        return result.get_count() or 0
    except Exception as e:
        print(f"⚠️  Warning: Could not check RAG index: {e}")
        return 0


def _ensure_checklist_index_exists() -> bool:
    """Ensure checklist index exists, create if missing."""
    try:
        checklist_manager = ChecklistIndexManager()
        if not checklist_manager.index_exists():
            print(f"⚠️  Checklist index '{checklist_manager.index_name}' does not exist. Creating...")
            checklist_manager.create_index()
            print(f"✅ Checklist index created (empty - needs to be populated)")
        return True
    except Exception as e:
        print(f"⚠️  Warning: Could not create checklist index: {e}")
        return False


async def generate_country_icf(
    global_icf_path: str,
    customization_plan_path: str,
    country: str,
    output_path: Optional[str] = None,
    max_iterations: int = 5
) -> Dict[str, Any]:
    """
    Generate country-specific ICF using iterative section-by-section processing.
    
    This follows the approach that achieved 90%+ customization plan usage:
    - Process each customization item individually
    - Match → Generate → Validate → Approve → Next
    - Immediate feedback loop for each item
    
    Args:
        global_icf_path: Path to Global ICF DOCX file
        customization_plan_path: Path to Excel customization plan
        country: Target country code (e.g., "USA")
        output_path: Optional output path (auto-generated if not provided)
        max_iterations: Maximum iterations for QA validation per item
        
    Returns:
        Dictionary with results, including output file path and coverage report
    """
    
    print("="*80)
    print("ICF Country-Specific Generation - Iterative Section-by-Section Flow")
    print("="*80)
    print(f"Global ICF: {global_icf_path}")
    print(f"Customization Plan: {customization_plan_path}")
    print(f"Country: {country}")
    print("="*80)
    
    # Generate output path if not provided
    if not output_path:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_path = f"output/ICF_{country}_{timestamp}.docx"
    
    Path("output").mkdir(exist_ok=True)
    Path("median").mkdir(exist_ok=True)
    Path("logs").mkdir(exist_ok=True)
    
    results = {
        "success": False,
        "output_path": output_path,
        "coverage_report": None,
        "match_results": [],
        "changes": [],
        "approved_changes": [],
        "errors": []
    }
    
    try:
        # Step 1: Ingestion
        print("\n[STEP 1] Ingestion & Structuring")
        print("-" * 80)
        
        ingestion_service = IngestionService()
        
        # Ingest Global ICF
        print(f"Parsing Global ICF: {global_icf_path}")
        section_tree = ingestion_service.ingest_global_icf(
            docx_path=global_icf_path,
            document_id=f"global_icf_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        )
        print(f"✅ Extracted {section_tree.total_sections} sections, {section_tree.total_paragraphs} paragraphs")
        
        # Ingest customization plan
        print(f"Parsing customization plan: {customization_plan_path}")
        customization_plan = ingestion_service.ingest_customization_plan(
            excel_path=customization_plan_path,
            country=country,
            plan_id=f"{country}_plan_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        )
        print(f"✅ Parsed {len(customization_plan.items)} customization items")
        
        # Validate and normalize country
        normalized_country = CountryValidator.normalize(country)
        if not normalized_country:
            raise ValueError(f"Invalid country code: {country}. Supported: {CountryValidator.get_all_supported_countries()}")
        country = normalized_country  # Use normalized country code
        
        # Validate indexes before processing
        print("\n[INDEX VALIDATION]")
        print("-" * 80)
        
        # Check RAG index
        rag_doc_count = _check_rag_index_document_count()
        if rag_doc_count == 0:
            print(f"⚠️  CRITICAL WARNING: RAG index '{config.RAG_INDEX_NAME}' is EMPTY!")
            print(f"   This means:")
            print(f"   - No regulatory documents (FDA, HIPAA, PIPEDA) are indexed")
            print(f"   - RAG queries will return NO results")
            print(f"   - Generated citations may be hallucinated or generic")
            print(f"   - QA validation cannot verify regulatory references")
            print(f"   ACTION REQUIRED: Populate RAG index using /add-document or /add-folder endpoints")
            print(f"   The system will continue but results may be inaccurate.")
            results["errors"].append("RAG index is empty - regulatory documents not indexed")
        else:
            print(f"✅ RAG index contains {rag_doc_count} document chunks")
        
        # Ensure checklist index exists
        _ensure_checklist_index_exists()
        
        # Initialize services and tools
        matcher_service = SectionMatcherService()
        rag_tool = RAGTool()  # Keep for backward compatibility if needed
        di_tool = DocumentIntelligenceTool()
        openxml_generator = OpenXmlDocxGenerator(author="ICF Generator Agent", output_folder="median")
        
        # Get agents from pool (reuses shared instances)
        agent_pool = get_agent_pool()
        kernel = agent_pool.get_kernel()
        generator_agent = agent_pool.get_generator_agent()
        qa_agent = agent_pool.get_qa_agent()
        
        # Get cache manager
        cache_manager = get_cache_manager()
        
        print(f"✅ Initialized agents from pool with dynamic RAG and Checklist capabilities")
        
        # Step 2: Parallel Batch Processing
        print("\n[STEP 2] Parallel Batch Processing")
        print("-" * 80)
        print(f"Processing {len(customization_plan.items)} items in batches of {config.BATCH_SIZE}...\n")
        
        all_changes = []
        all_match_results = []
        approved_count = 0
        rejected_count = 0
        skipped_count = 0
        
        # Process items in parallel batches
        batch_size = config.BATCH_SIZE
        semaphore = asyncio.Semaphore(config.MAX_CONCURRENT_ITEMS)
        
        async def process_item(item, idx, total):
            """Process a single item (helper function for parallel processing)."""
            async with semaphore:  # Limit concurrent items
                return await _process_single_item(
                    item=item,
                    idx=idx,
                    total=total,
                    section_tree=section_tree,
                    country=country,
                    matcher_service=matcher_service,
                    generator_agent=generator_agent,
                    qa_agent=qa_agent,
                    kernel=kernel,
                    max_iterations=max_iterations,
                    cache_manager=cache_manager
                )
        
        # Process in batches
        for batch_start in range(0, len(customization_plan.items), batch_size):
            batch_end = min(batch_start + batch_size, len(customization_plan.items))
            batch = customization_plan.items[batch_start:batch_end]
            batch_num = (batch_start // batch_size) + 1
            total_batches = (len(customization_plan.items) + batch_size - 1) // batch_size
            
            print(f"\n[Batch {batch_num}/{total_batches}] Processing {len(batch)} items...")
            
            # Process batch in parallel
            batch_results = await asyncio.gather(
                *[process_item(item, batch_start + i + 1, len(customization_plan.items)) 
                  for i, item in enumerate(batch)],
                return_exceptions=True
            )
            
            # Aggregate results from batch
            for result in batch_results:
                if isinstance(result, Exception):
                    print(f"  ❌ Error in batch processing: {result}")
                    skipped_count += 1
                    continue
                
                if result:
                    match_result, change, validation_result = result
                    
                    if match_result:
                        all_match_results.append(match_result)
                    
                    if change and validation_result and validation_result.get("approved"):
                        all_changes.append(change)
                        approved_count += 1
                    elif change and validation_result and not validation_result.get("approved"):
                        rejected_count += 1
                    elif not change:
                        skipped_count += 1
        
        # Parallel batch processing completed above
        
        results["match_results"] = all_match_results
        results["changes"] = all_changes
        results["approved_changes"] = all_changes  # All changes that made it here are approved
        
        print(f"\n{'='*60}")
        print(f"Processing Summary:")
        print(f"  Total Items: {len(customization_plan.items)}")
        print(f"  Approved: {approved_count}")
        print(f"  Rejected: {rejected_count}")
        print(f"  Skipped: {skipped_count}")
        print(f"{'='*60}")
        
        # Step 3: Generate Coverage Report
        print("\n[STEP 3] Coverage Report")
        print("-" * 80)
        
        total_items = len(customization_plan.items)
        handled_items = approved_count
        unmapped_items = skipped_count
        low_confidence_items = [
            mr.item_id for mr in all_match_results 
            if mr.decision.best_match_confidence < 0.7
        ]
        requires_review_items = [
            mr.item_id for mr in all_match_results 
            if mr.decision.requires_review
        ]
        
        coverage_percentage = (handled_items / total_items * 100) if total_items > 0 else 0
        
        coverage_report = {
            "total_plan_items": total_items,
            "handled_items": handled_items,
            "unmapped_items": unmapped_items,
            "low_confidence_items": low_confidence_items,
            "requires_review_items": requires_review_items,
            "coverage_percentage": coverage_percentage,
            "requires_human_review": len(requires_review_items) > 0 or unmapped_items > 0,
            "approved_changes": approved_count,
            "rejected_changes": rejected_count
        }
        
        results["coverage_report"] = coverage_report
        
        print(f"Total Plan Items: {total_items}")
        print(f"Handled Items: {handled_items} ({coverage_percentage:.1f}%)")
        print(f"Unmapped Items: {unmapped_items}")
        print(f"Low Confidence Items: {len(low_confidence_items)}")
        print(f"Requires Review: {len(requires_review_items)}")
        
        # Step 4: Generate Final DOCX using Writer Agent (if we have approved changes)
        if len(all_changes) > 0:
            print("\n[STEP 4] Generating Final DOCX using Writer Agent")
            print("-" * 80)
            
            # Get Writer Agent from pool
            writer_agent = agent_pool.get_writer_agent()
            
            # Convert changes to format expected by Writer Agent/OpenXML generator
            # Include section context for accurate location finding
            changes_dict = []
            skipped_final = 0
            for change in all_changes:
                # Get section information for better location finding
                section_info = None
                matched_section = None
                if change.source_global_section_id:
                    matched_section = _get_section_from_tree(section_tree, change.source_global_section_id)
                    if matched_section:
                        section_info = {
                            "section_id": matched_section.section_id,
                            "title": matched_section.title or "",
                            "text": matched_section.text[:500] if matched_section.text else "",  # First 500 chars for matching
                            "order_index": matched_section.order_index
                        }
                
                # Final skip check - check section title, text, and location
                if _should_skip_section(
                    section_title=matched_section.title if matched_section else None,
                    section_text=matched_section.text[:300] if matched_section and matched_section.text else None,
                    location=change.location
                ):
                    print(f"  ⏭️  SKIPPED (final check): Change at location '{change.location}' matches skip pattern")
                    skipped_final += 1
                    continue
                
                change_dict = {
                    "location": change.location,
                    "change_type": change.change_type.value.lower(),  # 'insertion', 'deletion', 'modification'
                    "old_text": change.old_text or "",
                    "new_text": change.new_text or "",
                    "after_text": change.after_text or "",
                    "regulatory_reference": change.regulatory_reference,
                    "justification": change.justification,
                    "comment": change.comment,
                    "source_section_id": change.source_global_section_id or "",
                    "section_info": section_info  # Include section metadata for accurate placement
                }
                changes_dict.append(change_dict)
            
            if skipped_final > 0:
                print(f"  ⚠️  Skipped {skipped_final} changes in final check due to skip section patterns")
            
            # Format changes for Writer Agent
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            median_filename = f"ICF_{country}_{timestamp}.docx"
            
            # Format changes summary for Writer Agent prompt
            changes_summary = "\n\n".join([
                f"CHANGE {i+1}:\n"
                f"Location: {c['location']}\n"
                f"Type: {c['change_type'].upper()}\n"
                f"{'Old text: ' + c['old_text'] if c['old_text'] else ''}"
                f"{'New text: ' + c['new_text'] if c['new_text'] else ''}"
                f"{'After text: ' + c['after_text'] if c['after_text'] else ''}"
                f"Regulatory Reference: {c['regulatory_reference']}\n"
                f"Justification: {c['justification']}\n"
                f"Comment: {c['comment']}"
                for i, c in enumerate(changes_dict)
            ])
            
            writer_prompt = f"""You have received APPROVED changes from QA Agent. Generate the final DOCX document.

APPROVED CHANGES ({len(changes_dict)} total):
{changes_summary}

Master ICF Path: {global_icf_path}
Target Country: {country}
Output Filename: {median_filename}

Please invoke the OpenXML generator to create the DOCX with tracked changes."""
            
            try:
                # Use Writer Agent to coordinate DOCX generation
                print(f"Involving Writer Agent to apply {len(changes_dict)} approved changes...")
                arguments = KernelArguments(
                    changes_count=len(changes_dict),
                    country=country,
                    output_filename=median_filename,
                    master_docx_path=global_icf_path
                )
                
                # Invoke Writer Agent - it should coordinate with OpenXML tool
                # For now, we'll use Writer Agent but fallback to direct OpenXML for reliability
                # The Writer Agent architecture expects conversational coordination, but we need immediate functionality
                response_parts = []
                async for response_item in writer_agent.invoke(writer_prompt, arguments=arguments):
                    if hasattr(response_item, 'content'):
                        response_parts.append(str(response_item.content))
                    else:
                        response_parts.append(str(response_item))
                writer_response = " ".join(response_parts)
                
                # Writer Agent should handle DOCX generation, but for reliability,
                # we'll also call OpenXML directly to ensure the document is generated
                # In a full implementation, Writer Agent would invoke the OpenXML tool via kernel
                print(f"Writer Agent response received. Generating DOCX with OpenXML generator...")
                median_output = openxml_generator.create_icf_with_tracked_changes(
                    master_docx_path=global_icf_path,
                    changes=changes_dict,
                    output_filename=median_filename,
                    country=country,
                    section_tree=section_tree  # Pass section tree for better location finding
                )
                
                # Copy to final output
                import shutil
                shutil.copy(median_output, output_path)
                
                print(f"✅ DOCX generated: {output_path}")
                results["success"] = True
                results["output_path"] = output_path
                
            except Exception as e:
                print(f"❌ Error during Writer Agent DOCX generation: {e}")
                import traceback
                traceback.print_exc()
                # Fallback to direct OpenXML call if Writer Agent fails
                try:
                    print(f"Attempting fallback to direct OpenXML generation...")
                    median_output = openxml_generator.create_icf_with_tracked_changes(
                        master_docx_path=global_icf_path,
                        changes=changes_dict,
                        output_filename=median_filename,
                        country=country,
                        section_tree=section_tree
                    )
                    import shutil
                    shutil.copy(median_output, output_path)
                    print(f"✅ DOCX generated via fallback: {output_path}")
                    results["success"] = True
                    results["output_path"] = output_path
                except Exception as fallback_error:
                    print(f"❌ Fallback also failed: {fallback_error}")
                    results["success"] = False
                    results["errors"].append(f"DOCX generation failed: {str(e)}")
        else:
            print("\n⚠️  No approved changes to generate DOCX")
            results["success"] = False
            results["errors"].append("No approved changes generated")
        
        print("\n" + "="*80)
        print("Generation Complete!")
        print("="*80)
        
        return results
        
    except Exception as e:
        print(f"\n❌ Error during generation: {e}")
        import traceback
        traceback.print_exc()
        results["success"] = False
        results["errors"].append(str(e))
        return results


async def _process_single_item(
    item,
    idx: int,
    total: int,
    section_tree: ICFSectionTree,
    country: str,
    matcher_service: SectionMatcherService,
    generator_agent,
    qa_agent,
    kernel: Kernel,
    max_iterations: int,
    cache_manager
) -> Optional[tuple]:
    """
    Process a single customization plan item (helper for parallel batch processing).
    
    Returns:
        Tuple of (match_result, change, validation_result) or None if skipped
    """
    try:
        print(f"  [{idx}/{total}] Processing: {item.item_id} - {item.topic}")
        
        # 2a. Match this item to Global ICF sections
        match_result = await matcher_service.match_customization_item(
            item=item,
            global_icf_id=section_tree.document_id
        )
        
        decision = match_result.decision
        print(f"    ✓ Matched to: {decision.best_match_section_id or 'None'} (confidence: {decision.best_match_confidence:.2f})")
        
        # 2b. Get matched section context
        matched_section = None
        if decision.best_match_section_id:
            matched_section = _get_section_from_tree(
                section_tree, 
                decision.best_match_section_id
            )
        
        # Check if matched section should be skipped
        if matched_section and _should_skip_section(matched_section.title, matched_section.text):
            print(f"    ⏭️  SKIPPED: Section in skip list")
            return None
        
        # 2c. Generate change
        change = await _generate_change_for_item_with_agent(
            item=item,
            match_result=match_result,
            matched_section=matched_section,
            country=country,
            generator_agent=generator_agent,
            kernel=kernel
        )
        
        if not change:
            # Retry with more context
            change = await _generate_change_for_item_with_agent(
                item=item,
                match_result=match_result,
                matched_section=matched_section,
                country=country,
                generator_agent=generator_agent,
                kernel=kernel,
                retry=True,
                full_section_context=True
            )
            if not change:
                print(f"    ❌ Failed to generate change")
                return None
        
        # 2d. Validate change
        validation_result = await _validate_change_with_agent(
            change=change,
            country=country,
            qa_agent=qa_agent,
            kernel=kernel,
            max_iterations=max_iterations
        )
        
        # Final skip check
        if validation_result.get("approved"):
            if _should_skip_section(
                section_title=None, 
                section_text=None, 
                location=change.location
            ):
                print(f"    ⏭️  SKIPPED: Location matches skip pattern")
                return None
        
        return (match_result, change, validation_result)
        
    except Exception as e:
        print(f"    ❌ Error processing item {item.item_id}: {e}")
        import traceback
        traceback.print_exc()
        return None


def _get_section_from_tree(section_tree: ICFSectionTree, section_id: str):
    """Recursively find a section by ID in the section tree."""
    def find_recursive(sections, target_id):
        for section in sections:
            if section.section_id == target_id:
                return section
            if section.children:
                found = find_recursive(section.children, target_id)
                if found:
                    return found
        return None
    
    return find_recursive(section_tree.sections, section_id)


async def _generate_change_for_item_with_agent(
    item,
    match_result: SectionMatchResult,
    matched_section,
    country: str,
    generator_agent,
    kernel: Kernel,
    retry: bool = False,
    full_section_context: bool = False
) -> Optional[ICFChange]:
    """
    Generate a single change for a customization item using Generator Agent with dynamic RAG.
    
    The agent will dynamically query RAG for regulatory requirements as needed.
    """
    decision = match_result.decision
    
    # Build section context
    section_context = ""
    if matched_section:
        section_text = matched_section.text
        if full_section_context and len(section_text) > 2500:
            section_text = section_text[:2500] + "..."
        elif not full_section_context and len(section_text) > 2000:
            section_text = section_text[:2000] + "..."
        
        section_context = f"EXISTING SECTION (read fully to understand context before modifying):\nTitle: {matched_section.title or matched_section.section_id}\n\nText:\n{section_text}"
    
    action_instruction = {
        ActionType.NO_MATCH: "INSERT new section",
        ActionType.MODIFY_EXISTING: "MODIFY existing section",
        ActionType.INSERT_NEW: "INSERT new content",
        ActionType.BOTH: "MODIFY and INSERT content"
    }.get(decision.action, "MODIFY section")
    
    # Build prompt for agent - note: agent will dynamically query RAG as needed
    prompt = f"""Generate tracked change. CRITICAL: First understand the EXISTING section context, then modify it naturally.

Requirement to address: {item.requirement_text}

{item.topic} - {item.requirement_text[:200]}

EXISTING SECTION CONTEXT (read and understand this first - CHECK FOR DUPLICATES):
{section_context}

CRITICAL DUPLICATE PREVENTION:
1. CAREFULLY READ the entire existing section text above
2. IDENTIFY if the information from the requirement ALREADY EXISTS in the section
3. If similar/duplicate information exists, you MUST use MODIFY (not INSERT) to enhance/update it
4. If the EXACT information already exists, you may need to skip or only make minor improvements
5. DO NOT add text that repeats or duplicates information already present

Example of duplicate detection:
- If section says "You will be reimbursed for expenses" and requirement is "reimbursement for expenses"
  → This is ALREADY COVERED. Either MODIFY to enhance it, or SKIP if it's complete
- If section says "expenses" and requirement says "transportation, parking, meals"
  → Check if these specific items are mentioned. If yes, MODIFY to enhance. If no, can INSERT carefully

IMPORTANT: Use the RAG.query_regulations tool to dynamically retrieve regulatory requirements for:
- Topic: {item.topic}
- Country: {country}
- Query examples: "{item.topic} requirements", "informed consent {item.topic.lower()}", "{country} {item.topic.lower()} regulations"
- Call the tool as needed to get relevant regulatory context before generating changes

INSTRUCTIONS:
1. READ and UNDERSTAND the entire existing section text above - CHECK FOR DUPLICATES FIRST
2. IDENTIFY if the requirement information already exists (even if worded differently)
3. If information exists: Use MODIFY to enhance/update it (do NOT INSERT duplicate)
4. If information does NOT exist: Use INSERT to add it (but check it's not redundant)
5. Use RAG.query_regulations to retrieve relevant regulatory requirements for this topic and country
6. Provide a MODIFIED version that integrates the requirement naturally into the existing text
7. NEVER add redundant text or duplicate information already present
8. Ensure the modified text flows naturally and maintains context

For MODIFY: Provide old_text (existing text to replace) and new_text (complete modified version that incorporates the requirement naturally - DO NOT duplicate existing info)
For INSERT: Provide after_text (where to insert) and new_text (text that adds required information without redundancy - CHECK IT DOESN'T ALREADY EXIST FIRST)

Action: {action_instruction}
Match Confidence: {decision.best_match_confidence:.2f}
Country: {country}

Return JSON:
{{
    "location": "Section X - Title",
    "change_type": "INSERT" or "DELETE" or "MODIFY",
    "old_text": "EXISTING text from section that needs to be replaced (for MODIFY, provide the full sentence/paragraph)",
    "new_text": "COMPLETE modified text that naturally integrates the requirement (not just additional text)",
    "after_text": "anchor text for insertions (only for INSERT type)",
    "regulatory_reference": "citation from regulatory requirements (from RAG query)",
    "justification": "why this change addresses the requirement",
    "comment": "reviewer note"
}}"""

    try:
        # Use agent to generate change - agent will call RAG.query_regulations dynamically
        arguments = KernelArguments(
            item_id=item.item_id,
            topic=item.topic,
            requirement_text=item.requirement_text,
            country=country,
            action=action_instruction,
            confidence=decision.best_match_confidence
        )
        
        # Invoke agent with retry logic for rate limiting
        # The agent can dynamically call RAG.query_regulations via kernel plugin
        response_text = await _invoke_agent_with_retry(generator_agent, prompt, arguments, max_retries=3)
        
        # Check if response looks like an error message before trying to parse JSON
        response_lower = response_text.lower().strip()
        if any(keyword in response_lower for keyword in ["error", "exception", "failed", "rate limit", "429"]):
            if "rate limit" in response_lower or "429" in response_lower:
                raise ValueError(f"Rate limit error in agent response: {response_text[:200]}")
            else:
                raise ValueError(f"Error message in agent response: {response_text[:200]}")
        
        # Try to extract JSON from response
        import re
        change_data = None
        
        # First try: Look for JSON object with location or change_type fields
        json_match = re.search(r'\{[^{}]*(?:"location"|"change_type")[^{}]*\}', response_text, re.DOTALL)
        if json_match:
            try:
                change_data = json.loads(json_match.group())
            except json.JSONDecodeError:
                pass
        
        # Second try: Look for any JSON object in the response
        if change_data is None:
            json_objects = re.findall(r'\{[^{}]*\}', response_text, re.DOTALL)
            for json_str in json_objects:
                try:
                    candidate = json.loads(json_str)
                    if "change_type" in candidate or "location" in candidate:
                        change_data = candidate
                        break
                except json.JSONDecodeError:
                    continue
        
        # Third try: Try parsing entire response as JSON
        if change_data is None:
            try:
                change_data = json.loads(response_text.strip())
            except json.JSONDecodeError as e:
                raise ValueError(
                    f"Failed to parse JSON from agent response. "
                    f"Response text: {response_text[:500]}... "
                    f"Error: {str(e)}"
                ) from e
        
        # Map change_type to enum
        change_type_str = change_data.get("change_type", "MODIFY").upper()
        if "INSERT" in change_type_str:
            change_type = ChangeType.INSERT
        elif "DELETE" in change_type_str:
            change_type = ChangeType.DELETE
        else:
            change_type = ChangeType.MODIFY
        
        change = ICFChange(
            change_id=f"{item.item_id}_change_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
            source_plan_item_id=item.item_id,
            source_global_section_id=decision.best_match_section_id,
            location=change_data.get("location", "Unknown"),
            change_type=change_type,
            old_text=change_data.get("old_text"),
            new_text=change_data.get("new_text"),
            after_text=change_data.get("after_text"),
            regulatory_reference=change_data.get("regulatory_reference", ""),
            justification=change_data.get("justification", ""),
            comment=change_data.get("comment", ""),
            rationale=decision.justification
        )
        
        return change
        
    except Exception as e:
        print(f"    ⚠️  Failed to generate change with agent: {e}")
        import traceback
        traceback.print_exc()
        return None


async def _generate_change_for_item(
    item,
    match_result: SectionMatchResult,
    matched_section,
    regulations: List[Dict],
    openai_client: AzureOpenAI,
    deployment_name: str,
    retry: bool = False,
    full_section_context: bool = False
) -> Optional[ICFChange]:
    """Generate a single change for a customization item."""
    
    decision = match_result.decision
    
    # Build context from retrieved chunks - let data speak, not verbose prompts
    # Use full regulatory content from vectorized chunks
    regulation_context = "\n\n".join([
        f"[{r.get('source', 'Unknown')}]\n{r.get('content', '')}"
        for r in regulations[:10]  # Top 10 semantically matched regulatory chunks
    ])
    
    # Section context - use retrieved section text (provide full context for better understanding)
    section_context = ""
    if matched_section:
        section_text = matched_section.text
        # Provide more context to help agent understand the existing section better
        if full_section_context and len(section_text) > 2500:
            section_text = section_text[:2500] + "..."
        elif not full_section_context and len(section_text) > 2000:
            section_text = section_text[:2000] + "..."
        
        section_context = f"EXISTING SECTION (read fully to understand context before modifying):\nTitle: {matched_section.title or matched_section.section_id}\n\nText:\n{section_text}"
    
    # Minimal prompt - let retrieved chunks provide the context
    action_instruction = {
        ActionType.NO_MATCH: "INSERT new section",
        ActionType.MODIFY_EXISTING: "MODIFY existing section",
        ActionType.INSERT_NEW: "INSERT new content",
        ActionType.BOTH: "MODIFY and INSERT content"
    }.get(decision.action, "MODIFY section")
    
    prompt = f"""Generate tracked change. CRITICAL: First understand the EXISTING section context, then modify it naturally.

Requirement to address: {item.requirement_text}

EXISTING SECTION CONTEXT (read and understand this first):
{section_context}

Regulatory Requirements (from vectorized search):
{regulation_context}

INSTRUCTIONS:
1. READ and UNDERSTAND the existing section text above
2. Identify what needs to be changed to address the requirement
3. Provide a MODIFIED version that integrates the requirement naturally into the existing text
4. Do NOT add redundant text or duplicate information already present
5. Ensure the modified text flows naturally and maintains context

For MODIFY: Provide old_text (existing text to replace) and new_text (complete modified version that incorporates the requirement naturally)
For INSERT: Provide after_text (where to insert) and new_text (text that adds required information without redundancy)

Action: {action_instruction}
Match Confidence: {decision.best_match_confidence:.2f}

Return JSON:
{{
    "location": "Section X - Title",
    "change_type": "INSERT" or "DELETE" or "MODIFY",
    "old_text": "EXISTING text from section that needs to be replaced (for MODIFY, provide the full sentence/paragraph)",
    "new_text": "COMPLETE modified text that naturally integrates the requirement (not just additional text)",
    "after_text": "anchor text for insertions (only for INSERT type)",
    "regulatory_reference": "citation from regulatory requirements above",
    "justification": "why this change addresses the requirement",
    "comment": "reviewer note"
}}"""

    try:
        response = openai_client.chat.completions.create(
            model=deployment_name,
            messages=[
                {"role": "system", "content": "You are an ICF customization agent. CRITICAL: Always read and understand the EXISTING section context first before generating changes. Modify existing text naturally to integrate requirements, avoiding redundant or out-of-context additions. Provide complete modified text that flows naturally, not just additional text appended."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.1,  # Lower temperature for consistency with retrieved context
            response_format={"type": "json_object"}
        )
        
        response_text = response.choices[0].message.content
        change_data = json.loads(response_text.strip())
        
        # Map change_type to enum
        change_type_str = change_data.get("change_type", "MODIFY").upper()
        if "INSERT" in change_type_str:
            change_type = ChangeType.INSERT
        elif "DELETE" in change_type_str:
            change_type = ChangeType.DELETE
        else:
            change_type = ChangeType.MODIFY
        
        change = ICFChange(
            change_id=f"{item.item_id}_change_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
            source_plan_item_id=item.item_id,
            source_global_section_id=decision.best_match_section_id,
            location=change_data.get("location", "Unknown"),
            change_type=change_type,
            old_text=change_data.get("old_text"),
            new_text=change_data.get("new_text"),
            after_text=change_data.get("after_text"),
            regulatory_reference=change_data.get("regulatory_reference", ""),
            justification=change_data.get("justification", ""),
            comment=change_data.get("comment", ""),
            rationale=decision.justification
        )
        
        return change
        
    except Exception as e:
        print(f"    ⚠️  Failed to generate change: {e}")
        return None


async def _refine_change_with_agent(
    original_change: ICFChange,
    feedback: List[str],
    country: str,
    generator_agent,
    kernel: Kernel
) -> Optional[ICFChange]:
    """Refine a change based on validation feedback using Generator Agent with dynamic RAG."""
    
    # Build prompt - agent will dynamically query RAG as needed
    prompt = f"""Refine change based on validation feedback.

Original Change:
- Location: {original_change.location}
- Type: {original_change.change_type.value}
- Old Text: {original_change.old_text or 'N/A'}
- New Text: {original_change.new_text or 'N/A'}
- Regulatory Reference: {original_change.regulatory_reference}
- Justification: {original_change.justification}

Feedback Issues:
{chr(10).join(f'- {issue}' for issue in feedback)}

Country: {country}

IMPORTANT: Use RAG.query_regulations tool to dynamically retrieve relevant regulatory requirements to address the feedback issues.

Return JSON with refined change:
{{
    "location": "Section X - Title",
    "change_type": "INSERT" or "DELETE" or "MODIFY",
    "old_text": "text to remove",
    "new_text": "refined text addressing feedback",
    "after_text": "anchor text",
    "regulatory_reference": "citation",
    "justification": "how this addresses feedback",
    "comment": "reviewer note"
}}"""

    try:
        # Use agent to refine change
        arguments = KernelArguments(
            location=original_change.location,
            change_type=original_change.change_type.value,
            regulatory_reference=original_change.regulatory_reference,
            country=country
        )
        
        # Invoke agent with retry logic for rate limiting
        # The agent can dynamically call RAG.query_regulations to address feedback
        response_text = await _invoke_agent_with_retry(generator_agent, prompt, arguments, max_retries=3)
        
        # Check if response looks like an error message before trying to parse JSON
        response_lower = response_text.lower().strip()
        if any(keyword in response_lower for keyword in ["error", "exception", "failed", "rate limit", "429"]):
            if "rate limit" in response_lower or "429" in response_lower:
                raise ValueError(f"Rate limit error in agent response: {response_text[:200]}")
            else:
                raise ValueError(f"Error message in agent response: {response_text[:200]}")
        
        # Try to extract JSON from response
        import re
        change_data = None
        
        # First try: Look for JSON object with location or change_type fields
        json_match = re.search(r'\{[^{}]*(?:"location"|"change_type")[^{}]*\}', response_text, re.DOTALL)
        if json_match:
            try:
                change_data = json.loads(json_match.group())
            except json.JSONDecodeError:
                pass
        
        # Second try: Try parsing entire response as JSON
        if change_data is None:
            try:
                change_data = json.loads(response_text.strip())
            except json.JSONDecodeError as e:
                raise ValueError(
                    f"Failed to parse JSON from refine agent response. "
                    f"Response text: {response_text[:500]}... "
                    f"Error: {str(e)}"
                ) from e
        
        if change_data is None:
            raise ValueError(f"Could not extract valid JSON from agent response: {response_text[:500]}")
        
        # Map change_type to enum
        change_type_str = change_data.get("change_type", "MODIFY").upper()
        if "INSERT" in change_type_str:
            change_type = ChangeType.INSERT
        elif "DELETE" in change_type_str:
            change_type = ChangeType.DELETE
        else:
            change_type = ChangeType.MODIFY
        
        refined_change = ICFChange(
            change_id=f"{original_change.source_plan_item_id}_refined_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
            source_plan_item_id=original_change.source_plan_item_id,
            source_global_section_id=original_change.source_global_section_id,
            location=change_data.get("location", original_change.location),
            change_type=change_type,
            old_text=change_data.get("old_text", original_change.old_text),
            new_text=change_data.get("new_text", original_change.new_text),
            after_text=change_data.get("after_text", original_change.after_text),
            regulatory_reference=change_data.get("regulatory_reference", original_change.regulatory_reference),
            justification=change_data.get("justification", original_change.justification),
            comment=change_data.get("comment", f"Refined based on: {', '.join(feedback)}"),
            rationale=original_change.rationale
        )
        
        return refined_change
        
    except Exception as e:
        print(f"    ⚠️  Failed to refine change with agent: {e}")
        import traceback
        traceback.print_exc()
        return None


async def _refine_change(
    original_change: ICFChange,
    feedback: List[str],
    regulations: List[Dict],
    openai_client,
    deployment_name: str
) -> Optional[ICFChange]:
    """
    Legacy refine function (kept for backward compatibility).
    Use _refine_change_with_agent instead.
    """
    # Use full regulatory content from retrieved chunks
    regulation_context = "\n\n".join([
        f"[{r.get('source', 'Unknown')}]\n{r.get('content', '')}"
        for r in regulations[:10]
    ])
    
    # Minimal prompt - let retrieved chunks provide refinement context
    prompt = f"""Refine change based on feedback.

Original Change:
- Location: {original_change.location}
- Type: {original_change.change_type.value}
- Old Text: {original_change.old_text or 'N/A'}
- New Text: {original_change.new_text or 'N/A'}
- Reference: {original_change.regulatory_reference}

Feedback Issues:
{chr(10).join(f'- {issue}' for issue in feedback)}

Regulatory Requirements:
{regulation_context}

Return JSON with refined change:
{{
    "location": "Section X - Title",
    "change_type": "INSERT" or "DELETE" or "MODIFY",
    "old_text": "text to remove",
    "new_text": "refined text addressing feedback",
    "after_text": "anchor text",
    "regulatory_reference": "citation",
    "justification": "how this addresses feedback",
    "comment": "reviewer note"
}}"""

    try:
        response = openai_client.chat.completions.create(
            model=deployment_name,
            messages=[
                {"role": "system", "content": "You are an ICF customization agent. Refine changes based on feedback to ensure comprehensive compliance."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.2,
            response_format={"type": "json_object"}
        )
        
        response_text = response.choices[0].message.content
        change_data = json.loads(response_text.strip())
        
        # Map change_type to enum
        change_type_str = change_data.get("change_type", "MODIFY").upper()
        if "INSERT" in change_type_str:
            change_type = ChangeType.INSERT
        elif "DELETE" in change_type_str:
            change_type = ChangeType.DELETE
        else:
            change_type = ChangeType.MODIFY
        
        refined_change = ICFChange(
            change_id=f"{original_change.source_plan_item_id}_refined_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
            source_plan_item_id=original_change.source_plan_item_id,
            source_global_section_id=original_change.source_global_section_id,
            location=change_data.get("location", original_change.location),
            change_type=change_type,
            old_text=change_data.get("old_text", original_change.old_text),
            new_text=change_data.get("new_text", original_change.new_text),
            after_text=change_data.get("after_text", original_change.after_text),
            regulatory_reference=change_data.get("regulatory_reference", original_change.regulatory_reference),
            justification=change_data.get("justification", original_change.justification),
            comment=change_data.get("comment", f"Refined based on: {', '.join(feedback)}"),
            rationale=original_change.rationale
        )
        
        return refined_change
        
    except Exception as e:
        print(f"    ⚠️  Failed to refine change: {e}")
        return None


async def _validate_change_with_agent(
    change: ICFChange,
    country: str,
    qa_agent,
    kernel: Kernel,
    max_iterations: int = 5
) -> Dict[str, Any]:
    """
    Validate a single change using QA Agent with dynamic RAG queries.
    
    The agent will dynamically query RAG to verify regulatory references.
    """
    # Build prompt - agent will dynamically query RAG to validate references
    prompt = f"""Validate change against regulatory requirements. Use RAG.query_regulations and RAG.verify_regulatory_reference tools to validate.

Change to validate:
- Location: {change.location}
- Type: {change.change_type.value}
- Old Text: {change.old_text or 'N/A'}
- New Text: {change.new_text or 'N/A'}
- Regulatory Reference: {change.regulatory_reference}
- Justification: {change.justification}

Country: {country}

CRITICAL: Check for duplicate/redundant content:
1. If change_type is INSERT, verify the new_text doesn't duplicate information that might already exist in the section
2. If new_text repeats information from old_text (when type is MODIFY), flag as potentially redundant
3. Check if the new_text adds genuinely new information or just rephrases existing content

IMPORTANT: Use the RAG tools to dynamically verify:
1. Call RAG.verify_regulatory_reference(reference="{change.regulatory_reference}", country="{country}") to verify the citation exists
2. If needed, call RAG.query_regulations(query="regulatory topic related to this change", country="{country}", top_k=10) to get relevant regulations
3. Compare the change against the retrieved regulatory requirements
4. Validate that the change correctly implements the regulation

Return JSON:
{{
    "approved": true or false,
    "reason": "explanation of approval or rejection",
    "issues": ["list of specific issues if rejected"]
}}"""

    try:
        # Use QA agent to validate - agent will call RAG tools dynamically
        arguments = KernelArguments(
            location=change.location,
            change_type=change.change_type.value,
            regulatory_reference=change.regulatory_reference,
            country=country
        )
        
        # Invoke agent with retry logic for rate limiting
        # The agent can dynamically call RAG.verify_regulatory_reference and RAG.query_regulations
        response_text = await _invoke_agent_with_retry(qa_agent, prompt, arguments, max_retries=3)
        
        # Check if response looks like an error message before trying to parse JSON
        response_lower = response_text.lower().strip()
        if any(keyword in response_lower for keyword in ["error", "exception", "failed", "rate limit", "429"]):
            if "rate limit" in response_lower or "429" in response_lower:
                raise ValueError(f"Rate limit error in QA agent response: {response_text[:200]}")
            else:
                raise ValueError(f"Error message in QA agent response: {response_text[:200]}")
        
        # Try to extract JSON from response
        import re
        validation = None
        
        # First try: Look for JSON object with approved or reason fields
        json_match = re.search(r'\{[^{}]*(?:"approved"|"reason")[^{}]*\}', response_text, re.DOTALL)
        if json_match:
            try:
                validation = json.loads(json_match.group())
            except json.JSONDecodeError:
                pass
        
        # Second try: Look for any JSON object in the response
        if validation is None:
            json_objects = re.findall(r'\{[^{}]*\}', response_text, re.DOTALL)
            for json_str in json_objects:
                try:
                    candidate = json.loads(json_str)
                    if "approved" in candidate or "reason" in candidate:
                        validation = candidate
                        break
                except json.JSONDecodeError:
                    continue
        
        # Third try: Try parsing entire response as JSON
        if validation is None:
            try:
                validation = json.loads(response_text.strip())
            except json.JSONDecodeError as e:
                raise ValueError(
                    f"Failed to parse JSON from QA agent response. "
                    f"Response text: {response_text[:500]}... "
                    f"Error: {str(e)}"
                ) from e
        
        return validation
        
    except Exception as e:
        print(f"    ⚠️  Validation failed with agent: {e}")
        import traceback
        traceback.print_exc()
        # Default to rejected on error
        return {
            "approved": False,
            "reason": f"Validation error: {str(e)}",
            "issues": ["Validation process failed"]
        }


async def _validate_change(
    change: ICFChange,
    regulations: List[Dict],
    openai_client,
    deployment_name: str,
    max_iterations: int = 5
) -> Dict[str, Any]:
    """
    Legacy validation function (kept for backward compatibility).
    Use _validate_change_with_agent instead.
    """
    # Use full regulatory content from retrieved chunks
    regulation_context = "\n\n".join([
        f"[{r.get('source', 'Unknown')}]\n{r.get('content', '')}"
        for r in regulations[:10]  # Top 10 semantically matched chunks
    ])
    
    # Minimal prompt - let retrieved regulatory chunks provide validation context
    prompt = f"""Validate change against retrieved regulatory requirements.

Change:
- Location: {change.location}
- Type: {change.change_type.value}
- Old Text: {change.old_text or 'N/A'}
- New Text: {change.new_text or 'N/A'}
- Reference: {change.regulatory_reference}

Regulatory Requirements:
{regulation_context}

Return JSON:
{{
    "approved": true or false,
    "reason": "explanation",
    "issues": ["list of issues if rejected"]
}}"""

    try:
        response = openai_client.chat.completions.create(
            model=deployment_name,
            messages=[
                {"role": "system", "content": "You are a QA validation agent. Strictly validate ICF changes for regulatory compliance."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.0,  # Deterministic validation
            response_format={"type": "json_object"}
        )
        
        response_text = response.choices[0].message.content
        validation = json.loads(response_text.strip())
        
        return validation
        
    except Exception as e:
        print(f"    ⚠️  Validation failed: {e}")
        # Default to rejected on error
        return {
            "approved": False,
            "reason": f"Validation error: {str(e)}",
            "issues": ["Validation process failed"]
        }
