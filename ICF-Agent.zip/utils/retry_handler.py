"""
Retry Handler with exponential backoff for ICF Generator.
Handles transient failures from Azure services.
"""

import time
import random
from typing import Callable, Any, Tuple, Type
from functools import wraps


class RetryHandler:
    """Retry handler with exponential backoff."""
    
    DEFAULT_MAX_RETRIES = 3
    DEFAULT_BASE_DELAY = 1.0
    DEFAULT_MAX_DELAY = 30.0
    
    RETRYABLE_EXCEPTIONS = (
        ConnectionError,
        TimeoutError,
        OSError,
    )
    
    RETRYABLE_STATUS_CODES = {429, 500, 502, 503, 504}
    
    @staticmethod
    def with_retry(
        max_retries: int = DEFAULT_MAX_RETRIES,
        base_delay: float = DEFAULT_BASE_DELAY,
        max_delay: float = DEFAULT_MAX_DELAY,
        exceptions: Tuple[Type[Exception], ...] = None
    ):
        """
        Decorator for retrying functions with exponential backoff.
        
        Args:
            max_retries: Maximum number of retry attempts
            base_delay: Initial delay in seconds
            max_delay: Maximum delay in seconds
            exceptions: Tuple of exceptions to retry on
        """
        retry_exceptions = exceptions or RetryHandler.RETRYABLE_EXCEPTIONS
        
        def decorator(func: Callable) -> Callable:
            @wraps(func)
            def wrapper(*args, **kwargs) -> Any:
                last_exception = None
                
                for attempt in range(max_retries + 1):
                    try:
                        return func(*args, **kwargs)
                    except retry_exceptions as e:
                        last_exception = e
                        
                        if attempt < max_retries:
                            delay = min(
                                base_delay * (2 ** attempt) + random.uniform(0, 1),
                                max_delay
                            )
                            print(f"⚠️ Retry {attempt + 1}/{max_retries} after {delay:.1f}s: {e}")
                            time.sleep(delay)
                        else:
                            print(f"❌ All {max_retries} retries failed: {e}")
                    except Exception as e:
                        # Check for HTTP status codes in exception message
                        error_str = str(e).lower()
                        if any(str(code) in error_str for code in RetryHandler.RETRYABLE_STATUS_CODES):
                            last_exception = e
                            if attempt < max_retries:
                                delay = min(
                                    base_delay * (2 ** attempt) + random.uniform(0, 1),
                                    max_delay
                                )
                                print(f"⚠️ Retry {attempt + 1}/{max_retries} (status code): {e}")
                                time.sleep(delay)
                                continue
                        raise
                
                raise last_exception
            
            return wrapper
        return decorator
    
    @staticmethod
    def retry_call(
        func: Callable,
        args: tuple = (),
        kwargs: dict = None,
        max_retries: int = DEFAULT_MAX_RETRIES,
        base_delay: float = DEFAULT_BASE_DELAY
    ) -> Any:
        """
        Retry a function call with exponential backoff.
        
        Args:
            func: Function to call
            args: Positional arguments
            kwargs: Keyword arguments
            max_retries: Maximum retries
            base_delay: Base delay in seconds
        """
        kwargs = kwargs or {}
        last_exception = None
        
        for attempt in range(max_retries + 1):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                last_exception = e
                error_str = str(e).lower()
                
                is_retryable = (
                    isinstance(e, RetryHandler.RETRYABLE_EXCEPTIONS) or
                    any(str(code) in error_str for code in RetryHandler.RETRYABLE_STATUS_CODES) or
                    "rate" in error_str or
                    "timeout" in error_str or
                    "connection" in error_str
                )
                
                if is_retryable and attempt < max_retries:
                    delay = base_delay * (2 ** attempt) + random.uniform(0, 1)
                    print(f"⚠️ Retry {attempt + 1}/{max_retries} after {delay:.1f}s: {e}")
                    time.sleep(delay)
                elif not is_retryable:
                    raise
        
        raise last_exception


# Convenience decorator
retry = RetryHandler.with_retry