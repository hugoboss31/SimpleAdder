from azure.search.documents import SearchClient
from azure.search.documents.models import VectorizedQuery
from azure.search.documents.indexes import SearchIndexClient
from azure.search.documents.indexes.models import (
    SearchIndex,
    SearchField,
    SearchFieldDataType,
    VectorSearch,
    HnswAlgorithmConfiguration,
    VectorSearchProfile
)
from pypdf import PdfReader
from typing import List, Dict
import os
import re
from io import BytesIO
from openai import AzureOpenAI
from dotenv import load_dotenv
#from tracing_config import get_tracer
from opentelemetry import trace
import json
import threading

load_dotenv()

class RAGManager:
    """RAG system using Azure AI Search with hybrid search (vector + keyword)"""
    
    def __init__(self):
        from config import config
        
        # Azure AI Search
        self.search_endpoint = config.get_search_endpoint()
        self.search_credential = config.get_search_credential()
        self.index_name = config.RAG_INDEX_NAME
        
        # Azure OpenAI for embeddings
        self.embedding_deployment = config.EMBEDDINGS_MODEL_DEPLOYMENT
        self.openai_endpoint = config.AZURE_OPENAI_ENDPOINT
        self.openai_key = config.AZURE_OPENAI_API_KEY
        
        # Azure Blob Storage
        self.container_name = config.AZURE_STORAGE_CONTAINER_NAME
        self.blob_service_client = None
        self.container_client = None
        if config.AZURE_STORAGE_CONNECTION_STRING or config.AZURE_STORAGE_BLOB_ENDPOINT:
            self.blob_service_client = config.get_blob_service_client()
            self.container_client = self.blob_service_client.get_container_client(self.container_name)
            print(f"✅ RAGManager connected to Azure Blob Storage: {self.container_name}")
        
        # Initialize Search and OpenAI clients
        self.search_client = SearchClient(
            endpoint=self.search_endpoint,
            index_name=self.index_name,
            credential=self.search_credential
        )
        self.index_client = SearchIndexClient(
            endpoint=self.search_endpoint,
            credential=self.search_credential
        )
        self.openai_client = AzureOpenAI(
            api_key=self.openai_key,
            api_version=config.AZURE_OPENAI_API_VERSION,
            azure_endpoint=self.openai_endpoint
        )
        
        # Create index if doesn't exist — run in background so worker startup is not blocked (avoids liveness probe killing the pod)
        def _ensure_index_background():
            try:
                self._ensure_index_exists()
            except Exception as e:
                print(f"[RAGManager] ⚠️ Azure AI Search index check/create failed (will retry on next start or first use): {e}")
        t = threading.Thread(target=_ensure_index_background, daemon=True)
        t.start()
        
        # ✅ CHANGE 1: Initialize tracer for RAG operations
        try:
            self.tracer = get_tracer("rag_manager")
        except:
            self.tracer = None
        
        print(f"✅ RAGManager is Activated (Azure AI Search)...")
    
    def _ensure_index_exists(self):
        """Create Azure AI Search index if it doesn't exist"""
        try:
            self.index_client.get_index(self.index_name)
            print(f"✅ Index '{self.index_name}' already exists")
        except:
            print(f"📝 Creating new index: {self.index_name}")
            
            fields = [
                SearchField(name="id", type=SearchFieldDataType.String, key=True, sortable=True, filterable=True),
                SearchField(name="content", type=SearchFieldDataType.String, searchable=True),
                SearchField(name="contentVector", type=SearchFieldDataType.Collection(SearchFieldDataType.Single), 
                           searchable=True, vector_search_dimensions=1536, vector_search_profile_name="vector-profile"),
                SearchField(name="source", type=SearchFieldDataType.String, filterable=True, facetable=True),
                SearchField(name="doc_type", type=SearchFieldDataType.String, filterable=True, facetable=True),
                SearchField(name="chunk_id", type=SearchFieldDataType.Int32, filterable=True),
                SearchField(name="total_chunks", type=SearchFieldDataType.Int32, filterable=True),
                SearchField(name="storage_type", type=SearchFieldDataType.String, filterable=True)
            ]
            
            vector_search = VectorSearch(
                algorithms=[HnswAlgorithmConfiguration(name="hnsw-config")],
                profiles=[VectorSearchProfile(name="vector-profile", algorithm_configuration_name="hnsw-config")]
            )
            
            index = SearchIndex(name=self.index_name, fields=fields, vector_search=vector_search)
            self.index_client.create_index(index)
            print(f"✅ Index created successfully")
    
    def _generate_embedding(self, text: str, document_id: str = None) -> List[float]:
        """Generate embedding using Azure OpenAI
        
        Args:
            text: Text to generate embedding for
            document_id: Optional document identifier for tracking
        """
        # Build embedding request parameters
        params = {
            "input": text,
            "model": self.embedding_deployment
        }
        
        # Add document ID as user metadata if provided
        if document_id:
            params["user"] = document_id
        
        response = self.openai_client.embeddings.create(**params)
        return response.data[0].embedding
    
    def chunk_text(self, text: str, chunk_size: int = 500, overlap: int = 100) -> List[str]:
        """Split text into overlapping chunks"""
        words = text.split()
        chunks = []
        
        for i in range(0, len(words), chunk_size - overlap):
            chunk = ' '.join(words[i:i + chunk_size])
            if chunk.strip():
                chunks.append(chunk)
        
        return chunks
    
    def add_document(self, text: str, metadata: Dict = None, document_id: str = None, document_type: str = "Guideline"):
        """Add document to Azure AI Search index
        
        Args:
            text: Document text to index
            metadata: Optional metadata dictionary
            document_id: Optional document ID to use for embedding tracking.
                        If not provided, will use sanitized source-based ID
            document_type: Document type/category. Defaults to "Guideline"
        """
        chunks = self.chunk_text(text)
        print(f"📦 Adding document to Azure AI Search")
        print(f"   Total chunks: {len(chunks)}")
        
        documents = []
        for idx, chunk in enumerate(chunks):
            chunk_metadata = metadata.copy() if metadata else {}
            chunk_id_str = f"{chunk_metadata.get('source', 'doc')}_{idx}"
            
            # ✅ FIX: Sanitize ID - remove ALL invalid characters
            sanitized_id = chunk_id_str.replace("/", "_").replace(".", "_").replace("(", "_").replace(")", "_").replace(" ", "_")
            
            # Use provided document_id or fall back to sanitized_id
            embedding_doc_id = document_id if document_id else sanitized_id
            
            # Generate embedding with document ID for tracking
            embedding = self._generate_embedding(chunk, document_id=embedding_doc_id)
            
            # Use document_type parameter, or fall back to metadata, or use default
            final_doc_type = chunk_metadata.get("doc_type") if "doc_type" in chunk_metadata else document_type
            
            doc = {
                "id": sanitized_id,  # ✅ Now safe for Azure AI Search
                "content": chunk,
                "contentVector": embedding,
                "source": chunk_metadata.get("source", "Unknown"),
                "doc_type": final_doc_type,
                "chunk_id": idx,
                "total_chunks": len(chunks),
                "storage_type": chunk_metadata.get("storage_type", "unknown")
            }
            documents.append(doc)
        
        # Batch upload to Azure AI Search
        self.search_client.upload_documents(documents=documents)
        print(f"✅ Successfully indexed {len(chunks)} chunks to Azure AI Search")
    
    def clear_index(self):
        """Clear all documents from Azure AI Search index"""
        print(f"🧹 Clearing all indexed documents from Azure AI Search...")
        try:
            # Get all document IDs
            results = self.search_client.search(search_text="*", select=["id"], top=10000)
            doc_ids = [{"id": result["id"]} for result in results]
            
            if doc_ids:
                # Delete all documents
                self.search_client.delete_documents(documents=doc_ids)
                print(f"✅ Index cleared. Removed {len(doc_ids)} documents")
            else:
                print(f"✅ Index is already empty")
        except Exception as e:
            print(f"❌ Error clearing index: {str(e)}")
    
    def remove_document_by_blob(self, blob_name: str) -> int:
        """Remove all chunks belonging to a given blob (source) from Azure AI Search.
        Returns number of removed chunks.
        """
        if not blob_name:
            return 0
        
        try:
            # Search for all documents with matching source
            results = self.search_client.search(
                search_text="*",
                filter=f"source eq '{blob_name}'",
                select=["id"],
                top=10000
            )
            
            doc_ids = [{"id": result["id"]} for result in results]
            
            if not doc_ids:
                print(f"⚠️ No chunks found for blob '{blob_name}' to remove")
                return 0
            
            # Delete documents
            self.search_client.delete_documents(documents=doc_ids)
            removed_count = len(doc_ids)
            
            print(f"🧹 Removed {removed_count} chunk(s) for blob '{blob_name}'")
            print(f"✅ Deletion complete")
            
            return removed_count
            
        except Exception as e:
            print(f"❌ Error removing document: {str(e)}")
            return 0
    
    def retrieve_by_document_type(self, query: str, doc_type: str, top_k: int = 2) -> List[Dict]:
        """Retrieve context from specific document type using hybrid search"""
        if self.index.ntotal == 0:  
            print(f"⚠️ RAG: Index is empty, no documents loaded")
            return []
        # ✅ CHANGE 2: Create tracing span for RAG operations
        if self.tracer:
            with self.tracer.start_as_current_span(f"RAG_Search_{doc_type}") as span:
                span.set_attribute("gen_ai.system", "azure.search")
                span.set_attribute("gen_ai.operation.name", "retrieval")
                span.set_attribute("tool.name", "azure_ai_search")
                span.set_attribute("tool.call.arguments", json.dumps({"query": query[:200], "doc_type": doc_type}))
                span.set_attribute("doc_type", doc_type)
                span.set_attribute("top_k", top_k)
                span.set_attribute("query_length", len(query))
                span.set_attribute("search.type", "hybrid_vector_keyword")
                        
                try:
                    print(f"\n🔎 RAG Query for {doc_type}: {query[:100]}...")
                    
                    # Generate query embedding
                    query_vector = self._generate_embedding(query)
                    
                    # Hybrid search: vector + keyword with doc_type filter
                    vector_query = VectorizedQuery(
                        vector=query_vector,
                        k_nearest_neighbors=top_k * 3,
                        fields="contentVector"
                    )
                    
                    results = self.search_client.search(
                        search_text=query,
                        vector_queries=[vector_query],
                        filter=f"doc_type eq '{doc_type}'",
                        select=["content", "source", "doc_type", "chunk_id", "storage_type"],
                        top=top_k
                    )
                    
                    retrieved = []
                    for result in results:
                        print(f"  📌 Found in: {doc_type} ({result['source']}) - Chunk {result.get('chunk_id', 0)} (score: {result['@search.score']:.4f})")
                        retrieved.append({
                            "content": result["content"],
                            "metadata": {
                                "source": result["source"],
                                "doc_type": result["doc_type"],
                                "chunk_id": result.get("chunk_id", 0),
                                "storage_type": result.get("storage_type", "unknown")
                            },
                            "score": result['@search.score']
                        })
                    ## ToDo: Remove Score - Bella
                    # Add span attributes for retrieved results
                    span.set_attribute("chunks_retrieved", len(retrieved))
                    if retrieved:
                        span.set_attribute("top_score", retrieved[0]["score"])
                    
                    print(f"✅ RAG: Retrieved {len(retrieved)} chunks from {doc_type}")
                    return retrieved
                    
                except Exception as e:
                    span.set_attribute("error", str(e))
                    raise
        else:
            try:
                print(f"\n🔎 RAG Query for {doc_type}: {query[:100]}...")
                
                # Generate query embedding
                query_vector = self._generate_embedding(query)
                
                # Hybrid search: vector + keyword with doc_type filter
                vector_query = VectorizedQuery(
                    vector=query_vector,
                    k_nearest_neighbors=top_k * 3,
                    fields="contentVector"
                )
                
                results = self.search_client.search(
                    search_text=query,
                    vector_queries=[vector_query],
                    filter=f"doc_type eq '{doc_type}'",
                    select=["content", "source", "doc_type", "chunk_id", "storage_type"],
                    top=top_k
                )
                
                retrieved = []
                for result in results:
                    print(f"  📌 Found in: {doc_type} ({result['source']}) - Chunk {result.get('chunk_id', 0)} (score: {result['@search.score']:.4f})")
                    retrieved.append({
                        "content": result["content"],
                        "metadata": {
                            "source": result["source"],
                            "doc_type": result["doc_type"],
                            "chunk_id": result.get("chunk_id", 0),
                            "storage_type": result.get("storage_type", "unknown")
                        },
                        "score": result['@search.score']
                    })
                
                print(f"✅ RAG: Retrieved {len(retrieved)} chunks from {doc_type}")
                return retrieved
                
            except Exception as e:
                raise
    
    def retrieve_by_document_id(self, query: str, document_id: str, top_k: int = 2) -> List[Dict]:
        """Retrieve context from specific document using hybrid search
        
        Args:
            query: Search query text
            document_id: Document ID to filter by
            top_k: Number of top results to return
            
        Returns:
            List of retrieved chunks with metadata
        """
        if self.index.ntotal == 0:  
            print(f"⚠️ RAG: Index is empty, no documents loaded")
            return []
        
        if self.tracer:
            with self.tracer.start_as_current_span(f"RAG_Search_DocID") as span:
                span.set_attribute("gen_ai.system", "azure.search")
                span.set_attribute("gen_ai.operation.name", "retrieval")
                span.set_attribute("tool.name", "azure_ai_search")
                span.set_attribute("tool.call.arguments", json.dumps({"query": query[:200], "document_id": document_id}))
                span.set_attribute("document_id", document_id)
                span.set_attribute("top_k", top_k)
                span.set_attribute("query_length", len(query))
                span.set_attribute("search.type", "hybrid_vector_keyword")
                        
                try:
                    print(f"\n🔎 RAG Query for document ID '{document_id}': {query[:100]}...")
                    
                    # Generate query embedding
                    query_vector = self._generate_embedding(query)
                    
                    # Hybrid search: vector + keyword with document ID filter
                    vector_query = VectorizedQuery(
                        vector=query_vector,
                        k_nearest_neighbors=top_k * 3,
                        fields="contentVector"
                    )
                    
                    results = self.search_client.search(
                        search_text=query,
                        vector_queries=[vector_query],
                        filter=f"id eq '{document_id}'",
                        select=["content", "source", "doc_type", "chunk_id", "storage_type"],
                        top=top_k
                    )
                    
                    retrieved = []
                    for result in results:
                        print(f"  📌 Found in: {document_id} ({result['source']}) - Chunk {result.get('chunk_id', 0)} (score: {result['@search.score']:.4f})")
                        retrieved.append({
                            "content": result["content"],
                            "metadata": {
                                "source": result["source"],
                                "doc_type": result["doc_type"],
                                "chunk_id": result.get("chunk_id", 0),
                                "storage_type": result.get("storage_type", "unknown")
                            },
                            "score": result['@search.score']
                        })
                    
                    # Add span attributes for retrieved results
                    span.set_attribute("chunks_retrieved", len(retrieved))
                    if retrieved:
                        span.set_attribute("top_score", retrieved[0]["score"])
                    
                    print(f"✅ RAG: Retrieved {len(retrieved)} chunks for document ID '{document_id}'")
                    return retrieved
                    
                except Exception as e:
                    span.set_attribute("error", str(e))
                    raise
        else:
            try:
                print(f"\n🔎 RAG Query for document ID '{document_id}': {query[:100]}...")
                
                # Generate query embedding
                query_vector = self._generate_embedding(query)
                
                # Hybrid search: vector + keyword with document ID filter
                vector_query = VectorizedQuery(
                    vector=query_vector,
                    k_nearest_neighbors=top_k * 3,
                    fields="contentVector"
                )
                
                results = self.search_client.search(
                    search_text=query,
                    vector_queries=[vector_query],
                    filter=f"id eq '{document_id}'",
                    select=["content", "source", "doc_type", "chunk_id", "storage_type"],
                    top=top_k
                )
                
                retrieved = []
                for result in results:
                    print(f"  📌 Found in: {document_id} ({result['source']}) - Chunk {result.get('chunk_id', 0)} (score: {result['@search.score']:.4f})")
                    retrieved.append({
                        "content": result["content"],
                        "metadata": {
                            "source": result["source"],
                            "doc_type": result["doc_type"],
                            "chunk_id": result.get("chunk_id", 0),
                            "storage_type": result.get("storage_type", "unknown")
                        },
                        "score": result['@search.score']
                    })
                
                print(f"✅ RAG: Retrieved {len(retrieved)} chunks for document ID '{document_id}'")
                return retrieved
                
            except Exception as e:
                raise
        
    @property
    def index(self):
        """Compatibility property for existing code that checks index.ntotal"""
        class IndexCompat:
            def __init__(self, search_client):
                self._client = search_client
            
            @property
            def ntotal(self):
                try:
                    result = self._client.search(search_text="*", include_total_count=True, top=0)
                    return result.get_count() or 0
                except:
                    return 0
        
        return IndexCompat(self.search_client)