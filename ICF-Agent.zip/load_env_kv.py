"""
Load environment variables from Azure Key Vault.
Call this after load_dotenv() so AZURE_KEY_VAULT_URI can come from .env.
Sets os.environ from all secrets in the vault; secret names use hyphens -> env vars use underscores.
"""
import os
import re


def _secret_name_to_env_key(name: str) -> str:
    if "-" in name:
        return name.replace("-", "_").upper()
    # PascalCase/camelCase -> SCREAMING_SNAKE
    s1 = re.sub(r"([a-z])([A-Z0-9])", r"\1_\2", name)
    s2 = re.sub(r"([A-Z])([A-Z][a-z])", r"\1_\2", s1)
    return s2.upper()


# Key Vault secret names (lowercase) -> env var name for agent
ENV_ALIASES = {
    "agent-azure-openai-api-key": "AZURE_OPENAI_API_KEY",
    "agent-azure-openai-api-version": "AZURE_OPENAI_API_VERSION",
    "agent-azure-openai-deployment": "AZURE_OPENAI_DEPLOYMENT_NAME",
    "agent-azure-openai-embeddings-deployment": "EMBEDDINGS_MODEL_DEPLOYMENT",
    "agent-azure-openai-endpoint": "AZURE_OPENAI_ENDPOINT",
    "agent-azure-search-endpoint": "AZURE_SEARCH_ENDPOINT",
    "agent-azure-search-key": "AZURE_SEARCH_KEY",
    "agent-azure-storage-account-name": "AZURE_STORAGE_ACCOUNT_NAME",
    "agent-azure-storage-container-name": "AZURE_STORAGE_CONTAINER_NAME",
    "agent-backend-api-url": "BACKEND_API_URL",
    "application-insights-connection-string": "APPLICATION_INSIGHTS_CONNECTION_STRING",
    "azure-service-bus-connection-string": "AZURE_SERVICE_BUS_CONNECTION_STRING",
    "azure-storage-account-name": "AZURE_STORAGE_ACCOUNT_NAME",
    "azure-storage-connection-string": "AZURE_STORAGE_CONNECTION_STRING",
    "azure-storage-container-name": "AZURE_STORAGE_CONTAINER_NAME",
    "kv-openai-api-key-value": "AZURE_OPENAI_API_KEY",
}


def load_env_from_kv() -> None:
    vault_uri = (os.environ.get("AZURE_KEY_VAULT_URI") or "").strip()
    if not vault_uri:
        return

    try:
        from azure.identity import DefaultAzureCredential
        from azure.keyvault.secrets import SecretClient
    except ImportError as e:
        raise RuntimeError(
            "AZURE_KEY_VAULT_URI is set but azure-identity or azure-keyvault-secrets is not installed. "
            "pip install azure-identity azure-keyvault-secrets"
        ) from e

    credential = DefaultAzureCredential()
    client = SecretClient(vault_url=vault_uri, credential=credential)
    secret_names = [p.name for p in client.list_properties_of_secrets() if p.name]
    count = 0
    for name in secret_names:
        try:
            secret = client.get_secret(name)
            if secret and secret.value:
                env_key = _secret_name_to_env_key(name)
                os.environ[env_key] = secret.value
                alias_key = ENV_ALIASES.get(name.lower())
                if alias_key:
                    os.environ[alias_key] = secret.value
                count += 1
        except Exception as e:
            print(f"[load_env_kv] Could not read secret '{name}': {e}")
    # Local: force backend URL to localhost so agent never uses Azure URL when running locally.
    # Production: do not overwrite; use only Key Vault (Azure) URL.
    if os.environ.get("NODE_ENV") != "production":
        os.environ["BACKEND_API_URL"] = "http://localhost:5001"
    print(f"[load_env_kv] Loaded {count} secret(s) from Key Vault ({vault_uri}).")
