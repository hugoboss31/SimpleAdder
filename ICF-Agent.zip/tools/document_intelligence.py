"""Document Intelligence tool for DOCX processing."""

import os
from typing import Dict, Any, List, Optional
from azure.ai.documentintelligence import DocumentIntelligenceClient
from azure.core.credentials import AzureKeyCredential
from schemas.icf_schemas import ICFSection, ICFSectionTree


class DocumentIntelligenceTool:
    """Tool for extracting content from DOCX files using Azure Document Intelligence (optional)."""
    
    def __init__(self):
        self.endpoint = os.getenv("AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT")
        self.api_key = os.getenv("AZURE_DOCUMENT_INTELLIGENCE_API_KEY")
        self._available = bool(self.endpoint and self.api_key)
        self.client = None
        if self._available:
            self.client = DocumentIntelligenceClient(
                endpoint=self.endpoint,
                credential=AzureKeyCredential(self.api_key)
            )
    
    def extract_document(self, file_path: str) -> Dict[str, Any]:
        """
        Extract content and structure from DOCX file.
        """
        if not self._available or not self.client:
            raise ValueError(
                "Document Intelligence is not configured. Set AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT and "
                "AZURE_DOCUMENT_INTELLIGENCE_API_KEY to enable DOCX extraction."
            )
        with open(file_path, "rb") as f:
            file_content = f.read()
        
        poller = self.client.begin_analyze_document(
            model_id="prebuilt-layout",
            body=file_content,
            content_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        )
        
        result = poller.result()
        
        sections = []
        all_paragraphs = []
        current_section = None
        
        if hasattr(result, 'paragraphs'):
            for idx, para in enumerate(result.paragraphs):
                para_info = {
                    'index': idx,
                    'content': para.content,
                    'role': getattr(para, 'role', None),
                    'is_heading': False
                }
                
                if hasattr(para, 'role') and para.role and 'heading' in para.role.lower():
                    # This is a heading - create new section
                    para_info['is_heading'] = True
                    current_section = {
                        'section_id': f"section_{len(sections)}",
                        'title': para.content,
                        'heading_index': idx,
                        'content': '',
                        'paragraphs': []
                    }
                    sections.append(current_section)
                elif current_section is not None:
                    # Add content to current section
                    current_section['content'] += para.content + "\n"
                    current_section['paragraphs'].append(para_info)
                
                all_paragraphs.append(para_info)
        
        return {
            'sections': sections,
            'paragraphs': all_paragraphs,
            'full_text': result.content if hasattr(result, 'content') else "",
            'metadata': {
                'page_count': len(result.pages) if hasattr(result, 'pages') else 0,
                'total_paragraphs': len(all_paragraphs),
                'total_sections': len(sections)
            }
        }
    
    def extract_with_tracked_changes(self, file_path: str) -> Dict[str, Any]:
        """
        Extract document with tracked changes information.
        """
        if not self._available or not self.client:
            raise ValueError(
                "Document Intelligence is not configured. Set AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT and "
                "AZURE_DOCUMENT_INTELLIGENCE_API_KEY to enable DOCX extraction."
            )
        # First get basic structure
        doc_structure = self.extract_document(file_path)
        
        # Parse tracked changes using python-docx
        from docx import Document
        from docx.oxml.ns import qn
        
        doc = Document(file_path)
        
        tracked_changes = {
            'insertions': [],
            'deletions': [],
            'comments': []
        }
        
        # Extract tracked changes from paragraphs
        for para_idx, para in enumerate(doc.paragraphs):
            para_text = para.text
            
            # Check for insertions and deletions in runs
            for run in para.runs:
                run_element = run._element
                
                # Check for insertions (<w:ins>)
                ins_elements = run_element.findall(qn('w:ins'))
                for ins in ins_elements:
                    tracked_changes['insertions'].append({
                        'paragraph_index': para_idx,
                        'text': run.text,
                        'author': ins.get(qn('w:author'), 'Unknown'),
                        'date': ins.get(qn('w:date'), ''),
                        'location': para_text[:50] + '...' if len(para_text) > 50 else para_text
                    })
                
                # Check for deletions (<w:del>)
                del_elements = run_element.findall(qn('w:del'))
                for deletion in del_elements:
                    tracked_changes['deletions'].append({
                        'paragraph_index': para_idx,
                        'text': run.text,
                        'author': deletion.get(qn('w:author'), 'Unknown'),
                        'date': deletion.get(qn('w:date'), ''),
                        'location': para_text[:50] + '...' if len(para_text) > 50 else para_text
                    })
        
        # Extract comments
        if hasattr(doc, 'part') and hasattr(doc.part, 'comments_part'):
            try:
                comments_part = doc.part.comments_part
                if comments_part:
                    comment_elements = comments_part.element.findall(qn('w:comment'))
                    for comment in comment_elements:
                        comment_id = comment.get(qn('w:id'), '')
                        author = comment.get(qn('w:author'), 'Unknown')
                        date = comment.get(qn('w:date'), '')
                        
                        # Extract comment text
                        comment_text = ''
                        for paragraph in comment.findall(qn('w:p')):
                            for run in paragraph.findall(qn('w:r')):
                                text_elem = run.find(qn('w:t'))
                                if text_elem is not None and text_elem.text:
                                    comment_text += text_elem.text
                        
                        tracked_changes['comments'].append({
                            'id': comment_id,
                            'author': author,
                            'date': date,
                            'text': comment_text
                        })
            except Exception as e:
                print(f"Warning: Could not extract comments: {e}")
        
        return {
            **doc_structure,
            'tracked_changes': tracked_changes
        }
    
    def extract_section_tree(self, file_path: str, document_id: Optional[str] = None) -> ICFSectionTree:
        """
        Extract Global ICF into a hierarchical section tree structure.
        """
        if not self._available or not self.client:
            raise ValueError(
                "Document Intelligence is not configured. Set AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT and "
                "AZURE_DOCUMENT_INTELLIGENCE_API_KEY to enable section tree extraction."
            )
        with open(file_path, "rb") as f:
            file_content = f.read()
        
        poller = self.client.begin_analyze_document(
            model_id="prebuilt-layout",
            body=file_content,
            content_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        )
        
        result = poller.result()
        
        # Generate document_id if not provided
        if not document_id:
            document_id = f"doc_{os.path.basename(file_path).replace('.docx', '')}"
        
        # Build hierarchical section tree
        sections: List[ICFSection] = []
        section_stack: List[ICFSection] = []  # Stack to track parent sections
        order_index = 0
        
        # First try Document Intelligence
        paragraphs_found = False
        if hasattr(result, 'paragraphs') and result.paragraphs:
            paragraphs_found = True
            for para in result.paragraphs:
                para_role = getattr(para, 'role', None)
                is_heading = para_role and 'heading' in para_role.lower()
                
                if is_heading:
                    # Determine heading level (simplified - can be enhanced)
                    heading_level = self._determine_heading_level(para.content, para_role)
                    
                    # Pop stack until we find the correct parent level
                    while section_stack and section_stack[-1].level >= heading_level:
                        section_stack.pop()
                    
                    # Create new section
                    parent_id = section_stack[-1].section_id if section_stack else None
                    section_id = self._generate_section_id(len(sections), parent_id)
                    
                    section = ICFSection(
                        section_id=section_id,
                        title=para.content,
                        level=heading_level,
                        page=self._get_page_number(para, result),
                        order_index=order_index,
                        text=para.content,
                        parent_section_id=parent_id,
                        children=[],
                        metadata={"role": para_role}
                    )
                    
                    # Add to parent's children if parent exists
                    if section_stack:
                        section_stack[-1].children.append(section)
                    else:
                        sections.append(section)
                    
                    section_stack.append(section)
                    order_index += 1
                
                elif section_stack:
                    # Add paragraph text to current section
                    current_section = section_stack[-1]
                    if current_section.text and not current_section.text.endswith('\n'):
                        current_section.text += '\n'
                    current_section.text += para.content
                    order_index += 1
        
        # Fallback: If no sections found, use python-docx to detect headings
        if not sections and paragraphs_found:
            print("[INFO] No headings detected by Document Intelligence, trying python-docx fallback...")
            try:
                from docx import Document
                doc = Document(file_path)
                
                for para_idx, para in enumerate(doc.paragraphs):
                    para_text = para.text.strip()
                    if not para_text:
                        continue
                    
                    # Check if paragraph is a heading based on style
                    is_heading = False
                    heading_level = 2
                    
                    if para.style and para.style.name:
                        style_name = para.style.name.lower()
                        if 'heading' in style_name:
                            is_heading = True
                            # Extract level from style name (e.g., "Heading 1" -> level 1)
                            try:
                                level_str = style_name.replace('heading', '').strip()
                                if level_str:
                                    heading_level = int(level_str)
                                else:
                                    heading_level = 1
                            except:
                                heading_level = 1
                        elif para.style.name.startswith('Heading'):
                            is_heading = True
                            heading_level = 1
                    
                    # Also check if text looks like a heading (all caps, short, etc.)
                    if not is_heading and len(para_text) < 100:
                        # Check if it's all caps or starts with number
                        if para_text.isupper() or (para_text and para_text[0].isdigit()):
                            # Check if next paragraph is regular text (not heading)
                            if para_idx + 1 < len(doc.paragraphs):
                                next_para = doc.paragraphs[para_idx + 1]
                                if next_para.text and len(next_para.text) > 50:
                                    is_heading = True
                                    heading_level = 1 if para_text.isupper() else 2
                    
                    if is_heading:
                        # Pop stack until we find the correct parent level
                        while section_stack and section_stack[-1].level >= heading_level:
                            section_stack.pop()
                        
                        # Create new section
                        parent_id = section_stack[-1].section_id if section_stack else None
                        section_id = self._generate_section_id(len(sections), parent_id)
                        
                        section = ICFSection(
                            section_id=section_id,
                            title=para_text,
                            level=heading_level,
                            page=None,  # python-docx doesn't provide page numbers easily
                            order_index=order_index,
                            text=para_text,
                            parent_section_id=parent_id,
                            children=[],
                            metadata={"style": para.style.name if para.style else None}
                        )
                        
                        # Add to parent's children if parent exists
                        if section_stack:
                            section_stack[-1].children.append(section)
                        else:
                            sections.append(section)
                        
                        section_stack.append(section)
                        order_index += 1
                    
                    elif section_stack:
                        # Add paragraph text to current section
                        current_section = section_stack[-1]
                        if current_section.text and not current_section.text.endswith('\n'):
                            current_section.text += '\n'
                        current_section.text += para_text
                        order_index += 1
                    elif not sections:
                        # Create a default section if no headings found
                        section = ICFSection(
                            section_id="sec_1",
                            title=None,
                            level=1,
                            page=None,
                            order_index=0,
                            text=para_text,
                            parent_section_id=None,
                            children=[],
                            metadata={}
                        )
                        sections.append(section)
                        section_stack.append(section)
                        order_index += 1
                
                print(f"[OK] Extracted {len(sections)} sections using python-docx fallback")
            except Exception as e:
                print(f"[WARN] python-docx fallback failed: {e}")
        
        # Count total paragraphs
        total_paragraphs = sum(1 for s in sections for _ in self._flatten_sections(s))
        
        return ICFSectionTree(
            document_id=document_id,
            document_name=os.path.basename(file_path),
            sections=sections,
            total_sections=len(sections),
            total_paragraphs=total_paragraphs,
            page_count=len(result.pages) if hasattr(result, 'pages') else 0,
            metadata={
                "source_file": file_path,
                "extraction_method": "azure_document_intelligence"
            }
        )
    
    def _determine_heading_level(self, text: str, role: Optional[str]) -> int:
        """Determine heading level from text and role."""
        # Check role first
        if role:
            role_lower = role.lower()
            if 'heading1' in role_lower or 'title' in role_lower:
                return 1
            elif 'heading2' in role_lower:
                return 2
            elif 'heading3' in role_lower:
                return 3
            elif 'heading4' in role_lower:
                return 4
        
        # Fallback: check text formatting patterns
        text_upper = text.upper().strip()
        if text_upper.isupper() and len(text) < 50:
            return 1  # Likely a main heading
        
        # Check for numbered sections (e.g., "1.", "2.1", "A.")
        if text and text[0].isdigit():
            parts = text.split('.')
            if len(parts) > 1:
                return len(parts)  # "2.1" -> level 2, "2.1.3" -> level 3
        
        return 2  # Default to level 2
    
    def _generate_section_id(self, index: int, parent_id: Optional[str]) -> str:
        """Generate a unique section ID."""
        if parent_id:
            # Get parent's numeric part and append sub-index
            parent_parts = parent_id.split('_')
            if len(parent_parts) > 1:
                try:
                    # Count existing children to get next number
                    if '.' in parent_id:
                        # Already has sub-sections, increment
                        parts = parent_id.split('.')
                        last_part = parts[-1]
                        if last_part.isdigit():
                            next_num = int(last_part) + 1
                            return f"{'.'.join(parts[:-1])}.{next_num}"
                    else:
                        # First child
                        return f"{parent_id}.1"
                except:
                    pass
        
        return f"sec_{len([s for s in sections if not s.parent_section_id]) + 1}" if 'sections' in locals() else f"sec_{index + 1}"
    
    def _get_page_number(self, para, result) -> Optional[int]:
        """Extract page number for a paragraph."""
        if hasattr(para, 'spans') and para.spans:
            span = para.spans[0]
            if hasattr(span, 'offset') and hasattr(result, 'pages'):
                # Find which page contains this offset
                offset = span.offset
                for page_idx, page in enumerate(result.pages):
                    if hasattr(page, 'spans'):
                        for page_span in page.spans:
                            if hasattr(page_span, 'offset'):
                                if page_span.offset <= offset < page_span.offset + page_span.length:
                                    return page_idx + 1
        return None
    
    def _flatten_sections(self, section: ICFSection) -> List[ICFSection]:
        """Flatten section tree into list."""
        result = [section]
        for child in section.children:
            result.extend(self._flatten_sections(child))
        return result
