# ICF POC Project Index

This document provides a comprehensive index of all three applications in the ICF (Informed Consent Form) POC project.

## Overview

This project consists of three interconnected applications:

1. **icf-agent** - Python FastAPI application for LLM-powered ICF generation
2. **icf-backend** - Node.js/TypeScript Express API server for document management
3. **icf-web** - React frontend application for user interface

---

## 1. icf-agent (Python Application)

**Location:** `C:\Users\VermaMi\Work\icf-poc\icf-agent`

### Purpose
Python FastAPI service that uses LLM agents (Semantic Kernel/Magentic Orchestration) to generate country-specific Informed Consent Forms from Global ICF templates and customization plans.

### Tech Stack
- **Framework:** FastAPI
- **LLM Framework:** Semantic Kernel with Magentic Orchestration
- **AI Services:** Azure OpenAI, Azure AI Search
- **Document Processing:** Azure Document Intelligence, python-docx, openpyxl
- **Storage:** Azure Blob Storage
- **Testing:** pytest, pytest-asyncio

### Key Components

#### Main Entry Points
- `app.py` - FastAPI application with REST endpoints
- `main.py` - Main orchestration script for agentic ICF generation

#### Agents (`agents/`)
- `generator_agent.py` - Generates country-specific ICF changes
- `qa_agent.py` - Validates and approves generated changes
- `writer_agent.py` - Generates final DOCX with tracked changes
- `section_matcher_agent.py` - Matches customization items to ICF sections
- `ingestion_agent.py` - Processes and indexes Global ICF documents

#### Tools (`tools/`)
- `document_intelligence.py` - Azure Document Intelligence integration for document extraction
- `excel_parser.py` - Parses customization plan Excel files
- `rag_tool.py` - RAG (Retrieval Augmented Generation) for regulatory queries
- `section_search_tool.py` - Hybrid search (BM25 + vector) for section matching
- `openxml_docx_generator.py` - Generates DOCX files with OpenXML tracked changes
- `docx_tool.py` - DOCX manipulation utilities
- `icf_index_manager.py` - Manages Azure AI Search index for ICF documents

#### Schemas (`schemas/`)
- `icf_schemas.py` - Pydantic models for ICF processing pipeline:
  - `ICFSection` - ICF section/paragraph structure
  - `ICFSectionTree` - Hierarchical section tree
  - `CustomizationPlanItem` - Excel customization plan row
  - `SectionMatchResult` - Section matching results
  - `ICFChange` - Document change representation
  - `QACoverageReport` - QA validation results

#### API Endpoints (`app.py`)
- `POST /add-document` - Add a document to RAG index
- `POST /add-folder` - Add all documents from a blob folder to RAG
- `POST /run-agenic` - Run agentic ICF generation (multipart file upload)
- `POST /generate-country-icf` - Generate country ICF from Global ICF + customization plan
- `GET /` - Health check and API documentation

### Key Workflows

1. **ICF Generation Flow:**
   - Ingestion Agent: Parse Global ICF into section tree, index to AI Search
   - Section Matcher Agent: Match customization plan items to ICF sections
   - Generator Agent: Generate country-specific changes
   - QA Agent: Validate changes with iterative refinement
   - Writer Agent: Generate final DOCX with tracked changes

2. **Document Processing:**
   - Extract text from DOCX/PDF/Excel using Azure Document Intelligence
   - Parse Excel customization plans
   - Index documents to Azure AI Search with embeddings
   - Generate DOCX with OpenXML tracked changes

### Dependencies (`requirements.txt`)
- fastapi, uvicorn
- semantic-kernel (Magentic Orchestration)
- azure-search-documents, azure-storage-blob, azure-ai-documentintelligence
- openai
- python-docx, openpyxl, pandas
- pytest (testing)

---

## 2. icf-backend (Node.js Backend)

**Location:** `C:\Users\VermaMi\Work\icf-poc\icf-backend`

### Purpose
Express.js REST API server providing document management, authentication, and ICF generation orchestration. Acts as the central backend service coordinating between frontend and Python agent service.

### Tech Stack
- **Runtime:** Node.js with TypeScript
- **Framework:** Express.js
- **Database:** PostgreSQL (Neon serverless) with Drizzle ORM
- **Authentication:** Passport.js with bcrypt
- **File Storage:** Azure Blob Storage
- **Document Processing:** mammoth (Word), pdf-parse (PDF), exceljs (Excel)
- **AI Integration:** OpenAI GPT-4 (optional)
- **Session:** express-session with PostgreSQL store

### Project Structure

```
src/
├── index.ts              # Application entry point
├── routes/
│   └── index.ts         # API route definitions
├── middleware/
│   ├── auth.ts          # Passport authentication setup
│   └── requireAuth.ts   # Authentication middleware
├── services/
│   ├── storage.ts       # Database operations (Drizzle ORM)
│   ├── blobStorage.ts   # Azure Blob Storage operations
│   ├── documentExtraction.ts  # Document text extraction
│   ├── openai.ts        # OpenAI integration
│   ├── wordGenerator.ts # Word document generation
│   ├── aiservice.ts     # AI service integration (calls Python agent)
│   └── upload.ts        # File upload handling
├── config/
│   └── database.ts      # Database configuration
├── constants/
│   └── countryCatalog.ts  # Country reference data
├── models/
│   └── schema.ts        # Drizzle schema definitions (also in shared/)
└── utils/
    └── logger.ts        # Logging utility
```

### Database Schema (`shared/schema.ts`)

**Tables:**
- `users` - User authentication
- `roles` - User roles (admin, contributor)
- `countries` - Country reference data
- `statuses` - Document status lookup
- `documentTypes` - Document type lookup
- `documents` - Document metadata (file URL, name, type, country)
- `studies` - Global ICF studies/templates
- `icfDocuments` - Generated country-specific ICF documents
- `documentVault` - Country-specific document vault (HIPAA, customization plans, etc.)

### API Endpoints (`src/routes/index.ts`)

#### Authentication
- `POST /api/login` - User login
- `POST /api/logout` - User logout
- `GET /api/me` - Get current user

#### Reference Data
- `GET /api/countries` - List all countries
- `GET /api/statuses` - List all statuses
- `GET /api/document-types` - List document types

#### Global ICF (Studies)
- `GET /api/global-icf` - List all studies
- `GET /api/global-icf/:id` - Get study details
- `POST /api/global-icf` - Create study (with file upload)
- `PATCH /api/global-icf/:id` - Update study
- `DELETE /api/global-icf/:id` - Delete study
- `GET /api/global-icf/:id/download` - Download Global ICF file
- `GET /api/global-icf/:id/preview` - Preview document content

#### Documents
- `GET /api/documents` - List documents (with filters)
- `GET /api/documents/:id` - Get document
- `POST /api/documents` - Upload document
- `PATCH /api/documents/:id` - Update document
- `DELETE /api/documents/:id` - Delete document
- `GET /api/documents/:id/download` - Download document

#### Generated ICF Documents
- `GET /api/generated-icf` - List generated ICFs (with filters)
- `GET /api/generated-icf/:id` - Get ICF document
- `POST /api/generated-icf` - Create ICF document (triggers AI generation)
- `PATCH /api/generated-icf/:id/status` - Update ICF status
- `GET /api/generated-icf/:id/download` - Download generated ICF
- `DELETE /api/generated-icf/:id` - Delete ICF document
- `POST /api/generate-icf-callback` - Python agent callback endpoint

#### Country Document Vault
- `GET /api/countrywise-documents` - List vault documents
- `GET /api/countrywise-documents/country/:countryId` - Get by country
- `GET /api/countrywise-documents/:documentId` - Get document
- `POST /api/countrywise-documents` - Upload vault document
- `PATCH /api/countrywise-documents/:documentId` - Update document
- `PATCH /api/countrywise-documents/:documentId/sync` - Update sync time
- `GET /api/countrywise-documents/:documentId/download` - Download document
- `DELETE /api/countrywise-documents/:documentId` - Delete document

### Key Services

#### `storage.ts` (Database Operations)
- Implements `IStorage` interface with Drizzle ORM
- CRUD operations for all entities
- Query filtering and pagination support

#### `blobStorage.ts` (Azure Blob Storage)
- Upload files to Azure Blob Storage
- Download files from blob URLs
- Delete files from blob storage
- Generate blob names with directory structure

#### `aiservice.ts` (AI Service Integration)
- Calls Python agent service for ICF generation
- Handles async generation workflow
- Receives callbacks from Python service

#### `documentExtraction.ts`
- Extract text from Word (mammoth), PDF (pdf-parse), Excel (exceljs)
- Generate HTML previews
- Extract metadata (page count, word count)

### Configuration

**Environment Variables:**
- `DATABASE_URL` - PostgreSQL connection string
- `SESSION_SECRET` - Session encryption secret
- `AZURE_STORAGE_CONNECTION_STRING` - Azure Blob Storage connection
- `AZURE_STORAGE_CONTAINER_NAME` - Blob container name
- `PORT` / `BACKEND_PORT` - Server port (default: 5001)
- `ALLOWED_ORIGINS` - CORS allowed origins
- `OPENAI_API_KEY` - Optional OpenAI API key
- `AI_AGENT_URL` - Python agent service URL

---

## 3. icf-web (React Frontend)

**Location:** `C:\Users\VermaMi\Work\icf-poc\icf-web`

### Purpose
React TypeScript frontend application providing user interface for ICF document management, generation, and review.

### Tech Stack
- **Framework:** React 18 with TypeScript
- **Build Tool:** Vite
- **Routing:** Wouter
- **State Management:** TanStack React Query
- **UI Components:** Radix UI primitives
- **Styling:** Tailwind CSS
- **Forms:** React Hook Form with Zod validation
- **Document Preview:** mammoth (Word to HTML conversion)

### Project Structure

```
client/
├── src/
│   ├── App.tsx           # Main application component
│   ├── main.tsx          # Application entry point
│   ├── pages/
│   │   ├── Login.tsx           # Login page
│   │   ├── AdminPanel.tsx      # Admin dashboard
│   │   ├── GeneratedICFList.tsx  # Generated ICF list (contributor view)
│   │   ├── ICFReviewPage.tsx   # ICF review and change tracking
│   │   ├── CountryDocumentVault.tsx  # Document vault management
│   │   └── ...
│   ├── components/
│   │   ├── app-sidebar.tsx     # Navigation sidebar
│   │   ├── Topbar.tsx          # Top navigation bar
│   │   ├── GeneratorModal.tsx  # ICF generation modal
│   │   ├── TrackChangesView.tsx # Track changes viewer
│   │   ├── WordPreviewDialog.tsx # Word document preview
│   │   └── ui/                 # Radix UI components
│   ├── hooks/
│   │   ├── use-toast.ts        # Toast notification hook
│   │   └── use-mobile.tsx      # Mobile detection hook
│   ├── lib/
│   │   ├── queryClient.ts      # React Query setup
│   │   └── utils.ts            # Utility functions
│   └── shared/
│       ├── schema.ts           # Shared TypeScript types
│       └── countryCatalog.ts   # Country reference data
```

### Key Pages

#### `Login.tsx`
- User authentication
- Password-based login
- Session management

#### `AdminPanel.tsx`
- Admin dashboard for managing:
  - Global ICF studies
  - Generated ICF documents
  - Country document vault
  - ICF generation workflows

#### `GeneratedICFList.tsx`
- Contributor view of generated ICFs
- Filter by study and status
- Navigate to review page

#### `ICFReviewPage.tsx`
- Review generated ICF documents
- Track changes viewer
- Accept/reject changes
- Preview document
- Download final document

#### `CountryDocumentVault.tsx`
- Manage country-specific documents
- Upload HIPAA documents, customization plans
- Organize by country
- Sync status tracking

### Key Components

#### `app-sidebar.tsx`
- Navigation sidebar with role-based menu
- Study navigation
- User menu with logout

#### `GeneratorModal.tsx`
- Modal for initiating ICF generation
- Select study and country
- Trigger backend API call
- Show generation status

#### `TrackChangesView.tsx`
- Visual track changes display
- Highlight insertions/deletions
- Show comments and justifications
- Accept/reject individual changes

#### `WordPreviewDialog.tsx`
- Word document preview using mammoth
- Converts DOCX to HTML
- Side-by-side comparison view

### Shared Types (`shared/schema.ts`)

Mirrors backend schema with TypeScript types:
- `User`, `Role`, `Country`, `Status`
- `Document`, `Study`, `IcfDocument`
- `DocumentVault`

### API Integration

**API Client (`lib/queryClient.ts`):**
- Uses TanStack React Query for data fetching
- Centralized API request function
- Automatic retry and error handling
- Query caching and invalidation

**Base URL:** Configured to point to backend API (default: `http://localhost:5001/api`)

### UI Component Library

Uses Radix UI primitives with custom styling:
- `button`, `dialog`, `dropdown-menu`, `select`, `table`, `tabs`
- `toast`, `tooltip`, `accordion`, `card`, `form`
- Fully accessible and keyboard navigable

### Configuration

**Build Configuration (`vite.config.ts`):**
- React plugin
- Path aliases (`@/` for `src/`)
- TypeScript support

**Styling (`tailwind.config.ts`):**
- Tailwind CSS with custom theme
- Dark mode support
- Custom color palette

---

## Integration Flow

### ICF Generation Workflow

1. **Frontend (icf-web):**
   - Admin selects Global ICF study and target country
   - Triggers generation via `POST /api/generated-icf`

2. **Backend (icf-backend):**
   - Creates ICF document record in database
   - Downloads Global ICF from blob storage
   - Calls Python agent service via `aiservice.ts`

3. **Agent Service (icf-agent):**
   - Receives Global ICF file
   - Runs multi-agent orchestration:
     - Ingestion: Parse and index ICF
     - Section Matcher: Match customization items
     - Generator: Generate country-specific changes
     - QA: Validate changes iteratively
     - Writer: Generate DOCX with tracked changes
   - Uploads generated DOCX to blob storage
   - Calls backend callback: `POST /api/generate-icf-callback`

4. **Backend:**
   - Updates ICF document with file URL
   - Sets status to completed

5. **Frontend:**
   - Polls or receives notification
   - Displays generated ICF for review
   - User reviews changes, accepts/rejects
   - Downloads final document

### Document Management Flow

1. **Upload Documents:**
   - Frontend: User uploads file via form
   - Backend: Saves to Azure Blob Storage, creates database record
   - Storage: Files organized by type/country in blob containers

2. **Document Vault:**
   - Country-specific documents (HIPAA, customization plans)
   - Stored in country-specific blob directories
   - Synced with AI Search index for agent access

3. **RAG Indexing:**
   - Python agent service indexes documents to Azure AI Search
   - Creates embeddings for semantic search
   - Enables regulatory requirement queries

---

## Environment Setup

### icf-agent
```bash
cd icf-agent
python -m venv venv
venv\Scripts\activate  # Windows
pip install -r requirements.txt
python app.py  # Run FastAPI server
```

### icf-backend
```bash
cd icf-backend
npm install
npm run dev  # Development
npm run build  # Production build
npm start  # Production
```

### icf-web
```bash
cd icf-web
npm install
npm run dev  # Development (Vite dev server)
npm run build  # Production build
npm start  # Production (serves built files)
```

---

## Key Features

### Multi-Agent Orchestration
- Generator, QA, Writer, Section Matcher, Ingestion agents
- Iterative refinement with QA validation
- Magentic Orchestration for agent coordination

### Document Processing
- Azure Document Intelligence for extraction
- Word, PDF, Excel support
- Track changes generation with OpenXML
- Document preview and download

### Database & Storage
- PostgreSQL for metadata and user management
- Azure Blob Storage for file storage
- Azure AI Search for semantic document search

### Authentication & Authorization
- Passport.js session-based auth
- Role-based access control (admin, contributor)
- Protected API routes

### User Interface
- Modern React UI with Radix components
- Track changes visualization
- Document preview and download
- Real-time status updates

---

## Architecture Highlights

1. **Separation of Concerns:**
   - Frontend: UI and user interactions
   - Backend: API, database, orchestration
   - Agent: LLM processing and document generation

2. **Async Processing:**
   - ICF generation runs asynchronously
   - Callback mechanism for status updates
   - Non-blocking API responses

3. **Document Pipeline:**
   - Upload → Index → Search → Generate → Review → Download

4. **Multi-Agent System:**
   - Specialized agents for different tasks
   - Iterative QA validation
   - Track changes for review

---

## Future Enhancements

- WebSocket support for real-time updates
- Batch ICF generation
- Version control for documents
- Audit logging
- Advanced search and filtering
- Export/import functionality
- Multi-language support

