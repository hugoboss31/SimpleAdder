# PowerShell script for manual deployment to Azure App Service
# Usage: .\deploy-to-azure.ps1

param(
    [string]$ResourceGroup = "USE2-HEX-POC-RG001",
    [string]$AppServiceName = "ICF-COUNTRY-AGENT",
    [string]$SubscriptionId = "8aa051f5-1b27-4195-99b6-bb50177a87ea"
)

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "ICF Agent - Azure App Service Deployment" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Check if Azure CLI is installed
if (-not (Get-Command az -ErrorAction SilentlyContinue)) {
    Write-Host "❌ Azure CLI not found. Please install it first." -ForegroundColor Red
    Write-Host "Download from: https://aka.ms/installazurecliwindows" -ForegroundColor Yellow
    exit 1
}

# Login check
Write-Host "🔐 Checking Azure login..." -ForegroundColor Green
$account = az account show 2>$null | ConvertFrom-Json
if (-not $account) {
    Write-Host "Please login to Azure..." -ForegroundColor Yellow
    az login
}

# Set subscription
Write-Host "📋 Setting subscription..." -ForegroundColor Green
az account set --subscription $SubscriptionId
Write-Host "✅ Subscription set to: $SubscriptionId" -ForegroundColor Green

# Create deployment package
Write-Host ""
Write-Host "📦 Creating deployment package..." -ForegroundColor Green
$deployZip = "deploy-$(Get-Date -Format 'yyyyMMdd-HHmmss').zip"

# Exclude unnecessary files
$excludeItems = @(
    "*.git*",
    "*.venv*",
    "*.env*",
    "__pycache__*",
    "*.pyc",
    "*.pyo",
    "*.pyd",
    ".pytest_cache*",
    "*.md",
    "*.log",
    "output/*",
    "logs/*",
    "median/*",
    "uploads/*",
    "venv",
    ".git",
    ".vscode",
    ".idea"
)

# Create zip (using .NET compression)
Add-Type -AssemblyName System.IO.Compression.FileSystem
$zipPath = Join-Path $PWD $deployZip

try {
    $zip = [System.IO.Compression.ZipFile]::Open($zipPath, [System.IO.Compression.ZipArchiveMode]::Create)
    
    Get-ChildItem -Path . -Recurse | Where-Object {
        $item = $_
        $relativePath = $item.FullName.Substring($PWD.Path.Length + 1)
        $shouldExclude = $false
        
        foreach ($pattern in $excludeItems) {
            if ($relativePath -like $pattern -or $item.Name -like $pattern) {
                $shouldExclude = $true
                break
            }
        }
        
        -not $shouldExclude -and -not $item.PSIsContainer
    } | ForEach-Object {
        $relativePath = $_.FullName.Substring($PWD.Path.Length + 1)
        [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip, $_.FullName, $relativePath) | Out-Null
    }
    
    $zip.Dispose()
    Write-Host "✅ Deployment package created: $deployZip" -ForegroundColor Green
} catch {
    Write-Host "❌ Error creating deployment package: $_" -ForegroundColor Red
    exit 1
}

# Deploy to App Service
Write-Host ""
Write-Host "🚀 Deploying to Azure App Service..." -ForegroundColor Green
Write-Host "   App Service: $AppServiceName" -ForegroundColor Cyan
Write-Host "   Resource Group: $ResourceGroup" -ForegroundColor Cyan
Write-Host ""

try {
    az webapp deployment source config-zip `
        --resource-group $ResourceGroup `
        --name $AppServiceName `
        --src $zipPath
    
    Write-Host ""
    Write-Host "✅ Deployment completed successfully!" -ForegroundColor Green
    Write-Host ""
    Write-Host "🌐 Application URL:" -ForegroundColor Cyan
    $appUrl = az webapp show --name $AppServiceName --resource-group $ResourceGroup --query defaultHostName -o tsv
    Write-Host "   https://$appUrl" -ForegroundColor White
    Write-Host ""
    Write-Host "📚 API Documentation:" -ForegroundColor Cyan
    Write-Host "   https://$appUrl/docs" -ForegroundColor White
    Write-Host ""
    
    # Cleanup
    Remove-Item $zipPath -Force
    Write-Host "🧹 Cleaned up deployment package" -ForegroundColor Green
    
} catch {
    Write-Host ""
    Write-Host "❌ Deployment failed: $_" -ForegroundColor Red
    Write-Host "Deployment package kept at: $zipPath" -ForegroundColor Yellow
    exit 1
}

Write-Host ""
Write-Host "✨ Done!" -ForegroundColor Green

