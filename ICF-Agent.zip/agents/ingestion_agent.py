"""
Ingestion & Structuring Agent.
Parses Global ICF into section tree and indexes to Azure AI Search.
Matches requirements to sections with confidence scoring.
"""

import os
import re
import io
import hashlib
from typing import List, Dict, Tuple, Optional
from datetime import datetime
import pandas as pd
from docx import Document
from dotenv import load_dotenv
from models.models import (
    SectionNode, ParagraphNode, DocumentTree,
    RequirementRecord, MatchedPair,
    SectionRecord, GlobalIcfSectionTree
)
from config import Config
from services.app_insights import get_logger as get_ai_logger

try:
    from azure.ai.formrecognizer import DocumentAnalysisClient
    from azure.core.credentials import AzureKeyCredential
    AZURE_DI_AVAILABLE = True
except ImportError:
    AZURE_DI_AVAILABLE = False

try:
    from azure.storage.blob import BlobServiceClient
    AZURE_BLOB_AVAILABLE = True
except ImportError:
    AZURE_BLOB_AVAILABLE = False

try:
    from openai import AzureOpenAI
    OPENAI_AVAILABLE = True
except ImportError:
    OPENAI_AVAILABLE = False

try:
    from azure.search.documents import SearchClient
    from azure.search.documents.indexes import SearchIndexClient
    from azure.search.documents.indexes.models import (
        SearchIndex, SimpleField, SearchableField,
        SearchFieldDataType, VectorSearch, HnswAlgorithmConfiguration,
        VectorSearchProfile, SearchField
    )
    AZURE_SEARCH_AVAILABLE = True
except ImportError:
    AZURE_SEARCH_AVAILABLE = False

load_dotenv()


class IngestionAgent:
    """
    Parses documents into structured section trees.
    - Uses python-docx for heading detection
    - Extracts hierarchy: Section → Subsection → Paragraphs
    - Generates embeddings for matching
    """
    
    NUMBERED_HEADING_PATTERN = re.compile(r'^(\d+\.?\d*[\.\)]?\s+)(.+)$')
    
    def __init__(self):
        self.azure_di_client = None
        self.blob_client = None
        self.openai_client = None
        self.embedding_model = os.getenv("EMBEDDINGS_MODEL_DEPLOYMENT", "text-embedding-3-small")
        self.logger = get_ai_logger("ingestion_agent")
        self._correlation_id: Optional[str] = None
        self._document_id: Optional[str] = None
        
        self._init_azure_clients()
        self._log("info", "Ingestion Agent initialized")
    
    def set_logging_context(self, correlation_id: Optional[str] = None, document_id: Optional[str] = None) -> None:
        """Set default correlation/document IDs for telemetry."""
        if correlation_id is not None:
            self._correlation_id = correlation_id
        if document_id is not None:
            self._document_id = document_id

    def _build_dimensions(self, **extra: Optional[str]) -> Optional[dict]:
        dims = {}
        if self._correlation_id:
            dims["correlationId"] = self._correlation_id
        if self._document_id:
            dims["documentId"] = self._document_id
        for key, value in extra.items():
            if value is not None:
                dims[key] = str(value)
        return {"custom_dimensions": dims} if dims else None

    def _log(self, level: str, message: str, **extra: Optional[str]) -> None:
        dims = self._build_dimensions(**extra)
        log_method = getattr(self.logger, level, self.logger.info)
        if dims:
            log_method(message, extra=dims)
        else:
            log_method(message)

    def _init_azure_clients(self):
        """Initialize Azure clients."""
        if AZURE_DI_AVAILABLE:
            endpoint = os.getenv("AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT")
            key = os.getenv("AZURE_DOCUMENT_INTELLIGENCE_API_KEY")
            if endpoint and key:
                try:
                    self.azure_di_client = DocumentAnalysisClient(
                        endpoint=endpoint,
                        credential=AzureKeyCredential(key)
                    )
                    self._log("info", "Azure Document Intelligence ready")
                except Exception as e:
                    self._log("warning", f"Azure Document Intelligence init failed: {e}")
        
        if AZURE_BLOB_AVAILABLE:
            conn_str = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
            if conn_str:
                try:
                    self.blob_client = BlobServiceClient.from_connection_string(conn_str)
                    self._log("info", "Azure Blob Storage ready")
                except Exception as e:
                    self._log("warning", f"Blob Storage init failed: {e}")
        
        if OPENAI_AVAILABLE:
            api_key = os.getenv("AZURE_OPENAI_API_KEY")
            endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
            if api_key and endpoint:
                try:
                    self.openai_client = AzureOpenAI(
                        api_key=api_key,
                        api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2025-01-01-preview"),
                        azure_endpoint=endpoint
                    )
                    self._log("info", "Azure OpenAI ready for embeddings")
                except Exception as e:
                    self._log("warning", f"Azure OpenAI init failed: {e}")
    
    # ==================== DOCUMENT PARSING ====================
    
    def parse_document(self, docx_path: str) -> DocumentTree:
        """Parse a Word document into a structured section tree."""
        self._log("info", f"Parsing document: {docx_path}")
        
        doc_id = self._generate_doc_id(docx_path)
        filename = os.path.basename(docx_path)
        if not self._document_id:
            self._document_id = doc_id
        
        paragraphs = self._extract_paragraphs(docx_path)
        self._log("info", "Paragraphs extracted", paragraph_count=len(paragraphs))
        
        sections = self._build_section_tree(paragraphs)
        self._log("info", "Built section tree", top_level_sections=len(sections))
        
        title = self._extract_title(paragraphs)
        
        doc_tree = DocumentTree(
            doc_id=doc_id,
            filename=filename,
            title=title,
            sections=sections,
            total_pages=max(1, len(paragraphs) // 40)
        )
        
        self._log(
            "info",
            "Document tree ready",
            total_sections=len(doc_tree.get_all_sections_flat())
        )
        return doc_tree
    
    def _generate_doc_id(self, path: str) -> str:
        """Generate unique document ID."""
        content = f"{path}_{datetime.utcnow().isoformat()}"
        return hashlib.md5(content.encode()).hexdigest()[:12]
    
    def _extract_paragraphs(self, docx_path: str) -> List[ParagraphNode]:
        """Extract all paragraphs with metadata."""
        doc = Document(docx_path)
        paragraphs = []
        
        for idx, para in enumerate(doc.paragraphs):
            text = para.text.strip()
            if not text:
                continue
            
            heading_level = self._detect_heading_level(para)
            is_heading = heading_level > 0
            is_bold = self._is_paragraph_bold(para)
            font_size = self._get_font_size(para)
            
            para_node = ParagraphNode(
                para_id=f"P-{idx:04d}",
                text=text,
                page_no=0,
                order_index=idx,
                is_heading=is_heading,
                heading_level=heading_level,
                font_bold=is_bold,
                font_size=font_size
            )
            paragraphs.append(para_node)
        
        return paragraphs
    
    def _detect_heading_level(self, para) -> int:
        """Detect heading level from paragraph style and formatting."""
        text = para.text.strip()
        if not text:
            return 0
        
        style_name = para.style.name.lower() if para.style else ''
        if 'heading' in style_name:
            match = re.search(r'heading\s*(\d+)', style_name)
            if match:
                return int(match.group(1))
            return 1
        
        if 'title' in style_name:
            return 1
        
        num_match = self.NUMBERED_HEADING_PATTERN.match(text)
        if num_match:
            prefix = num_match.group(1)
            dots = prefix.count('.')
            if dots == 0:
                return 1
            elif dots == 1:
                return 2 if '.' in prefix.rstrip('. ') else 1
            else:
                return min(dots + 1, 4)
        
        if len(text) < 100 and self._is_paragraph_bold(para):
            return 2
        
        if text.isupper() and len(text) < 80 and len(text.split()) > 1:
            return 2
        
        if text.endswith('?') and len(text) < 120:
            return 2
        
        return 0
    
    def _is_paragraph_bold(self, para) -> bool:
        """Check if paragraph is bold."""
        if not para.runs:
            return False
        bold_count = sum(1 for run in para.runs if run.bold and run.text.strip())
        total_count = sum(1 for run in para.runs if run.text.strip())
        return total_count > 0 and bold_count >= total_count * 0.5
    
    def _get_font_size(self, para) -> float:
        """Get font size of paragraph."""
        for run in para.runs:
            if run.font.size:
                return run.font.size.pt
        return 11.0
    
    def _build_section_tree(self, paragraphs: List[ParagraphNode]) -> List[SectionNode]:
        """Build hierarchical section tree from paragraphs."""
        sections = []
        section_stack = []
        section_counter = 0
        current_paragraphs = []
        current_start_idx = 0
        
        for para_idx, para in enumerate(paragraphs):
            if para.is_heading:
                if section_stack:
                    section_stack[-1][1].paragraphs.extend(current_paragraphs)
                    section_stack[-1][1].full_text = self._build_full_text(
                        section_stack[-1][1].heading,
                        section_stack[-1][1].paragraphs
                    )
                    section_stack[-1][1].end_para_idx = para_idx - 1
                current_paragraphs = []
                
                section_counter += 1
                new_section = SectionNode(
                    section_id=f"SEC-{section_counter:03d}",
                    heading=para.text,
                    level=para.heading_level,
                    page_no=para.page_no,
                    order_index=para.order_index,
                    start_para_idx=para_idx
                )
                
                while section_stack and section_stack[-1][0] >= para.heading_level:
                    section_stack.pop()
                
                if section_stack:
                    parent = section_stack[-1][1]
                    new_section.parent_id = parent.section_id
                    parent.children.append(new_section)
                else:
                    sections.append(new_section)
                
                section_stack.append((para.heading_level, new_section))
            else:
                current_paragraphs.append(para)
        
        if section_stack and current_paragraphs:
            section_stack[-1][1].paragraphs.extend(current_paragraphs)
            section_stack[-1][1].full_text = self._build_full_text(
                section_stack[-1][1].heading,
                section_stack[-1][1].paragraphs
            )
            section_stack[-1][1].end_para_idx = len(paragraphs) - 1
        
        return sections
    
    def _build_full_text(self, heading: str, paragraphs: List[ParagraphNode]) -> str:
        """Build full text from heading and paragraphs."""
        parts = [heading]
        for p in paragraphs:
            if p.text.strip():
                parts.append(p.text)
        return '\n'.join(parts)
    
    def _extract_title(self, paragraphs: List[ParagraphNode]) -> str:
        """Extract document title."""
        for para in paragraphs[:5]:
            if para.is_heading and para.heading_level == 1:
                return para.text
        if paragraphs:
            return paragraphs[0].text[:100]
        return "Untitled Document"
    
    # ==================== EXCEL PARSING ====================
    
    def parse_excel_requirements(
        self,
        excel_path: str = None,
        blob_container: str = None,
        blob_name: str = None
    ) -> List[RequirementRecord]:
        """Parse Excel customization plan into requirement records."""
        self._log("info", "Parsing customization requirements")
        
        if excel_path and os.path.exists(excel_path):
            df = pd.read_excel(excel_path)
        elif blob_container and self.blob_client:
            file_bytes = self._download_from_blob(blob_container, blob_name)
            df = pd.read_excel(io.BytesIO(file_bytes))
        else:
            self._log("warning", "No Excel source provided")
            return []
        
        requirements = []
        current_topic = None
        
        for idx, row in df.iterrows():
            col_a = str(row.iloc[0]).strip() if pd.notna(row.iloc[0]) else ""
            col_b = str(row.iloc[1]).strip() if len(row) > 1 and pd.notna(row.iloc[1]) else ""
            
            if col_a and col_a.lower() not in ["nan", ""]:
                current_topic = col_a
            
            if col_b and col_b.lower() not in ["nan", ""]:
                req = RequirementRecord.from_excel_row(idx + 1, current_topic, col_b)
                requirements.append(req)
        
        self._log("info", "Parsed customization requirements", requirement_count=len(requirements))
        return requirements
    
    def _download_from_blob(self, container: str, blob_name: str) -> bytes:
        """Download file from Azure Blob Storage."""
        if not blob_name:
            blob_name = self._find_xlsx_in_blob(container)
        
        blob_client = self.blob_client.get_blob_client(container=container, blob=blob_name)
        return blob_client.download_blob().readall()
    
    def _find_xlsx_in_blob(self, container: str) -> str:
        """Find .xlsx file in usa/ folder."""
        container_client = self.blob_client.get_container_client(container)
        for blob in container_client.list_blobs(name_starts_with="usa/"):
            if blob.name.endswith('.xlsx'):
                return blob.name
        raise FileNotFoundError("No .xlsx file found in usa/ folder")
    
    # ==================== EMBEDDINGS ====================
    
    def generate_embeddings(
        self,
        doc_tree: DocumentTree,
        requirements: List[RequirementRecord]
    ) -> Tuple[DocumentTree, List[RequirementRecord]]:
        """Generate embeddings for sections and requirements."""
        if not self.openai_client:
            self._log("warning", "OpenAI client not available for embeddings")
            return doc_tree, requirements
        
        self._log("info", "Generating embeddings")
        
        for section in doc_tree.get_all_sections_flat():
            text = f"{section.heading}\n{section.full_text[:1000]}"
            section.embedding = self._embed(text)
        
        for req in requirements:
            text = f"{req.topic}: {req.requirement_text}"
            req.embedding = self._embed(text)
        
        self._log(
            "info",
            "Embeddings ready",
            section_count=len(doc_tree.get_all_sections_flat()),
            requirement_count=len(requirements)
        )
        return doc_tree, requirements
    
    def _embed(self, text: str) -> List[float]:
        """Generate embedding for text with caching."""
        from utils import cache
        
        cached = cache.get_embedding(text)
        if cached:
            return cached
        
        try:
            response = self.openai_client.embeddings.create(
                model=self.embedding_model,
                input=text[:8000]
            )
            embedding = response.data[0].embedding
            cache.set_embedding(text, embedding)
            return embedding
        except Exception as e:
            self._log("warning", f"Embedding error: {e}")
            return []
    
    # ==================== MATCHING WITH CONFIDENCE ====================
    
    def match_requirements_to_sections(
        self,
        doc_tree: DocumentTree,
        requirements: List[RequirementRecord]
    ) -> List[MatchedPair]:
        """
        Match each requirement to the best document section.
        
        Confidence scoring:
        - High (0.9+): Semantic meaning clearly aligns
        - Medium (0.7-0.89): Meaning aligns but wording differs
        - Low (<0.7): Weak semantic connection
        """
        self._log("info", "Matching requirements to sections")
        
        sections = doc_tree.get_all_sections_flat()
        matched_pairs = []
        
        for req in requirements:
            best_section = None
            best_score = 0.0
            
            for section in sections:
                score = self._compute_match_score(req, section)
                if score > best_score:
                    best_score = score
                    best_section = section
            
            if best_section:
                confidence_label = self._get_confidence_label(best_score)
                matched_pairs.append(MatchedPair(
                    requirement=req,
                    matched_section=best_section,
                    confidence=best_score,
                    match_type=f"hybrid_{confidence_label}"
                ))
        
        high_conf = sum(1 for m in matched_pairs if m.confidence >= 0.9)
        med_conf = sum(1 for m in matched_pairs if 0.7 <= m.confidence < 0.9)
        low_conf = sum(1 for m in matched_pairs if m.confidence < 0.7)
        
        self._log(
            "info",
            "Requirement matching complete",
            matched_pairs=len(matched_pairs),
            high_conf=high_conf,
            medium_conf=med_conf,
            low_conf=low_conf
        )
        
        return matched_pairs
    
    def _get_confidence_label(self, score: float) -> str:
        """Get confidence label based on score."""
        if score >= 0.9:
            return "high"
        elif score >= 0.7:
            return "medium"
        else:
            return "low"
    
    def _compute_match_score(self, req: RequirementRecord, section: SectionNode) -> float:
        """
        Compute matching score between requirement and section.
        
        Scoring components:
        - Topic-heading exact match: +0.35
        - Topic/body word overlap: +0.25
        - Topic present in section body: +0.20
        - Vector similarity: +0.55
        """
        score = 0.0
        
        topic_lower = req.topic.lower()
        heading_lower = section.heading.lower()
        content_lower = section.full_text.lower()
        body_snippet = content_lower[:400]
        section_text_for_overlap = f"{heading_lower} {body_snippet}"
        
        if topic_lower in heading_lower or heading_lower in topic_lower:
            score += 0.35
        
        topic_words = set(topic_lower.split())
        section_words = set(section_text_for_overlap.split())
        stop_words = {'the', 'a', 'an', 'and', 'or', 'of', 'to', 'in', 'for', 'on', 'with'}
        topic_words = topic_words - stop_words
        section_words = section_words - stop_words
        
        if topic_words and section_words:
            common = topic_words & section_words
            overlap_ratio = len(common) / max(len(topic_words), len(section_words))
            score += 0.25 * overlap_ratio
        
        if topic_lower in body_snippet:
            score += 0.20
        
        if req.embedding and section.embedding:
            dot = sum(a * b for a, b in zip(req.embedding, section.embedding))
            norm_req = sum(a * a for a in req.embedding) ** 0.5
            norm_sec = sum(b * b for b in section.embedding) ** 0.5
            if norm_req > 0 and norm_sec > 0:
                cosine_sim = dot / (norm_req * norm_sec)
                score += 0.55 * max(0, cosine_sim)
        
        return min(score, 1.0)


# =============================================================================
# IngestionService - For FastAPI Global ICF Indexing
# =============================================================================

class IngestionService:
    """
    Service for ingesting and indexing Global ICF documents.
    Called by FastAPI endpoint to persist sections in Azure AI Search.
    """
    
    SECTIONS_INDEX_NAME = os.getenv("AI_SEARCH_INDEX_NAME", "icf-sections-index")
    
    def __init__(self):
        self.ingestion_agent = IngestionAgent()
        self.search_client = None
        self.index_client = None
        self.embedding_model = os.getenv("EMBEDDINGS_MODEL_DEPLOYMENT", "text-embedding-3-small")
        
        self._init_search_clients()
    
    def _init_search_clients(self):
        """Initialize Azure AI Search clients."""
        if not AZURE_SEARCH_AVAILABLE:
            print("⚠️ Azure Search SDK not available")
            return

        try:
            endpoint = Config.get_search_endpoint()
            credential = Config.get_search_credential()
        except Exception as e:
            print(f"⚠️ Azure Search credentials not configured: {e}")
            print("⚠️ Azure Search credentials not configured")
            return

        try:
            self.index_client = SearchIndexClient(
                endpoint=endpoint,
                credential=credential
            )
            self._ensure_index_exists()
            
            self.search_client = SearchClient(
                endpoint=endpoint,
                index_name=self.SECTIONS_INDEX_NAME,
                credential=credential
            )
            print(f"✅ IngestionService connected to {self.SECTIONS_INDEX_NAME}")
        except Exception as e:
            print(f"⚠️ Search client init failed: {e}")
    
    def _ensure_index_exists(self):
        """Create icf-sections-index if it doesn't exist."""
        try:
            self.index_client.get_index(self.SECTIONS_INDEX_NAME)
            print(f"  ✓ Index {self.SECTIONS_INDEX_NAME} exists")
        except Exception:
            print(f"  → Creating index {self.SECTIONS_INDEX_NAME}...")
            self._create_sections_index()
    
    def _create_sections_index(self):
        """Create the icf-sections-index schema."""
        fields = [
            SimpleField(name="id", type=SearchFieldDataType.String, key=True),
            SimpleField(name="document_id", type=SearchFieldDataType.String, filterable=True, sortable=True),
            SimpleField(name="section_id", type=SearchFieldDataType.String, filterable=True),
            SearchableField(name="heading", type=SearchFieldDataType.String),
            SearchableField(name="content", type=SearchFieldDataType.String),
            SimpleField(name="page_number", type=SearchFieldDataType.Int32),
            SimpleField(name="section_order", type=SearchFieldDataType.Int32, sortable=True),
            SimpleField(name="parent_section_id", type=SearchFieldDataType.String, filterable=True),
            SimpleField(name="level", type=SearchFieldDataType.Int32),
            SearchField(
                name="embedding",
                type=SearchFieldDataType.Collection(SearchFieldDataType.Single),
                searchable=True,
                vector_search_dimensions=1536,
                vector_search_profile_name="default-profile"
            )
        ]
        
        vector_search = VectorSearch(
            algorithms=[
                HnswAlgorithmConfiguration(name="default-algorithm")
            ],
            profiles=[
                VectorSearchProfile(
                    name="default-profile",
                    algorithm_configuration_name="default-algorithm"
                )
            ]
        )
        
        index = SearchIndex(
            name=self.SECTIONS_INDEX_NAME,
            fields=fields,
            vector_search=vector_search
        )
        
        self.index_client.create_index(index)
        print(f"  ✓ Created index {self.SECTIONS_INDEX_NAME}")
    
    def ingest_global_icf(
        self,
        docx_path: str,
        document_id: str
    ) -> GlobalIcfSectionTree:
        """
        Ingest Global ICF document and index all sections.
        
        Args:
            docx_path: Path to DOCX file (local or temp)
            document_id: Unique document ID from frontend
            
        Returns:
            GlobalIcfSectionTree with indexed section metadata
        """
        print(f"\n📥 Ingesting Global ICF: {document_id}")
        
        doc_tree = self.ingestion_agent.parse_document(docx_path)
        
        all_sections = doc_tree.get_all_sections_flat()
        section_records = []
        
        for idx, section in enumerate(all_sections):
            text_for_embedding = f"{section.heading}\n{section.full_text[:1500]}"
            embedding = self.ingestion_agent._embed(text_for_embedding)
            
            record = SectionRecord(
                id=f"{document_id}_{section.section_id}",
                document_id=document_id,
                section_id=section.section_id,
                heading=section.heading,
                content=section.full_text[:8000],
                page_number=section.page_no,
                section_order=idx,
                parent_section_id=section.parent_id,
                level=section.level,
                embedding=embedding if embedding else None
            )
            section_records.append(record)
        
        # Ensure the index exists before indexing
        self._ensure_index_exists()
        
        if self.search_client and section_records:
            self._upload_sections(section_records)
        
        result = GlobalIcfSectionTree(
            document_id=document_id,
            document_name=doc_tree.filename,
            total_sections=len(section_records),
            total_paragraphs=sum(len(s.paragraphs) for s in all_sections),
            page_count=doc_tree.total_pages,
            sections=section_records
        )
        
        print(f"  ✓ Indexed {len(section_records)} sections for document {document_id}")
        return result
    
    def _upload_sections(self, records: List[SectionRecord]):
        """Upload section records to Azure AI Search."""
        docs = []
        for rec in records:
            doc = {
                "id": rec.id,
                "document_id": rec.document_id,
                "section_id": rec.section_id,
                "heading": rec.heading,
                "content": rec.content,
                "page_number": rec.page_number,
                "section_order": rec.section_order,
                "parent_section_id": rec.parent_section_id or "",
                "level": rec.level
            }
            if rec.embedding:
                doc["embedding"] = rec.embedding
            docs.append(doc)
        
        batch_size = 100
        for i in range(0, len(docs), batch_size):
            batch = docs[i:i + batch_size]
            self.search_client.upload_documents(documents=batch)
        
        print(f"  ✓ Uploaded {len(docs)} sections to {self.SECTIONS_INDEX_NAME}")
    
    def get_sections_by_document_id(self, document_id: str) -> List[Dict]:
        """
        Retrieve all sections for a specific document.
        
        Args:
            document_id: The document ID to filter by
            
        Returns:
            List of section records
        """
        if not self.search_client:
            return []
        
        results = self.search_client.search(
            search_text="*",
            filter=f"document_id eq '{document_id}'",
            order_by=["section_order asc"],
            top=1000
        )
        
        sections = []
        for result in results:
            sections.append({
                "id": result["id"],
                "document_id": result["document_id"],
                "section_id": result["section_id"],
                "heading": result["heading"],
                "content": result["content"],
                "page_number": result.get("page_number", 0),
                "section_order": result.get("section_order", 0),
                "level": result.get("level", 1)
            })
        
        return sections
    
    def delete_document_sections(self, document_id: str) -> int:
        """
        Delete all sections for a specific document.
        
        Args:
            document_id: The document ID to delete sections for
            
        Returns:
            Number of sections deleted
        """
        if not self.search_client:
            return 0
        
        sections = self.get_sections_by_document_id(document_id)
        if not sections:
            return 0
        
        docs_to_delete = [{"id": s["id"]} for s in sections]
        self.search_client.delete_documents(documents=docs_to_delete)
        
        print(f"  ✓ Deleted {len(docs_to_delete)} sections for document {document_id}")
        return len(docs_to_delete)