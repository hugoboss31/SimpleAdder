"""
DPO JSONL Deduplication Module

Provides functionality to detect and handle duplicate records in DPO training JSONL files.
Uses content-based hashing to identify unique records and prevent duplicates.
"""

import json
import hashlib
import logging
from typing import List, Dict, Tuple
from pathlib import Path

logger = logging.getLogger(__name__)


class DPODeduplicator:
    """Handles deduplication of DPO JSONL records."""

    @staticmethod
    def _normalize_text(value: object) -> str:
        """Normalize text for stable hashing."""
        if value is None:
            return ""
        return " ".join(str(value).split())

    @staticmethod
    def _normalize_messages(messages: List[Dict]) -> List[Dict]:
        """Normalize message content for hashing."""
        normalized = []
        for message in messages:
            normalized.append({
                "role": message.get("role", ""),
                "content": DPODeduplicator._normalize_text(message.get("content", "")),
            })
        return normalized

    @staticmethod
    def _normalize_outputs(outputs: object) -> object:
        """Normalize preferred/non-preferred outputs for hashing."""
        if isinstance(outputs, list):
            normalized = []
            for item in outputs:
                if isinstance(item, dict):
                    normalized.append({
                        "role": item.get("role", ""),
                        "content": DPODeduplicator._normalize_text(item.get("content", "")),
                    })
                else:
                    normalized.append(DPODeduplicator._normalize_text(item))
            return normalized
        return DPODeduplicator._normalize_text(outputs)

    @staticmethod
    def _create_non_pref_version_hash(record: Dict) -> str:
        """
        Create a hash based on non_preferred_output and version.
        
        This hash is used to detect records with identical non_preferred_output
        and version combinations, which should not be duplicated.
        
        Args:
            record: The DPO record dict
            
        Returns:
            str: SHA-256 hash of non_preferred_output + version
        """
        try:
            metadata = record.get("metadata", {})
            version = metadata.get("version", 0)
            non_pref = record.get("non_preferred_output", [])
            
            # Extract non_preferred_output text
            non_pref_content = ""
            if isinstance(non_pref, list):
                for item in non_pref:
                    if isinstance(item, dict):
                        non_pref_content += item.get("content", "")
                    else:
                        non_pref_content += str(item)
            else:
                non_pref_content = str(non_pref)
            
            # Normalize the text
            normalized_content = DPODeduplicator._normalize_text(non_pref_content)
            
            # Create hash from non_preferred_output + version
            unique_key = {
                "non_preferred_output": normalized_content,
                "version": version
            }
            
            hash_string = json.dumps(unique_key, sort_keys=True)
            return hashlib.sha256(hash_string.encode()).hexdigest()
        except Exception as e:
            logger.warning(f"Error creating non_pref_version hash: {e}")
            return None

    @staticmethod
    def _create_record_hash(record: Dict) -> str:
        """
        Create a unique hash for a record based on its content.
        
        Uses the icf_case_id, iteration_id, and the input messages to create
        a deterministic hash. This ensures identical records are detected.
        
        Args:
            record: The DPO record dict
            
        Returns:
            str: SHA-256 hash of the record's unique content
        """
        try:
            # Extract key fields that uniquely identify a record
            metadata = record.get("metadata", {})
            input_messages = record.get("input", {}).get("messages", [])
            normalized_messages = DPODeduplicator._normalize_messages(input_messages)
            
            # Create a canonical string from key fields
            unique_content = {
                "icf_case_id": metadata.get("icf_case_id"),
                "iteration_id": metadata.get("iteration_id"),
                "document_id": metadata.get("document_id"),
                "input_messages": json.dumps(normalized_messages, sort_keys=True),
                "preferred_output": DPODeduplicator._normalize_outputs(
                    record.get("preferred_output")
                ),
                "non_preferred_output": DPODeduplicator._normalize_outputs(
                    record.get("non_preferred_output")
                ),
            }
            
            # Create deterministic hash
            content_string = json.dumps(unique_content, sort_keys=True)
            record_hash = hashlib.sha256(content_string.encode()).hexdigest()
            
            return record_hash
        except Exception as e:
            logger.warning(f"Error creating record hash: {e}")
            return None

    @staticmethod
    def load_existing_records(file_path: str) -> Tuple[List[Dict], set]:
        """
        Load all existing records from JSONL file and build hash set.
        
        Args:
            file_path: Path to the JSONL file
            
        Returns:
            Tuple of (list of records, set of record hashes)
        """
        records = []
        hashes = set()
        
        try:
            if not Path(file_path).exists():
                logger.info(f"File {file_path} does not exist yet. Starting fresh.")
                return records, hashes
            
            with open(file_path, 'r', encoding='utf-8') as f:
                for line in f:
                    if line.strip():
                        try:
                            record = json.loads(line)
                            records.append(record)
                            
                            # Generate and store hash
                            record_hash = DPODeduplicator._create_record_hash(record)
                            if record_hash:
                                hashes.add(record_hash)
                        except json.JSONDecodeError as je:
                            logger.warning(f"Skipping invalid JSON line: {je}")
                            continue
            
            logger.info(f"Loaded {len(records)} existing records from {file_path}")
            return records, hashes
        except Exception as e:
            logger.error(f"Error loading existing records: {e}")
            return records, hashes

    @staticmethod
    def is_duplicate(record: Dict, existing_hashes: set) -> bool:
        """
        Check if a record is a duplicate based on hash.
        
        Args:
            record: The record to check
            existing_hashes: Set of existing record hashes
            
        Returns:
            bool: True if duplicate, False otherwise
        """
        record_hash = DPODeduplicator._create_record_hash(record)
        return record_hash in existing_hashes if record_hash else False

    @staticmethod
    def is_duplicate_by_non_pref_version(record: Dict, existing_non_pref_version_hashes: set) -> bool:
        """
        Check if a record has duplicate non_preferred_output + version combination.
        
        This checks if the same non_preferred_output and version already exist,
        which should be skipped to avoid duplicating training pairs.
        
        Args:
            record: The record to check
            existing_non_pref_version_hashes: Set of existing non_pref+version hashes
            
        Returns:
            bool: True if duplicate found, False otherwise
        """
        non_pref_version_hash = DPODeduplicator._create_non_pref_version_hash(record)
        return non_pref_version_hash in existing_non_pref_version_hashes if non_pref_version_hash else False

    @staticmethod
    def add_record_deduplicated(record: Dict, file_path: str, mode: str = "skip") -> Tuple[bool, str]:
        """
        Add a record to JSONL file with deduplication.
        
        Args:
            record: The record to add
            file_path: Path to the JSONL file
            mode: 'skip' to skip duplicates, 'replace' to replace duplicates
            
        Returns:
            Tuple of (success: bool, message: str)
        """
        try:
            # Load existing records and hashes
            existing_records, existing_hashes = DPODeduplicator.load_existing_records(file_path)
            
            # Check if record is duplicate
            if DPODeduplicator.is_duplicate(record, existing_hashes):
                if mode == "skip":
                    metadata = record.get('metadata', {})
                    message = (f"  RECORD SKIPPED - Data already present in JSONL. "
                             f"Case ID: {metadata.get('icf_case_id')}, "
                             f"Document ID: {metadata.get('document_id')}, "
                             f"Iteration: {metadata.get('iteration_id')}, "
                             f"Section: {metadata.get('section_heading', 'N/A')}")
                    logger.info(message)
                    return False, message
                
                elif mode == "replace":
                    # Remove old record with same hash and add new one
                    record_hash = DPODeduplicator._create_record_hash(record)
                    existing_records = [r for r in existing_records 
                                      if DPODeduplicator._create_record_hash(r) != record_hash]
                    existing_records.append(record)
                    
                    # Rewrite entire file
                    DPODeduplicator._write_records_to_file(existing_records, file_path)
                    
                    message = (f"Record replaced (duplicate updated). "
                             f"Document: {record.get('metadata', {}).get('document_id')}, "
                             f"Case: {record.get('metadata', {}).get('icf_case_id')}")
                    logger.info(message)
                    return True, message
            
            else:
                # New record - append it
                existing_records.append(record)
                DPODeduplicator._write_records_to_file(existing_records, file_path)
                
                message = (f"Record added (new). "
                         f"Document: {record.get('metadata', {}).get('document_id')}, "
                         f"Case: {record.get('metadata', {}).get('icf_case_id')}")
                logger.info(message)
                return True, message
        
        except Exception as e:
            error_msg = f"Error during deduplication: {e}"
            logger.error(error_msg)
            return False, error_msg

    @staticmethod
    def _write_records_to_file(records: List[Dict], file_path: str) -> None:
        """
        Write all records to JSONL file.
        
        Args:
            records: List of records to write
            file_path: Path to the JSONL file
        """
        try:
            # Ensure directory exists
            Path(file_path).parent.mkdir(parents=True, exist_ok=True)
            
            with open(file_path, 'w', encoding='utf-8') as f:
                for record in records:
                    f.write(json.dumps(record) + '\n')
            
            logger.debug(f"Wrote {len(records)} records to {file_path}")
        except Exception as e:
            logger.error(f"Error writing records to file: {e}")
            raise

    @staticmethod
    def get_deduplication_stats(file_path: str) -> Dict:
        """
        Get deduplication statistics for the JSONL file.
        
        Args:
            file_path: Path to the JSONL file
            
        Returns:
            Dict with statistics (total records, unique records, duplicate count, etc.)
        """
        try:
            records, hashes = DPODeduplicator.load_existing_records(file_path)
            
            stats = {
                "total_records": len(records),
                "unique_records": len(hashes),
                "duplicate_count": len(records) - len(hashes),
                "deduplication_ratio": f"{((1 - len(hashes) / len(records)) * 100):.2f}%" if records else "0%",
                "file_path": file_path,
                "file_exists": Path(file_path).exists(),
            }
            
            return stats
        except Exception as e:
            logger.error(f"Error getting deduplication stats: {e}")
            return {"error": str(e)}

    @staticmethod
    def deduplicate_file(file_path: str) -> Tuple[int, int]:
        """
        Deduplicate an existing JSONL file by removing duplicate records.
        
        Args:
            file_path: Path to the JSONL file
            
        Returns:
            Tuple of (original_count, deduplicated_count)
        """
        try:
            records, hashes = DPODeduplicator.load_existing_records(file_path)
            original_count = len(records)
            
            # Rebuild records, keeping only first occurrence of each hash
            seen_hashes = set()
            deduplicated_records = []
            
            for record in records:
                record_hash = DPODeduplicator._create_record_hash(record)
                if record_hash and record_hash not in seen_hashes:
                    seen_hashes.add(record_hash)
                    deduplicated_records.append(record)
            
            # Write deduplicated records back
            DPODeduplicator._write_records_to_file(deduplicated_records, file_path)
            
            deduplicated_count = len(deduplicated_records)
            removed_count = original_count - deduplicated_count
            
            logger.info(f"Deduplication complete: {original_count} → {deduplicated_count} "
                       f"(removed {removed_count} duplicates)")
            
            return original_count, deduplicated_count
        
        except Exception as e:
            logger.error(f"Error during file deduplication: {e}")
            return 0, 0
