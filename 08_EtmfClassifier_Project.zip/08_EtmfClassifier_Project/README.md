# Integrated single-file eTMF classifier
This is a new integrated implementation, NOT a child-process wrapper.
All stages execute in-process: PDF page count, Microsoft Document Intelligence
OCR, branch catalog, gpt-5 routing, candidate lookup, precise classification,
evidence validation. Only final JSON is written. No prior utilities/projects needed.

## Build once (Windows x64 target assumed)
Install a .NET 8-compatible SDK on the BUILD machine, with NuGet access.
Set DocumentEndpoint, DocumentKey and OpenAiKey constants in Program.cs locally.
OpenAiEndpoint and gpt-5 deployment are already configured.
Never commit/distribute real keys. Keys compiled into an EXE are recoverable;
this inline configuration is local POC only, not safe shared-user deployment.
Managed identity or approved secret management is required before distribution.

Run:
dotnet publish EtmfClassifier.csproj -c Release -r win-x64 --self-contained true -o publish

Or run publish-win-x64.ps1. The publish folder should contain EtmfClassifier.exe
with the runtime/dependencies bundled. Target users need no .NET SDK/runtime or
separate utility projects. Internet/service access and configured Azure resources
are still required. This is not offline or a GUI upload app.
For other OS/CPU targets change RID and publish separately.

## Run executable
.\EtmfClassifier.exe process-document --taxonomy "taxonomy_v1.json" --input "sample.pdf" --output "classification_result.json"
Optional: --context "context.json" for operator-supplied verified study/site facts.
Use full quoted paths when appropriate. Existing output is never overwritten.

## Compatibility and limits
Taxonomy envelope: schema_version 1.0, taxonomy_version, record_count,
classifications. Each classification requires artifact_number,
parexel_classification, composite_key, zone, section and guidance/definition.
No assessment or Excel input at runtime. Branch catalog is generated in memory
from exact names; SME scope guidance from old catalog files is not imported.
Branch IDs are per-run sorted IDs, not persistent identifiers.

PDF page count via pinned PdfPig 0.1.11; Microsoft performs OCR. All pages are
requested. Free F0 may return only two pages; mismatch -> needs_review. Blank text
pages -> review. 25 MiB POC input limit; content/base64/results held in memory.
No image rendering, signature verification, bundle splitting or metadata extraction.
No aggregate OCR confidence threshold. Extraction checks do not certify accuracy.
Raw OCR stays in memory, not persisted. Only page text is sent to models.

Model requests use strict shape schemas, local pair/evidence/abstention checks,
100000-character guard (NOT token budget), max_completion_tokens 8192,
reasoning_effort low, no temperature. No silent truncation, forced classification,
automatic rerouting or filing. Up to two branch alternatives, one final pair.
API errors/refusals/incomplete responses stop with no accepted result.
Human review always required; quote matching does not prove classification accuracy.
20-minute overall cancellation deadline; Ctrl+C stops local waiting. Submitted
Azure work may continue/bill. GET throttling/server errors are retried; POST is not.
HTTP response bodies/document content are not logged.

Exit 0: final response passed structural/evidence checks (may be abstention).
Exit 2: review or failed validation result saved. Exit 1: technical failure, no
accepted result. Inspect classification.decision and status, not just exit code.
Early review results omit model usage; final result includes both model usages.
The final envelope differs slightly from the previous runner: source, stage,
taxonomy hash, pipeline version replace request-file fingerprint.

## Test before use
Publish, test one digital and one scanned PDF, compare with SME-approved labels,
verify correct branch recall/final classification. Test missing credentials,
invalid PDF, taxonomy duplicate, long request, page coverage, API failures and
existing output. This refactor has not been compiled/run in the assistant sandbox
(no .NET SDK/Azure credentials). No binary or test result is claimed in this ZIP.

## Licensing and deployment
PdfPig and dependencies are bundled by publish; review their license/notice
obligations before distribution. Native runtime components may self-extract at
startup; this does not expose pipeline intermediate files. No signing is configured.
Protect clinical data, endpoint access, output storage and embedded credentials.

Official publishing reference:
https://learn.microsoft.com/en-us/dotnet/core/deploying/single-file/overview
PdfPig package reference:
https://www.nuget.org/packages/PdfPig/0.1.11
