from azure.ai.formrecognizer import DocumentAnalysisClient
from azure.core.credentials import AzureKeyCredential
from typing import Optional, Dict
import os
from dotenv import load_dotenv
from io import BytesIO

load_dotenv()


class DocumentExtractor:
    """Agent that uses Azure Document Intelligence to extract text from any file format"""
    
    def __init__(self):
        try:
            from config import config
            # Azure Document Intelligence (Form Recognizer) — optional; app starts without it
            self.doc_intel_endpoint = os.getenv("AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT")
            self.doc_intel_key = os.getenv("AZURE_DOCUMENT_INTELLIGENCE_API_KEY")
            
            # Azure Blob Storage (optional): use config so RBAC or connection string works
            self.blob_service_client = None
            self.container_client = None
            if config.AZURE_STORAGE_CONNECTION_STRING or config.AZURE_STORAGE_BLOB_ENDPOINT:
                self.blob_service_client = config.get_blob_service_client()
                self.container_client = self.blob_service_client.get_container_client(config.AZURE_STORAGE_CONTAINER_NAME)
                print(f"✅ DocumentExtractor connected to Azure Blob Storage: {config.AZURE_STORAGE_CONTAINER_NAME}")
            
            # Document Intelligence client — optional; do not require for startup
            self.document_client = None
            if self.doc_intel_endpoint and self.doc_intel_key:
                self.document_client = DocumentAnalysisClient(
                    endpoint=self.doc_intel_endpoint,
                    credential=AzureKeyCredential(self.doc_intel_key)
                )
                print(f"✅ DocumentExtractor is Activated (Azure Document Intelligence)")
            else:
                print("[DocumentExtractor] Document Intelligence not configured (AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT/API_KEY). add-document and add-folder will return 503 if used.")
            
        except Exception as e:
            print(f"❌ Error initializing DocumentExtractor: {str(e)}")
            raise
    
    def extract_from_file(self, file_path: str) -> Dict[str, any]:
        """Extract text from a local file using Azure Document Intelligence"""
        if not self.document_client:
            raise ValueError(
                "Document Intelligence is not configured. Set AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT and "
                "AZURE_DOCUMENT_INTELLIGENCE_API_KEY to enable document extraction."
            )
        try:
            print(f"📄 Extracting text from file: {file_path}")
            
            # Determine content type based on file extension
            content_type = None
            if file_path.lower().endswith('.docx'):
                content_type = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            elif file_path.lower().endswith('.doc'):
                content_type = "application/msword"
            elif file_path.lower().endswith('.pdf'):
                content_type = "application/pdf"
            
            # Analyze document - specify content type explicitly for better compatibility
            with open(file_path, "rb") as f:
                if content_type:
                    poller = self.document_client.begin_analyze_document(
                        model_id="prebuilt-layout",
                        document=f,
                        content_type=content_type
                    )
                else:
                    poller = self.document_client.begin_analyze_document(
                        model_id="prebuilt-layout",
                        document=f
                    )
            
            result = poller.result()
            
            # Extract text content
            text_content = result.content
            
            # Extract metadata
            metadata = {
                "page_count": len(result.pages),
                "languages": [lang.locale for lang in result.languages] if result.languages else [],
                "tables_count": len(result.tables) if result.tables else 0,
                "key_value_pairs_count": len(result.key_value_pairs) if result.key_value_pairs else 0
            }
            
            print(f"✅ Extracted {len(text_content)} characters from {metadata['page_count']} page(s)")
            
            return {
                "text": text_content,
                "metadata": metadata,
                "pages": result.pages,
                "tables": result.tables if result.tables else [],
                "key_value_pairs": result.key_value_pairs if result.key_value_pairs else []
            }
            
        except Exception as e:
            print(f"❌ Error extracting from file: {str(e)}")
            raise
    
    def extract_from_url(self, file_url: str) -> Dict[str, any]:
        """Extract text from a file URL using Azure Document Intelligence"""
        if not self.document_client:
            raise ValueError(
                "Document Intelligence is not configured. Set AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT and "
                "AZURE_DOCUMENT_INTELLIGENCE_API_KEY to enable document extraction."
            )
        try:
            print(f"📄 Extracting text from URL: {file_url}")
            
            poller = self.document_client.begin_analyze_document_from_url(
                model_id="prebuilt-layout",
                document_url=file_url
            )
            
            result = poller.result()
            
            # Extract text content
            text_content = result.content
            
            # Extract metadata
            metadata = {
                "page_count": len(result.pages),
                "languages": [lang.locale for lang in result.languages] if result.languages else [],
                "tables_count": len(result.tables) if result.tables else 0,
                "key_value_pairs_count": len(result.key_value_pairs) if result.key_value_pairs else 0
            }
            
            print(f"✅ Extracted {len(text_content)} characters from {metadata['page_count']} page(s)")
            
            return {
                "text": text_content,
                "metadata": metadata,
                "pages": result.pages,
                "tables": result.tables if result.tables else [],
                "key_value_pairs": result.key_value_pairs if result.key_value_pairs else []
            }
            
        except Exception as e:
            print(f"❌ Error extracting from URL: {str(e)}")
            raise
    
    def extract_from_blob(self, blob_name: str) -> Dict[str, any]:
        """Extract text from a file in Azure Blob Storage using Azure Document Intelligence"""
        if not self.document_client:
            raise ValueError(
                "Document Intelligence is not configured. Set AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT and "
                "AZURE_DOCUMENT_INTELLIGENCE_API_KEY to enable document extraction."
            )
        if not self.container_client:
            raise ValueError(
                "Blob Storage not configured. Set AZURE_STORAGE_CONNECTION_STRING and AZURE_STORAGE_CONTAINER_NAME, "
                "or AZURE_STORAGE_BLOB_ENDPOINT (or AZURE_STORAGE_ACCOUNT_NAME) and AZURE_STORAGE_CONTAINER_NAME for RBAC."
            )
        
        try:
            print(f"📄 Downloading blob: {blob_name}")
            
            # Download blob to memory
            blob_client = self.container_client.get_blob_client(blob_name)
            blob_data = blob_client.download_blob().readall()
            
            print(f"📄 Extracting text from blob: {blob_name}")
            
            # Create BytesIO and ensure it's at the start
            blob_stream = BytesIO(blob_data)
            blob_stream.seek(0)
            
            # Determine content type based on file extension for better compatibility
            content_type = None
            if blob_name.lower().endswith('.docx'):
                content_type = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            elif blob_name.lower().endswith('.doc'):
                content_type = "application/msword"
            elif blob_name.lower().endswith('.pdf'):
                content_type = "application/pdf"
            
            # Analyze document with explicit content type if available
            # Note: Azure Document Intelligence may auto-detect, but explicit type helps
            if content_type:
                poller = self.document_client.begin_analyze_document(
                    model_id="prebuilt-layout",
                    document=blob_stream,
                    content_type=content_type
                )
            else:
                poller = self.document_client.begin_analyze_document(
                    model_id="prebuilt-layout",
                    document=blob_stream
                )
            
            result = poller.result()
            
            # Extract text content
            text_content = result.content
            
            # Extract metadata
            metadata = {
                "source": blob_name,
                "page_count": len(result.pages),
                "languages": [lang.locale for lang in result.languages] if result.languages else [],
                "tables_count": len(result.tables) if result.tables else 0,
                "key_value_pairs_count": len(result.key_value_pairs) if result.key_value_pairs else 0
            }
            
            print(f"✅ Extracted {len(text_content)} characters from {metadata['page_count']} page(s) in blob '{blob_name}'")
            
            return {
                "text": text_content,
                "metadata": metadata,
                "pages": result.pages,
                "tables": result.tables if result.tables else [],
                "key_value_pairs": result.key_value_pairs if result.key_value_pairs else []
            }
            
        except Exception as e:
            print(f"❌ Error extracting from blob: {str(e)}")
            raise
    
    def extract_tables_as_markdown(self, tables) -> str:
        """Convert extracted tables to markdown format
        
        Args:
            tables: Tables from Document Intelligence result
            
        Returns:
            Markdown formatted string of tables
        """
        if not tables:
            return ""
        
        markdown = []
        for table_idx, table in enumerate(tables, 1):
            markdown.append(f"\n## Table {table_idx}\n")
            
            # Get table dimensions
            row_count = table.row_count
            col_count = table.column_count
            
            # Initialize table grid
            grid = [["" for _ in range(col_count)] for _ in range(row_count)]
            
            # Fill in cells
            for cell in table.cells:
                row_idx = cell.row_index
                col_idx = cell.column_index
                grid[row_idx][col_idx] = cell.content
            
            # Build markdown table
            for row_idx, row in enumerate(grid):
                markdown.append("| " + " | ".join(row) + " |")
                if row_idx == 0:  # Add header separator
                    markdown.append("| " + " | ".join(["---"] * col_count) + " |")
            
            markdown.append("")
        
        return "\n".join(markdown)
    
    def extract_key_value_pairs_as_dict(self, key_value_pairs) -> Dict[str, str]:
        """Convert extracted key-value pairs to dictionary
        
        Args:
            key_value_pairs: Key-value pairs from Document Intelligence result
            
        Returns:
            Dictionary of key-value pairs
        """
        if not key_value_pairs:
            return {}
        
        result = {}
        for kv in key_value_pairs:
            key = kv.key.content if kv.key else ""
            value = kv.value.content if kv.value else ""
            if key:
                result[key] = value
        
        return result


# Example usage
if __name__ == "__main__":
    extractor = DocumentExtractor()
    
    # Example 1: Extract from local file
    # result = extractor.extract_from_file("path/to/document.pdf")
    # print(result["text"][:500])
    
    # Example 2: Extract from URL
    # result = extractor.extract_from_url("https://example.com/document.pdf")
    # print(result["text"][:500])
    
    # Example 3: Extract from blob
    # result = extractor.extract_from_blob("ref_data/sample.pdf")
    # print(result["text"][:500])
    
    print("\n📋 DocumentExtractor ready to use!")
    print("Methods available:")
    print("  - extract_from_file(file_path)")
    print("  - extract_from_url(file_url)")
    print("  - extract_from_blob(blob_name)")
    print("  - extract_tables_as_markdown(tables)")
    print("  - extract_key_value_pairs_as_dict(key_value_pairs)")
