"""Generate DPO training datasets from learning artifacts in Azure AI Search."""

from __future__ import annotations

import json
import logging
from datetime import datetime
from typing import Any, Dict, Iterable, List, Optional

from azure.core.credentials import AzureKeyCredential
from azure.search.documents import SearchClient
from azure.storage.blob import BlobServiceClient, ContentSettings

from config import Config
from dpo.dpo_jsonl_builder import DPOJsonlBuilder
from dpo.dpo_deduplicator import DPODeduplicator

logger = logging.getLogger(__name__)


class DPOTrainingGenerator:
    """Orchestrates JSONL dataset generation and upload for DPO training."""

    def __init__(self, country: str, schema_version: str = "1.0"):
        self.country = country.lower().replace(" ", "-").replace("_", "-")
        self.schema_version = schema_version
        self.index_name = f"icf-learning-artifacts-{self.country}"
        self.container_name = Config.AZURE_STORAGE_CONTAINER_NAME
        self.blob_service = None
        self.search_client = None

        self._init_blob_service()
        self._init_search_client()

    def _init_blob_service(self) -> None:
        conn_str = Config.AZURE_STORAGE_CONNECTION_STRING
        if not conn_str:
            raise RuntimeError("Azure Storage connection string not configured")
        self.blob_service = BlobServiceClient.from_connection_string(conn_str)

    def _init_search_client(self) -> None:
        endpoint = Config.get_search_endpoint()
        self.search_client = SearchClient(
            endpoint=endpoint,
            index_name=self.index_name,
            credential=Config.get_search_credential(),
        )

    def fetch_learning_artifacts(
        self,
        min_confidence: float = 0.0,
        icf_case_id: Optional[str] = None,
        iteration_id: Optional[int] = None,
        include_superseded: bool = False,
        top_k: Optional[int] = None,
    ) -> List[Dict[str, Any]]:
        """Fetch learning artifacts for a country from Azure AI Search."""
        if not self.search_client:
            return []

        filters = []
        if not include_superseded:
            filters.append("is_superseded eq false")
        if min_confidence is not None:
            filters.append(f"confidence ge {min_confidence}")
        if icf_case_id:
            filters.append(f"icf_case_id eq '{icf_case_id}'")
        if iteration_id is not None:
            filters.append(f"iteration_id eq {iteration_id}")

        filter_expr = " and ".join(filters) if filters else None

        results = self.search_client.search(
            search_text="*",
            filter=filter_expr,
            top=top_k or 1000,
        )

        artifacts: List[Dict[str, Any]] = []
        if top_k:
            for item in results:
                artifacts.append(dict(item))
            return artifacts

        for page in results.by_page():
            for item in page:
                artifacts.append(dict(item))

        return artifacts

    def build_training_data(self, artifacts: Iterable[Dict[str, Any]]) -> DPOJsonlBuilder:
        """Build JSONL records from learning artifacts."""
        builder = DPOJsonlBuilder(country=self.country, version=self.schema_version)
        skipped_records = 0
        seen_hashes = set()
        seen_non_pref_version_hashes = set()

        for artifact in artifacts:
            # Fetch exact values from artifact without modification or stripping
            ai_output = artifact.get("ai_output", "")
            human_output = artifact.get("human_output", "")
            
            # Skip only if BOTH ai_output AND human_output are empty
            if not ai_output and not human_output:
                skipped_records += 1
                logger.debug(
                    f"Skipped artifact {artifact.get('id')}: "
                    f"ai_output empty={not ai_output}, human_output empty={not human_output}"
                )
                continue

            evidence_ids = artifact.get("evidence_ids", []) or []
            
            # Build system and user prompts from artifact metadata
            country_upper = artifact.get("country", self.country).upper()
            section_type = artifact.get("section_type", "")
            intent = artifact.get("intent", "")
            context = artifact.get("context", "")
            
            system_prompt = self._build_system_prompt(country_upper)
            user_prompt = self._build_user_prompt_from_artifact(
                country_upper, section_type, intent, context, ai_output
            )

            # Build metadata with exact values from learning artifacts index only
            # DO NOT add hallucinated fields, generated values, or defaults
            metadata = {
                "document_id": artifact.get("source_document_id"),
                "icf_case_id": artifact.get("icf_case_id"),
                "version": artifact.get("version"),
                "iteration_id": artifact.get("iteration_id"),
                "intent": artifact.get("intent"),
                "confidence": artifact.get("confidence"),
                "evidence_ids": evidence_ids,
                "country": artifact.get("country"),
            }

            record = builder.create_record(
                system_prompt=system_prompt,
                user_prompt=user_prompt,
                preferred_output=human_output,
                non_preferred_output=ai_output,
                metadata=metadata,
            )
            record_hash = DPODeduplicator._create_record_hash(record)
            
            # Check for content-based duplicates
            if record_hash and record_hash in seen_hashes:
                skipped_records += 1
                logger.info(
                    "Skipped duplicate record in batch (content-based): doc=%s case=%s iter=%s",
                    metadata.get("document_id"),
                    metadata.get("icf_case_id"),
                    metadata.get("iteration_id"),
                )
                continue
            
            # Check for non_preferred_output + version duplicates
            non_pref_version_hash = DPODeduplicator._create_non_pref_version_hash(record)
            if non_pref_version_hash and non_pref_version_hash in seen_non_pref_version_hashes:
                skipped_records += 1
                logger.info(
                    "Skipped duplicate record in batch (non_pref+version): doc=%s case=%s iter=%s version=%s",
                    metadata.get("document_id"),
                    metadata.get("icf_case_id"),
                    metadata.get("iteration_id"),
                    metadata.get("version"),
                )
                continue

            if record_hash:
                seen_hashes.add(record_hash)
            if non_pref_version_hash:
                seen_non_pref_version_hashes.add(non_pref_version_hash)

            builder.add_record(record)

        if skipped_records > 0:
            logger.info(f"Skipped {skipped_records} artifacts due to missing ai_output or human_output")
        
        logger.info(f"Built {len(builder.records)} JSONL training records")
        return builder

    def _build_system_prompt(self, country_upper: str) -> str:
        """
        Build system prompt for ICF editing based on country context.
        Used during human review when client feedback is applied.
        """
        return f"""You are an expert ICF (Informed Consent Form) editor for clinical trials.
You are editing a {country_upper}-specific ICF document based on client review comments.

CRITICAL RULES:
1. Analyze the client's comment and determine what change they want
2. Use the provided REGULATORY REQUIREMENTS to ensure compliance
3. Learn from PAST CORRECTIONS to apply consistent editing patterns
4. Determine the appropriate action: REPLACE, INSERT, DELETE, or CLARIFY
5. Generate ONLY the new text - the original text will be taken from the comment's linked text
6. Maintain {country_upper} regulatory compliance

MANDATORY TEXT REPLACEMENTS:
- Always replace "your country" with "the {country_upper}" throughout the document
- Always replace "Your country" with "The {country_upper}" (maintain capitalization)
- Apply these replacements whenever generating new_text

OUTPUT FORMAT: Provide clear, patient-friendly text that addresses the client's feedback."""

    def _build_user_prompt_from_artifact(
        self,
        country_upper: str,
        section_type: str,
        intent: str,
        context: str,
        ai_output: str
    ) -> str:
        """
        Build user prompt from learning artifact metadata.
        Reconstructs the prompt that would have been used during editing.
        """
        return f"""COUNTRY: {country_upper}

CLIENT COMMENT/INTENT:
"{intent}"

SECTION:
{section_type}

ORIGINAL TEXT (what needs to be edited):
"{ai_output}"

SECTION CONTEXT:
{context or "(No additional context available)"}

Based on the client's intent above, generate the corrected/improved text.
- Use the section context to understand the broader document structure
- Apply {country_upper} regulatory standards
- Ensure the new text addresses the client's stated intent
- Write in patient-friendly language at an 8th-grade reading level
- Only provide the new text - do not include explanations"""

    def upload_to_blob(self, jsonl_content: str) -> str:
        """Upload JSONL content to Azure Blob Storage (append to existing file)."""
        if not self.blob_service:
            raise RuntimeError("Blob service not initialized")

        blob_path = "learning/dpo_learning.jsonl"
        container_client = self.blob_service.get_container_client(self.container_name)
        try:
            container_client.get_container_properties()
        except Exception:
            container_client.create_container()
        blob_client = container_client.get_blob_client(blob_path)

        # Use deduplication to handle blob content
        new_content = jsonl_content.strip()
        if not new_content:
            raise ValueError("No JSONL content to upload")

        # If blob exists, download and merge with deduplication
        if blob_client.exists():
            existing_content = blob_client.download_blob().readall().decode("utf-8")
            
            # Parse existing records
            existing_records = []
            existing_hashes = set()
            existing_non_pref_version_hashes = set()
            
            if existing_content:
                for line in existing_content.split('\n'):
                    if line.strip():
                        try:
                            existing_record = json.loads(line)
                            existing_records.append(existing_record)
                            
                            # Build hashes for existing records
                            existing_hash = DPODeduplicator._create_record_hash(existing_record)
                            if existing_hash:
                                existing_hashes.add(existing_hash)
                            
                            non_pref_version_hash = DPODeduplicator._create_non_pref_version_hash(existing_record)
                            if non_pref_version_hash:
                                existing_non_pref_version_hashes.add(non_pref_version_hash)
                        except json.JSONDecodeError:
                            pass
            
            # Parse new records
            new_records = []
            for line in new_content.split('\n'):
                if line.strip():
                    try:
                        new_records.append(json.loads(line))
                    except json.JSONDecodeError:
                        pass
            
            # Combine records with deduplication
            combined_records = existing_records.copy()
            
            stats = {"added": 0, "skipped_content": 0, "skipped_non_pref_version": 0}
            for new_record in new_records:
                # Check content-based duplicate
                if DPODeduplicator.is_duplicate(new_record, existing_hashes):
                    stats["skipped_content"] += 1
                    metadata = new_record.get('metadata', {})
                    logger.info(f"   ⏭️  CONTENT DUPLICATE SKIPPED - Case: {metadata.get('icf_case_id')}, "
                              f"Doc: {metadata.get('document_id')}, "
                              f"Iter: {metadata.get('iteration_id')}")
                    continue
                
                # Check non_preferred_output + version duplicate
                if DPODeduplicator.is_duplicate_by_non_pref_version(new_record, existing_non_pref_version_hashes):
                    stats["skipped_non_pref_version"] += 1
                    metadata = new_record.get('metadata', {})
                    logger.info(f"   ⏭️  NON_PREF+VERSION DUPLICATE SKIPPED - Case: {metadata.get('icf_case_id')}, "
                              f"Doc: {metadata.get('document_id')}, "
                              f"Iter: {metadata.get('iteration_id')}, "
                              f"Version: {metadata.get('version')}")
                    continue
                
                # New unique record
                combined_records.append(new_record)
                new_hash = DPODeduplicator._create_record_hash(new_record)
                if new_hash:
                    existing_hashes.add(new_hash)
                
                non_pref_version_hash = DPODeduplicator._create_non_pref_version_hash(new_record)
                if non_pref_version_hash:
                    existing_non_pref_version_hashes.add(non_pref_version_hash)
                
                stats["added"] += 1
                metadata = new_record.get('metadata', {})
                logger.info(f"   ✅ NEW RECORD ADDED - Case: {metadata.get('icf_case_id')}, "
                          f"Doc: {metadata.get('document_id')}, "
                          f"Iter: {metadata.get('iteration_id')}")
            
            logger.info(f"   [Deduplicate Summary] ✅ Added: {stats['added']}, "
                       f"⏭️  Content Dups: {stats['skipped_content']}, "
                       f"⏭️  Non_Pref+Version Dups: {stats['skipped_non_pref_version']}")
            
            # Rebuild JSONL content from combined records
            combined = "\n".join(json.dumps(r) for r in combined_records) + "\n"
        else:
            combined = new_content + "\n"

        blob_client.upload_blob(
            combined.encode("utf-8"),
            overwrite=True,
            content_settings=ContentSettings(content_type="application/jsonl"),
        )

        account_name = Config.AZURE_STORAGE_ACCOUNT_NAME
        if account_name:
            return (
                f"https://{account_name}.blob.core.windows.net/"
                f"{self.container_name}/{blob_path}"
            )

        return blob_client.url

    def generate_training_dataset(
        self,
        min_confidence: float = 0.0,
        icf_case_id: Optional[str] = None,
        iteration_id: Optional[int] = None,
        include_superseded: bool = False,
        top_k: Optional[int] = None,
        callback_url: Optional[str] = None,
        artifacts_override: Optional[Iterable[Dict[str, Any]]] = None,
    ) -> Dict[str, Any]:
        """Fetch artifacts (or use overrides), generate JSONL, upload to blob, return results."""
        if artifacts_override is not None:
            artifacts = list(artifacts_override)
        else:
            artifacts = self.fetch_learning_artifacts(
                min_confidence=min_confidence,
                icf_case_id=icf_case_id,
                iteration_id=iteration_id,
                include_superseded=include_superseded,
                top_k=top_k,
            )

        builder = self.build_training_data(artifacts)
        jsonl_content = builder.to_jsonl_string()
        blob_url = self.upload_to_blob(jsonl_content)

        result = {
            "success": True,
            "country": self.country,
            "index_name": self.index_name,
            "records": len(builder.records),
            "blob_url": blob_url,
            "schema_version": self.schema_version,
            "timestamp": datetime.utcnow().isoformat(),
        }

        if callback_url:
            try:
                import requests

                requests.post(callback_url, json=result, timeout=30)
            except Exception as exc:
                logger.warning("Callback failed: %s", exc)

        return result
