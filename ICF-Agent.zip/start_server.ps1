# ICF Agent - FastAPI Server Startup Script
# This script starts the FastAPI server for the ICF Agent project

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "ICF Agent - Starting FastAPI Server" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Check if virtual environment exists
if (-not (Test-Path "venv\Scripts\Activate.ps1")) {
    Write-Host "❌ Virtual environment not found!" -ForegroundColor Red
    Write-Host "Please run: python -m venv venv" -ForegroundColor Yellow
    exit 1
}

# Activate virtual environment
Write-Host "📦 Activating virtual environment..." -ForegroundColor Green
& .\venv\Scripts\Activate.ps1

# Check if .env file exists
if (-not (Test-Path ".env")) {
    Write-Host "⚠️  Warning: .env file not found!" -ForegroundColor Yellow
    Write-Host "Please create a .env file with your Azure credentials." -ForegroundColor Yellow
    Write-Host "See PROJECT_INDEX.md for required environment variables." -ForegroundColor Yellow
    Write-Host ""
}

# Create necessary directories
Write-Host "📁 Creating necessary directories..." -ForegroundColor Green
New-Item -ItemType Directory -Force -Path output,logs,median,uploads | Out-Null

# Start the server
Write-Host ""
Write-Host "🚀 Starting FastAPI server on http://localhost:8000" -ForegroundColor Green
Write-Host "Press Ctrl+C to stop the server" -ForegroundColor Yellow
Write-Host ""
Write-Host "API Documentation: http://localhost:8000/docs" -ForegroundColor Cyan
Write-Host "Health Check: http://localhost:8000/" -ForegroundColor Cyan
Write-Host ""

python app.py

