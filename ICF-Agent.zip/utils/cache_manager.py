"""
Persistent Cache Manager for ICF Generator.
Caches embeddings, RAG queries, and document sections.
File-based with TTL support and LRU eviction.
"""

import os
import json
import hashlib
import time
from typing import Any, Optional, Dict, List
from threading import Lock
from collections import OrderedDict


class CacheManager:
    """
    In-memory + file-based cache with TTL and LRU eviction.
    Used to cache expensive operations: embeddings, RAG queries, parsed sections.
    """
    
    DEFAULT_TTL = 3600  # 1 hour
    MAX_MEMORY_ITEMS = 1000
    CACHE_DIR = ".cache"
    
    def __init__(self, cache_dir: str = None, max_items: int = None, default_ttl: int = None):
        """
        Initialize cache manager.
        
        Args:
            cache_dir: Directory for file-based cache
            max_items: Maximum items in memory cache
            default_ttl: Default time-to-live in seconds
        """
        self.cache_dir = cache_dir or self.CACHE_DIR
        self.max_items = max_items or self.MAX_MEMORY_ITEMS
        self.default_ttl = default_ttl or self.DEFAULT_TTL
        
        self._memory_cache: OrderedDict = OrderedDict()
        self._lock = Lock()
        
        os.makedirs(self.cache_dir, exist_ok=True)
        os.makedirs(os.path.join(self.cache_dir, "embeddings"), exist_ok=True)
        os.makedirs(os.path.join(self.cache_dir, "rag"), exist_ok=True)
        os.makedirs(os.path.join(self.cache_dir, "sections"), exist_ok=True)
    
    def _hash_key(self, key: str) -> str:
        """Generate hash for cache key."""
        return hashlib.md5(key.encode()).hexdigest()
    
    def _is_expired(self, entry: Dict) -> bool:
        """Check if cache entry is expired."""
        if "expires_at" not in entry:
            return False
        return time.time() > entry["expires_at"]
    
    def _evict_if_needed(self):
        """Evict oldest items if cache is full (LRU)."""
        while len(self._memory_cache) >= self.max_items:
            self._memory_cache.popitem(last=False)
    
    # ==========================================================================
    # GENERIC CACHE OPERATIONS
    # ==========================================================================
    
    def get(self, key: str, category: str = "general") -> Optional[Any]:
        """
        Get value from cache.
        
        Args:
            key: Cache key
            category: Cache category (embeddings, rag, sections, general)
        """
        cache_key = f"{category}:{key}"
        key_hash = self._hash_key(cache_key)
        
        with self._lock:
            # Check memory cache first
            if key_hash in self._memory_cache:
                entry = self._memory_cache[key_hash]
                if not self._is_expired(entry):
                    self._memory_cache.move_to_end(key_hash)
                    return entry["value"]
                else:
                    del self._memory_cache[key_hash]
            
            # Check file cache
            file_path = os.path.join(self.cache_dir, category, f"{key_hash}.json")
            if os.path.exists(file_path):
                try:
                    with open(file_path, "r") as f:
                        entry = json.load(f)
                    if not self._is_expired(entry):
                        self._evict_if_needed()
                        self._memory_cache[key_hash] = entry
                        return entry["value"]
                    else:
                        os.remove(file_path)
                except:
                    pass
        
        return None
    
    def set(self, key: str, value: Any, category: str = "general", ttl: int = None):
        """
        Set value in cache.
        
        Args:
            key: Cache key
            value: Value to cache
            category: Cache category
            ttl: Time-to-live in seconds
        """
        cache_key = f"{category}:{key}"
        key_hash = self._hash_key(cache_key)
        ttl = ttl or self.default_ttl
        
        entry = {
            "value": value,
            "created_at": time.time(),
            "expires_at": time.time() + ttl
        }
        
        with self._lock:
            self._evict_if_needed()
            self._memory_cache[key_hash] = entry
            
            # Persist to file
            file_path = os.path.join(self.cache_dir, category, f"{key_hash}.json")
            try:
                os.makedirs(os.path.dirname(file_path), exist_ok=True)
                with open(file_path, "w") as f:
                    json.dump(entry, f)
            except:
                pass
    
    def delete(self, key: str, category: str = "general"):
        """Delete from cache."""
        cache_key = f"{category}:{key}"
        key_hash = self._hash_key(cache_key)
        
        with self._lock:
            if key_hash in self._memory_cache:
                del self._memory_cache[key_hash]
            
            file_path = os.path.join(self.cache_dir, category, f"{key_hash}.json")
            if os.path.exists(file_path):
                os.remove(file_path)
    
    # ==========================================================================
    # EMBEDDING CACHE
    # ==========================================================================
    
    def get_embedding(self, text: str) -> Optional[List[float]]:
        """Get cached embedding for text."""
        key = self._hash_key(text[:1000])
        return self.get(key, category="embeddings")
    
    def set_embedding(self, text: str, embedding: List[float], ttl: int = 86400):
        """Cache embedding (default: 24 hours)."""
        key = self._hash_key(text[:1000])
        self.set(key, embedding, category="embeddings", ttl=ttl)
    
    # ==========================================================================
    # RAG QUERY CACHE
    # ==========================================================================
    
    def get_rag_query(self, query: str, country: str) -> Optional[List[Dict]]:
        """Get cached RAG query results."""
        key = f"{country}:{self._hash_key(query)}"
        return self.get(key, category="rag")
    
    def set_rag_query(self, query: str, country: str, results: List[Dict], ttl: int = 1800):
        """Cache RAG query results (default: 30 minutes)."""
        key = f"{country}:{self._hash_key(query)}"
        self.set(key, results, category="rag", ttl=ttl)
    
    # ==========================================================================
    # DOCUMENT SECTIONS CACHE
    # ==========================================================================
    
    def get_document_sections(self, document_id: str) -> Optional[List[Dict]]:
        """Get cached document sections."""
        return self.get(document_id, category="sections")
    
    def set_document_sections(self, document_id: str, sections: List[Dict], ttl: int = 7200):
        """Cache document sections (default: 2 hours)."""
        self.set(document_id, sections, category="sections", ttl=ttl)
    
    # ==========================================================================
    # CACHE MANAGEMENT
    # ==========================================================================
    
    def clear(self, category: str = None):
        """Clear cache (all or specific category)."""
        with self._lock:
            if category:
                keys_to_delete = [k for k in self._memory_cache if k.startswith(f"{category}:")]
                for k in keys_to_delete:
                    del self._memory_cache[k]
                
                category_dir = os.path.join(self.cache_dir, category)
                if os.path.exists(category_dir):
                    for f in os.listdir(category_dir):
                        os.remove(os.path.join(category_dir, f))
            else:
                self._memory_cache.clear()
                for subdir in ["embeddings", "rag", "sections", "general"]:
                    subdir_path = os.path.join(self.cache_dir, subdir)
                    if os.path.exists(subdir_path):
                        for f in os.listdir(subdir_path):
                            os.remove(os.path.join(subdir_path, f))
    
    def get_stats(self) -> Dict:
        """Get cache statistics."""
        stats = {
            "memory_items": len(self._memory_cache),
            "max_memory_items": self.max_items,
            "categories": {}
        }
        
        for category in ["embeddings", "rag", "sections", "general"]:
            category_dir = os.path.join(self.cache_dir, category)
            if os.path.exists(category_dir):
                stats["categories"][category] = len(os.listdir(category_dir))
            else:
                stats["categories"][category] = 0
        
        return stats


# Singleton instance
cache = CacheManager()