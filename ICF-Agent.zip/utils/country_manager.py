"""
Country Management System for USA and Canada.
Provides validation, normalization, and country-specific configuration.
Extensible architecture for future country additions.
"""

from typing import Optional, Dict, List, Tuple
from enum import Enum


class CountryCode(str, Enum):
    """Supported country codes."""
    USA = "USA"
    CAN = "CAN"
    
    # Normalized codes
    US = "US"  # Normalized from USA
    CA = "CA"  # Normalized from CAN


class CountryConfig:
    """Configuration for a specific country."""
    
    def __init__(
        self,
        code: str,
        normalized_code: str,
        display_name: str,
        checklist_types: List[str]
    ):
        """
        Initialize country configuration.
        
        Args:
            code: Primary country code (e.g., "USA")
            normalized_code: Normalized ISO code (e.g., "US")
            display_name: Display name (e.g., "United States")
            checklist_types: List of checklist types for this country
        """
        self.code = code
        self.normalized_code = normalized_code
        self.display_name = display_name
        self.checklist_types = checklist_types
    
    def __repr__(self) -> str:
        return f"CountryConfig(code={self.code}, normalized={self.normalized_code}, name={self.display_name})"


# Country configurations
_COUNTRY_CONFIGS: Dict[str, CountryConfig] = {
    "USA": CountryConfig(
        code="USA",
        normalized_code="US",
        display_name="United States",
        checklist_types=["HIPAA", "country"]
    ),
    "US": CountryConfig(
        code="USA",
        normalized_code="US",
        display_name="United States",
        checklist_types=["HIPAA", "country"]
    ),
    "UNITED STATES": CountryConfig(
        code="USA",
        normalized_code="US",
        display_name="United States",
        checklist_types=["HIPAA", "country"]
    ),
    "CAN": CountryConfig(
        code="CAN",
        normalized_code="CA",
        display_name="Canada",
        checklist_types=["PIPEDA", "country"]
    ),
    "CA": CountryConfig(
        code="CAN",
        normalized_code="CA",
        display_name="Canada",
        checklist_types=["PIPEDA", "country"]
    ),
    "CANADA": CountryConfig(
        code="CAN",
        normalized_code="CA",
        display_name="Canada",
        checklist_types=["PIPEDA", "country"]
    ),
}

# Supported country codes (for validation)
SUPPORTED_COUNTRIES = {"USA", "US", "UNITED STATES", "CAN", "CA", "CANADA"}


class CountryValidator:
    """
    Validates and normalizes country codes.
    Supports USA and Canada with extensible architecture.
    """
    
    @staticmethod
    def validate(country: str) -> bool:
        """
        Validate if a country code is supported.
        
        Args:
            country: Country code to validate
            
        Returns:
            True if country is supported, False otherwise
        """
        if not country:
            return False
        return country.upper().strip() in SUPPORTED_COUNTRIES
    
    @staticmethod
    def normalize(country: str, case: str = "upper") -> Optional[str]:
        """
        Normalize country code to standard format.
        
        Args:
            country: Country code to normalize (e.g., "USA", "US", "United States")
            case: Output case - "upper" for "USA"/"CAN", "lower" for "usa"/"can", "mixed" for "Usa"/"Can"
            
        Returns:
            Normalized country code (USA or CAN), or None if invalid
            
        Examples:
            normalize("USA") -> "USA"
            normalize("US") -> "USA"
            normalize("United States") -> "USA"
            normalize("CAN") -> "CAN"
            normalize("CA") -> "CAN"
            normalize("Canada") -> "CAN"
        """
        if not country:
            return None
        
        country_upper = country.upper().strip()
        
        # Check if country exists in configs
        if country_upper not in _COUNTRY_CONFIGS:
            return None
        
        config = _COUNTRY_CONFIGS[country_upper]
        normalized = config.code
        
        # Apply case transformation
        if case == "lower":
            return normalized.lower()
        elif case == "mixed":
            return normalized.capitalize()
        else:  # default to upper
            return normalized
    
    @staticmethod
    def get_normalized_iso_code(country: str) -> Optional[str]:
        """
        Get normalized ISO country code (2-letter).
        
        Args:
            country: Country code (e.g., "USA", "CAN")
            
        Returns:
            ISO code (e.g., "US", "CA"), or None if invalid
        """
        if not country:
            return None
        
        country_upper = country.upper().strip()
        if country_upper not in _COUNTRY_CONFIGS:
            return None
        
        config = _COUNTRY_CONFIGS[country_upper]
        return config.normalized_code
    
    @staticmethod
    def get_config(country: str) -> Optional[CountryConfig]:
        """
        Get country configuration.
        
        Args:
            country: Country code
            
        Returns:
            CountryConfig object, or None if country not supported
        """
        if not country:
            return None
        
        country_upper = country.upper().strip()
        return _COUNTRY_CONFIGS.get(country_upper)
    
    @staticmethod
    def get_display_name(country: str) -> Optional[str]:
        """
        Get display name for country.
        
        Args:
            country: Country code
            
        Returns:
            Display name (e.g., "United States", "Canada"), or None if invalid
        """
        config = CountryValidator.get_config(country)
        return config.display_name if config else None
    
    @staticmethod
    def get_checklist_types(country: str) -> List[str]:
        """
        Get checklist types for a country.
        
        Args:
            country: Country code
            
        Returns:
            List of checklist types (e.g., ["HIPAA", "country"] for USA)
        """
        config = CountryValidator.get_config(country)
        return config.checklist_types if config else []
    
    @staticmethod
    def get_all_supported_countries() -> List[str]:
        """
        Get list of all supported country codes (normalized).
        
        Returns:
            List of normalized country codes (e.g., ["USA", "CAN"])
        """
        return sorted(set(config.code for config in _COUNTRY_CONFIGS.values()))


# Convenience functions for backward compatibility
def validate_country(country: str) -> bool:
    """Validate country code."""
    return CountryValidator.validate(country)


def normalize_country(country: str, case: str = "upper") -> Optional[str]:
    """Normalize country code."""
    return CountryValidator.normalize(country, case=case)


def get_country_config(country: str) -> Optional[CountryConfig]:
    """Get country configuration."""
    return CountryValidator.get_config(country)

