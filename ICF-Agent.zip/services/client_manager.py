"""
Shared Azure Service Client Manager for Connection Pooling.
Provides singleton instances of Azure OpenAI, Azure AI Search, and Blob Storage clients.
Uses Config for Search credentials (supports RBAC when API key is not set).
"""

import os
from typing import Optional
from openai import AzureOpenAI
from azure.storage.blob import BlobServiceClient
from azure.search.documents import SearchClient
from azure.search.documents.indexes import SearchIndexClient
from dotenv import load_dotenv

load_dotenv()


class ClientManager:
    """Singleton manager for Azure service clients with connection pooling."""
    
    _instance: Optional['ClientManager'] = None
    _openai_client: Optional[AzureOpenAI] = None
    _blob_service_client: Optional[BlobServiceClient] = None
    _search_index_client: Optional[SearchIndexClient] = None
    _search_clients: dict = {}  # Cache for per-index SearchClients
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(ClientManager, cls).__new__(cls)
        return cls._instance
    
    @property
    def openai_client(self) -> AzureOpenAI:
        """Get or create Azure OpenAI client (singleton)."""
        if self._openai_client is None:
            self._openai_client = AzureOpenAI(
                api_key=os.getenv("AZURE_OPENAI_API_KEY"),
                api_version=os.getenv("AZURE_OPENAI_API_VERSION"),
                azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT")
            )
        return self._openai_client
    
    @property
    def blob_service_client(self) -> Optional[BlobServiceClient]:
        """Get or create Blob Service client (singleton). Uses connection string or Config (RBAC)."""
        if self._blob_service_client is None:
            try:
                from config import config
                self._blob_service_client = config.get_blob_service_client()
            except Exception:
                # Config may raise if storage not configured; leave as None
                pass
        return self._blob_service_client
    
    @property
    def search_index_client(self) -> SearchIndexClient:
        """Get or create Search Index client (singleton)."""
        if self._search_index_client is None:
            from config import Config
            self._search_index_client = SearchIndexClient(
                endpoint=Config.get_search_endpoint(),
                credential=Config.get_search_credential()
            )
        return self._search_index_client
    
    def get_search_client(self, index_name: str) -> SearchClient:
        """
        Get or create SearchClient for a specific index (cached per index).
        Uses Config for credential (API key or RBAC/DefaultAzureCredential).
        
        Args:
            index_name: Name of the Azure AI Search index
            
        Returns:
            SearchClient instance for the specified index
        """
        if index_name not in self._search_clients:
            from config import Config
            self._search_clients[index_name] = SearchClient(
                endpoint=Config.get_search_endpoint(),
                index_name=index_name,
                credential=Config.get_search_credential()
            )
        return self._search_clients[index_name]
    
    def close_all(self):
        """Close all client connections (for cleanup)."""
        # Azure clients don't require explicit closing, but we can clear references
        self._openai_client = None
        self._blob_service_client = None
        self._search_index_client = None
        self._search_clients.clear()


# Global singleton instance
client_manager = ClientManager()
