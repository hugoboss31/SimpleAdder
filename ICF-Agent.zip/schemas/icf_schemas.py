"""
JSON schemas for ICF processing pipeline.

Defines data structures for:
- Global ICF section tree (hierarchical structure)
- Customization plan items (Excel rows)
- Section matching results
- ICF changes
- QA coverage reports
"""

from typing import List, Optional, Dict, Any, Literal
from pydantic import BaseModel, Field
from datetime import datetime
from enum import Enum


class RequirementType(str, Enum):
    """Type of customization requirement."""
    MANDATORY = "mandatory"
    OPTIONAL = "optional"


class ActionType(str, Enum):
    """Action to take for a customization item."""
    MODIFY_EXISTING = "modify_existing"
    INSERT_NEW = "insert_new"
    BOTH = "both"
    NO_MATCH = "no_match"
    AMBIGUOUS = "ambiguous"


class ChangeType(str, Enum):
    """Type of document change."""
    INSERT = "INSERT"
    DELETE = "DELETE"
    MODIFY = "MODIFY"


class ICFSection(BaseModel):
    """Represents a single section or paragraph in the Global ICF."""
    
    section_id: str = Field(..., description="Unique identifier for this section (e.g., 'sec_2.1')")
    title: Optional[str] = Field(None, description="Section heading/title")
    level: int = Field(..., description="Hierarchy level (1 = top-level, 2 = subsection, etc.)")
    page: Optional[int] = Field(None, description="Page number where section appears")
    order_index: int = Field(..., description="Order within document (0-based)")
    text: str = Field(..., description="Full text content of the section/paragraph")
    parent_section_id: Optional[str] = Field(None, description="Parent section ID if this is a subsection")
    children: List['ICFSection'] = Field(default_factory=list, description="Child subsections")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Additional metadata")


class ICFSectionTree(BaseModel):
    """Complete hierarchical structure of Global ICF."""
    
    document_id: str = Field(..., description="Unique identifier for the Global ICF document")
    document_name: str = Field(..., description="Name/title of the document")
    version: Optional[str] = Field(None, description="Document version")
    sections: List[ICFSection] = Field(default_factory=list, description="Top-level sections")
    total_sections: int = Field(..., description="Total number of sections")
    total_paragraphs: int = Field(..., description="Total number of paragraphs")
    page_count: int = Field(..., description="Total page count")
    created_at: datetime = Field(default_factory=datetime.utcnow)
    metadata: Dict[str, Any] = Field(default_factory=dict)


class CustomizationPlanItem(BaseModel):
    """Single row from the Excel customization plan."""
    
    item_id: str = Field(..., description="Unique identifier (e.g., 'USA-07')")
    topic: str = Field(..., description="Topic name (e.g., 'Contact for further information')")
    country: str = Field(..., description="Target country code (e.g., 'USA')")
    requirement_text: str = Field(..., description="Country-specific requirement text")
    requirement_type: RequirementType = Field(..., description="Whether requirement is mandatory or optional")
    applies_to: Optional[str] = Field(None, description="'existing_section', 'insert_new', 'both', or null if unknown")
    synonyms: List[str] = Field(default_factory=list, description="Synonyms for topic (e.g., ['HOW TO CONTACT US', 'contact information'])")
    importance: Optional[str] = Field(None, description="'high', 'medium', 'low' for legal sensitivity")
    metadata: Dict[str, Any] = Field(default_factory=dict)


class CustomizationPlan(BaseModel):
    """Complete customization plan parsed from Excel."""
    
    plan_id: str = Field(..., description="Unique identifier for this plan")
    country: str = Field(..., description="Target country")
    source_file: str = Field(..., description="Path to source Excel file")
    items: List[CustomizationPlanItem] = Field(default_factory=list, description="All customization items")
    created_at: datetime = Field(default_factory=datetime.utcnow)
    metadata: Dict[str, Any] = Field(default_factory=dict)


class MatchDecision(BaseModel):
    """LLM decision for matching a customization item to ICF section."""
    
    item_id: str = Field(..., description="Customization plan item ID")
    best_match_section_id: Optional[str] = Field(None, description="Best matching section ID (null if no match)")
    best_match_confidence: float = Field(..., ge=0.0, le=1.0, description="Confidence score 0-1")
    secondary_matches: List[str] = Field(default_factory=list, description="Alternative section IDs")
    action: ActionType = Field(..., description="Recommended action")
    justification: str = Field(..., description="Why this match/action was chosen")
    requires_review: bool = Field(False, description="Whether human review is required")


class SectionMatchResult(BaseModel):
    """Complete matching result for a customization plan item."""
    
    item_id: str = Field(..., description="Customization plan item ID")
    topic: str = Field(..., description="Topic from customization plan")
    query_text: str = Field(..., description="Query text used for search")
    candidate_sections: List[Dict[str, Any]] = Field(default_factory=list, description="Top-k candidate sections from search")
    decision: MatchDecision = Field(..., description="LLM decision")
    matched_section: Optional[ICFSection] = Field(None, description="Full matched section if found")
    search_metadata: Dict[str, Any] = Field(default_factory=dict, description="Search performance metrics")
    created_at: datetime = Field(default_factory=datetime.utcnow)


class ICFChange(BaseModel):
    """A single change to be applied to the ICF."""
    
    change_id: str = Field(..., description="Unique identifier for this change")
    source_plan_item_id: str = Field(..., description="Source customization plan item ID")
    source_global_section_id: Optional[str] = Field(None, description="Source Global ICF section ID")
    location: str = Field(..., description="Human-readable location (e.g., 'Section 2 - Study Purpose')")
    change_type: ChangeType = Field(..., description="Type of change")
    old_text: Optional[str] = Field(None, description="Text to be removed/modified")
    new_text: Optional[str] = Field(None, description="Text to be added/inserted")
    after_text: Optional[str] = Field(None, description="Anchor text for insertions")
    regulatory_reference: str = Field(..., description="Regulatory citation")
    justification: str = Field(..., description="Why this change is required")
    comment: str = Field(..., description="Short reviewer note")
    rationale: Optional[str] = Field(None, description="Matching rationale from Section-Matcher")
    created_at: datetime = Field(default_factory=datetime.utcnow)


class QACoverageReport(BaseModel):
    """Coverage report from QA Agent."""
    
    total_plan_items: int = Field(..., description="Total items in customization plan")
    handled_items: int = Field(..., description="Items with valid matches/changes")
    unmapped_items: List[str] = Field(default_factory=list, description="Item IDs with no match")
    low_confidence_items: List[str] = Field(default_factory=list, description="Item IDs with confidence < threshold")
    insert_new_items: List[str] = Field(default_factory=list, description="Items requiring new sections")
    high_risk_items: List[str] = Field(default_factory=list, description="Legally sensitive items requiring review")
    coverage_percentage: float = Field(..., ge=0.0, le=100.0, description="Percentage of items handled")
    requires_human_review: bool = Field(False, description="Whether any items require human review")
    created_at: datetime = Field(default_factory=datetime.utcnow)


class QAValidationResult(BaseModel):
    """QA validation result for a single change."""
    
    change_id: str = Field(..., description="Change ID being validated")
    valid: bool = Field(..., description="Whether change is valid")
    issues: List[str] = Field(default_factory=list, description="List of validation issues")
    regulatory_reference_valid: bool = Field(True, description="Whether regulatory reference is valid")
    regulatory_reference_applicable: bool = Field(True, description="Whether reference applies to country")
    conflicts: List[str] = Field(default_factory=list, description="Conflicting sections/changes")
    created_at: datetime = Field(default_factory=datetime.utcnow)


# Update forward references
ICFSection.model_rebuild()
ICFSectionTree.model_rebuild()

