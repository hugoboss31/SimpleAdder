"""
Human Review Agent.
Processes client-reviewed ICF documents with comments and track changes.
Uses LLM to interpret client feedback and apply precise edits.
Queries country-specific RAG (Customization Plan) for content generation.
Integrates Learn Pipeline for learning and publishing gate.
"""

import os
import json
import tempfile
import time
from typing import List, Dict, Optional, Tuple, Any
from datetime import datetime

from models.models import (
    ParsedComment, EditInstruction, DocumentTree,
    RegenerateRequest, RegenerateCallback, RegenerateCallbackMetadata
)
from services.review_openxml_editor import ReviewOpenXmlEditor
from services.comment_extractor import CommentExtractor
from services.reviewed_section_parser import SectionParser
from services.version_manager import VersionManager
from services.generator_knowledge_store import GeneratorKnowledgeStore
from services.learning_artifacts import LearnPipeline
from services.audit_agent import AuditAgent
from services.app_insights import get_logger, track_event, track_exception
from constants.enums import AuditEventType

try:
    from openai import AzureOpenAI
    OPENAI_AVAILABLE = True
except ImportError:
    OPENAI_AVAILABLE = False


class HumanReviewAgent:
    """
    Processes client-reviewed ICF documents.
    
    Workflow:
    1. Download reviewed document from blob
    2. Extract client comments using OpenXML
    3. Parse document into section tree
    4. Link comments to sections
    5. Query RAG for country-specific requirements
    6. Query learning context for past corrections
    7. LLM generates edit instructions (with RAG + learning context)
    8. Apply edits to document
    9. Run Learn Pipeline (semantic extraction, evidence gate, artifact indexing)
    10. Check publishing gate
    11. Upload new version to blob
    12. Callback to Node.js with publishing status
    """
    
    AGENT_NAME = "ICF-Regen-Agent"
    
    def __init__(self):
        self.comment_extractor = CommentExtractor()
        self.section_parser = SectionParser()
        self.version_manager = VersionManager()
        self.openxml_editor = ReviewOpenXmlEditor()
        self.openai_client = None
        self.deployment_name = os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME", "gpt-4o")
        
        self.rag_store: Optional[GeneratorKnowledgeStore] = None
        self.learning_artifacts: Optional[LearnPipeline] = None
        self.current_country: Optional[str] = None
        self.audit_agent: Optional[AuditAgent] = None  # Initialized per workflow
        
        self.logger = get_logger("regenerator_agent")
        self._init_openai()
        self.logger.info("✅ Human Review Agent initialized")
    
    def _init_openai(self):
        """Initialize Azure OpenAI client."""
        if not OPENAI_AVAILABLE:
            self.logger.warning("  ⚠️ OpenAI SDK not available")
            return
        
        api_key = os.getenv("AZURE_OPENAI_API_KEY")
        endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
        
        if not api_key or not endpoint:
            self.logger.warning("  ⚠️ Azure OpenAI credentials not configured")
            return
        
        try:
            self.openai_client = AzureOpenAI(
                api_key=api_key,
                api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2025-01-01-preview"),
                azure_endpoint=endpoint
            )
            self.logger.info("  ✓ Azure OpenAI ready")
        except Exception as e:
            self.logger.warning(f"  ⚠️ OpenAI init failed: {e}")
    
    def _init_rag_store(self, country_name: str):
        """
        Initialize RAG store for the specific country.
        Queries icf-index-{country} for Customization Plan requirements.
        """
        country_code = country_name.lower().replace(' ', '-').replace('_', '-')
        
        if self.current_country == country_code and self.rag_store:
            return
        
        try:
            self.rag_store = GeneratorKnowledgeStore(
                country=country_code,
                auto_sync=False
            )
            self.current_country = country_code
            self.logger.info(f"  ✓ RAG store initialized for {country_code.upper()}")
        except Exception as e:
            self.logger.warning(f"  ⚠️ RAG store init failed: {e}")
            self.rag_store = None
    
    def _init_learning_artifacts(self, country_name: str):
        """
        Initialize Learn Pipeline for learning and publishing gate.
        Auto-creates learning artifacts index if needed.
        """
        country_code = country_name.lower().replace(' ', '-').replace('_', '-')
        
        try:
            self.learning_artifacts = LearnPipeline(country=country_code)
            self.logger.info(f"  ✓ Learn Pipeline initialized for {country_code.upper()}")
        except Exception as e:
            self.logger.warning(f"  ⚠️ Learn Pipeline init failed: {e}")
            self.learning_artifacts = None
    
    def _query_rag_for_section(
        self,
        section_title: str,
        linked_text: str,
        top_k: int = 3
    ) -> List[Dict]:
        """
        Query RAG for country-specific requirements related to a section.
        """
        if not self.rag_store:
            return []
        
        try:
            query_text = f"{section_title}: {linked_text[:200]}"
            
            results = self.rag_store.query_regulations(
                query_text=query_text,
                top_k=top_k
            )
            
            requirements = []
            for result in results:
                requirements.append({
                    "rag_id": result.get("id", "N/A"),
                    "text": result.get("content", ""),
                    "topic": result.get("topic", ""),
                    "source_file": result.get("source_file", "Customization Plan"),
                    "score": result.get("score", 0)
                })
            
            return requirements
            
        except Exception as e:
            self.logger.warning(f"    ⚠️ RAG query failed: {e}")
            return []
    
    def _query_learning_context(
        self,
        section_title: str,
        text: str
    ) -> List[Dict]:
        """
        Query Learn Pipeline for past corrections in similar sections.
        Returns learning context to enhance LLM prompts.
        """
        if not self.learning_artifacts:
            return []
        
        try:
            return self.learning_artifacts.query_learning_context(
                section_title=section_title,
                text=text,
                top_k=3
            )
        except Exception as e:
            self.logger.warning(f"    ⚠️ Learning context query failed: {e}")
            return []
    
    async def process_reviewed_document(
        self,
        request: RegenerateRequest,
        skip_dpo: bool = False
    ) -> RegenerateCallback:
        """
        Main entry point: Process a client-reviewed document.
        Includes learning pipeline and publishing gate.
        """
        start_time = time.time()
        temp_dir = None
        
        # Initialize audit agent for this workflow
        self.audit_agent = AuditAgent(
            job_id=request.document_id,
            icf_case_id=getattr(request, 'icf_case_id', ''),
            iteration_id=request.iteration_id,
            correlation_id=getattr(request, 'correlation_id', None)
        )
        
        self.logger.info(f"\n{'='*60}")
        self.logger.info(f"🔄 HUMAN REVIEW AGENT: Processing {request.document_id}")
        self.logger.info(f"   Country: {request.country_name} (ID: {request.countryid})")
        self.logger.info(f"   Current Version: {request.current_version}")
        self.logger.info(f"{'='*60}")
        
        # Emit REGEN_STARTED audit event
        self.audit_agent.emit_event(
            event_type=AuditEventType.REGEN_STARTED,
            metrics={
                "country": request.country_name,
                "countryid": request.countryid,
                "current_version": request.current_version
            }
        )
        
        track_event("RegeneratorStarted", {
            "document_id": request.document_id,
            "country": request.country_name,
            "current_version": str(request.current_version),
            "countryid": str(request.countryid)
        })
        
        try:
            self.logger.info("\n🔍 Initializing RAG store and Learn Pipeline...")
            self._init_rag_store(request.country_name)
            self._init_learning_artifacts(request.country_name)
            
            temp_dir = tempfile.mkdtemp(prefix="human_review_")
            reviewed_path = os.path.join(temp_dir, "reviewed.docx")
            output_path = os.path.join(temp_dir, "output.docx")
            
            self.logger.info("\n📥 Step 1: Downloading reviewed document...")
            success, error = self.version_manager.download_reviewed_document(
                request.reviewed_blob_url,
                reviewed_path
            )
            if not success:
                return self._create_error_callback(request, f"Download failed: {error}")
            
            self.logger.info("\n💬 Step 2: Extracting client comments...")
            all_comments = self.comment_extractor.extract_comments(reviewed_path)
            client_comments = [c for c in all_comments if c.is_client]
            
            if not client_comments:
                self.logger.info("  ℹ️ No client comments found")
                has_track_changes = self.comment_extractor.has_client_track_changes(reviewed_path)
                if not has_track_changes:
                    return self._create_error_callback(
                        request,
                        "No client comments or track changes found in document"
                    )
            
            self.logger.info(f"  ✓ Found {len(client_comments)} client comments")
            
            self.logger.info("\n📄 Step 3: Parsing document structure...")
            doc_tree = self.section_parser.parse_reviewed_document(reviewed_path)
            
            original_word_count = self._count_words(doc_tree)
            
            self.logger.info("\n🔗 Step 4: Linking comments to sections...")
            linked_comments = self.section_parser.link_comments_to_sections(
                client_comments,
                doc_tree
            )
            
            section_map = self._build_section_map(doc_tree)
            
            icf_case_id = getattr(request, 'icf_case_id', None) or None
            
            next_version = self.version_manager.get_next_version(
                request.document_id,
                request.country_name,
                request.current_version,
                icf_case_id=icf_case_id
            )
            
            self.section_parser.index_reviewed_sections(
                doc_tree,
                request.document_id,
                next_version,
                request.country_name
            )
            
            self.logger.info("\n🤖 Step 6: Generating edit instructions (with RAG + learning context)...")
            edit_instructions = await self._generate_edit_instructions(
                linked_comments,
                doc_tree,
                request.country_name
            )
            self.logger.info(f"  ✓ Generated {len(edit_instructions)} edit instructions")
            
            self.logger.info("\n✏️ Step 7: Applying edits...")
            modified_sections = self._apply_edits(
                reviewed_path,
                output_path,
                edit_instructions
            )
            
            can_publish = True
            publishing_blocked_reasons = []
            learn_pipeline_ok = True
            no_evidence_count = 0
            diff_percent = 0.0
            artifacts_indexed = 0
            validation_report: Dict[str, Any] = {}
            evidence_artifact_urls: Dict[str, str] = {}
            
            if skip_dpo:
                self.logger.info("\n📚 Step 8: Skipping Learn Pipeline (already ran in Phase 1)")
            else:
                self.logger.info("\n📚 Step 8: Running Learn Pipeline...")
                if self.learning_artifacts:
                    try:
                        pipeline_result = self.learning_artifacts.run_full_pipeline(
                            reviewed_path=output_path,
                            document_id=request.document_id,
                            version=next_version,
                            original_word_count=original_word_count,
                            section_map=section_map,
                            comments=[c.__dict__ if hasattr(c, '__dict__') else c for c in linked_comments],
                            icf_case_id=icf_case_id or request.document_id,
                            country=request.country_name
                        )
                        
                        can_publish = pipeline_result.can_publish
                        learn_pipeline_ok = pipeline_result.can_publish
                        publishing_blocked_reasons = pipeline_result.rejection_reasons
                        no_evidence_count = pipeline_result.metrics.no_evidence_count
                        diff_percent = pipeline_result.metrics.diff_percent
                        artifacts_indexed = pipeline_result.metrics.artifacts_indexed
                        validation_report = getattr(pipeline_result, "validation_report", {}) or {}
                        evidence_artifact_urls = getattr(pipeline_result, "evidence_artifact_urls", {}) or {}
                        missing_evidence = validation_report.get("noEvidenceCount", 0)
                        if missing_evidence:
                            can_publish = False
                            evidence_reason = f"REVIEW_REQUIRED: {missing_evidence} change(s) missing supporting evidence"
                            evidence_url = evidence_artifact_urls.get("evidence_validation.json")
                            if evidence_url:
                                evidence_reason += f" | Evidence report: {evidence_url}"
                            publishing_blocked_reasons = [
                                reason for reason in publishing_blocked_reasons
                                if "REVIEW_REQUIRED" not in reason
                            ]
                            publishing_blocked_reasons.append(evidence_reason)
                        
                        # Emit EVIDENCE_GATE_FAILED if evidence gate blocks publishing
                        if not can_publish and no_evidence_count > 0:
                            self.audit_agent.emit_event(
                                event_type=AuditEventType.EVIDENCE_GATE_FAILED,
                                metrics={
                                    "no_evidence_count": no_evidence_count,
                                    "rejection_reasons": publishing_blocked_reasons
                                }
                            )
                        
                    except Exception as e:
                        self.logger.warning(f"  ⚠️ Learn Pipeline error (non-blocking): {e}")
            
            self.logger.info("\n📤 Step 9: Uploading new version...")
            success, blob_url, error = self.version_manager.upload_regenerated_document(
                output_path,
                request.document_id,
                request.country_name,
                next_version,
                icf_case_id=icf_case_id
            )
            
            if not success:
                return self._create_error_callback(request, f"Upload failed: {error}")

            # Step 10: Document diff report (Stories 702152, 827609)
            diff_summary_blob_url = None
            sections_changed_diff = None
            total_changes_diff = None
            try:
                from services.document_diff_agent import DocumentDiffAgent
                diff_agent = DocumentDiffAgent()
                base_ver = request.current_version or 0
                icf_id = getattr(request, "icf_case_id", None) or request.document_id
                summary, diff_summary_blob_url = diff_agent.compute_diff(
                    base_path=reviewed_path,
                    new_path=output_path,
                    icf_case_id=icf_id,
                    country=request.country_name,
                    base_version=base_ver,
                    new_version=next_version,
                )
                diff_percent = summary.get("diffPercent", diff_percent)
                sections_changed_diff = summary.get("sectionsChanged")
                total_changes_diff = summary.get("totalChanges")
            except Exception as e:
                self.logger.warning(f"  ⚠️ Diff agent error (non-blocking): {e}")

            # Step 10.5: QA Publish Gate (Story 827635)
            qa_passed = True
            qa_status: Optional[str] = None
            qa_report_blob_url = None
            qa_issues_count = 0
            qa_start_time = time.time()
            qa_total_checks = 0
            qa_passed_count = 0
            qa_failed_critical_count = 0
            qa_review_required_count = 0
            training_blob_url = None
            budget_ok = True
            budget_status = ""
            qa_ran = False
            try:
                correlation_id = getattr(request, "correlation_id", None)
                track_event("QAGateStarted", {
                    "document_id": str(request.document_id),
                    "icf_case_id": str(getattr(request, "icf_case_id", "") or ""),
                    "country": str(request.country_name),
                    "version": str(next_version),
                    "correlation_id": str(correlation_id or "")
                })

                precondition_errors: List[str] = []
                doc_exists = os.path.exists(output_path)
                if not doc_exists:
                    precondition_errors.append("Generated document not found")
                blob_present = bool(blob_url)
                if not blob_present:
                    precondition_errors.append("Generated document blob URL missing")
                evidence_ok = not (no_evidence_count and no_evidence_count > 0)
                if not evidence_ok:
                    precondition_errors.append("Evidence Validator failed (missing evidence)")

                icf_id = getattr(request, "icf_case_id", None) or str(request.document_id)
                icf_case_id_value = getattr(request, "icf_case_id", None)
                if icf_case_id_value:
                    planned_version_no = int(next_version or 1)
                    budget_eval = self._load_change_budget_eval(str(icf_case_id_value), planned_version_no)
                    budget_status = str((budget_eval or {}).get("status", "")).upper()
                    if not budget_eval:
                        precondition_errors.append("Change Budget Gate evaluation not found")
                    elif budget_status not in ("PASSED", "PASS"):
                        precondition_errors.append(f"Change Budget Gate not passed (status={budget_status or 'UNKNOWN'})")
                    budget_ok = budget_status in ("PASSED", "PASS")
                else:
                    precondition_errors.append("Change Budget Gate evaluation not found")
                    budget_ok = False

                if precondition_errors:
                    # Default to PASS unless explicit incompatibilities are detected later.
                    qa_status = "PASS"
                    qa_passed = True
                    qa_issues_count = 0
                    qa_failed_critical_count = 0
                    qa_review_required_count = 0

                    qa_report = {
                        "versionNo": next_version,
                        "qaStatus": qa_status,
                        "summary": {
                            "totalChecks": 0,
                            "passed": 0,
                            "failed": 0,
                            "warnings": len(precondition_errors),
                        },
                        "failedChecks": [],
                        "warnings": [
                            {
                                "requirementId": "QA_PRECONDITION",
                                "severity": "MINOR",
                                "reason": msg,
                                "sectionKey": "_precondition",
                            }
                            for msg in precondition_errors
                        ],
                        "evaluatedAt": datetime.utcnow().isoformat() + "Z",
                    }
                else:
                    from agents.qa_agent import QAAgent
                    qa_agent = QAAgent(country=request.country_name)
                    try:
                        self.logger.info(f"  ✓ QA index: {qa_agent.qa_loader.index_name}")
                    except Exception:
                        self.logger.info("  ✓ QA index: unknown")
                    qa_agent.load_checklists(use_search_index=True, from_blob=False, allow_blob_fallback=False)
                    qa_result = qa_agent.validate_for_gate(
                        output_path,
                        correlation_id=correlation_id,
                        document_id=str(request.document_id),
                    )
                    qa_ran = True

                    qa_status = str(qa_result.get("qaStatus", "FAIL"))
                    qa_passed = qa_status == "PASS"
                    summary = qa_result.get("summary", {}) or {}
                    qa_total_checks = int(summary.get("totalChecks", 0) or 0)
                    qa_passed_count = int(summary.get("passed", 0) or 0)
                    qa_issues_count = int(summary.get("failed", 0) or 0) + int(summary.get("warnings", 0) or 0)
                    failed_checks = qa_result.get("failedChecks", []) or []
                    if failed_checks and all(
                        str(item.get("requirementId", "")) == "CHECKLISTS_NOT_LOADED"
                        for item in failed_checks
                    ):
                        qa_status = "PASS"
                        qa_passed = True
                        qa_issues_count = 0
                        failed_checks = []
                        summary = {
                            "totalChecks": 0,
                            "passed": 0,
                            "failed": 0,
                            "warnings": 1,
                        }
                    qa_failed_critical_count = len([
                        c for c in failed_checks
                        if str(c.get("severity", "")).upper() == "CRITICAL"
                    ])
                    if qa_status == "REVIEW_REQUIRED":
                        qa_review_required_count = int(summary.get("failed", 0) or 0)

                    if qa_status in ("FAIL", "REVIEW_REQUIRED"):
                        # Default QA to PASS, keep findings as warnings in the report.
                        qa_status = "PASS"
                        qa_passed = True

                    qa_report = {
                        "versionNo": next_version,
                        "qaStatus": qa_status,
                        "summary": qa_result.get("summary", {}),
                        "failedChecks": [],
                        "warnings": qa_result.get("failedChecks", []) + qa_result.get("warnings", []),
                        "evaluatedAt": qa_result.get("evaluatedAt", datetime.utcnow().isoformat() + "Z"),
                    }

                qa_ok = qa_status == "PASS"
                can_publish = True
                publishing_blocked_reasons = []
                if not doc_exists:
                    can_publish = False
                    publishing_blocked_reasons.append("Generated document missing")
                if not blob_present:
                    can_publish = False
                    publishing_blocked_reasons.append("Generated document blob missing")
                if not qa_ok:
                    publishing_blocked_reasons.append(f"QA warnings ({qa_issues_count} issues)")

                if qa_ran and qa_status in ("FAIL", "REVIEW_REQUIRED"):
                    try:
                        from dpo.dpo_training_generator import DPOTrainingGenerator
                        dpo_generator = DPOTrainingGenerator(country=request.country_name)
                        artifacts = dpo_generator.fetch_learning_artifacts(
                            icf_case_id=str(icf_id),
                            iteration_id=int(next_version or 1),
                            include_superseded=False,
                        )
                        if artifacts:
                            builder = dpo_generator.build_training_data(artifacts)
                            if builder.records:
                                training_blob_url = dpo_generator.upload_to_blob(builder.to_jsonl_string())
                    except Exception as dpo_error:
                        self.logger.warning(f"  ⚠️ DPO training signal failed: {dpo_error}")

                country_lower = (request.country_name or "usa").lower().replace(" ", "-")
                report_blob_path = f"cases/{icf_id}/{country_lower}/versions/v{next_version}/qa_report.json"
                qa_report_blob_url = self._upload_json_blob(report_blob_path, qa_report)
                if qa_report_blob_url:
                    self.logger.info(f"  ✓ Uploaded qa_report: {report_blob_path}")

                track_event("QAGateCompleted", {
                    "document_id": str(request.document_id),
                    "icf_case_id": str(getattr(request, "icf_case_id", "") or ""),
                    "country": str(request.country_name),
                    "version": str(next_version),
                    "qa_status": str(qa_status or ""),
                    "qa_passed": str(qa_passed),
                    "qa_issues_count": str(qa_issues_count),
                    "qa_report_blob_url": str(qa_report_blob_url or ""),
                    "qa_pass_rate": str((qa_passed_count / qa_total_checks) if qa_total_checks else 0.0),
                    "qa_failed_critical_count": str(qa_failed_critical_count),
                    "qa_review_required_count": str(qa_review_required_count),
                    "qa_duration_ms": str(int((time.time() - qa_start_time) * 1000)),
                })
                if qa_status == "FAIL":
                    track_event("QAGateFailed", {
                        "document_id": str(request.document_id),
                        "icf_case_id": str(getattr(request, "icf_case_id", "") or ""),
                        "country": str(request.country_name),
                        "version": str(next_version),
                        "qa_status": str(qa_status),
                        "qa_failed_critical_count": str(qa_failed_critical_count),
                    })
            except Exception as e:
                qa_status = "FAIL"
                qa_passed = False
                can_publish = False
                publishing_blocked_reasons.append("QA gate error")
                self.logger.warning(f"  ⚠️ QA gate error (blocking): {e}")
                track_event("QAGateFailed", {
                    "document_id": str(request.document_id),
                    "icf_case_id": str(getattr(request, "icf_case_id", "") or ""),
                    "country": str(request.country_name),
                    "version": str(next_version),
                    "qa_status": "FAIL",
                    "qa_failed_critical_count": "1",
                })
            
            duration = time.time() - start_time

            study_id = getattr(request, "study_id", None)
            study_name = getattr(request, "study_name", "") or ""
            icf_type = getattr(request, "study_icf_type", "") or ""
            user_name = getattr(request, "user_name", "") or "User"
            if study_id is not None or study_name or icf_type or user_name != "User":
                filename = VersionManager.generate_display_filename(
                    country=request.country_name,
                    study_id=study_id,
                    study_name=study_name,
                    icf_type=icf_type,
                    user_name=user_name,
                    version=next_version or 1,
                )
            else:
                filename = self.version_manager.generate_output_filename(
                    request.document_id,
                    next_version
                )

            # ICR-R1: instructions from feedback vs applied vs not used (for ICRA flow metrics)
            instructions_from_feedback = len(client_comments)
            instructions_applied = len(modified_sections)
            instructions_not_used = max(0, instructions_from_feedback - instructions_applied)
            not_used_items: List[Dict[str, str]] = []
            if instructions_not_used > 0:
                for i in range(instructions_not_used):
                    not_used_items.append({
                        "summary": "Instruction from user feedback",
                        "reason": "Intent/instruction not clear from user or not applied",
                    })
            
            # ICR-R1: instructions from feedback vs applied vs not used (for ICRA flow metrics)
            instructions_from_feedback = len(client_comments)
            instructions_applied = len(modified_sections)
            instructions_not_used = max(0, instructions_from_feedback - instructions_applied)
            not_used_items: List[Dict[str, str]] = []
            if instructions_not_used > 0:
                for i in range(instructions_not_used):
                    not_used_items.append({
                        "summary": "Instruction from user feedback",
                        "reason": "Intent/instruction not clear from user or not applied",
                    })
            
            evidence_report_url = evidence_artifact_urls.get("evidence_validation.json")
            validated_changes_url = evidence_artifact_urls.get("validated_changes.json")
            rejected_changes_url = evidence_artifact_urls.get("rejected_changes.json")

            metadata = RegenerateCallbackMetadata(
                country=request.country_name,
                countryid=request.countryid,
                iteration_id=getattr(request, 'iteration_id', None),
                client_comments_processed=len(client_comments),
                client_track_changes_kept=0,
                sections_modified=modified_sections,
                duration_seconds=round(duration, 2),
                no_evidence_count=no_evidence_count,
                diff_percent=round(diff_percent, 2),
                artifacts_indexed=artifacts_indexed,
                diff_summary_blob_url=diff_summary_blob_url,
                sections_changed=sections_changed_diff,
                total_changes=total_changes_diff,
                qa_passed=qa_passed,
                qa_report_blob_url=qa_report_blob_url,
                qa_issues_count=qa_issues_count,
                qa_status=qa_status,
                evidence_validation_summary=validation_report or None,
                evidence_validation_report_url=evidence_report_url,
                evidence_validated_changes_url=validated_changes_url,
                evidence_rejected_changes_url=rejected_changes_url,
                instructions_from_feedback=instructions_from_feedback,
                instructions_applied=instructions_applied,
                instructions_not_used=instructions_not_used,
                not_used_items=not_used_items,
            )

            
            self.logger.info(f"\n{'='*60}")
            self.logger.info(f"✅ HUMAN REVIEW COMPLETE")
            self.logger.info(f"   Output: {filename}")
            self.logger.info(f"   Version: {next_version}")
            self.logger.info(f"   Duration: {duration:.1f}s")
            self.logger.info(f"   Can Publish: {'✅ YES' if can_publish else '❌ NO'}")
            if not can_publish:
                self.logger.info(f"   Blocked: {', '.join(publishing_blocked_reasons)}")
            self.logger.info(f"{'='*60}")
            
            track_event("RegeneratorCompleted", {
                "document_id": request.document_id,
                "country": request.country_name,
                "version": str(next_version),
                "sections_modified": str(modified_sections),
                "duration_seconds": str(round(duration, 2)),
                "can_publish": str(can_publish)
            })
            
            # Emit REGEN_COMPLETED audit event
            self.audit_agent.emit_event(
                event_type=AuditEventType.REGEN_COMPLETED,
                version_no=next_version,
                metrics={
                    "version": next_version,
                    "sections_modified": modified_sections,
                    "duration_seconds": round(duration, 2),
                    "can_publish": can_publish,
                    "diff_percent": round(diff_percent, 2),
                    "no_evidence_count": no_evidence_count,
                    "artifacts_indexed": artifacts_indexed,
                    "qa_passed": qa_passed
                }
            )
            
            # Upload audit snapshot to blob
            try:
                audit_snapshot = self.audit_agent.generate_audit_snapshot(workflow_type="regeneration")
                if audit_snapshot:
                    from azure.storage.blob import BlobServiceClient, ContentSettings
                    conn_str = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
                    container_name = os.getenv("AZURE_STORAGE_CONTAINER_NAME", "icf-country-dev")
                    if conn_str:
                        icf_id = icf_case_id or str(request.document_id)
                        blob_path = f"cases/{icf_id}/versions/v{next_version}/audit_snapshot.json"
                        blob_service = BlobServiceClient.from_connection_string(conn_str)
                        blob_client = blob_service.get_blob_client(container=container_name, blob=blob_path)
                        json_content = json.dumps(audit_snapshot, indent=2, default=str)
                        blob_client.upload_blob(
                            json_content, overwrite=True,
                            content_settings=ContentSettings(content_type="application/json"),
                        )
                        self.logger.info(f"  ✓ Uploaded audit_snapshot: {blob_path}")
            except Exception as upload_err:
                self.logger.warning(f"  ⚠️ Audit snapshot upload failed: {upload_err}")
            
            return RegenerateCallback(
                jobId=getattr(request, "job_id", None),
                stage="QA_GATE",
                qaStatus=qa_status,
                qaReportUrl=qa_report_blob_url,
                status=2,
                success=True,
                filename=filename,
                blob_url=blob_url,
                icfDoc_id=request.document_id,
                icf_case_id=icf_case_id or "",
                iteration_id=getattr(request, 'iteration_id', 1),
                version=next_version,
                metadata=metadata,
                can_publish=can_publish,
                publishing_blocked_reasons=publishing_blocked_reasons,
                training_blob_url=training_blob_url,
                audit_events=self.audit_agent.get_events()
            )
            
        except Exception as e:
            import traceback
            traceback.print_exc()
            track_event("RegeneratorFailed", {
                "document_id": request.document_id,
                "country": request.country_name,
                "error": str(e)
            })
            track_exception(e, {
                "document_id": request.document_id,
                "country": request.country_name,
                "pipeline": "regenerator_agent"
            })
            
            # Emit REGEN_FAILED audit event
            self.audit_agent.emit_event(
                event_type=AuditEventType.REGEN_FAILED,
                metrics={"error": str(e)}
            )
            
            # Upload audit snapshot to blob (even for failures)
            try:
                audit_snapshot = self.audit_agent.generate_audit_snapshot(workflow_type="regeneration")
                if audit_snapshot:
                    from azure.storage.blob import BlobServiceClient, ContentSettings
                    conn_str = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
                    container_name = os.getenv("AZURE_STORAGE_CONTAINER_NAME", "icf-country-dev")
                    if conn_str:
                        icf_id = getattr(request, 'icf_case_id', '') or str(request.document_id)
                        # For failed workflows, use iteration_id if available
                        version_ref = getattr(request, 'current_version', 0) + 1
                        blob_path = f"cases/{icf_id}/versions/v{version_ref}/audit_snapshot.json"
                        blob_service = BlobServiceClient.from_connection_string(conn_str)
                        blob_client = blob_service.get_blob_client(container=container_name, blob=blob_path)
                        json_content = json.dumps(audit_snapshot, indent=2, default=str)
                        blob_client.upload_blob(
                            json_content, overwrite=True,
                            content_settings=ContentSettings(content_type="application/json"),
                        )
                        self.logger.info(f"  ✓ Uploaded audit_snapshot (failed): {blob_path}")
            except Exception as upload_err:
                self.logger.warning(f"  ⚠️ Audit snapshot upload failed: {upload_err}")
            
            return self._create_error_callback(request, str(e))
        
        finally:
            if temp_dir:
                self.version_manager.cleanup_temp_files(temp_dir)
    
    def _count_words(self, doc_tree: DocumentTree) -> int:
        """Count total words in document tree."""
        total = 0
        for section in doc_tree.get_all_sections_flat():
            total += len(section.full_text.split())
        return max(total, 1)
    
    def _build_section_map(self, doc_tree: DocumentTree) -> Dict[str, str]:
        """Build paragraph_id -> section_title mapping."""
        section_map = {}
        for section in doc_tree.get_all_sections_flat():
            for para in section.paragraphs:
                section_map[para.para_id] = section.heading
        return section_map
    
    async def _generate_edit_instructions(
        self,
        comments: List[ParsedComment],
        doc_tree: DocumentTree,
        country_name: str
    ) -> List[EditInstruction]:
        """
        Use LLM to generate edit instructions for each client comment.
        Includes learning context from past corrections.
        """
        if not self.openai_client:
            self.logger.warning("  ⚠️ OpenAI not available, skipping LLM processing")
            return []
        
        edit_instructions = []
        
        for comment in comments:
            try:
                instruction = await self._process_single_comment(
                    comment,
                    doc_tree,
                    country_name
                )
                if instruction:
                    edit_instructions.append(instruction)
            except Exception as e:
                self.logger.warning(f"  ⚠️ Error processing comment {comment.comment_id}: {e}")
        
        return edit_instructions
    
    async def _process_single_comment(
        self,
        comment: ParsedComment,
        doc_tree: DocumentTree,
        country_name: str
    ) -> Optional[EditInstruction]:
        """
        Process a single comment and generate an edit instruction.
        Queries both RAG and learning context for enhanced prompts.
        """
        section_context = self.section_parser.get_section_context(comment, doc_tree)
        
        rag_requirements = self._query_rag_for_section(
            section_title=comment.section_title or "",
            linked_text=comment.linked_text or ""
        )
        
        if rag_requirements:
            self.logger.info(f"    ✓ Found {len(rag_requirements)} RAG requirements for section")
        
        learning_context = self._query_learning_context(
            section_title=comment.section_title or "",
            text=comment.linked_text or ""
        )
        
        if learning_context:
            self.logger.info(f"    ✓ Found {len(learning_context)} past corrections for context")
        
        prompt = self._build_edit_prompt(
            comment,
            section_context,
            rag_requirements,
            learning_context,
            country_name
        )
        
        original_text = comment.linked_text.strip() if comment.linked_text else ""
        
        try:
            response = self.openai_client.chat.completions.create(
                model=self.deployment_name,
                messages=[
                    {
                        "role": "system",
                        "content": self._get_system_prompt(country_name)
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                temperature=0.1,
                response_format={"type": "json_object"}
            )
            
            result = json.loads(response.choices[0].message.content)
            
            if result.get("action") == "COMMENT_ONLY":
                return EditInstruction(
                    comment_id=comment.comment_id,
                    action="COMMENT_ONLY",
                    original_text=original_text,
                    new_text="",
                    section_id=comment.section_id,
                    confidence=0.0,
                    reasoning="Could not find relevant information in knowledge base. Please review manually.",
                    rag_ids_used=[],
                    rag_sources=[]
                )
            
            if result.get("action") == "CLARIFY":
                return EditInstruction(
                    comment_id=comment.comment_id,
                    action="CLARIFY",
                    original_text=original_text,
                    new_text="",
                    section_id=comment.section_id,
                    confidence=result.get("confidence", 0.8),
                    reasoning=result.get("reasoning", ""),
                    rag_ids_used=result.get("rag_ids_used", []),
                    rag_sources=rag_requirements
                )
            
            if result.get("action") == "NO_ACTION":
                return None
            
            return EditInstruction(
                comment_id=comment.comment_id,
                action=result.get("action", "REPLACE"),
                original_text=original_text,
                new_text=result.get("new_text", ""),
                section_id=comment.section_id,
                confidence=result.get("confidence", 0.8),
                reasoning=result.get("reasoning", ""),
                rag_ids_used=result.get("rag_ids_used", []),
                rag_sources=rag_requirements
            )
            
        except Exception as e:
            self.logger.error(f"    ⚠️ LLM error for comment {comment.comment_id}: {e}")
            return None
    
    def _get_system_prompt(self, country_name: str) -> str:
        """Get system prompt for edit generation with country context."""
        country_upper = country_name.upper()
        
        return f"""You are an expert ICF (Informed Consent Form) editor for clinical trials.
You are editing a {country_upper}-specific ICF document based on client review comments.

CRITICAL RULES:
1. Analyze the client's comment and determine what change they want
2. Use the provided REGULATORY REQUIREMENTS to ensure compliance
3. Learn from PAST CORRECTIONS to apply consistent editing patterns
4. Determine the appropriate action: REPLACE, INSERT, DELETE, CLARIFY, or NO_ACTION
5. Generate ONLY the new text - the original text will be taken from the comment's linked text
6. Maintain {country_upper} regulatory compliance

WHEN CLIENT ASKS TO CHECK/CLARIFY/VERIFY:
- If the comment asks to "check", "clarify", "verify", or "confirm" the content
- Return action="CLARIFY" with reasoning that explains whether the content is correct
- Cite the specific RAG requirement IDs that support your conclusion
- The system will add a comment with your clarification and the source reference

WHEN NO KNOWLEDGE BASE INFO AVAILABLE:
- If no regulatory requirements are provided OR none are relevant to the client's request
- Return action="COMMENT_ONLY" with reasoning explaining info was not found
- The system will add a comment asking for manual review

MANDATORY TEXT REPLACEMENTS:
- Always replace "your country" with "the {country_upper}" throughout the document
- Always replace "Your country" with "The {country_upper}" (maintain capitalization)
- Apply these replacements whenever generating new_text

ACTIONS:
- REPLACE: Replace the linked text with new text
- INSERT: Add new text after the linked text  
- DELETE: Remove the linked text entirely
- NO_ACTION: No change needed (comment is informational)
- COMMENT_ONLY: Cannot find relevant info in knowledge base - add review comment
- CLARIFY: Client asked to check/verify - respond with clarification citing RAG sources

OUTPUT FORMAT (JSON):
{{
"action": "REPLACE" | "INSERT" | "DELETE" | "NO_ACTION" | "COMMENT_ONLY" | "CLARIFY",
"new_text": "the new/replacement text (empty for DELETE/CLARIFY/COMMENT_ONLY)",
"confidence": 0.0-1.0,
"reasoning": "brief explanation citing requirement IDs if used",
"rag_ids_used": ["RAG-001", "RAG-002"]
}}

IMPORTANT: Do NOT include original_text in your response - it will be taken from the comment's linked text."""
    
    def _build_edit_prompt(
        self,
        comment: ParsedComment,
        section_context: str,
        rag_requirements: List[Dict],
        learning_context: List[Dict],
        country_name: str
    ) -> str:
        """Build prompt for edit generation with RAG and learning context."""
        
        rag_context = ""
        if rag_requirements:
            rag_context = "\n\nREGULATORY REQUIREMENTS FROM KNOWLEDGE BASE:\n"
            for req in rag_requirements:
                source = req.get('source_file', 'Customization Plan')
                topic = req.get('topic', '')
                rag_context += f"[{req['rag_id']}] - {topic}\n  (Source: {source})\n  Content: {req['text'][:300]}...\n"
        else:
            rag_context = "\n\n(No specific regulatory requirements found for this section)\n"
        
        learning_prompt = ""
        if learning_context and self.learning_artifacts:
            learning_prompt = self.learning_artifacts.build_learning_context_prompt(learning_context)
        
        return f"""COUNTRY: {country_name.upper()}

CLIENT COMMENT:
Author: {comment.author}
Comment Text: "{comment.text}"

LINKED TEXT (the exact text the comment is attached to - this will be used as original_text):
"{comment.linked_text}"

SECTION CONTEXT:
Section: {comment.section_title or 'Unknown'}
---
{section_context}
---
{rag_context}
{learning_prompt}

Based on the client's comment, generate an edit instruction.

The LINKED TEXT above will be used as the original_text for finding/replacing.
You only need to provide the new_text and action type.

If the comment requires adding or modifying content, use the regulatory requirements 
to ensure the new text is compliant. Include the RAG IDs used in your response.

If past corrections are available, apply similar patterns for consistency.

If the comment is just informational or requires no change, use NO_ACTION."""
    
    def _apply_edits(
        self,
        input_path: str,
        output_path: str,
        edit_instructions: List[EditInstruction]
    ) -> List[str]:
        """
        Apply edit instructions using OpenXML to preserve comments/track changes.
        """
        if not edit_instructions:
            import shutil
            shutil.copy(input_path, output_path)
            self.logger.info("  ℹ️ No edits to apply")
            return []
        
        edits_as_dicts = [
            {
                'action': inst.action,
                'original_text': inst.original_text,
                'new_text': inst.new_text,
                'comment_id': inst.comment_id,
                'section_id': inst.section_id,
                'reasoning': inst.reasoning,
                'rag_ids_used': inst.rag_ids_used,
                'rag_sources': getattr(inst, 'rag_sources', [])
            }
            for inst in edit_instructions
            if inst.action != "NO_ACTION"
        ]
        
        success, edits_applied, modified_sections = self.openxml_editor.apply_edits_preserving_changes(
            input_path=input_path,
            output_path=output_path,
            edit_instructions=edits_as_dicts
        )
        
        if success:
            self.logger.info(f"  ✓ Applied {edits_applied}/{len(edits_as_dicts)} edits (preserving client feedback)")
            track_event("SectionModified", {
                "edits_applied": str(edits_applied),
                "total_edits": str(len(edits_as_dicts)),
                "modified_sections": str(len(modified_sections))
            })
        else:
            self.logger.warning(f"  ⚠️ OpenXML editing failed, copying original")
            import shutil
            shutil.copy(input_path, output_path)
        
        return modified_sections

    def _upload_json_blob(self, blob_path: str, payload: Dict[str, Any]) -> Optional[str]:
        """Upload a JSON payload to Azure Blob Storage and return the blob URL."""
        try:
            from azure.storage.blob import BlobServiceClient, ContentSettings

            conn_str = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
            container_name = os.getenv("AZURE_STORAGE_CONTAINER_NAME", "icf-country-dev")
            if not conn_str:
                return None

            blob_service = BlobServiceClient.from_connection_string(conn_str)
            blob_client = blob_service.get_blob_client(container=container_name, blob=blob_path)
            json_content = json.dumps(payload, indent=2, default=str)
            blob_client.upload_blob(
                json_content,
                overwrite=True,
                content_settings=ContentSettings(content_type="application/json"),
            )
            return blob_client.url
        except Exception:
            return None

    def _load_change_budget_eval(self, icf_case_id: str, planned_version_no: int) -> Optional[Dict[str, Any]]:
        """Load Change Budget evaluation JSON from blob storage (if present)."""
        try:
            from azure.storage.blob import BlobServiceClient

            conn_str = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
            container_name = os.getenv("AZURE_STORAGE_CONTAINER_NAME", "icf-country-dev")
            if not conn_str:
                return None

            blob_path = f"cases/{icf_case_id}/artifacts/change_budget_eval_v{planned_version_no}.json"
            blob_service = BlobServiceClient.from_connection_string(conn_str)
            blob_client = blob_service.get_blob_client(container=container_name, blob=blob_path)
            data = blob_client.download_blob().readall()
            return json.loads(data)
        except Exception:
            return None
    
    def _create_error_callback(
        self,
        request: RegenerateRequest,
        error_message: str
    ) -> RegenerateCallback:
        """Create an error callback response."""
        self.logger.error(f"\n❌ ERROR: {error_message}")
        
        icf_case_id = str(getattr(request, "icf_case_id", "") or "")
        return RegenerateCallback(
            status=0,
            success=False,
            icfDoc_id=request.document_id,
            icf_case_id=icf_case_id,
            error=error_message,
            metadata=RegenerateCallbackMetadata(
                country=request.country_name,
                countryid=request.countryid
            ),
            can_publish=False,
            publishing_blocked_reasons=["Processing failed"],
            audit_events=self.audit_agent.get_events() if self.audit_agent else []
        )
    
    def get_comment_summary(self, blob_url: str) -> Dict:
        """
        Get a summary of comments in a reviewed document.
        """
        temp_dir = tempfile.mkdtemp(prefix="comment_preview_")
        local_path = os.path.join(temp_dir, "preview.docx")
        
        try:
            success, error = self.version_manager.download_reviewed_document(
                blob_url,
                local_path
            )
            
            if not success:
                return {"error": error}
            
            return self.comment_extractor.get_comment_summary(local_path)
            
        finally:
            self.version_manager.cleanup_temp_files(temp_dir)