"""
Generator Knowledge Store for Multi-Country ICF Customization.
Uses Azure AI Search with automatic change detection on startup.
Supports both country-specific index and Global ICF sections index.
"""

import os
from typing import List, Dict, Optional
from dotenv import load_dotenv
from utils import RetryHandler
from azure.search.documents import SearchClient
from azure.search.documents.models import VectorizedQuery
from azure.core.credentials import AzureKeyCredential
from openai import AzureOpenAI
from services.client_manager import client_manager

load_dotenv()


class GeneratorKnowledgeStore:
    """
    Azure AI Search RAG for Multi-Country ICF Customization.
    Each country has its own index: icf-index-{country}
    Global ICF sections stored in: icf-sections-index
    Uses doctypeid for filtering: 3 = Customization Plan (CP)
    """
    
    # Document Type IDs (matches database)
    DOCTYPE_CUSTOMIZATION = 3  # CP - Customization Plan (Generator Agent uses this)
    
    # Index names
    SECTIONS_INDEX_NAME = "icf-sections-index"  # Global ICF sections
    
    def __init__(self, country: str, knowledge_base_path: str = None, auto_sync: bool = True):
        """
        Initialize RAG store for a specific country.
        
        Args:
            country: Country code (e.g., 'usa', 'canada', 'argentina')
            knowledge_base_path: Kept for backward compatibility (ignored)
            auto_sync: If True, check for changes and sync on startup
        """
        self.country = country.lower().replace(' ', '-').replace('_', '-')
        self.index_name = f"icf-index-{self.country}"
        self.knowledge_base_path = knowledge_base_path  # kept for compatibility
        
        # Use shared client manager for connection pooling
        self.openai = client_manager.openai_client
        self.embedding_model = os.getenv("EMBEDDINGS_MODEL_DEPLOYMENT")
        
        # Country-specific index (Customization Plans, etc.) - use shared client
        self.search_client = client_manager.get_search_client(self.index_name)
        
        # Global ICF sections index
        self.sections_client = None
        self._init_sections_client()
        
        if auto_sync:
            pass  # Placeholder for future implementation of auto-sync logic

        print(f"✅ GeneratorKnowledgeStore initialized for {country.upper()} (Index: {self.index_name})")
    
    def _init_sections_client(self):
        """Initialize search client for Global ICF sections index."""
        try:
            # Use shared client manager for connection pooling
            self.sections_client = client_manager.get_search_client(self.SECTIONS_INDEX_NAME)
            print(f"  ✓ Connected to {self.SECTIONS_INDEX_NAME}")
        except Exception as e:
            print(f"  ⚠️ Sections index not available: {e}")
    
    def _embed(self, text: str) -> List[float]:
        """Generate embedding for text with caching."""
        from utils import cache
        
        # Check cache first
        cached = cache.get_embedding(text)
        if cached:
            return cached
        
        try:
            resp = RetryHandler.retry_call(
                self.openai.embeddings.create,
                kwargs={"model": self.embedding_model, "input": text[:8000]},
                max_retries=3
            )
            embedding = resp.data[0].embedding
            cache.set_embedding(text, embedding)
            return embedding
        except Exception as e:
            print(f"⚠️ Embedding error: {e}")
            return [0.0] * 1536
    
    def query(self, query_text: str, top_k: int = 5, doctypeid: Optional[int] = None, filter_expr: str = None) -> List[Dict]:
        """
        Query using hybrid search (BM25 + vector) with result caching.
        
        Args:
            query_text: The search query
            top_k: Number of results to return
            doctypeid: Filter by document type ID (3=CP, 4=RC, etc.). Default: 3 (Customization Plan)
            filter_expr: Optional additional OData filter expression
        """
        from utils import cache
        
        # Use doctypeid for filtering (default to Customization Plan)
        if doctypeid is None:
            doctypeid = self.DOCTYPE_CUSTOMIZATION
        
        # Create composite query string for cache key (includes all parameters)
        composite_query = f"{query_text}|top_k:{top_k}|doctypeid:{doctypeid}|filter:{filter_expr or ''}"
        
        # Check cache first (30 minute TTL)
        cached_results = cache.get_rag_query(composite_query, self.country)
        if cached_results is not None:
            return cached_results
        
        try:
            vector_query = VectorizedQuery(
                vector=self._embed(query_text),
                k_nearest_neighbors=top_k,
                fields="contentVector"
            )
            
            base_filter = f"doctypeid eq {doctypeid}"
            if filter_expr:
                base_filter = f"({base_filter}) and ({filter_expr})"
            
            results = self.search_client.search(
                search_text=query_text,
                vector_queries=[vector_query],
                top=top_k,
                filter=base_filter,
                select=["id", "content", "topic", "section_type", "is_required", "source_file", "doctypeid", "countryid"]
            )
            
            query_results = [{
                "id": r.get("id", ""),
                "content": r.get("content", ""),
                "topic": r.get("topic", ""),
                "section_type": r.get("section_type", ""),
                "is_required": r.get("is_required", False),
                "source_file": r.get("source_file", ""),
                "doctypeid": r.get("doctypeid", 0),
                "countryid": r.get("countryid", 0),
                "score": r.get("@search.score", 0.0)
            } for r in results]
            
            # Cache results (30 minutes TTL)
            cache.set_rag_query(composite_query, self.country, query_results, ttl=1800)
            
            return query_results
        except Exception as e:
            print(f"⚠️ Query error: {e}")
            return []
    
    def query_regulations(self, query_text: str, top_k: int = 10) -> List[Dict]:
        """Query customization requirements (for Generator Agent). Uses doctypeid=3."""
        return self.query(query_text, top_k=top_k, doctypeid=self.DOCTYPE_CUSTOMIZATION)
    
    def query_by_topic(self, topic: str, top_k: int = 10, doctypeid: Optional[int] = None) -> List[Dict]:
        """Query requirements by topic name."""
        if doctypeid is None:
            doctypeid = self.DOCTYPE_CUSTOMIZATION
        filter_expr = f"topic eq '{topic}'"
        return self.query(topic, top_k=top_k, doctypeid=doctypeid, filter_expr=filter_expr)
    
    # ==================== GLOBAL ICF SECTIONS ====================
    
    def get_global_icf_sections(self, document_id: str) -> List[Dict]:
        """
        Retrieve all indexed sections for a Global ICF document.

        Args:
            document_id: The document ID assigned by frontend

        Returns:
            List of section records ordered by section_order
        """
        if not self.sections_client:
            print("⚠️ Sections index not available")
            return []

        try:
            print(f"🔍 Querying sections for document_id: {document_id}")
            results = self.sections_client.search(
                search_text="*",
                filter=f"document_id eq '{document_id}'",
                order_by=["section_order asc"],
                top=1000,
                select=["id", "document_id", "section_id", "heading", "content", "page_number", "section_order", "level", "parent_section_id"]
            )

            sections = []
            for r in results:
                sections.append({
                    "id": r.get("id", ""),
                    "document_id": r.get("document_id", ""),
                    "section_id": r.get("section_id", ""),
                    "heading": r.get("heading", ""),
                    "content": r.get("content", ""),
                    "page_number": r.get("page_number", 0),
                    "section_order": r.get("section_order", 0),
                    "level": r.get("level", 1),
                    "parent_section_id": r.get("parent_section_id", "")
                })

            print(f"  ✓ Retrieved {len(sections)} sections for document {document_id}")
            return sections
        except Exception as e:
            print(f"⚠️ Error retrieving sections for document_id '{document_id}': {e}")
            return []
    
    def search_global_icf_sections(
        self,
        document_id: str,
        query_text: str,
        top_k: int = 5
    ) -> List[Dict]:
        """
        Semantic search within a specific Global ICF document's sections.
        
        Args:
            document_id: The document ID to search within
            query_text: Search query
            top_k: Number of results
            
        Returns:
            List of matching sections with scores
        """
        if not self.sections_client:
            print("⚠️ Sections index not available")
            return []
        
        try:
            vector_query = VectorizedQuery(
                vector=self._embed(query_text),
                k_nearest_neighbors=top_k,
                fields="embedding"
            )
            
            results = self.sections_client.search(
                search_text=query_text,
                vector_queries=[vector_query],
                filter=f"document_id eq '{document_id}'",
                top=top_k,
                select=["id", "document_id", "section_id", "heading", "content", "page_number", "section_order", "level"]
            )
            
            sections = []
            for r in results:
                sections.append({
                    "id": r.get("id", ""),
                    "document_id": r.get("document_id", ""),
                    "section_id": r.get("section_id", ""),
                    "heading": r.get("heading", ""),
                    "content": r.get("content", ""),
                    "page_number": r.get("page_number", 0),
                    "section_order": r.get("section_order", 0),
                    "level": r.get("level", 1),
                    "score": r.get("@search.score", 0.0)
                })
            
            return sections
        except Exception as e:
            print(f"⚠️ Section search error: {e}")
            return []
    
    def check_document_indexed(self, document_id: str) -> bool:
        """Check if a Global ICF document has been indexed."""
        if not self.sections_client:
            return False
        
        try:
            results = self.sections_client.search(
                search_text="*",
                filter=f"document_id eq '{document_id}'",
                top=1,
                include_total_count=True
            )
            count = results.get_count()
            return count is not None and count > 0
        except:
            return False
    
    # ==================== UTILITY METHODS ====================
    
    def get_document_count(self, doctypeid: Optional[int] = None) -> int:
        """Get count of documents in index."""
        try:
            filter_expr = f"doctypeid eq {doctypeid}" if doctypeid else None
            results = self.search_client.search("*", top=0, include_total_count=True, filter=filter_expr)
            return results.get_count() or 0
        except:
            return 0
    
    def get_all_requirements(self, doctypeid: Optional[int] = None) -> List[Dict]:
        """Get all indexed requirements of a specific type."""
        try:
            if doctypeid is None:
                doctypeid = self.DOCTYPE_CUSTOMIZATION
            results = self.search_client.search(
                "*", top=1000, filter=f"doctypeid eq {doctypeid}",
                select=["id", "content", "topic", "section_type", "is_required", "source_file", "doctypeid", "countryid"]
            )
            return [dict(r) for r in results]
        except:
            return []
    
    def force_reindex(self) -> Dict:
        """Force a full re-index from blob storage."""
        try:
            from services.indexer import MultiCountryIndexer
            indexer = MultiCountryIndexer()
            
            mapping = indexer.get_country_mapping()
            original_folder = mapping.get(self.country, self.country)
            
            result = indexer.index_country(original_folder, force=True)
            return result
        except Exception as e:
            return {"error": str(e)}
    
    def check_sync_status(self) -> Dict:
        """Check if knowledge base is in sync with blob storage."""
        try:
            doc_count = self.get_document_count()
            cp_count = self.get_document_count(doctypeid=self.DOCTYPE_CUSTOMIZATION)
            
            # Also check sections index
            sections_count = 0
            if self.sections_client:
                try:
                    results = self.sections_client.search("*", top=0, include_total_count=True)
                    sections_count = results.get_count() or 0
                except:
                    pass
            
            return {
                "country": self.country,
                "index_name": self.index_name,
                "total_documents": doc_count,
                "customization_plan_docs": cp_count,
                "global_icf_sections": sections_count,
                "is_ready": cp_count > 0
            }
        except Exception as e:
            return {"error": str(e)}