"""
Audit Agent - Tracks and emits audit events for workflow progression.
Provides append-only audit trail for learning and regeneration workflows.
"""

from typing import List, Dict, Optional, Any
from datetime import datetime
from dataclasses import dataclass, field, asdict
from constants.enums import AuditEventType


@dataclass
class AuditEvent:
    """
    Single audit event with correlation and metrics.
    Append-only, immutable after creation.
    """
    event_type: str  # AuditEventType value
    timestamp: str  # ISO format
    job_id: Optional[str] = None
    icf_case_id: Optional[str] = None
    iteration_id: Optional[int] = None
    version_no: Optional[int] = None
    correlation_id: Optional[str] = None
    
    # Metrics snapshot
    metrics: Dict[str, Any] = field(default_factory=dict)
    
    # Additional context
    context: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return asdict(self)


class AuditAgent:
    """
    Collects audit events during workflow execution.
    Events are append-only and emitted via callback payload.
    """
    
    def __init__(
        self,
        job_id: Optional[str] = None,
        icf_case_id: Optional[str] = None,
        iteration_id: Optional[int] = None,
        correlation_id: Optional[str] = None
    ):
        """
        Initialize audit agent for a workflow execution.
        
        Args:
            job_id: Unique job identifier
            icf_case_id: ICF case identifier
            iteration_id: Feedback iteration number
            correlation_id: Correlation ID for tracing
        """
        self.job_id = job_id
        self.icf_case_id = icf_case_id
        self.iteration_id = iteration_id
        self.correlation_id = correlation_id
        self.events: List[AuditEvent] = []
    
    def emit_event(
        self,
        event_type: AuditEventType,
        version_no: Optional[int] = None,
        metrics: Optional[Dict[str, Any]] = None,
        context: Optional[Dict[str, Any]] = None
    ) -> AuditEvent:
        """
        Emit an audit event.
        
        Args:
            event_type: Type of audit event
            version_no: Document version number (if applicable)
            metrics: Metrics snapshot (diff%, evidence stats, counts, etc.)
            context: Additional context (error messages, gate details, etc.)
            
        Returns:
            Created audit event
        """
        event = AuditEvent(
            event_type=event_type.value,
            timestamp=datetime.utcnow().isoformat() + "Z",
            job_id=self.job_id,
            icf_case_id=self.icf_case_id,
            iteration_id=self.iteration_id,
            version_no=version_no,
            correlation_id=self.correlation_id,
            metrics=metrics or {},
            context=context or {}
        )
        
        self.events.append(event)
        return event
    
    def get_events(self) -> List[Dict[str, Any]]:
        """
        Get all emitted events as dictionaries for callback payload.
        
        Returns:
            List of event dictionaries
        """
        return [event.to_dict() for event in self.events]
    
    def clear(self):
        """Clear all events (use with caution - events should be append-only)."""
        self.events.clear()
    
    def event_count(self) -> int:
        """Get number of emitted events."""
        return len(self.events)
    
    def has_started_event(self) -> bool:
        """Check if workflow has a STARTED event."""
        started_types = {
            AuditEventType.LEARNING_STARTED.value,
            AuditEventType.REGEN_STARTED.value
        }
        return any(e.event_type in started_types for e in self.events)
    
    def has_terminal_event(self) -> bool:
        """Check if workflow has a terminal (COMPLETED/FAILED) event."""
        terminal_types = {
            AuditEventType.LEARNING_COMPLETED.value,
            AuditEventType.LEARNING_FAILED.value,
            AuditEventType.REGEN_COMPLETED.value,
            AuditEventType.REGEN_FAILED.value
        }
        return any(e.event_type in terminal_types for e in self.events)
    
    def generate_audit_snapshot(self, workflow_type: Optional[str] = None) -> Dict[str, Any]:
        """
        Generate structured audit snapshot for blob storage and LLM analysis.
        
        Args:
            workflow_type: "regeneration" or "learning" (auto-detected if not provided)
            
        Returns:
            Structured audit snapshot with metadata, events, and summary
        """
        if not self.events:
            return {}
        
        # Auto-detect workflow type if not provided
        if not workflow_type:
            if any(e.event_type.startswith("REGEN_") for e in self.events):
                workflow_type = "regeneration"
            elif any(e.event_type.startswith("LEARNING_") for e in self.events):
                workflow_type = "learning"
            else:
                workflow_type = "unknown"
        
        # Determine workflow outcome
        final_event = self.events[-1] if self.events else None
        failed_event_types = {
            AuditEventType.LEARNING_FAILED.value,
            AuditEventType.REGEN_FAILED.value
        }
        status = "failed" if (final_event and final_event.event_type in failed_event_types) else "completed"
        
        # Calculate total duration
        if len(self.events) >= 2:
            start_time = datetime.fromisoformat(self.events[0].timestamp.replace('Z', '+00:00'))
            end_time = datetime.fromisoformat(self.events[-1].timestamp.replace('Z', '+00:00'))
            total_duration = (end_time - start_time).total_seconds()
        else:
            total_duration = 0.0
        
        # Analyze gates
        gate_events = {
            "EVIDENCE_GATE": AuditEventType.EVIDENCE_GATE_FAILED.value,
            "BUDGET_GATE": AuditEventType.BUDGET_GATE_TRIMMED.value,
            "QA_GATE": AuditEventType.QA_FAILED.value
        }
        
        gates_encountered = []
        gates_failed = []
        gates_passed = []
        critical_metrics = {}
        
        for event in self.events:
            if event.event_type == AuditEventType.EVIDENCE_GATE_FAILED.value:
                gates_encountered.append("EVIDENCE_GATE")
                gates_failed.append("EVIDENCE_GATE")
                if "evidence_gaps" in event.metrics:
                    critical_metrics["evidence_gaps"] = event.metrics["evidence_gaps"]
            elif event.event_type == AuditEventType.QA_FAILED.value:
                gates_encountered.append("QA_GATE")
                gates_failed.append("QA_GATE")
                if "qa_issues" in event.metrics:
                    critical_metrics["qa_issues"] = event.metrics["qa_issues"]
            elif event.event_type == AuditEventType.BUDGET_GATE_TRIMMED.value:
                gates_encountered.append("BUDGET_GATE")
                gates_failed.append("BUDGET_GATE")
                if "sections_trimmed" in event.metrics:
                    critical_metrics["sections_trimmed"] = event.metrics["sections_trimmed"]
        
        # Gates passed = encountered gates that aren't in failed list
        all_gates = ["EVIDENCE_GATE", "QA_GATE", "BUDGET_GATE"]
        for gate in all_gates:
            if gate in gates_encountered and gate not in gates_failed:
                gates_passed.append(gate)
        
        # Set defaults for missing critical metrics
        critical_metrics.setdefault("evidence_gaps", 0)
        critical_metrics.setdefault("qa_issues", 0)
        critical_metrics.setdefault("sections_trimmed", 0)
        
        # Get version number from events (use last event's version_no)
        version_no = final_event.version_no if final_event else None
        
        # Build snapshot structure
        snapshot = {
            "workflow_metadata": {
                "workflow_type": workflow_type,
                "icf_case_id": self.icf_case_id,
                "job_id": self.job_id,
                "iteration_id": self.iteration_id,
                "version_no": version_no,
                "correlation_id": self.correlation_id,
                "uploaded_at": datetime.utcnow().isoformat() + "Z"
            },
            "workflow_outcome": {
                "status": status,
                "total_duration_seconds": round(total_duration, 2),
                "final_event": final_event.event_type if final_event else None
            },
            "events": self.get_events(),
            "summary": {
                "total_events": len(self.events),
                "gates_encountered": list(set(gates_encountered)),
                "gates_failed": list(set(gates_failed)),
                "gates_passed": list(set(gates_passed)),
                "critical_metrics": critical_metrics
            }
        }
        
        return snapshot
