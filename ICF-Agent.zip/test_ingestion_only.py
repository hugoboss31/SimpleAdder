"""
Simplified test that demonstrates ingestion without AI Search dependency.

This test shows that the core ingestion components work correctly.
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))

from agents import IngestionService
from schemas.icf_schemas import ICFSectionTree, CustomizationPlan


def test_ingestion():
    """Test ingestion components without AI Search."""
    
    print("="*80)
    print("ICF Ingestion Test (No AI Search Required)")
    print("="*80)
    print()
    
    # Check for test data
    test_data_dir = Path("test_data")
    global_icf_path = test_data_dir / "global_icf.docx"
    excel_plan_path = test_data_dir / "usa_customization_plan.xlsx"
    
    if not global_icf_path.exists() or not excel_plan_path.exists():
        print("[ERROR] Test data not found. Run create_test_data.py first.")
        return 1
    
    try:
        # Initialize ingestion service
        ingestion_service = IngestionService()
        
        # Test 1: Parse Global ICF
        print("[TEST 1] Parsing Global ICF into section tree...")
        section_tree = ingestion_service.ingest_global_icf(
            docx_path=str(global_icf_path),
            document_id="test_global_icf_001"
        )
        
        assert isinstance(section_tree, ICFSectionTree), "Should return ICFSectionTree"
        assert section_tree.total_sections > 0, "Should have sections"
        assert section_tree.total_paragraphs > 0, "Should have paragraphs"
        
        print(f"[OK] Extracted {section_tree.total_sections} sections")
        print(f"[OK] Extracted {section_tree.total_paragraphs} paragraphs")
        print(f"[OK] Document: {section_tree.document_name}")
        print(f"[OK] Pages: {section_tree.page_count}")
        
        # Show section structure
        print("\nSection Structure:")
        for section in section_tree.sections[:3]:
            print(f"  - {section.section_id}: {section.title or '(no title)'} (level {section.level})")
            if section.children:
                for child in section.children[:2]:
                    print(f"    - {child.section_id}: {child.title or '(no title)'} (level {child.level})")
        
        # Test 2: Parse Excel Plan
        print("\n[TEST 2] Parsing Excel customization plan...")
        customization_plan = ingestion_service.ingest_customization_plan(
            excel_path=str(excel_plan_path),
            country="USA",
            plan_id="test_usa_plan_001"
        )
        
        assert isinstance(customization_plan, CustomizationPlan), "Should return CustomizationPlan"
        assert len(customization_plan.items) > 0, "Should have items"
        
        print(f"[OK] Parsed {len(customization_plan.items)} customization items")
        print(f"[OK] Country: {customization_plan.country}")
        print(f"[OK] Plan ID: {customization_plan.plan_id}")
        
        # Show items
        print("\nCustomization Items:")
        for item in customization_plan.items:
            print(f"  - {item.item_id}: {item.topic}")
            print(f"    Type: {item.requirement_type.value}")
            print(f"    Applies To: {item.applies_to or 'unknown'}")
            print(f"    Importance: {item.importance or 'not set'}")
            if item.synonyms:
                print(f"    Synonyms: {', '.join(item.synonyms[:3])}")
            print()
        
        # Test 3: Validate data structures
        print("[TEST 3] Validating data structures...")
        
        # Validate section tree
        assert section_tree.document_id == "test_global_icf_001"
        assert section_tree.sections is not None
        assert isinstance(section_tree.sections, list)
        
        # Validate customization plan
        assert customization_plan.country == "USA"
        assert customization_plan.plan_id == "test_usa_plan_001"
        assert all(isinstance(item, CustomizationPlanItem) for item in customization_plan.items)
        
        print("[OK] All data structures validated")
        
        # Summary
        print("\n" + "="*80)
        print("TEST SUMMARY")
        print("="*80)
        print(f"[OK] Global ICF: {section_tree.total_sections} sections, {section_tree.total_paragraphs} paragraphs")
        print(f"[OK] Customization Plan: {len(customization_plan.items)} items")
        print(f"[OK] All ingestion components working correctly!")
        print()
        
        return 0
        
    except Exception as e:
        print(f"\n[ERROR] Test failed: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    exit_code = test_ingestion()
    sys.exit(exit_code)

