"""
Change Budget Gate - Pre-generation guardrail (Story 827607).
Validates Regeneration Change Plan against diff % and section limits.
Drops lowest-priority changes when over budget.
"""

import os
import json
import urllib.request
from typing import Dict, Any, List, Optional, Tuple

from services.app_insights import get_logger, track_event, track_exception


def _get_budget_config() -> Dict[str, Any]:
    max_diff = os.getenv("MAX_DIFF_PERCENT", "5")
    max_sections = os.getenv("MAX_SECTIONS_CHANGED", "10")
    hard_fail = os.getenv("HARD_FAIL_ON_EXCEED", "true").lower() in ("true", "1", "yes")
    return {
        "maxDiffPercent": float(max_diff),
        "maxSectionsChanged": int(max_sections),
        "hardFailOnExceed": hard_fail,
    }


class ChangeBudgetGate:
    """
    Enforces strict change budgets before document generation.
    Non-bypassable when hardFailOnExceed is true.
    """

    def __init__(self):
        self.logger = get_logger("change_budget_gate")

    def _load_plan(self, change_plan_blob_url: str) -> Optional[Dict[str, Any]]:
        """Download and parse change plan JSON from Blob URL."""
        try:
            with urllib.request.urlopen(change_plan_blob_url, timeout=30) as resp:
                data = resp.read().decode()
                return json.loads(data)
        except Exception as e:
            self.logger.error(f"Failed to load change plan: {e}")
            return None

    def evaluate(
        self,
        plan: Dict[str, Any],
        base_word_count: int = 5000,
    ) -> Tuple[Dict[str, Any], bool]:
        """
        Evaluate change plan against budget.
        Returns (result_dict, passed: bool).
        """
        budget = _get_budget_config()
        planned = plan.get("plannedChanges", [])
        max_diff = budget["maxDiffPercent"]
        max_sections = budget["maxSectionsChanged"]

        def _metrics(changes: List[Dict]) -> Tuple[float, int]:
            total_words = len(changes) * 50  # rough estimate
            diff_pct = (total_words / max(base_word_count, 1)) * 100
            sections = len(set(c.get("sectionKey", "") for c in changes))
            return min(diff_pct, 100.0), sections

        diff_pct, sec_cnt = _metrics(planned)
        failure_reasons: List[str] = []

        if diff_pct > max_diff:
            failure_reasons.append("DIFF_PERCENT_EXCEEDED")
        if sec_cnt > max_sections:
            failure_reasons.append("SECTION_LIMIT_EXCEEDED")

        if not failure_reasons:
            return {
                "icfCaseId": plan.get("icfCaseId"),
                "baseVersionNo": plan.get("baseVersionNo"),
                "plannedVersionNo": plan.get("plannedVersionNo"),
                "budget": {"maxDiffPercent": max_diff, "maxSectionsChanged": max_sections},
                "measured": {"estimatedDiffPercent": round(diff_pct, 2), "sectionsChanged": sec_cnt},
                "status": "PASSED",
                "failureReasons": [],
            }, True

        # Try trimming: drop lowest priority
        sorted_changes = sorted(planned, key=lambda c: (c.get("priority", 5), c.get("changeId", "")))
        kept = list(sorted_changes)
        while kept:
            d, s = _metrics(kept)
            if d <= max_diff and s <= max_sections:
                break
            kept.pop()

        d_final, s_final = _metrics(kept)
        if d_final <= max_diff and s_final <= max_sections:
            return {
                "icfCaseId": plan.get("icfCaseId"),
                "baseVersionNo": plan.get("baseVersionNo"),
                "plannedVersionNo": plan.get("plannedVersionNo"),
                "budget": {"maxDiffPercent": max_diff, "maxSectionsChanged": max_sections},
                "measured": {"estimatedDiffPercent": round(d_final, 2), "sectionsChanged": s_final},
                "status": "PASSED",
                "failureReasons": [],
                "trimmed": True,
                "originalCount": len(planned),
                "keptCount": len(kept),
            }, True

        if budget["hardFailOnExceed"]:
            return {
                "icfCaseId": plan.get("icfCaseId"),
                "baseVersionNo": plan.get("baseVersionNo"),
                "plannedVersionNo": plan.get("plannedVersionNo"),
                "budget": {"maxDiffPercent": max_diff, "maxSectionsChanged": max_sections},
                "measured": {"estimatedDiffPercent": round(diff_pct, 2), "sectionsChanged": sec_cnt},
                "status": "FAILED",
                "failureReasons": failure_reasons,
            }, False

        return {
            "icfCaseId": plan.get("icfCaseId"),
            "baseVersionNo": plan.get("baseVersionNo"),
            "plannedVersionNo": plan.get("plannedVersionNo"),
            "budget": {"maxDiffPercent": max_diff, "maxSectionsChanged": max_sections},
            "measured": {"estimatedDiffPercent": round(d_final, 2), "sectionsChanged": s_final},
            "status": "PASSED",
            "failureReasons": [],
            "trimmed": True,
        }, True

    def upload_eval(
        self,
        result: Dict[str, Any],
        icf_case_id: str,
        planned_version_no: int,
    ) -> Optional[str]:
        """Upload evaluation to Blob: cases/{icfCaseId}/artifacts/change_budget_eval_v{plannedVersionNo}.json"""
        try:
            from azure.storage.blob import BlobServiceClient, ContentSettings
        except ImportError:
            return None

        conn_str = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
        container = os.getenv("AZURE_STORAGE_CONTAINER_NAME", "icf-country-dev")
        if not conn_str:
            return None

        blob_path = f"cases/{icf_case_id}/artifacts/change_budget_eval_v{planned_version_no}.json"
        try:
            blob_service = BlobServiceClient.from_connection_string(conn_str)
            blob_client = blob_service.get_blob_client(container=container, blob=blob_path)
            blob_client.upload_blob(
                json.dumps(result, indent=2, default=str),
                overwrite=True,
                content_settings=ContentSettings(content_type="application/json"),
            )
            self.logger.info(f"  ✓ Uploaded budget eval: {blob_path}")
            return blob_client.url
        except Exception as e:
            self.logger.error(f"Budget eval upload failed: {e}")
            return None
