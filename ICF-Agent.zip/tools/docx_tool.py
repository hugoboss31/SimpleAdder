"""DOCX tool for applying tracked changes with OpenXML."""

from datetime import datetime
from typing import List, Dict, Any
import shutil
from docx import Document
from docx.oxml import OxmlElement
from docx.oxml.ns import qn


class DocxTrackerTool:
    """Tool for applying tracked changes to DOCX documents."""
    
    def __init__(self, author: str = "ICF Generator"):
        self.author = author
        self.change_counter = 0
    
    def apply_tracked_changes(
        self,
        input_path: str,
        output_path: str,
        changes: List[Dict[str, Any]]
    ) -> str:
        """
        Apply tracked changes to DOCX document using OpenXML markup.
        
        Args:
            input_path: Path to input DOCX
            output_path: Path to save output DOCX
            changes: List of change dictionaries with location, type, old_text, new_text, etc.
            
        Returns:
            Path to output file
        """
        shutil.copy(input_path, output_path)
        doc = Document(output_path)
        
        print(f"\nApplying {len(changes)} tracked changes to document...")
        
        for idx, change in enumerate(changes, 1):
            print(f"  Processing change {idx}/{len(changes)}: {change.get('change_type', 'unknown')} at {change.get('location', 'unknown')}")
            try:
                self._apply_change_to_document(doc, change)
            except Exception as e:
                print(f"    ⚠️  Warning: Could not apply change {idx}: {e}")
        
        doc.save(output_path)
        print(f"✅ Document saved with tracked changes")
        return output_path
    
    def _apply_change_to_document(self, doc: Document, change: Dict[str, Any]):
        """Apply a single tracked change to the document by finding and modifying existing content."""
        change_type = change.get('change_type', 'insertion')
        location = change.get('location', '')
        old_text = change.get('old_text', '').strip()
        new_text = change.get('new_text', '').strip()
        after_text = change.get('after_text', '').strip()
        
        target_paragraph = None
        insert_position = None
        
        print(f"    Searching for location: '{location}' or text: '{old_text[:50] if old_text else after_text[:50] if after_text else ''}'...")
        
        # Strategy 1: Find by old_text (most reliable for modifications/deletions)
        if old_text:
            for para in doc.paragraphs:
                para_text = para.text.strip()
                # Try exact match first
                if old_text in para_text:
                    target_paragraph = para
                    print(f"    ✓ Found exact text match in paragraph")
                    break
                # Try normalized match (ignoring extra spaces)
                normalized_old = ' '.join(old_text.split())
                normalized_para = ' '.join(para_text.split())
                if normalized_old in normalized_para:
                    target_paragraph = para
                    print(f"    ✓ Found normalized text match in paragraph")
                    break
        
        # Strategy 2: Find by "after text" for insertions
        if not target_paragraph and after_text:
            for para in doc.paragraphs:
                para_text = para.text.strip()
                if after_text in para_text:
                    target_paragraph = para
                    insert_position = para_text.find(after_text) + len(after_text)
                    print(f"    ✓ Found after-text anchor in paragraph")
                    break
        
        # Strategy 3: Find by section/location header
        if not target_paragraph and location and location != 'Unknown':
            for para in doc.paragraphs:
                para_text = para.text.strip()
                # Look for section headers
                if location.lower() in para_text.lower() and len(para_text) < 200:
                    # Found section header, use next paragraph
                    para_idx = doc.paragraphs.index(para)
                    if para_idx + 1 < len(doc.paragraphs):
                        target_paragraph = doc.paragraphs[para_idx + 1]
                        print(f"    ✓ Found section header, using next paragraph")
                        break
        
        # If still not found, create new paragraph at end
        if not target_paragraph:
            print(f"    ⚠ Text not found, creating new paragraph")
            target_paragraph = doc.add_paragraph()
            run = target_paragraph.add_run(f"\n[Change for: {location}]\n" if location != 'Unknown' else "\n[New Change]\n")
            run.bold = True
        
        # Apply the tracked change
        if change_type == 'insertion':
            self._apply_insertion(target_paragraph, new_text, after_text, insert_position, change)
        
        elif change_type == 'deletion':
            self._apply_deletion(target_paragraph, old_text, change)
        
        elif change_type == 'modification':
            self._apply_modification(target_paragraph, old_text, new_text, change)
        
        # Add comment with regulatory justification
        comment_text = self._format_comment(change)
        if comment_text:
            self._add_comment(target_paragraph, comment_text)
    
    def _apply_insertion(self, paragraph, new_text: str, after_text: str, position: int, change: Dict):
        """Apply an insertion with tracked change markup."""
        if not new_text:
            return
        
        # Add space before insertion if needed
        if paragraph.text and not paragraph.text.endswith(' '):
            paragraph.add_run(' ')
        
        # Add the new text with insertion markup
        run = paragraph.add_run(new_text)
        self._add_insertion_markup(run, change)
    
    def _apply_deletion(self, paragraph, old_text: str, change: Dict):
        """Apply a deletion with tracked change markup."""
        if not old_text:
            return
        
        # Find and mark text for deletion
        para_text = paragraph.text
        if old_text in para_text:
            # Clear existing runs and rebuild with deletion
            paragraph.clear()
            
            # Split text around the deletion
            before, _, after = para_text.partition(old_text)
            
            if before:
                paragraph.add_run(before)
            
            # Add deleted text with deletion markup
            del_run = paragraph.add_run(old_text)
            self._add_deletion_markup(del_run, change)
            
            if after:
                paragraph.add_run(after)
        else:
            # Text not found, add deletion at end
            run = paragraph.add_run(old_text)
            self._add_deletion_markup(run, change)
    
    def _apply_modification(self, paragraph, old_text: str, new_text: str, change: Dict):
        """Apply a modification (delete old, insert new) with tracked change markup."""
        if not old_text and not new_text:
            return
        
        para_text = paragraph.text
        
        # Try exact match first
        if old_text and old_text in para_text:
            # Clear and rebuild paragraph with modification
            for run in paragraph.runs:
                run._element.getparent().remove(run._element)
            
            before, _, after = para_text.partition(old_text)
            
            if before:
                paragraph.add_run(before)
            
            # Mark old text as deleted
            del_run = paragraph.add_run(old_text)
            self._add_deletion_markup(del_run, change)
            
            # Add space between deletion and insertion
            paragraph.add_run(" ")
            
            # Mark new text as inserted
            ins_run = paragraph.add_run(new_text)
            self._add_insertion_markup(ins_run, change)
            
            if after:
                paragraph.add_run(after)
        else:
            # Try normalized match
            normalized_old = ' '.join(old_text.split())
            normalized_para = ' '.join(para_text.split())
            
            if normalized_old in normalized_para:
                # Find position in original text
                words_old = old_text.split()
                words_para = para_text.split()
                
                # Rebuild with tracked changes
                for run in paragraph.runs:
                    run._element.getparent().remove(run._element)
                
                # Try to find approximate position
                idx = normalized_para.find(normalized_old)
                if idx >= 0:
                    before_normalized = normalized_para[:idx]
                    after_normalized = normalized_para[idx + len(normalized_old):]
                    
                    if before_normalized:
                        paragraph.add_run(before_normalized + " ")
                    
                    del_run = paragraph.add_run(old_text)
                    self._add_deletion_markup(del_run, change)
                    
                    paragraph.add_run(" ")
                    
                    ins_run = paragraph.add_run(new_text)
                    self._add_insertion_markup(ins_run, change)
                    
                    if after_normalized:
                        paragraph.add_run(" " + after_normalized)
            else:
                # Text not found, append at end
                print(f"      ⚠ Could not find text to modify, appending tracked changes")
                paragraph.add_run(" ")
                
                if old_text:
                    del_run = paragraph.add_run(old_text)
                    self._add_deletion_markup(del_run, change)
                    paragraph.add_run(" ")
                
                if new_text:
                    ins_run = paragraph.add_run(new_text)
                    self._add_insertion_markup(ins_run, change)
    
    def _format_comment(self, change: Dict[str, Any]) -> str:
        """Format the comment text with regulatory information and QA validation."""
        parts = []
        
        # Change type and location
        change_type = change.get('change_type', 'change').upper()
        location = change.get('location', 'Unknown')
        parts.append(f"🔹 {change_type} at: {location}")
        parts.append("=" * 50)
        
        # Regulatory reference
        reg_ref = change.get('regulatory_reference', '')
        if reg_ref:
            parts.append(f"📋 Regulatory Reference:\n   {reg_ref}")
        
        # Justification
        justification = change.get('justification', '')
        if justification:
            parts.append(f"✓ Justification:\n   {justification}")
        
        # Original comment
        comment = change.get('comment', '')
        if comment:
            parts.append(f"💬 Note:\n   {comment}")
        
        # QA Validation feedback
        qa_validation = change.get('qa_validation', '')
        if qa_validation:
            parts.append(f"\n{'=' * 50}")
            parts.append(f"✅ QA VALIDATION:")
            parts.append(f"{qa_validation}")
        
        return '\n\n'.join(parts) if parts else 'Regulatory change'
    
    def _add_insertion_markup(self, run, change: Dict[str, Any]):
        """Add OpenXML insertion markup with proper formatting."""
        r = run._element
        
        # Create insertion element
        ins = OxmlElement('w:ins')
        ins.set(qn('w:id'), str(self.change_counter))
        ins.set(qn('w:author'), self.author)
        ins.set(qn('w:date'), datetime.now().isoformat())
        
        self.change_counter += 1
        
        # Move all run properties and content into insertion
        for child in list(r):
            ins.append(child)
            r.remove(child)
        
        r.append(ins)
        
        # Apply underline formatting for visibility
        rPr = run._element.get_or_add_rPr()
        u = OxmlElement('w:u')
        u.set(qn('w:val'), 'single')
        rPr.append(u)
        
        # Apply color (blue for insertions)
        color = OxmlElement('w:color')
        color.set(qn('w:val'), '0000FF')
        rPr.append(color)
    
    def _add_deletion_markup(self, run, change: Dict[str, Any]):
        """Add OpenXML deletion markup with proper formatting."""
        r = run._element
        
        # Create deletion element
        deletion = OxmlElement('w:del')
        deletion.set(qn('w:id'), str(self.change_counter))
        deletion.set(qn('w:author'), self.author)
        deletion.set(qn('w:date'), datetime.now().isoformat())
        
        self.change_counter += 1
        
        # Move all run properties and content into deletion
        for child in list(r):
            deletion.append(child)
            r.remove(child)
        
        r.append(deletion)
        
        # Apply strikethrough formatting for visibility
        rPr = run._element.get_or_add_rPr()
        strike = OxmlElement('w:strike')
        strike.set(qn('w:val'), '1')
        rPr.append(strike)
        
        # Apply color (red for deletions)
        color = OxmlElement('w:color')
        color.set(qn('w:val'), 'FF0000')
        rPr.append(color)
    
    def _add_comment(self, paragraph, comment_text: str):
        """Add a comment to paragraph."""
        comment_start = OxmlElement('w:commentRangeStart')
        comment_start.set(qn('w:id'), str(self.change_counter))
        
        comment_end = OxmlElement('w:commentRangeEnd')
        comment_end.set(qn('w:id'), str(self.change_counter))
        
        p = paragraph._element
        p.append(comment_start)
        p.append(comment_end)
        
        self.change_counter += 1
