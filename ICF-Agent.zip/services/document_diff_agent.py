"""
Document Diff Agent - Deterministic diff report between DOCX versions (Stories 702152, 827609).
Compares base v(N) and new v(N+1), computes diff metrics, persists to Blob.
No LLM calls - strictly content-based comparison.
"""

import os
import json
import re
from typing import Dict, Any, List, Optional, Tuple
from datetime import datetime

from services.app_insights import get_logger, track_event, track_exception

try:
    from docx import Document
    from docx.document import Document as DocxDocument
    from docx.paragraph import Paragraph
    DOCX_AVAILABLE = True
except ImportError:
    DOCX_AVAILABLE = False

try:
    import difflib
    DIFFLIB_AVAILABLE = True
except ImportError:
    DIFFLIB_AVAILABLE = False


def _normalize_whitespace(text: str) -> str:
    """Normalize whitespace - collapse runs, strip. Ignores formatting-only differences."""
    if not text:
        return ""
    text = re.sub(r"\s+", " ", text.strip())
    return text


def _extract_section_texts(doc) -> List[Tuple[str, str]]:
    """
    Extract (section_key, text) pairs from document by heading hierarchy.
    Paragraphs without a heading are grouped under the last seen heading.
    """
    sections: List[Tuple[str, str]] = []
    current_heading = "Body"
    current_texts: List[str] = []

    for para in doc.paragraphs:
        style = (para.style and para.style.name or "").lower()
        text = _normalize_whitespace(para.text)
        if not text:
            continue
        if "heading" in style:
            if current_texts:
                sections.append((current_heading, " ".join(current_texts)))
            # Use first 50 chars as section key for matching
            current_heading = text[:80].replace(" ", "_")
            current_texts = [text]
        else:
            current_texts.append(text)

    if current_texts:
        sections.append((current_heading, " ".join(current_texts)))
    return sections


def _compute_diff_chars(old_text: str, new_text: str) -> Tuple[int, int, int]:
    """Compute added, deleted, modified character counts using difflib."""
    old_n = _normalize_whitespace(old_text)
    new_n = _normalize_whitespace(new_text)
    if old_n == new_n:
        return 0, 0, 0
    matcher = difflib.SequenceMatcher(None, old_n, new_n)
    added = 0
    deleted = 0
    for tag, i1, i2, j1, j2 in matcher.get_opcodes():
        if tag == "insert":
            added += j2 - j1
        elif tag == "delete":
            deleted += i2 - i1
        elif tag == "replace":
            added += j2 - j1
            deleted += i2 - i1
    modified = added + deleted
    return added, deleted, modified


class DocumentDiffAgent:
    """
    Computes deterministic, auditable diff between two DOCX versions.
    Output: diff_summary.json with diff_percent, sections_changed, changes_by_section.
    """

    def __init__(self):
        self.logger = get_logger("document_diff_agent")

    def compute_diff(
        self,
        base_path: str,
        new_path: str,
        icf_case_id: str,
        country: str,
        base_version: int,
        new_version: int,
    ) -> Tuple[Dict[str, Any], Optional[str]]:
        """
        Compute diff between base and new DOCX.
        Returns (diff_summary_dict, blob_url or None).
        """
        if not DOCX_AVAILABLE or not DIFFLIB_AVAILABLE:
            self.logger.warning("docx or difflib not available")
            track_event("DiffAgentFailed", {"reason": "deps_unavailable"})
            return self._empty_summary(base_version, new_version), None

        start = datetime.utcnow()
        track_event("DiffAgentStarted", {
            "icf_case_id": icf_case_id,
            "base_version": str(base_version),
            "new_version": str(new_version),
        })

        if not os.path.exists(base_path):
            self.logger.error(f"Base file not found: {base_path}")
            track_event("DiffAgentFailed", {"reason": "file_missing", "file": "base"})
            return self._empty_summary(base_version, new_version), None
        if not os.path.exists(new_path):
            self.logger.error(f"New file not found: {new_path}")
            track_event("DiffAgentFailed", {"reason": "file_missing", "file": "new"})
            return self._empty_summary(base_version, new_version), None

        try:
            base_doc = Document(base_path)
            new_doc = Document(new_path)
            track_event("DocumentsLoaded", {"icf_case_id": icf_case_id})
        except Exception as e:
            self.logger.error(f"Failed to load DOCX: {e}")
            track_exception(e, {"pipeline": "document_diff_agent"})
            track_event("DiffAgentFailed", {"reason": "load_error", "error": str(e)})
            return self._empty_summary(base_version, new_version), None

        base_sections = _extract_section_texts(base_doc)
        new_sections = _extract_section_texts(new_doc)

        base_section_map = {k: t for k, t in base_sections}
        new_section_map = {k: t for k, t in new_sections}
        all_section_keys = sorted(set(base_section_map.keys()) | set(new_section_map.keys()))

        total_base_chars = sum(len(t) for _, t in base_sections)
        if total_base_chars == 0:
            total_base_chars = 1

        changes_by_section: List[Dict[str, Any]] = []
        total_added = 0
        total_deleted = 0
        total_modified = 0
        sections_with_changes = 0

        for skey in all_section_keys:
            old_t = base_section_map.get(skey, "")
            new_t = new_section_map.get(skey, "")
            added, deleted, modified = _compute_diff_chars(old_t, new_t)
            if modified > 0:
                sections_with_changes += 1
            total_added += added
            total_deleted += deleted
            total_modified += modified
            changes_by_section.append({
                "sectionKey": skey,
                "added": added,
                "deleted": deleted,
                "modified": modified,
            })

        track_event("SectionDiffComputed", {
            "sections_count": len(all_section_keys),
            "sections_changed": sections_with_changes,
        })

        total_changed_chars = total_added + total_deleted
        diff_percent = (total_changed_chars / total_base_chars) * 100

        summary = {
            "baseVersion": base_version,
            "newVersion": new_version,
            "diffPercent": round(diff_percent, 2),
            "sectionsChanged": sections_with_changes,
            "totalChanges": len([c for c in changes_by_section if c["modified"] > 0]),
            "addedChars": total_added,
            "deletedChars": total_deleted,
            "modifiedChars": total_modified,
            "changesBySection": changes_by_section,
            "generatedAt": datetime.utcnow().isoformat() + "Z",
        }

        duration_ms = (datetime.utcnow() - start).total_seconds() * 1000
        track_event("DiffAgentCompleted", {
            "icf_case_id": icf_case_id,
            "diff_percent": str(round(diff_percent, 2)),
            "sections_changed": str(sections_with_changes),
            "duration_ms": str(round(duration_ms, 2)),
        })

        blob_url = self._upload_diff_summary(
            summary, icf_case_id, country, new_version
        )
        return summary, blob_url

    def _empty_summary(self, base_version: int, new_version: int) -> Dict[str, Any]:
        return {
            "baseVersion": base_version,
            "newVersion": new_version,
            "diffPercent": 0.0,
            "sectionsChanged": 0,
            "totalChanges": 0,
            "addedChars": 0,
            "deletedChars": 0,
            "modifiedChars": 0,
            "changesBySection": [],
            "generatedAt": datetime.utcnow().isoformat() + "Z",
        }

    def _upload_diff_summary(
        self,
        summary: Dict[str, Any],
        icf_case_id: str,
        country: str,
        new_version: int,
    ) -> Optional[str]:
        """Upload diff_summary.json to Blob: cases/{icfCaseId}/{country}/versions/v{new}/diff_summary.json"""
        try:
            from azure.storage.blob import BlobServiceClient, ContentSettings
        except ImportError:
            self.logger.warning("Azure Blob SDK not available")
            return None

        conn_str = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
        container_name = os.getenv("AZURE_STORAGE_CONTAINER_NAME", "icf-country-dev")
        if not conn_str:
            return None

        blob_path = f"cases/{icf_case_id}/{country.lower()}/versions/v{new_version}/diff_summary.json"
        try:
            blob_service = BlobServiceClient.from_connection_string(conn_str)
            blob_client = blob_service.get_blob_client(
                container=container_name,
                blob=blob_path
            )
            json_content = json.dumps(summary, indent=2, default=str)
            blob_client.upload_blob(
                json_content,
                overwrite=True,
                content_settings=ContentSettings(content_type="application/json"),
            )
            self.logger.info(f"  ✓ Uploaded diff_summary: {blob_path}")
            return blob_client.url
        except Exception as e:
            self.logger.error(f"  ⚠️ Diff summary upload failed: {e}")
            track_exception(e, {"pipeline": "document_diff_agent", "stage": "upload"})
            return None
