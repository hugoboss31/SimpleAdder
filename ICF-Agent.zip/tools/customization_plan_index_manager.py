"""AI Search index manager for Customization Plans."""

import os
from typing import Optional
from azure.search.documents.indexes import SearchIndexClient
from azure.search.documents.indexes.models import (
    SearchIndex,
    SearchField,
    SearchFieldDataType,
    VectorSearch,
    HnswAlgorithmConfiguration,
    VectorSearchProfile
)
from azure.core.credentials import AzureKeyCredential
from dotenv import load_dotenv

load_dotenv()


class CustomizationPlanIndexManager:
    """Manages the AI Search index for customization plan items."""
    
    def __init__(self, index_name: Optional[str] = None):
        """
        Initialize the customization plan index manager.
        
        Args:
            index_name: Name of the index (defaults to env var or "icf-customization-plan-index")
        """
        from config import config
        
        self.search_endpoint = config.get_search_endpoint()
        self.search_key = config.get_search_key()
        self.index_name = index_name or config.CUSTOMIZATION_PLAN_INDEX_NAME
        
        if not all([self.search_endpoint, self.search_key]):
            raise ValueError("AI Search credentials not configured in .env")
        
        self.index_client = SearchIndexClient(
            endpoint=self.search_endpoint,
            credential=AzureKeyCredential(self.search_key)
        )
    
    def create_index(self, force_recreate: bool = False) -> bool:
        """
        Create the customization plan index with proper schema.
        
        Args:
            force_recreate: If True, delete existing index and recreate
            
        Returns:
            True if index was created successfully
        """
        try:
            # Check if index exists
            try:
                existing_index = self.index_client.get_index(self.index_name)
                if force_recreate:
                    print(f"[INFO] Deleting existing index: {self.index_name}")
                    self.index_client.delete_index(self.index_name)
                else:
                    print(f"[OK] Index '{self.index_name}' already exists")
                    return True
            except Exception:
                # Index doesn't exist, will create it
                pass
            
            print(f"[INFO] Creating customization plan index: {self.index_name}")
            
            # Define fields for customization plan items
            fields = [
                # Key field
                SearchField(
                    name="id",
                    type=SearchFieldDataType.String,
                    key=True,
                    sortable=True,
                    filterable=True
                ),
                
                # Item identification
                SearchField(
                    name="item_id",
                    type=SearchFieldDataType.String,
                    searchable=False,
                    filterable=True,
                    sortable=True
                ),
                
                # Plan identification
                SearchField(
                    name="plan_id",
                    type=SearchFieldDataType.String,
                    filterable=True,
                    facetable=True
                ),
                
                # Country (filterable for country-specific queries)
                SearchField(
                    name="country",
                    type=SearchFieldDataType.String,
                    filterable=True,
                    facetable=True
                ),
                
                # Content fields (searchable)
                SearchField(
                    name="topic",
                    type=SearchFieldDataType.String,
                    searchable=True,
                    filterable=False,
                    sortable=False
                ),
                SearchField(
                    name="requirement_text",
                    type=SearchFieldDataType.String,
                    searchable=True,
                    filterable=False,
                    sortable=False
                ),
                
                # Metadata fields (filterable)
                SearchField(
                    name="requirement_type",
                    type=SearchFieldDataType.String,
                    filterable=True,
                    facetable=True
                ),
                SearchField(
                    name="applies_to",
                    type=SearchFieldDataType.String,
                    filterable=True,
                    facetable=False
                ),
                SearchField(
                    name="synonyms",
                    type=SearchFieldDataType.String,
                    searchable=True,
                    filterable=False,
                    sortable=False
                ),
                SearchField(
                    name="importance",
                    type=SearchFieldDataType.String,
                    filterable=True,
                    facetable=True
                ),
                
                # Vector embedding for semantic search
                SearchField(
                    name="contentVector",
                    type=SearchFieldDataType.Collection(SearchFieldDataType.Single),
                    searchable=True,
                    vector_search_dimensions=1536,  # For text-embedding-ada-002
                    vector_search_profile_name="vector-profile"
                ),
                
                # Metadata (optional JSON)
                SearchField(
                    name="metadata",
                    type=SearchFieldDataType.String,
                    searchable=False,
                    filterable=False
                )
            ]
            
            # Configure vector search
            vector_search = VectorSearch(
                algorithms=[
                    HnswAlgorithmConfiguration(
                        name="hnsw-config",
                        parameters={
                            "m": 4,
                            "efConstruction": 400,
                            "efSearch": 500,
                            "metric": "cosine"
                        }
                    )
                ],
                profiles=[
                    VectorSearchProfile(
                        name="vector-profile",
                        algorithm_configuration_name="hnsw-config"
                    )
                ]
            )
            
            # Create index
            index = SearchIndex(
                name=self.index_name,
                fields=fields,
                vector_search=vector_search
            )
            
            self.index_client.create_index(index)
            print(f"[OK] Index '{self.index_name}' created successfully")
            return True
            
        except Exception as e:
            print(f"[ERROR] Failed to create index: {e}")
            raise
    
    def index_exists(self) -> bool:
        """Check if the index exists."""
        try:
            self.index_client.get_index(self.index_name)
            return True
        except Exception:
            return False
    
    def delete_index(self) -> bool:
        """Delete the index."""
        try:
            self.index_client.delete_index(self.index_name)
            print(f"[OK] Index '{self.index_name}' deleted")
            return True
        except Exception as e:
            print(f"[ERROR] Failed to delete index: {e}")
            return False
    
    def get_index_info(self) -> Optional[dict]:
        """Get information about the index."""
        try:
            index = self.index_client.get_index(self.index_name)
            return {
                "name": index.name,
                "fields": [field.name for field in index.fields],
                "vector_search": index.vector_search is not None
            }
        except Exception as e:
            print(f"[ERROR] Failed to get index info: {e}")
            return None


if __name__ == "__main__":
    """CLI to create/manage the index."""
    import argparse
    
    parser = argparse.ArgumentParser(description="Manage customization plan AI Search index")
    parser.add_argument("--create", action="store_true", help="Create the index")
    parser.add_argument("--recreate", action="store_true", help="Recreate the index (delete and create)")
    parser.add_argument("--delete", action="store_true", help="Delete the index")
    parser.add_argument("--info", action="store_true", help="Show index information")
    parser.add_argument("--index-name", type=str, help="Index name (defaults to env var)")
    
    args = parser.parse_args()
    
    manager = CustomizationPlanIndexManager(index_name=args.index_name)
    
    if args.create:
        manager.create_index()
    elif args.recreate:
        manager.create_index(force_recreate=True)
    elif args.delete:
        manager.delete_index()
    elif args.info:
        info = manager.get_index_info()
        if info:
            print(f"Index: {info['name']}")
            fields_list = info['fields']
            fields_str = ", ".join(fields_list)
            print(f"Fields: {fields_str}")
            print(f"Vector Search: {info['vector_search']}")
    else:
        # Default: check if exists, create if not
        if manager.index_exists():
            print(f"[OK] Index '{manager.index_name}' exists")
        else:
            print(f"[INFO] Index '{manager.index_name}' does not exist. Creating...")
            manager.create_index()



