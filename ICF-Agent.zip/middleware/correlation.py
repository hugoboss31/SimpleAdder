"""
Correlation ID middleware for request tracing.
Reads X-Correlation-ID from request headers or generates one.
Stores in request.state.correlation_id for use in handlers and logging.
"""

import uuid
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response


class CorrelationIdMiddleware(BaseHTTPMiddleware):
    """Extract or generate correlation ID and attach to request state."""

    async def dispatch(self, request: Request, call_next) -> Response:
        header = request.headers.get("x-correlation-id") or request.headers.get("X-Correlation-ID")
        correlation_id = header if header else str(uuid.uuid4())
        request.state.correlation_id = correlation_id
        response = await call_next(request)
        response.headers["X-Correlation-ID"] = correlation_id
        return response
