"""
Section Parser for Human Review Agent.
Builds section tree from reviewed documents and provides paragraph-to-section mapping.
Reuses IngestionAgent for parsing, adds comment linking capabilities.
"""

import os
from typing import List, Dict, Optional, Tuple
from datetime import datetime

from config import Config
from models.models import (
    DocumentTree, SectionNode, ParagraphNode,
    ParsedComment, SectionRecord
)
from agents.ingestion_agent import IngestionAgent

try:
    from azure.search.documents import SearchClient
    from azure.search.documents.indexes import SearchIndexClient
    from azure.search.documents.indexes.models import (
        SearchIndex, SimpleField, SearchableField,
        SearchFieldDataType, VectorSearch, HnswAlgorithmConfiguration,
        VectorSearchProfile, SearchField
    )
    from azure.core.credentials import AzureKeyCredential
    AZURE_SEARCH_AVAILABLE = True
except ImportError:
    AZURE_SEARCH_AVAILABLE = False


class SectionParser:
    """
    Parses reviewed documents into section trees.
    Provides mapping from paragraph indices to sections for comment linking.
    """
    
    REVIEWED_INDEX_NAME = "icf-reviewed-sections-index"
    
    def __init__(self):
        self.ingestion_agent = IngestionAgent()
        self.search_client = None
        self.index_client = None
        
        self._init_search_clients()
        print("✅ Section Parser initialized")
    
    def _init_search_clients(self):
        """Initialize Azure AI Search clients for reviewed sections."""
        if not AZURE_SEARCH_AVAILABLE:
            return

        try:
            endpoint = Config.get_search_endpoint()
            credential = Config.get_search_credential()
        except Exception:
            return

        try:
            self.index_client = SearchIndexClient(
                endpoint=endpoint,
                credential=credential
            )
            self._ensure_index_exists()
            
            self.search_client = SearchClient(
                endpoint=endpoint,
                index_name=self.REVIEWED_INDEX_NAME,
                credential=credential
            )
            print(f"  ✓ Connected to {self.REVIEWED_INDEX_NAME}")
        except Exception as e:
            print(f"  ⚠️ Search client init failed: {e}")
    
    def _ensure_index_exists(self):
        """Create reviewed-sections-index if it doesn't exist."""
        try:
            self.index_client.get_index(self.REVIEWED_INDEX_NAME)
        except Exception:
            print(f"  → Creating index {self.REVIEWED_INDEX_NAME}...")
            self._create_index()
    
    def _create_index(self):
        """Create the reviewed-sections-index schema."""
        fields = [
            SimpleField(name="id", type=SearchFieldDataType.String, key=True),
            SimpleField(name="document_id", type=SearchFieldDataType.String, filterable=True, sortable=True),
            SimpleField(name="version", type=SearchFieldDataType.Int32, filterable=True),
            SimpleField(name="section_id", type=SearchFieldDataType.String, filterable=True),
            SearchableField(name="heading", type=SearchFieldDataType.String),
            SearchableField(name="content", type=SearchFieldDataType.String),
            SimpleField(name="page_number", type=SearchFieldDataType.Int32),
            SimpleField(name="section_order", type=SearchFieldDataType.Int32, sortable=True),
            SimpleField(name="start_para_idx", type=SearchFieldDataType.Int32),
            SimpleField(name="end_para_idx", type=SearchFieldDataType.Int32),
            SimpleField(name="parent_section_id", type=SearchFieldDataType.String, filterable=True),
            SimpleField(name="level", type=SearchFieldDataType.Int32),
            SimpleField(name="country", type=SearchFieldDataType.String, filterable=True),
            SearchField(
                name="embedding",
                type=SearchFieldDataType.Collection(SearchFieldDataType.Single),
                searchable=True,
                vector_search_dimensions=1536,
                vector_search_profile_name="default-profile"
            )
        ]
        
        vector_search = VectorSearch(
            algorithms=[
                HnswAlgorithmConfiguration(name="default-algorithm")
            ],
            profiles=[
                VectorSearchProfile(
                    name="default-profile",
                    algorithm_configuration_name="default-algorithm"
                )
            ]
        )
        
        index = SearchIndex(
            name=self.REVIEWED_INDEX_NAME,
            fields=fields,
            vector_search=vector_search
        )
        
        self.index_client.create_index(index)
        print(f"  ✓ Created index {self.REVIEWED_INDEX_NAME}")
    
    def parse_reviewed_document(self, docx_path: str) -> DocumentTree:
        """
        Parse a reviewed document into a structured section tree.
        Reuses IngestionAgent's parsing logic.
        
        Args:
            docx_path: Path to the reviewed DOCX file
            
        Returns:
            DocumentTree with hierarchical sections
        """
        print(f"\n📄 Parsing reviewed document for section tree...")
        return self.ingestion_agent.parse_document(docx_path)
    
    def build_paragraph_to_section_map(
        self,
        doc_tree: DocumentTree
    ) -> Dict[int, Dict[str, str]]:
        """
        Build a mapping from paragraph indices to their containing sections.
        Used to link comments to sections.
        
        Args:
            doc_tree: Parsed document tree
            
        Returns:
            Dict mapping paragraph_index -> {section_id, section_title}
        """
        section_map = {}
        
        for section in doc_tree.get_all_sections_flat():
            section_map[section.start_para_idx] = {
                'section_id': section.section_id,
                'section_title': section.heading
            }
        
        return section_map
    
    def link_comments_to_sections(
        self,
        comments: List[ParsedComment],
        doc_tree: DocumentTree
    ) -> List[ParsedComment]:
        """
        Link parsed comments to their corresponding sections.
        
        Args:
            comments: List of parsed comments from comment_extractor
            doc_tree: Parsed document tree
            
        Returns:
            Comments with section_id and section_title populated
        """
        sections = doc_tree.get_all_sections_flat()
        
        # Sort sections by start_para_idx for efficient lookup
        sorted_sections = sorted(sections, key=lambda s: s.start_para_idx)
        
        for comment in comments:
            para_idx = comment.paragraph_index
            
            if para_idx < 0:
                continue
            
            # Find the section containing this paragraph
            best_section = None
            for section in sorted_sections:
                if section.start_para_idx <= para_idx:
                    if section.end_para_idx >= para_idx or section.end_para_idx == 0:
                        best_section = section
                else:
                    break
            
            if best_section:
                comment.section_id = best_section.section_id
                comment.section_title = best_section.heading
        
        linked_count = sum(1 for c in comments if c.section_id)
        print(f"  ✓ Linked {linked_count}/{len(comments)} comments to sections")
        
        return comments
    
    def get_section_context(
        self,
        comment: ParsedComment,
        doc_tree: DocumentTree,
        context_chars: int = 2000
    ) -> str:
        """
        Get surrounding section context for a comment.
        Used to provide LLM with context for edit generation.
        
        Args:
            comment: The parsed comment
            doc_tree: Document tree
            context_chars: Max characters of context to return
            
        Returns:
            Section content around the comment's linked text
        """
        if not comment.section_id:
            return ""
        
        section = doc_tree.get_section_by_id(comment.section_id)
        if not section:
            return ""
        
        full_text = section.full_text
        
        # Try to center around the linked text
        if comment.linked_text and comment.linked_text in full_text:
            idx = full_text.find(comment.linked_text)
            start = max(0, idx - context_chars // 2)
            end = min(len(full_text), idx + len(comment.linked_text) + context_chars // 2)
            return full_text[start:end]
        
        return full_text[:context_chars]
    
    def index_reviewed_sections(
        self,
        doc_tree: DocumentTree,
        document_id: str,
        version: int,
        country: str
    ) -> int:
        """
        Index reviewed document sections to Azure AI Search.
        
        Args:
            doc_tree: Parsed document tree
            document_id: Document ID
            version: Version number
            country: Country name (usa, canada, etc.)
            
        Returns:
            Number of sections indexed
        """
        if not self.search_client:
            print("  ⚠️ Search client not available, skipping indexing")
            return 0
        
        print(f"\n📥 Indexing reviewed sections: {document_id} v{version}")
        
        sections = doc_tree.get_all_sections_flat()
        docs = []
        
        for idx, section in enumerate(sections):
            # Generate embedding
            text_for_embedding = f"{section.heading}\n{section.full_text[:1500]}"
            embedding = self.ingestion_agent._embed(text_for_embedding)
            
            doc = {
                "id": f"{document_id}_v{version}_{section.section_id}",
                "document_id": document_id,
                "version": version,
                "section_id": section.section_id,
                "heading": section.heading,
                "content": section.full_text[:8000],
                "page_number": section.page_no,
                "section_order": idx,
                "start_para_idx": section.start_para_idx,
                "end_para_idx": section.end_para_idx,
                "parent_section_id": section.parent_id or "",
                "level": section.level,
                "country": country
            }
            
            if embedding:
                doc["embedding"] = embedding
            
            docs.append(doc)
        
        # Upload in batches
        batch_size = 100
        for i in range(0, len(docs), batch_size):
            batch = docs[i:i + batch_size]
            self.search_client.upload_documents(documents=batch)
        
        print(f"  ✓ Indexed {len(docs)} sections for {document_id} v{version}")
        return len(docs)
    
    def get_sections_by_document_version(
        self,
        document_id: str,
        version: int
    ) -> List[Dict]:
        """
        Retrieve all sections for a specific document version.
        
        Args:
            document_id: Document ID
            version: Version number
            
        Returns:
            List of section records
        """
        if not self.search_client:
            return []
        
        results = self.search_client.search(
            search_text="*",
            filter=f"document_id eq '{document_id}' and version eq {version}",
            order_by=["section_order asc"],
            top=1000
        )
        
        sections = []
        for result in results:
            sections.append({
                "id": result["id"],
                "document_id": result["document_id"],
                "version": result["version"],
                "section_id": result["section_id"],
                "heading": result["heading"],
                "content": result["content"],
                "start_para_idx": result.get("start_para_idx", 0),
                "end_para_idx": result.get("end_para_idx", 0),
                "level": result.get("level", 1)
            })
        
        return sections
    
    def delete_document_version_sections(
        self,
        document_id: str,
        version: int
    ) -> int:
        """
        Delete all sections for a specific document version.
        
        Args:
            document_id: Document ID
            version: Version number to delete
            
        Returns:
            Number of sections deleted
        """
        if not self.search_client:
            return 0
        
        sections = self.get_sections_by_document_version(document_id, version)
        if not sections:
            return 0
        
        docs_to_delete = [{"id": s["id"]} for s in sections]
        self.search_client.delete_documents(documents=docs_to_delete)
        
        print(f"  ✓ Deleted {len(docs_to_delete)} sections for {document_id} v{version}")
        return len(docs_to_delete)
    
    def get_comment_section_context_batch(
        self,
        comments: List[ParsedComment],
        doc_tree: DocumentTree
    ) -> Dict[str, str]:
        """
        Get section context for multiple comments at once.
        
        Args:
            comments: List of comments
            doc_tree: Document tree
            
        Returns:
            Dict mapping comment_id -> section_context
        """
        context_map = {}
        
        for comment in comments:
            context = self.get_section_context(comment, doc_tree)
            context_map[comment.comment_id] = context
        
        return context_map