"""Enhanced RAG tool with section-aware hybrid search."""

import os
from typing import List, Dict, Any, Optional
from azure.search.documents import SearchClient
from azure.search.documents.models import VectorizedQuery
from openai import AzureOpenAI
from schemas.icf_schemas import ICFSection


class SectionSearchTool:
    """
    Enhanced search tool for section-aware retrieval from Global ICF.
    
    Uses hybrid search (BM25 + vector) with section context preservation.
    """
    
    def __init__(self):
        """Initialize the section search tool."""
        from config import config
        
        self.search_endpoint = config.get_search_endpoint()
        self.search_credential = config.get_search_credential()
        # Use dedicated ICF sections index (separate from general RAG index)
        self.index_name = config.ICF_SECTIONS_INDEX_NAME
        
        self.openai_endpoint = config.AZURE_OPENAI_ENDPOINT
        self.openai_key = config.AZURE_OPENAI_API_KEY
        self.embedding_deployment = config.EMBEDDINGS_MODEL_DEPLOYMENT
        
        if not self.search_endpoint:
            raise ValueError(
                "AI Search endpoint not configured. "
                "Please set AZURE_SEARCH_ENDPOINT in .env (or use RBAC with managed identity)."
            )
        
        self.search_client = SearchClient(
            endpoint=self.search_endpoint,
            index_name=self.index_name,
            credential=self.search_credential
        )
        
        if not self.openai_endpoint or not self.openai_key:
            raise ValueError(
                "OpenAI client is required but not configured. "
                "Please set AZURE_OPENAI_ENDPOINT and AZURE_OPENAI_API_KEY in .env"
            )
        
        self.openai_client = AzureOpenAI(
            azure_endpoint=self.openai_endpoint,
            api_key=self.openai_key,
            api_version=config.AZURE_OPENAI_API_VERSION
        )
    
    def hybrid_search_sections(
        self,
        query: str,
        topic: str,
        synonyms: List[str] = None,
        top_k: int = 8,
        country: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """
        Perform hybrid search (BM25 + vector) for ICF sections.
        
        Args:
            query: Natural language query
            topic: Topic name (e.g., "Contact for further information")
            synonyms: List of synonyms for topic
            top_k: Number of results to return
            country: Optional country filter
            
        Returns:
            List of candidate sections with scores
        """
        # Build BM25 query with synonyms
        bm25_query = self._build_bm25_query(topic, query, synonyms)
        
        # Get embedding for vector search - OpenAI client is required
        # Build comprehensive semantic query for better embedding
        try:
            # Build semantic query that emphasizes meaning and context
            semantic_query = self._build_semantic_query(topic, query, synonyms)
            embedding = self._get_embedding(semantic_query)
            vector_query = VectorizedQuery(
                vector=embedding,
                k_nearest_neighbors=top_k * 2,  # Get more candidates for semantic search
                fields="embedding"  # Field name matches index schema
            )
        except Exception as e:
            raise RuntimeError(f"Failed to generate embedding for vector search: {e}") from e
        
        # Perform hybrid search (BM25 + vector - vector is required)
        try:
            # Perform hybrid search with both BM25 and vector
            search_options = {
                "search_text": bm25_query,  # BM25 keyword search
                "vector_queries": [vector_query],  # Vector semantic search (required)
                "top": top_k,
                "include_total_count": True
            }
            
            results = self.search_client.search(**search_options)
            
            candidates = []
            for result in results:
                candidate = {
                    "section_id": result.get("section_id", ""),
                    "title": result.get("title", ""),
                    "text": result.get("text", ""),
                    "level": result.get("level", 1),
                    "page": result.get("page"),
                    "order_index": result.get("order_index", 0),
                    "parent_section_id": result.get("parent_section_id"),
                    "bm25_score": result.get("@search.score", 0.0),
                    "vector_score": result.get("@search.score", 0.0),  # Will be same as BM25 in hybrid
                    "combined_score": result.get("@search.score", 0.0),
                    "metadata": {k: v for k, v in result.items() if not k.startswith("@")}
                }
                candidates.append(candidate)
            
            return candidates if candidates else []
            
        except Exception as e:
            print(f"Warning: Search failed: {e}")
            import traceback
            traceback.print_exc()
            return []
    
    def _build_semantic_query(self, topic: str, query: str, synonyms: List[str] = None) -> str:
        """Build comprehensive semantic query for embedding generation."""
        # Combine topic, query, and synonyms for rich semantic embedding
        parts = [topic]
        
        # Add the full query (includes requirement text)
        parts.append(query)
        
        # Add synonyms as semantic variations
        if synonyms:
            parts.extend(synonyms[:5])  # Top 5 synonyms
        
        # Build query that emphasizes semantic meaning
        semantic_query = " ".join(parts)
        
        # Add semantic context hints for better matching
        # For example: "compensation" should match "reimbursement", "payment", "expenses", etc.
        semantic_hints = []
        topic_lower = topic.lower()
        
        # Add semantic expansion based on common ICF topics
        semantic_expansions = {
            "compensation": ["reimbursement", "payment", "expenses", "costs", "financial compensation", "reimbursed for expenses", "out-of-pocket expenses"],
            "reimbursement": ["compensation", "payment", "expenses", "costs", "reimbursed for expenses", "out-of-pocket"],
            "payment": ["compensation", "reimbursement", "financial", "reimbursed"],
            "contact": ["reach", "phone", "email", "address", "communication"],
            "data": ["information", "privacy", "protection", "confidentiality"],
            "withdrawal": ["stop", "discontinue", "leave", "exit", "quit"],
            "risks": ["danger", "harm", "safety", "adverse", "side effects"],
            "benefits": ["advantage", "gain", "value", "positive"],
            "procedures": ["process", "methods", "what happens", "study activities"],
            "confidentiality": ["privacy", "data protection", "information security"],
            "injury": ["harm", "adverse event", "damage", "complications"]
        }
        
        # Check if topic matches any semantic expansion keys
        for key, expansions in semantic_expansions.items():
            if key in topic_lower or any(key in syn.lower() for syn in (synonyms or [])):
                semantic_hints.extend(expansions[:3])  # Add top 3 expansions
                break
        
        if semantic_hints:
            semantic_query += " " + " ".join(semantic_hints)
        
        return semantic_query
    
    def _build_bm25_query(self, topic: str, query: str, synonyms: List[str] = None) -> str:
        """Build BM25 query string with synonyms and semantic expansions."""
        query_parts = [topic, query]
        
        if synonyms:
            # Add synonyms with OR operator
            synonym_query = " OR ".join(f'"{syn}"' for syn in synonyms)
            query_parts.append(f"({synonym_query})")
        
        # Add semantic expansions for better keyword matching
        topic_lower = topic.lower()
        semantic_expansions = {
            "compensation": ["reimbursement", "reimbursed", "payment", "expenses", "out-of-pocket"],
            "reimbursement": ["compensation", "payment", "expenses", "reimbursed"],
            "payment": ["compensation", "reimbursement", "expenses"],
        }
        
        # Add semantic expansion terms to BM25 query
        for key, expansions in semantic_expansions.items():
            if key in topic_lower:
                expansion_query = " OR ".join(f'"{exp}"' for exp in expansions[:3])
                if expansion_query:
                    query_parts.append(f"({expansion_query})")
                break
        
        return " ".join(query_parts)
    
    def _get_embedding(self, text: str) -> List[float]:
        """Get embedding vector for text using OpenAI client (required)."""
        # OpenAI client is guaranteed to be available (checked in __init__)
        response = self.openai_client.embeddings.create(
            model=self.embedding_deployment,
            input=text
        )
        
        return response.data[0].embedding
    
    def get_section_context(self, section_id: str) -> Optional[Dict[str, Any]]:
        """
        Retrieve full section context including parent and children.
        
        Args:
            section_id: Section ID to retrieve
            
        Returns:
            Section with context or None
        """
        try:
            # Search for the specific section
            results = self.search_client.search(
                search_text=f"section_id:{section_id}",
                top=1
            )
            
            for result in results:
                section_data = dict(result)
                
                # Try to get parent section if exists
                parent_id = section_data.get("parent_section_id")
                parent_section = None
                if parent_id:
                    parent_results = self.search_client.search(
                        search_text=f"section_id:{parent_id}",
                        top=1
                    )
                    for parent_result in parent_results:
                        parent_section = dict(parent_result)
                        break
                
                # Try to get child sections
                children_results = self.search_client.search(
                    search_text=f"parent_section_id:{section_id}",
                    top=10
                )
                children = [dict(child) for child in children_results]
                
                return {
                    "section": section_data,
                    "parent": parent_section,
                    "children": children
                }
            
            return None
            
        except Exception as e:
            print(f"Warning: Failed to get section context: {e}")
            return None

