"""
Policy Index Setup - Creates icf_agent_policies Azure AI Search index (Story 827616).
"""

import os
from typing import Optional

try:
    from azure.search.documents.indexes import SearchIndexClient
    from azure.search.documents.indexes.models import (
        SearchIndex, SimpleField, SearchableField, SearchFieldDataType,
        VectorSearch, HnswAlgorithmConfiguration, VectorSearchProfile, SearchField
    )
    from azure.core.credentials import AzureKeyCredential
    AZURE_SEARCH_AVAILABLE = True
except ImportError:
    AZURE_SEARCH_AVAILABLE = False

INDEX_NAME = "icf_agent_policies"
EMBEDDING_DIMENSIONS = 1536


def create_policy_index() -> bool:
    """Create icf_agent_policies index if it doesn't exist."""
    if not AZURE_SEARCH_AVAILABLE:
        return False
    endpoint = os.getenv("AI_SEARCH_ENDPOINT")
    api_key = os.getenv("AI_SEARCH_KEY")
    if not endpoint or not api_key:
        return False
    client = SearchIndexClient(endpoint=endpoint, credential=AzureKeyCredential(api_key))
    try:
        client.get_index(INDEX_NAME)
        print(f"Index {INDEX_NAME} already exists")
        return True
    except Exception:
        pass
    fields = [
        SimpleField("policyId", SearchFieldDataType.String, key=True, filterable=True),
        SimpleField("scope", SearchFieldDataType.String, filterable=True, facetable=True),
        SimpleField("countryCode", SearchFieldDataType.String, filterable=True),
        SimpleField("studyId", SearchFieldDataType.String, filterable=True),
        SimpleField("policyType", SearchFieldDataType.String, filterable=True, facetable=True),
        SearchableField("content", SearchFieldDataType.String, analyzer_name="en.microsoft"),
        SearchField("contentVector", SearchFieldDataType.Collection(SearchFieldDataType.Single),
                    searchable=True, vector_search_dimensions=EMBEDDING_DIMENSIONS,
                    vector_search_profile_name="policy-vector-profile"),
        SimpleField("version", SearchFieldDataType.Int32, filterable=True, sortable=True),
        SimpleField("isActive", SearchFieldDataType.Boolean, filterable=True),
        SimpleField("updatedAt", SearchFieldDataType.DateTimeOffset, filterable=True, sortable=True),
    ]
    vector_search = VectorSearch(
        algorithms=[HnswAlgorithmConfiguration("policy-hnsw", parameters={"m": 4, "efConstruction": 400})],
        profiles=[VectorSearchProfile("policy-vector-profile", "policy-hnsw")]
    )
    index = SearchIndex(name=INDEX_NAME, fields=fields, vector_search=vector_search)
    client.create_index(index)
    print(f"Created index {INDEX_NAME}")
    return True
