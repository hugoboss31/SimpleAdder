"""
ICF Generator with Magentic Orchestration
Generates country-specific Informed Consent Forms using multi-agent system.
"""

import asyncio
import argparse
import json
import os
import shutil
from pathlib import Path
from datetime import datetime

from semantic_kernel.agents import MagenticOrchestration, StandardMagenticManager
from semantic_kernel.agents.runtime import InProcessRuntime
from semantic_kernel.connectors.ai.open_ai import AzureChatCompletion
from semantic_kernel.contents import ChatMessageContent

from agents import create_generator_agent, create_qa_agent, create_writer_agent
from tools import DocumentIntelligenceTool, RAGTool, DocxTrackerTool, OpenXmlDocxGenerator
from config import config

# Load environment variables
from dotenv import load_dotenv
load_dotenv()


def extract_qa_validations(response: str) -> dict:
    """Extract QA Agent validation comments from the conversation."""
    validations = {}
    lines = response.split('\n')
    
    current_change_num = None
    validation_text = []
    
    for line in lines:
        line_stripped = line.strip()
        
        # Look for validation blocks
        if line_stripped.startswith('**Change') or line_stripped.startswith('CHANGE'):
            # Save previous validation
            if current_change_num is not None and validation_text:
                validations[current_change_num] = '\n'.join(validation_text)
            
            # Extract change number
            import re
            match = re.search(r'[Cc]hange\s+(\d+)', line_stripped)
            if match:
                current_change_num = int(match.group(1)) - 1  # 0-indexed
                validation_text = []
        
        elif current_change_num is not None:
            # Collect validation details
            if any(marker in line_stripped.lower() for marker in [
                'validation:', 'justification', 'regulatory reference', 
                'score:', 'status:', 'valid', 'approved'
            ]):
                validation_text.append(line_stripped)
            
            # Stop at next change or summary
            if line_stripped.startswith('Overall') or line_stripped.startswith('**Overall'):
                if validation_text:
                    validations[current_change_num] = '\n'.join(validation_text)
                break
    
    # Save last validation
    if current_change_num is not None and validation_text:
        validations[current_change_num] = '\n'.join(validation_text)
    
    return validations


def parse_changes_from_response(response: str) -> list:
    """Parse changes from agent response text - handles both JSON and natural language formats."""
    changes = []
    
    # Extract QA validation comments from the response
    qa_validations = extract_qa_validations(response)
    
    # Try to extract JSON first (if present)
    import re
    json_match = re.search(r'\[\s*\{.*?\}\s*\]', response, re.DOTALL)
    if json_match:
        try:
            json_changes = json.loads(json_match.group())
            for idx, change in enumerate(json_changes):
                # Extract location from multiple possible fields
                location = (
                    change.get('location') or 
                    change.get('title') or 
                    change.get('section_id') or 
                    'Unknown'
                )
                
                # Extract change type from multiple possible fields
                change_type_raw = (
                    change.get('change_type') or 
                    change.get('type') or 
                    ''
                ).lower()
                
                # Normalize change types
                if 'insert' in change_type_raw:
                    change_type = 'insertion'
                elif 'delete' in change_type_raw:
                    change_type = 'deletion'
                elif 'modify' in change_type_raw:
                    change_type = 'modification'
                else:
                    # Infer from presence of old_text and new_text
                    has_old = bool(change.get('original_text') or change.get('old_text'))
                    has_new = bool(change.get('new_text'))
                    if has_old and has_new:
                        change_type = 'modification'
                    elif has_new:
                        change_type = 'insertion'
                    elif has_old:
                        change_type = 'deletion'
                    else:
                        change_type = 'insertion'
                
                # Get QA validation comment for this change
                qa_comment = qa_validations.get(idx, '') if qa_validations else ''
                
                parsed_change = {
                    'location': location,
                    'change_type': change_type,
                    'old_text': change.get('original_text') or change.get('old_text') or '',
                    'new_text': change.get('new_text') or '',
                    'after_text': change.get('after_text') or '',
                    'regulatory_reference': change.get('regulatory_reference') or '',
                    'justification': change.get('justification') or 'Regulatory compliance requirement',
                    'comment': change.get('comment') or f"Required by {change.get('regulatory_reference', 'regulation')}",
                    'qa_validation': qa_comment
                }
                
                changes.append(parsed_change)
            
            print(f"  Parsed {len(changes)} changes from JSON format")
            return changes
        except json.JSONDecodeError as e:
            print(f"  JSON parsing failed: {e}, trying natural language parsing...")
    
    # Fallback: parse natural language format
    lines = response.split('\n')
    current_change = {}
    in_change_block = False
    change_idx = 0
    
    for i, line in enumerate(lines):
        line = line.strip()
        
        # Detect change block start
        if line.startswith('CHANGE ') and ':' in line:
            if current_change and any(current_change.values()):
                # Get QA validation for this change
                current_change['qa_validation'] = qa_validations.get(change_idx, '')
                changes.append(current_change)
                change_idx += 1
            
            current_change = {}
            in_change_block = True
            continue
        
        if not in_change_block:
            continue
        
        # Parse change attributes with better handling
        if line.startswith('Location:'):
            current_change['location'] = line.replace('Location:', '').strip()
        
        elif line.startswith('Type:'):
            change_type = line.replace('Type:', '').strip().upper()
            if 'INSERT' in change_type:
                current_change['change_type'] = 'insertion'
            elif 'DELETE' in change_type:
                current_change['change_type'] = 'deletion'
            elif 'MODIFY' in change_type:
                current_change['change_type'] = 'modification'
        
        elif line.startswith('Original text:') or line.startswith('Old text:'):
            # Collect multi-line text
            text = line.split(':', 1)[1].strip().strip('"')
            # Check if text continues on next lines
            j = i + 1
            while j < len(lines) and not lines[j].strip().startswith(('New text:', 'After text:', 'Regulatory', 'Justification:', 'Comment:', 'CHANGE')):
                if lines[j].strip():
                    text += ' ' + lines[j].strip().strip('"')
                j += 1
            current_change['old_text'] = text
        
        elif line.startswith('New text:'):
            # Collect multi-line text
            text = line.split(':', 1)[1].strip().strip('"')
            j = i + 1
            while j < len(lines) and not lines[j].strip().startswith(('Regulatory', 'Justification:', 'Comment:', 'CHANGE', 'Location:', 'Type:')):
                if lines[j].strip():
                    text += ' ' + lines[j].strip().strip('"')
                j += 1
            current_change['new_text'] = text
        
        elif line.startswith('After text:'):
            text = line.split(':', 1)[1].strip().strip('"')
            j = i + 1
            while j < len(lines) and not lines[j].strip().startswith(('New text:', 'Regulatory', 'Justification:', 'Comment:', 'CHANGE')):
                if lines[j].strip():
                    text += ' ' + lines[j].strip().strip('"')
                j += 1
            current_change['after_text'] = text
        
        elif line.startswith('Regulatory Reference:'):
            current_change['regulatory_reference'] = line.split(':', 1)[1].strip()
        
        elif line.startswith('Justification:'):
            text = line.split(':', 1)[1].strip()
            j = i + 1
            while j < len(lines) and not lines[j].strip().startswith(('Comment:', 'CHANGE', 'Regulatory')):
                if lines[j].strip():
                    text += ' ' + lines[j].strip()
                j += 1
            current_change['justification'] = text
        
        elif line.startswith('Comment:'):
            text = line.split(':', 1)[1].strip()
            j = i + 1
            while j < len(lines) and not lines[j].strip().startswith(('CHANGE', 'Location:', '====', 'Agent:')):
                if lines[j].strip():
                    text += ' ' + lines[j].strip()
                j += 1
            current_change['comment'] = text
    
    # Add last change
    if current_change and any(current_change.values()):
        current_change['qa_validation'] = qa_validations.get(change_idx, '')
        changes.append(current_change)
    
    if changes:
        print(f"  Parsed {len(changes)} changes from natural language format")
    
    return changes


async def create_agents():
    """Create the ICF Generator agents for Magentic Orchestration."""
    generator_agent = create_generator_agent()
    qa_agent = create_qa_agent()
    writer_agent = create_writer_agent()
    
    return [generator_agent, qa_agent, writer_agent]


# Global variable to collect all agent messages
agent_messages = []

def agent_response_callback(message: ChatMessageContent) -> None:
    """Observer function to print agent messages."""
    print(f"\n{'='*80}")
    print(f"Agent: {message.name}")
    print(f"{'='*80}")
    print(message.content)
    print()
    
    # Collect message for parsing
    agent_messages.append({
        'agent': message.name,
        'content': message.content
    })


async def main(input_path: str = None, country: str = None, max_iterations: int = None, output: str = None):
    """Main function to run the ICF Generator with Magentic Orchestration.

    This function can be called either programmatically with explicit parameters
    or via the command-line. When called programmatically, pass `input_path`,
    `country`, `max_iterations` and optional `output`.
    """

    # Allow both programmatic invocation and CLI invocation
    # Clear global messages list for this run
    global agent_messages
    agent_messages = []

    # If required parameters are not provided, fall back to argparse (CLI mode)
    if input_path is None or country is None or max_iterations is None or output is None:
        # Parse command-line arguments
        parser = argparse.ArgumentParser(description="ICF Generator with Magentic Orchestration")
        parser.add_argument("--input", type=str, required=True, help="Path to master ICF DOCX file")
        parser.add_argument("--country", type=str, required=True, help="Target country code (e.g., USA, GBR)")
        parser.add_argument("--output", type=str, default="output/generated_icf.docx", help="Output path")
        parser.add_argument("--max-iterations", type=int, default=5, help="Maximum iterations")
        args = parser.parse_args()

        input_path = args.input
        country = args.country
        output = args.output
        max_iterations = args.max_iterations
    
    # Create output and support directories
    Path("output").mkdir(exist_ok=True)
    Path("logs").mkdir(exist_ok=True)
    Path("median").mkdir(exist_ok=True)
    Path("uploads").mkdir(exist_ok=True)

    # Validate input
    if not Path(input_path).exists():
        print(f"Error: Input file not found: {input_path}")
        return 1
    
    print("="*80)
    print("ICF Generator - Magentic Orchestration")
    print("="*80)
    print(f"\nInput: {input_path}")
    print(f"Country: {country}")
    print(f"Output: {output}")
    print(f"Max Iterations: {max_iterations}")
    
    # Initialize tools
    print("\nInitializing tools...")
    di_tool = DocumentIntelligenceTool()
    rag_tool = RAGTool()
    docx_tool = DocxTrackerTool()  # Keep for backward compatibility
    openxml_generator = OpenXmlDocxGenerator(author="ICF Generator Agent", output_folder="median")
    
    # Extract master ICF
    print("\nExtracting master ICF content...")
    doc_content = di_tool.extract_document(input_path)
    print(f"Extracted {len(doc_content['sections'])} sections")
    
    # Query regulations
    print(f"\nQuerying regulatory requirements for {country}...")
    regulations = rag_tool.query_regulations(
        query="informed consent requirements",
        country=country,
        top_k=10
    )
    print(f"Found {len(regulations)} regulatory requirements")
    
    # Prepare context for agents
    context = {
        'master_icf_path': input_path,
        'country': country,
        'sections': doc_content['sections'],
        'regulations': regulations,
        'output_path': output
    }
    
    # Build task description
    task = f"""Generate country-specific Informed Consent Form for {country}.

Master ICF: {input_path}
Sections extracted: {len(doc_content['sections'])}
Regulatory requirements found: {len(regulations)}

Master ICF Sections:
{json.dumps(doc_content['sections'][:5], indent=2)}

    Regulatory Requirements:
{json.dumps([
    {
        'source': r.get('source', ''),
        'article': r.get('article', ''),
        'content': (r.get('content')[:200] + '...') if r.get('content') else ''
    }
    for r in regulations[:5]
], indent=2)}

Task:
You are a multi-agent system working together to generate a compliant ICF for {country}.

WORKFLOW:
1. Generator Agent: Analyze the master ICF and propose changes for {country}
   - Identify sections requiring modification
   - For each change: location, change type, old/new text, regulatory reference, justification
   - Format: CHANGE 1, CHANGE 2, etc. with clear fields

2. QA Agent: Validate ALL proposed changes
   - Verify regulatory references using RAG
   - Check if changes are necessary and correctly implemented
   - Output: "APPROVED" if all valid, or "REJECTED - Corrections Required" with detailed feedback

3. IF REJECTED: Generator Agent must revise the changes based on QA feedback and resubmit
   - Address EACH issue raised by QA
   - Provide corrected changes
   - DO NOT output "APPROVED" - only Generator and QA agents should

4. Iterate until QA outputs "APPROVED" (max {max_iterations} iterations)

5. Writer Agent: After QA approval, generate the final DOCX
   - Parse all approved changes
   - Invoke OpenXML DOCX Generator tool
   - Apply tracked changes to master ICF
   - Save to median folder with timestamp
   - Report generation status

IMPORTANT: 
- Generator Agent: Only propose changes, never approve them
- QA Agent: Only you can output "APPROVED" or "REJECTED"
- Writer Agent: Only generate DOCX AFTER "APPROVED" from QA
- Continue iterations until QA approval or max iterations reached

Workflow: Generator → QA → (if approved) → Writer → Final Output
"""
    
    # Create Magentic Orchestration
    print("\nCreating Magentic Orchestration...")
    
    magentic_orchestration = MagenticOrchestration(
        members=await create_agents(),
        manager=StandardMagenticManager(
            chat_completion_service=AzureChatCompletion(
                deployment_name=config.AZURE_OPENAI_DEPLOYMENT_NAME,
                endpoint=config.AZURE_OPENAI_ENDPOINT,
                api_key=config.AZURE_OPENAI_API_KEY,
                api_version=config.AZURE_OPENAI_API_VERSION,
            )
        ),
        agent_response_callback=agent_response_callback,
    )
    
    # Create and start runtime
    print("\nStarting runtime...")
    runtime = InProcessRuntime()
    runtime.start()
    
    # Invoke orchestration with iterative refinement
    print("\nInvoking Magentic Orchestration...")
    print("="*80)
    print(f"Max iterations: {max_iterations}")
    print("="*80)
    
    orchestration_result = await magentic_orchestration.invoke(
        task=task,
        runtime=runtime,
    )
    
    # Wait for results
    result_message = await orchestration_result.get()
    
    # Extract text content from ChatMessageContent
    if hasattr(result_message, 'content'):
        value = result_message.content
    else:
        value = str(result_message)
    
    print("\n" + "="*80)
    print("Final Result from Magentic Orchestration")
    print("="*80)
    print(value)
    
    # Check if approved by looking at all agent messages
    approved = False
    writer_generated = False
    
    for msg in agent_messages:
        if msg['agent'] == 'ICFQAAgent' and 'APPROVED' in msg['content'].upper():
            approved = True
        if msg['agent'] == 'ICFWriterAgent' and 'Generation Complete' in msg['content']:
            writer_generated = True
    
    # Check if approved
    if not approved:
        print("\n" + "="*80)
        print("⚠️  Orchestration completed but changes not approved")
        print("="*80)
        
        # Check if it's a rejection with feedback
        if "REJECTED" in value.upper():
            print("\nQA Agent rejected the changes. The orchestration should have continued iterations.")
            print("This may indicate max iterations was reached before approval.")
            print("\nLast QA Feedback:")
            # Extract rejection feedback
            lines = value.split('\n')
            for i, line in enumerate(lines):
                if 'REJECTED' in line.upper():
                    print('\n'.join(lines[i:min(i+20, len(lines))]))
                    break
        
        print("\nPlease review the feedback. You may need to:")
        print("  1. Increase --max-iterations")
        print("  2. Improve regulatory data in AI Search index")
        print("  3. Adjust agent prompts for better compliance")
        return 1
    
    # If Writer Agent already generated the file, skip manual generation
    if writer_generated:
        print("\n" + "="*80)
        print("✅ Writer Agent completed DOCX generation")
        print("="*80)
        print("\nSkipping manual generation - Writer Agent handled it")
        
        # Find the generated file in median folder
        median_files = sorted(Path("median").glob("ICF_*.docx"), key=lambda p: p.stat().st_mtime, reverse=True)
        if median_files:
            latest_file = median_files[0]
            print(f"Latest median file: {latest_file}")

            # Copy to output
            shutil.copy2(latest_file, output)
            print(f"Copied to output: {output}")

            # Remove the median file after copying to final output
            try:
                latest_path = Path(latest_file)
                if latest_path.exists():
                    latest_path.unlink()
                    print(f"Removed median file: {latest_file}")
            except Exception as e:
                print(f"Warning: failed to remove median file {latest_file}: {e}")

            return 0
        else:
            print("\n⚠️  Writer Agent claimed to generate file but it's not found in median folder")
            print("Falling back to manual generation...")
    
    # Parse and apply changes
    try:
        print("\n" + "="*80)
        print("Parsing Changes and Applying Tracked Changes")
        print("="*80)
        
        # Build full conversation from collected messages
        full_conversation = ""
        for msg in agent_messages:
            full_conversation += f"\n{'='*80}\n"
            full_conversation += f"Agent: {msg['agent']}\n"
            full_conversation += f"{'='*80}\n"
            full_conversation += msg['content'] + "\n"
        
        # Save the full conversation for debugging
        conversation_log = f"logs/conversation_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
        with open(conversation_log, 'w', encoding='utf-8') as f:
            f.write(full_conversation)
        print(f"Full conversation saved to: {conversation_log}")
        
        # Extract changes from the agent conversation (use full conversation, not just final summary)
        print("\nAttempting to parse changes from response...")
        changes = parse_changes_from_response(full_conversation)
        
        if not changes:
            print("\n⚠️  No changes extracted from orchestration result")
            return 1
        
        print(f"\nExtracted {len(changes)} changes:")
        for i, change in enumerate(changes, 1):
            change_type = change.get('change_type', 'unknown')
            location = change.get('location', 'Unknown')
            print(f"  {i}. {change_type} at '{location}'")
        
        # Generate DOCX with OpenXML tracked changes in median folder
        print(f"\n{'='*80}")
        print("Generating DOCX with OpenXML Tracked Changes")
        print(f"{'='*80}")
        median_filename = f"ICF_{country}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.docx"
        median_output = openxml_generator.create_icf_with_tracked_changes(
            master_docx_path=input_path,
            changes=changes,
            output_filename=median_filename,
            country=country
        )
        
        print(f"\n✅ DOCX generated in median folder: {median_output}")
        
        # Validate the generated DOCX
        print(f"\n{'='*80}")
        print("Validating Generated DOCX with Document Intelligence")
        print(f"{'='*80}")
        
        validated_doc = di_tool.extract_with_tracked_changes(median_output)
        tracked_changes = validated_doc.get('tracked_changes', {})
        
        print(f"\n📊 Document Validation Results:")
        print(f"  - Insertions found: {len(tracked_changes.get('insertions', []))}")
        print(f"  - Deletions found: {len(tracked_changes.get('deletions', []))}")
        print(f"  - Comments found: {len(tracked_changes.get('comments', []))}")
        print(f"  - Total sections: {validated_doc['metadata']['total_sections']}")
        print(f"  - Total paragraphs: {validated_doc['metadata']['total_paragraphs']}")
        
        # Copy to final output location
        print(f"\n{'='*80}")
        print("Copying to Final Output Location")
        print(f"{'='*80}")
        
        import shutil
        shutil.copy(median_output, output)
        output_file = output

        # Remove the median file after copying to final output
        try:
            median_path = Path(median_output)
            if median_path.exists():
                median_path.unlink()
                print(f"Removed median file: {median_output}")
        except Exception as e:
            print(f"Warning: failed to remove median file {median_output}: {e}")
        
        print(f"✅ Final output: {output_file}")
        
        print(f"\n{'='*80}")
        print(f"✅ SUCCESS! ICF Generation Complete")
        print(f"{'='*80}")
        print(f"\n📁 Output Locations:")
        print(f"  • Median folder (working copy): {median_output}")
        print(f"  • Final output: {output_file}")
        print(f"\n📊 Document Statistics:")
        print(f"  • Total tracked changes applied: {len(changes)}")
        print(f"  • Insertions (OpenXML <w:ins>): {len(tracked_changes.get('insertions', []))}")
        print(f"  • Deletions (OpenXML <w:del>): {len(tracked_changes.get('deletions', []))}")
        print(f"  • Regulatory comments: {len(tracked_changes.get('comments', []))}")
        print(f"\n💡 How to Review:")
        print(f"  1. Open {output_file} in Microsoft Word")
        print(f"  2. Go to Review tab → Tracking section")
        print(f"  3. View tracked changes:")
        print(f"     • Red strikethrough = Deletions (<w:del>)")
        print(f"     • Blue underlined = Insertions (<w:ins>)")
        print(f"     • Comments = Regulatory justifications (<w:commentReference>)")
        print(f"  4. Accept/Reject changes as needed")
        print(f"  5. Check comments for regulatory references")
        
        # Save results
        results = {
            'success': True,
            'country': country,
            'input_path': input_path,
            'median_output': median_output,
            'final_output_path': output_file,
            'total_changes': len(changes),
            'timestamp': datetime.now().isoformat(),
            'changes': changes,
            'validation': {
                'insertions_count': len(tracked_changes.get('insertions', [])),
                'deletions_count': len(tracked_changes.get('deletions', [])),
                'comments_count': len(tracked_changes.get('comments', [])),
                'sections_count': validated_doc['metadata']['total_sections'],
                'paragraphs_count': validated_doc['metadata']['total_paragraphs']
            },
            'tracked_changes_details': tracked_changes,
            'agent_conversation': value
        }
        
        results_path = f"output/results_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        with open(results_path, 'w') as f:
            json.dump(results, f, indent=2)
        
        print(f"\nDetailed results saved to: {results_path}")
        
    except Exception as e:
        print(f"\n❌ Error applying changes: {e}")
        import traceback
        traceback.print_exc()
        # Attempt to remove any median files produced during this run, even on failure
        try:
            median_dir = Path("median")
            if median_dir.exists():
                for p in median_dir.glob(f"ICF_{country}_*.docx"):
                    try:
                        p.unlink()
                        print(f"Removed median file after failure: {p}")
                    except Exception as cleanup_err:
                        print(f"Warning: failed to remove median file {p}: {cleanup_err}")
        except Exception as cleanup_err:
            print(f"Warning: failed during median cleanup: {cleanup_err}")

        return 1
    
    # Stop runtime
    await runtime.stop_when_idle()
    
    print("\n" + "="*80)
    print("Workflow Complete")
    print("="*80)


if __name__ == "__main__":
    import sys
    # When invoked from CLI, run without parameters so argparse is used
    asyncio.run(main())
