"""
Learning Index Setup.
One-time script to create icf-learning-artifacts-{country} index in Azure AI Search.
Run this once per country before using the Learn Pipeline.
"""

import os
import sys
from typing import Optional

try:
    from azure.search.documents.indexes import SearchIndexClient
    from azure.search.documents.indexes.models import (
        SearchIndex,
        SimpleField,
        SearchableField,
        SearchFieldDataType,
        VectorSearch,
        HnswAlgorithmConfiguration,
        VectorSearchProfile,
        SearchField
    )
    from azure.core.credentials import AzureKeyCredential
    AZURE_SEARCH_AVAILABLE = True
except ImportError:
    AZURE_SEARCH_AVAILABLE = False
    print("❌ Azure Search SDK not installed. Run: pip install azure-search-documents")


class LearningIndexSetup:
    """
    Creates Azure AI Search index for learning artifacts.
    
    Index schema:
    - id: Unique pair ID
    - country: Country code
    - section_type: Section type (risks, consent, etc.)
    - ai_output: Original AI-generated text (rejected)
    - human_output: Client-corrected text (preferred)
    - context: Surrounding context
    - confidence: Confidence score
    - source_document_id: Source document ID
    - version: Document version
    - created_at: Timestamp
    - embedding: Vector embedding for semantic search
    """
    
    EMBEDDING_DIMENSIONS = 1536  # text-embedding-ada-002
    
    def __init__(self):
        self.endpoint = os.getenv("AI_SEARCH_ENDPOINT")
        self.api_key = os.getenv("AI_SEARCH_KEY")
        self.index_client: Optional[SearchIndexClient] = None
        
        if not AZURE_SEARCH_AVAILABLE:
            raise ImportError("Azure Search SDK not available")
        
        if not self.endpoint or not self.api_key:
            raise ValueError("AI_SEARCH_ENDPOINT and AI_SEARCH_KEY required")
        
        self.index_client = SearchIndexClient(
            endpoint=self.endpoint,
            credential=AzureKeyCredential(self.api_key)
        )
        print("✅ LearningIndexSetup initialized")
    
    def create_index(self, country: str) -> bool:
        """
        Create learning artifacts index for a specific country.
        
        Args:
            country: Country code (usa, canada, taiwan, etc.)
        
        Returns:
            True if created successfully
        """
        country_code = country.lower().replace(' ', '-').replace('_', '-')
        index_name = f"icf-learning-artifacts-{country_code}"
        
        print(f"\n{'='*60}")
        print(f"📚 Creating Learning Artifacts Index")
        print(f"   Index: {index_name}")
        print(f"   Country: {country_code.upper()}")
        print(f"{'='*60}")
        
        # Check if index already exists
        try:
            existing = self.index_client.get_index(index_name)
            print(f"  ⚠️ Index '{index_name}' already exists")
            print(f"     Documents: Use Azure Portal to check count")
            return True
        except Exception:
            pass  # Index doesn't exist, continue creating
        
        # Define fields
        fields = [
            SimpleField(
                name="id",
                type=SearchFieldDataType.String,
                key=True,
                filterable=True
            ),
            SimpleField(
                name="country",
                type=SearchFieldDataType.String,
                filterable=True,
                facetable=True
            ),
            SearchableField(
                name="section_type",
                type=SearchFieldDataType.String,
                filterable=True,
                facetable=True
            ),
            SearchableField(
                name="ai_output",
                type=SearchFieldDataType.String,
                analyzer_name="en.microsoft"
            ),
            SearchableField(
                name="human_output",
                type=SearchFieldDataType.String,
                analyzer_name="en.microsoft"
            ),
            SearchableField(
                name="context",
                type=SearchFieldDataType.String,
                analyzer_name="en.microsoft"
            ),
            SimpleField(
                name="confidence",
                type=SearchFieldDataType.Double,
                filterable=True,
                sortable=True
            ),
            SimpleField(
                name="source_document_id",
                type=SearchFieldDataType.String,
                filterable=True
            ),
            SimpleField(
                name="version",
                type=SearchFieldDataType.Int32,
                filterable=True,
                sortable=True
            ),
            SimpleField(
                name="created_at",
                type=SearchFieldDataType.String,
                filterable=True,
                sortable=True
            ),
            SearchField(
                name="embedding",
                type=SearchFieldDataType.Collection(SearchFieldDataType.Single),
                searchable=True,
                vector_search_dimensions=self.EMBEDDING_DIMENSIONS,
                vector_search_profile_name="learning-vector-profile"
            )
        ]
        
        # Configure vector search
        vector_search = VectorSearch(
            algorithms=[
                HnswAlgorithmConfiguration(
                    name="learning-hnsw-config",
                    parameters={
                        "m": 4,
                        "efConstruction": 400,
                        "efSearch": 500,
                        "metric": "cosine"
                    }
                )
            ],
            profiles=[
                VectorSearchProfile(
                    name="learning-vector-profile",
                    algorithm_configuration_name="learning-hnsw-config"
                )
            ]
        )
        
        # Create index
        index = SearchIndex(
            name=index_name,
            fields=fields,
            vector_search=vector_search
        )
        
        try:
            result = self.index_client.create_index(index)
            print(f"  ✅ Index '{index_name}' created successfully")
            print(f"     Fields: {len(fields)}")
            print(f"     Vector search: Enabled (HNSW)")
            return True
        except Exception as e:
            print(f"  ❌ Failed to create index: {e}")
            return False
    
    def delete_index(self, country: str) -> bool:
        """
        Delete learning artifacts index for a country.
        
        Args:
            country: Country code
        
        Returns:
            True if deleted successfully
        """
        country_code = country.lower().replace(' ', '-').replace('_', '-')
        index_name = f"icf-learning-artifacts-{country_code}"
        
        try:
            self.index_client.delete_index(index_name)
            print(f"  ✅ Index '{index_name}' deleted")
            return True
        except Exception as e:
            print(f"  ❌ Failed to delete index: {e}")
            return False
    
    def list_indexes(self) -> None:
        """List all learning artifact indexes."""
        print("\n📋 Learning Artifact Indexes:")
        
        try:
            indexes = self.index_client.list_indexes()
            learning_indexes = []
            
            for idx in indexes:
                if idx.name.startswith("icf-learning-artifacts-"):
                    learning_indexes.append(idx.name)
            
            if learning_indexes:
                for name in learning_indexes:
                    print(f"   - {name}")
            else:
                print("   (none found)")
                
        except Exception as e:
            print(f"  ❌ Failed to list indexes: {e}")


def main():
    """CLI entry point."""
    if len(sys.argv) < 2:
        print("Usage:")
        print("  python learning_index_setup.py create <country>")
        print("  python learning_index_setup.py delete <country>")
        print("  python learning_index_setup.py list")
        print("")
        print("Examples:")
        print("  python learning_index_setup.py create usa")
        print("  python learning_index_setup.py create canada")
        print("  python learning_index_setup.py list")
        return
    
    action = sys.argv[1].lower()
    
    try:
        setup = LearningIndexSetup()
    except Exception as e:
        print(f"❌ Setup failed: {e}")
        return
    
    if action == "create":
        if len(sys.argv) < 3:
            print("❌ Country required. Example: python learning_index_setup.py create usa")
            return
        country = sys.argv[2]
        setup.create_index(country)
        
    elif action == "delete":
        if len(sys.argv) < 3:
            print("❌ Country required. Example: python learning_index_setup.py delete usa")
            return
        country = sys.argv[2]
        confirm = input(f"⚠️ Delete index for {country}? (yes/no): ")
        if confirm.lower() == "yes":
            setup.delete_index(country)
        else:
            print("Cancelled.")
            
    elif action == "list":
        setup.list_indexes()
        
    else:
        print(f"❌ Unknown action: {action}")


if __name__ == "__main__":
    main()