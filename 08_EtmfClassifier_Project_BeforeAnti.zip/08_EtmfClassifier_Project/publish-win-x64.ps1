$ErrorActionPreference = "Stop"
Push-Location $PSScriptRoot
try {
    dotnet publish EtmfClassifier.csproj -c Release -r win-x64 --self-contained true -o publish
    if ($LASTEXITCODE -ne 0) { throw "Publish failed." }
    if (-not (Test-Path "publish/EtmfClassifier.exe")) { throw "Executable not found." }
    Write-Host "Executable: $PSScriptRoot/publish/EtmfClassifier.exe"
} finally { Pop-Location }
