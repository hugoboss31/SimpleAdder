"""
Customization Plan Manager for country-specific plan handling.
Manages indexing and retrieval of country-specific customization plans.
"""

from typing import Optional, Dict, Any, List
from pathlib import Path
from datetime import datetime
import json
from azure.search.documents import SearchClient
from azure.core.credentials import AzureKeyCredential
from openai import AzureOpenAI
from config import config
from utils.country_manager import CountryValidator
from tools.excel_parser import ExcelCustomizationPlanParser
from tools.customization_plan_index_manager import CustomizationPlanIndexManager
from schemas.icf_schemas import CustomizationPlan


class CustomizationPlanManager:
    """
    Manages country-specific customization plan documents.
    Handles indexing with country metadata for separate storage.
    """
    
    def __init__(self):
        """Initialize the customization plan manager."""
        self.search_endpoint = config.get_search_endpoint()
        self.search_key = config.get_search_key()
        self.index_name = config.CUSTOMIZATION_PLAN_INDEX_NAME
        
        self.openai_endpoint = config.AZURE_OPENAI_ENDPOINT
        self.openai_key = config.AZURE_OPENAI_API_KEY
        self.embedding_deployment = config.EMBEDDINGS_MODEL_DEPLOYMENT
        
        if not all([self.search_endpoint, self.search_key]):
            raise ValueError("AI Search credentials not configured")
        
        # Note: Index creation should be handled separately (similar to ICFIndexManager)
        # For now, we assume the index exists or will be created
        
        if not self.openai_endpoint or not self.openai_key:
            raise ValueError(
                "OpenAI client is required but not configured. "
                "Please set AZURE_OPENAI_ENDPOINT and AZURE_OPENAI_API_KEY in .env"
            )
        
        self.openai_client = AzureOpenAI(
            azure_endpoint=self.openai_endpoint,
            api_key=self.openai_key,
            api_version=config.AZURE_OPENAI_API_VERSION
        )
        
        self.excel_parser = ExcelCustomizationPlanParser()
        
        # Initialize search client for queries
        self.search_client = SearchClient(
            endpoint=self.search_endpoint,
            index_name=self.index_name,
            credential=AzureKeyCredential(self.search_key)
        )
    
    def parse_and_index_plan(
        self,
        excel_path: str,
        country: str,
        plan_id: Optional[str] = None
    ) -> CustomizationPlan:
        """
        Parse customization plan and index it with country metadata.
        
        Args:
            excel_path: Path to Excel customization plan file
            country: Country code (e.g., "USA", "CAN")
            plan_id: Optional plan identifier (auto-generated if not provided)
            
        Returns:
            CustomizationPlan object
        """
        # Validate and normalize country
        normalized_country = CountryValidator.normalize(country)
        if not normalized_country:
            raise ValueError(f"Invalid country code: {country}")
        
        # Generate plan_id if not provided
        if not plan_id:
            plan_id = f"{normalized_country}_plan_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        
        # Parse the Excel file
        customization_plan = self.excel_parser.parse_customization_plan(
            excel_path=excel_path,
            country=normalized_country,
            plan_id=plan_id
        )
        
        # Index plan items
        try:
            self.index_plan(customization_plan)
        except Exception as e:
            print(f"[WARN] Failed to index customization plan: {e}")
            print("[INFO] Continuing without indexing...")
        
        return customization_plan
    
    def get_plan_id_for_country(self, country: str, blob_path: Optional[str] = None) -> str:
        """
        Generate a standardized plan ID for a country.
        
        Args:
            country: Country code
            blob_path: Optional blob path to extract additional info
            
        Returns:
            Plan ID string (e.g., "USA_plan_20241216_123456")
        """
        normalized_country = CountryValidator.normalize(country)
        if not normalized_country:
            raise ValueError(f"Invalid country code: {country}")
        
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        
        if blob_path:
            # Extract filename from blob path if available
            filename = Path(blob_path).stem
            return f"{normalized_country}_plan_{filename}_{timestamp}"
        
        return f"{normalized_country}_plan_{timestamp}"
    
    def index_plan(self, customization_plan: CustomizationPlan) -> Dict[str, Any]:
        """
        Index customization plan items into Azure AI Search.
        
        Args:
            customization_plan: CustomizationPlan object to index
            
        Returns:
            Dictionary with indexing status and counts
        """
        # Ensure index exists
        index_manager = CustomizationPlanIndexManager()
        if not index_manager.index_exists():
            print(f"[INFO] Creating customization plan index: {index_manager.index_name}")
            index_manager.create_index()
        
        # Initialize search client
        search_client = SearchClient(
            endpoint=self.search_endpoint,
            index_name=self.index_name,
            credential=AzureKeyCredential(self.search_key)
        )
        
        print(f"[INFO] Indexing {len(customization_plan.items)} customization plan items for {customization_plan.country}...")
        
        documents = []
        skipped_count = 0
        
        for item in customization_plan.items:
            # Generate embedding text: topic + requirement_text + synonyms
            embedding_parts = [item.topic, item.requirement_text]
            if item.synonyms:
                embedding_parts.extend(item.synonyms)
            embedding_text = " ".join(str(part) for part in embedding_parts if part).strip()
            
            if not embedding_text:
                skipped_count += 1
                print(f"[WARN] Skipping item {item.item_id}: no text content")
                continue
            
            try:
                embedding = self._generate_embedding(embedding_text)
            except Exception as e:
                skipped_count += 1
                print(f"[WARN] Failed to generate embedding for item {item.item_id}: {e}")
                continue
            
            # Create unique document ID: country_plan_id_item_id
            doc_id = f"{customization_plan.country}_{customization_plan.plan_id}_{item.item_id}"
            
            # Create document for indexing
            doc = {
                "id": doc_id,
                "item_id": item.item_id,
                "plan_id": customization_plan.plan_id,
                "country": customization_plan.country,
                "topic": item.topic,
                "requirement_text": item.requirement_text,
                "requirement_type": item.requirement_type.value,
                "applies_to": item.applies_to or "",
                "synonyms": " ".join(item.synonyms) if item.synonyms else "",
                "importance": item.importance or "",
                "contentVector": embedding,
                "metadata": json.dumps(item.metadata) if item.metadata else ""
            }
            documents.append(doc)
        
        # Upload documents in batches
        batch_size = 100
        indexed_count = 0
        
        for i in range(0, len(documents), batch_size):
            batch = documents[i:i + batch_size]
            try:
                result = search_client.upload_documents(documents=batch)
                indexed_count += len([r for r in result if r.succeeded])
            except Exception as e:
                print(f"[ERROR] Failed to upload batch {i//batch_size + 1}: {e}")
        
        print(f"[OK] Indexed {indexed_count}/{len(documents)} customization plan items (skipped {skipped_count})")
        
        return {
            "success": True,
            "indexed_count": indexed_count,
            "total_items": len(customization_plan.items),
            "skipped_count": skipped_count
        }
    
    def retrieve_plan_from_index(self, plan_id: str, country: str) -> CustomizationPlan:
        """
        Retrieve customization plan items from index and reconstruct CustomizationPlan object.
        
        Args:
            plan_id: Plan ID to retrieve
            country: Country code for filtering
            
        Returns:
            CustomizationPlan object with all items
            
        Raises:
            ValueError: If plan not found or retrieval fails
        """
        from schemas.icf_schemas import CustomizationPlanItem, RequirementType
        
        try:
            # Normalize country
            normalized_country = CountryValidator.normalize(country)
            if not normalized_country:
                raise ValueError(f"Invalid country code: {country}")
            
            # Query all plan items for this plan_id and country
            filter_expr = f"plan_id eq '{plan_id}' and country eq '{normalized_country}'"
            
            # Retrieve all items
            items_data = []
            search_options = {
                "filter": filter_expr,
                "top": 10000,  # Large enough for most plans
                "select": ["item_id", "plan_id", "country", "topic", "requirement_text",
                          "requirement_type", "applies_to", "synonyms", "importance", "metadata"]
            }
            
            # Note: Sorting by item_id will be done in Python after retrieval
            results = self.search_client.search(search_text="*", **search_options)
            
            # Collect all results first, then sort by item_id
            results_list = list(results)
            # Sort by item_id (will be numeric string like "USA-01", "USA-02", etc.)
            results_list.sort(key=lambda r: r.get("item_id", ""))
            
            source_file = None
            for result in results_list:
                # Parse synonyms from string back to list
                # Synonyms are stored as space-separated values
                # Note: If synonyms contain spaces, this may not be perfect, but typical synonyms are short phrases
                synonyms_str = result.get("synonyms", "")
                if synonyms_str and synonyms_str.strip():
                    # Split by spaces and filter out empty strings
                    synonyms = [s.strip() for s in synonyms_str.split() if s.strip()]
                else:
                    synonyms = []
                
                # Parse metadata if it's a JSON string
                metadata = {}
                if result.get("metadata"):
                    try:
                        if isinstance(result["metadata"], str):
                            metadata = json.loads(result["metadata"])
                        else:
                            metadata = result["metadata"]
                    except (json.JSONDecodeError, TypeError):
                        metadata = {}
                
                # Map requirement_type string to enum
                req_type_str = result.get("requirement_type", "mandatory")
                try:
                    requirement_type = RequirementType(req_type_str)
                except ValueError:
                    requirement_type = RequirementType.MANDATORY  # Default
                
                item = CustomizationPlanItem(
                    item_id=result.get("item_id", ""),
                    topic=result.get("topic", ""),
                    country=result.get("country", normalized_country),
                    requirement_text=result.get("requirement_text", ""),
                    requirement_type=requirement_type,
                    applies_to=result.get("applies_to"),
                    synonyms=synonyms,
                    importance=result.get("importance"),
                    metadata=metadata
                )
                items_data.append(item)
            
            if not items_data:
                raise ValueError(f"No customization plan items found for plan_id: {plan_id}, country: {country}")
            
            # Build CustomizationPlan object
            customization_plan = CustomizationPlan(
                plan_id=plan_id,
                country=normalized_country,
                source_file=source_file or f"indexed_plan_{plan_id}",  # Use indexed source indicator
                items=items_data,
                metadata={}
            )
            
            print(f"[OK] Retrieved {len(items_data)} customization plan items for plan_id: {plan_id}, country: {country}")
            return customization_plan
            
        except ValueError:
            raise
        except Exception as e:
            print(f"[ERROR] Failed to retrieve customization plan for plan_id {plan_id}, country {country}: {e}")
            raise ValueError(f"Failed to retrieve customization plan: {str(e)}") from e
    
    def _generate_embedding(self, text: str) -> List[float]:
        """Generate embedding vector for text."""
        response = self.openai_client.embeddings.create(
            model=self.embedding_deployment,
            input=text
        )
        return response.data[0].embedding

