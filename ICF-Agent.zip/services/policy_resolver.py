"""
Policy Resolver - Loads policies in precedence STUDY > COUNTRY > GLOBAL (Story 827617).
Compiles into system prompt text for generator/regenerator.
"""

import os
from typing import Dict, Any, List, Optional

from config import Config
from services.app_insights import get_logger

try:
    from azure.search.documents import SearchClient
    from azure.core.credentials import AzureKeyCredential
    AZURE_SEARCH_AVAILABLE = True
except ImportError:
    AZURE_SEARCH_AVAILABLE = False

INDEX_NAME = "icf_agent_policies"


class PolicyResolver:
    """Resolves agent policies in precedence order: STUDY > COUNTRY > GLOBAL."""

    def __init__(self):
        self.logger = get_logger("policy_resolver")
        self._client = None
        if AZURE_SEARCH_AVAILABLE:
            try:
                self._client = SearchClient(
                    endpoint=Config.get_search_endpoint(),
                    index_name=INDEX_NAME,
                    credential=Config.get_search_credential(),
                )
            except Exception as e:
                self.logger.warning(f"Policy index client init failed: {e}")

    def resolve(
        self,
        country_code: str,
        study_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Load policies: isActive eq true, latest version per type/scope.
        Precedence: STUDY > COUNTRY > GLOBAL.
        Returns: { policies: [...], compiledText: str, snapshot: dict }
        """
        if not self._client:
            return {"policies": [], "compiledText": "", "snapshot": {}}

        policies: List[Dict] = []
        try:
            filter_expr = "isActive eq true"
            results = self._client.search(search_text="*", filter=filter_expr, top=100)
            raw = list(results)
            # Sort by scope precedence: STUDY(3) > COUNTRY(2) > GLOBAL(1)
            scope_order = {"STUDY": 3, "COUNTRY": 2, "GLOBAL": 1}
            for r in raw:
                scope = r.get("scope", "GLOBAL")
                cc = r.get("countryCode", "")
                sid = r.get("studyId", "")
                if scope == "STUDY" and study_id and sid != study_id:
                    continue
                if scope == "COUNTRY" and cc and cc.upper() != (country_code or "").upper():
                    continue
                policies.append({
                    "policyId": r.get("policyId"),
                    "scope": scope,
                    "policyType": r.get("policyType"),
                    "content": r.get("content", ""),
                    "version": r.get("version", 1),
                })
            policies.sort(key=lambda p: (scope_order.get(p["scope"], 0), -(p.get("version") or 0)), reverse=True)
        except Exception as e:
            self.logger.warning(f"Policy query failed: {e}")
            return {"policies": [], "compiledText": "", "snapshot": {}}

        lines = []
        for p in policies:
            lines.append(f"[{p['scope']} {p['policyType']}] {p['content']}")
        compiled = "\n\n".join(lines) if lines else ""

        snapshot = {"policies": policies, "countryCode": country_code, "studyId": study_id}
        return {"policies": policies, "compiledText": compiled, "snapshot": snapshot}

    def save_snapshot(self, snapshot: Dict[str, Any], icf_case_id: str, job_id: str) -> Optional[str]:
        """Save policy snapshot to Blob: cases/{icfCaseId}/jobs/{jobId}/policy_snapshot.json"""
        try:
            import json
            from azure.storage.blob import BlobServiceClient, ContentSettings
        except ImportError:
            return None
        conn_str = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
        container = os.getenv("AZURE_STORAGE_CONTAINER_NAME", "icf-country-dev")
        if not conn_str:
            return None
        blob_path = f"cases/{icf_case_id}/jobs/{job_id}/policy_snapshot.json"
        try:
            blob_service = BlobServiceClient.from_connection_string(conn_str)
            blob_client = blob_service.get_blob_client(container=container, blob=blob_path)
            blob_client.upload_blob(
                json.dumps(snapshot, indent=2, default=str),
                overwrite=True,
                content_settings=ContentSettings(content_type="application/json"),
            )
            return blob_client.url
        except Exception as e:
            self.logger.warning(f"Policy snapshot upload failed: {e}")
            return None
