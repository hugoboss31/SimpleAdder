"""
Test script for the /generate-country-icf API endpoint.

This script tests the complete flow by uploading test files.
"""

import requests
import sys
from pathlib import Path


def test_generate_country_icf():
    """Test the generate-country-icf endpoint."""
    
    print("="*80)
    print("Testing /generate-country-icf API Endpoint")
    print("="*80)
    print()
    
    # Check if test files exist
    test_data_dir = Path("test_data")
    global_icf_path = test_data_dir / "global_icf.docx"
    excel_plan_path = test_data_dir / "usa_customization_plan.xlsx"
    
    if not global_icf_path.exists():
        print("[ERROR] Test Global ICF not found. Run create_test_data.py first.")
        return 1
    
    if not excel_plan_path.exists():
        print("[ERROR] Test Excel plan not found. Run create_test_data.py first.")
        return 1
    
    # API endpoint
    url = "http://localhost:8000/generate-country-icf"
    
    print(f"[INFO] Uploading files to: {url}")
    print(f"  Global ICF: {global_icf_path}")
    print(f"  Customization Plan: {excel_plan_path}")
    print()
    
    try:
        # Prepare files
        files = {
            "global_icf": open(global_icf_path, "rb"),
            "customization_plan": open(excel_plan_path, "rb")
        }
        
        # Prepare form data
        data = {
            "country": "USA",
            "max_iterations": 5
        }
        
        print("[INFO] Sending request...")
        response = requests.post(url, files=files, data=data, timeout=300)  # 5 min timeout
        
        # Close files
        files["global_icf"].close()
        files["customization_plan"].close()
        
        # Check response
        if response.status_code == 200:
            result = response.json()
            
            print("[SUCCESS] Request completed!")
            print()
            print("Results:")
            print(f"  Success: {result.get('success')}")
            print(f"  Country: {result.get('country')}")
            print(f"  Output File: {result.get('output_file')}")
            
            if result.get('coverage_report'):
                cr = result['coverage_report']
                print()
                print("Coverage Report:")
                print(f"  Total Items: {cr.get('total_plan_items')}")
                print(f"  Handled Items: {cr.get('handled_items')} ({cr.get('coverage_percentage', 0):.1f}%)")
                print(f"  Unmapped Items: {cr.get('unmapped_items')}")
                print(f"  Low Confidence: {len(cr.get('low_confidence_items', []))}")
                print(f"  Requires Review: {len(cr.get('requires_review_items', []))}")
            
            if result.get('blob_url'):
                print()
                print(f"  Blob URL: {result.get('blob_url')}")
            
            if result.get('errors'):
                print()
                print("Warnings/Errors:")
                for error in result['errors']:
                    print(f"  - {error}")
            
            return 0 if result.get('success') else 1
            
        else:
            print(f"[ERROR] Request failed with status {response.status_code}")
            print(f"Response: {response.text}")
            return 1
            
    except requests.exceptions.ConnectionError:
        print("[ERROR] Could not connect to API. Is the server running?")
        print("Start the server with: python app.py")
        return 1
    except Exception as e:
        print(f"[ERROR] Test failed: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    exit_code = test_generate_country_icf()
    sys.exit(exit_code)

