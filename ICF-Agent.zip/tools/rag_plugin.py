"""
Semantic Kernel plugin for RAG tool to enable dynamic regulatory queries by agents.
"""

from typing import List, Dict, Any, Annotated
from semantic_kernel.functions import kernel_function
from tools.rag_tool import RAGTool
from config import config


class RAGPlugin:
    """
    Semantic Kernel plugin that wraps RAGTool for dynamic regulatory queries.
    Allows agents to query regulatory requirements on-demand during generation.
    """
    
    def __init__(self):
        """Initialize the RAG plugin with RAGTool."""
        self.rag_tool = RAGTool()
    
    @kernel_function(
        description="Query regulatory requirements for informed consent forms. Use this to dynamically retrieve country-specific regulations, FDA guidelines, EMA requirements, ICH standards, or other regulatory text relevant to ICF customization. Returns semantically matched regulatory chunks with sources and content.",
        name="query_regulations"
    )
    def query_regulations(
        self,
        query: Annotated[str, "Natural language query for regulatory requirements (e.g., 'compensation requirements', 'data protection rules', 'withdrawal procedures')"],
        country: Annotated[str, "Target country code (e.g., 'USA', 'GBR', 'DEU')"],
        top_k: Annotated[int, "Number of regulatory chunks to retrieve (default: 10, max: 20)"] = 10
    ) -> str:
        """
        Query regulatory knowledge base using hybrid search (BM25 + vector).
        
        This function enables dynamic RAG queries - agents can call this during
        generation to retrieve relevant regulatory context on-demand.
        
        Args:
            query: Natural language query describing what regulatory information is needed
            country: Target country code for context
            top_k: Number of results to return (default 10, max 20)
            
        Returns:
            JSON-formatted string with regulatory requirements
        """
        try:
            # Limit top_k to prevent excessive results
            top_k = min(top_k, 20)
            top_k = max(top_k, 1)
            
            # Build comprehensive query
            regulatory_query = f"{query} {country} informed consent requirements"
            
            # Query RAG tool
            regulations = self.rag_tool.query_regulations(
                query=regulatory_query,
                country=country,
                top_k=top_k
            )
            
            # Format results as JSON string for agent consumption
            import json
            formatted_results = []
            for reg in regulations:
                formatted_results.append({
                    "source": reg.get("source", "Unknown"),
                    "content": reg.get("content", ""),
                    "relevance_score": reg.get("relevance_score", 0.0),
                    "doc_type": reg.get("doc_type", ""),
                    "id": reg.get("id", "")
                })
            
            result_json = {
                "query": query,
                "country": country,
                "results_count": len(formatted_results),
                "regulations": formatted_results
            }
            
            return json.dumps(result_json, indent=2)
            
        except Exception as e:
            import json
            error_result = {
                "query": query,
                "country": country,
                "error": str(e),
                "results_count": 0,
                "regulations": []
            }
            return json.dumps(error_result)
    
    @kernel_function(
        description="Verify a specific regulatory reference (e.g., 'FDA 21 CFR 50.25(a)(1)') by searching the regulatory knowledge base. Use this to validate that a regulatory citation exists and is accurate.",
        name="verify_regulatory_reference"
    )
    def verify_regulatory_reference(
        self,
        reference: Annotated[str, "Regulatory reference to verify (e.g., 'FDA 21 CFR 50.25(a)(1)', 'ICH E6(R3)')"],
        country: Annotated[str, "Target country code"]
    ) -> str:
        """
        Verify a regulatory reference exists in the knowledge base.
        
        Args:
            reference: Regulatory citation to verify
            country: Target country for context
            
        Returns:
            JSON-formatted verification result
        """
        try:
            verification = self.rag_tool.verify_reference(reference, country)
            
            import json
            return json.dumps(verification, indent=2)
            
        except Exception as e:
            import json
            return json.dumps({
                "valid": False,
                "reference": reference,
                "error": str(e),
                "message": f"Verification failed: {str(e)}"
            })

