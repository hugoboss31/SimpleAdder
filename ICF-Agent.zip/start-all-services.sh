#!/bin/bash
# Bash script to start all ICF POC services (for Linux/Mac)
# Make sure you have:
# 1. Node.js installed
# 2. Python 3.x with venv activated
# 3. Environment variables configured (.env files)

echo "🚀 Starting ICF POC Services..."
echo ""

# Function to check if port is in use
check_port() {
    lsof -i :$1 > /dev/null 2>&1
}

# Start Backend
if check_port 5001; then
    echo "⚠️  Backend is already running on port 5001"
else
    echo "📦 Starting Backend (Node.js) on port 5001..."
    cd icf-backend
    npm run dev &
    BACKEND_PID=$!
    cd ..
    sleep 3
fi

# Start Agent Service
if check_port 8000; then
    echo "⚠️  Agent service is already running on port 8000"
else
    echo "🐍 Starting Agent Service (Python/FastAPI) on port 8000..."
    cd icf-agent
    source venv/bin/activate
    python app.py &
    AGENT_PID=$!
    cd ..
    sleep 3
fi

# Start Web App
if check_port 5173; then
    echo "⚠️  Web app is already running on port 5173"
else
    echo "🌐 Starting Web App (React) on port 5173..."
    cd icf-web
    VITE_API_BASE_URL=http://localhost:5001/api npm run dev &
    WEB_PID=$!
    cd ..
    sleep 3
fi

echo ""
echo "✅ All services starting..."
echo ""
echo "📍 Service URLs:"
echo "   Backend API:  http://localhost:5001/api"
echo "   Agent API:    http://localhost:8000"
echo "   Web App:      http://localhost:5173"
echo ""
echo "⏳ Waiting for services to initialize..."
sleep 5

# Check service health
echo ""
echo "🔍 Checking service health..."

if curl -s http://localhost:5001/api/health > /dev/null; then
    echo "✅ Backend is healthy"
else
    echo "⚠️  Backend not responding yet"
fi

if curl -s http://localhost:8000/ > /dev/null; then
    echo "✅ Agent service is healthy"
else
    echo "⚠️  Agent service not responding yet"
fi

echo ""
echo "🎉 Setup complete! Open http://localhost:5173 in your browser"
echo ""
echo "💡 Note: Make sure you have configured environment variables"
echo ""
echo "Press Ctrl+C to stop all services"

# Trap Ctrl+C to kill background processes
trap "kill $BACKEND_PID $AGENT_PID $WEB_PID 2>/dev/null; exit" INT TERM

# Wait for user interrupt
wait

