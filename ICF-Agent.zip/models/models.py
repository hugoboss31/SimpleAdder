"""
Data models for ICF Generator.
Structured representations for documents, sections, and requirements.
Fully generic - works for any country.
"""

from dataclasses import dataclass, field
from typing import List, Dict, Optional, Any
from datetime import datetime
from pydantic import BaseModel, Field


@dataclass
class ParagraphNode:
    """Represents a single paragraph in the document."""
    para_id: str
    text: str
    page_no: int = 0
    order_index: int = 0
    is_heading: bool = False
    heading_level: int = 0
    font_bold: bool = False
    font_size: float = 11.0
    embedding: Optional[List[float]] = None


@dataclass
class SectionNode:
    """Represents a document section with hierarchy."""
    section_id: str
    heading: str
    level: int = 1
    page_no: int = 0
    order_index: int = 0
    parent_id: Optional[str] = None
    children: List['SectionNode'] = field(default_factory=list)
    paragraphs: List[ParagraphNode] = field(default_factory=list)
    full_text: str = ""
    embedding: Optional[List[float]] = None
    
    start_para_idx: int = 0
    end_para_idx: int = 0


@dataclass
class DocumentTree:
    """Complete document structure."""
    doc_id: str
    filename: str
    title: str
    sections: List[SectionNode] = field(default_factory=list)
    total_pages: int = 0
    created_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    
    def get_all_sections_flat(self) -> List[SectionNode]:
        """Get all sections in document order (flattened)."""
        result = []
        
        def collect(sections: List[SectionNode]):
            for sec in sections:
                result.append(sec)
                collect(sec.children)
        
        collect(self.sections)
        return result
    
    def get_section_by_id(self, section_id: str) -> Optional[SectionNode]:
        """Find section by ID."""
        for sec in self.get_all_sections_flat():
            if sec.section_id == section_id:
                return sec
        return None


@dataclass
class RequirementRecord:
    """Single requirement from customization plan."""
    req_id: str
    topic: str
    requirement_text: str
    country: str = ""
    requirement_type: str = "mandatory"
    applies_to: str = "existing_section"
    is_nap: bool = False
    embedding: Optional[List[float]] = None
    
    @classmethod
    def from_excel_row(
        cls, 
        row_idx: int, 
        topic: str, 
        content: str,
        country: str = ""
    ) -> 'RequirementRecord':
        """Create from Excel row data."""
        is_nap = "nap" in content.lower() or "not applicable" in content.lower()
        return cls(
            req_id=f"RAG-{row_idx:03d}",
            topic=topic or "General",
            requirement_text=content,
            country=country,
            is_nap=is_nap
        )


@dataclass
class MatchedPair:
    """A requirement matched to a document section."""
    requirement: RequirementRecord
    matched_section: SectionNode
    confidence: float = 0.0
    match_type: str = "vector"
    
    def to_prompt_context(self) -> str:
        """Format for LLM prompt."""
        country_info = f" ({self.requirement.country})" if self.requirement.country else ""
        return f"""
[{self.requirement.req_id}] {self.requirement.topic}{country_info}
Requirement: {self.requirement.requirement_text}
Is NAP: {self.requirement.is_nap}

Matched Section [{self.matched_section.section_id}]: {self.matched_section.heading}
Section Content:
{self.matched_section.full_text[:2000]}
"""


@dataclass
class QARequirementRecord:
    """Represents a single checklist requirement for QA verification."""
    req_id: str
    checklist_type: str
    category: str
    requirement_text: str
    regulation_ref: str = ""
    scope_tags: List[str] = field(default_factory=list)
    severity: str = "required"
    status: str = "pending"
    evidence: str = ""
    embedding: Optional[List[float]] = None


@dataclass
class QAIssue:
    """Single issue found during QA verification."""
    section_id: str
    section_heading: str
    requirement_id: str
    requirement_text: str
    severity: str = "MUST"
    instructions: str = ""
    checklist_type: str = ""
    country: str = ""


@dataclass
class QAFeedback:
    """Structured feedback from QA Agent to Generator Agent."""
    status: str
    issues: List[QAIssue] = field(default_factory=list)
    qa_notes: str = ""
    iteration: int = 1
    country: str = ""
    
    def to_prompt_text(self) -> str:
        """Format feedback for Generator's prompt."""
        if self.status == "pass":
            return ""
        
        country_label = f" ({self.country.upper()})" if self.country else ""
        lines = [
            f"\n=== QA FEEDBACK{country_label} (ITERATION {self.iteration}/2) ===",
            "The following issues MUST be addressed in this revision:\n"
        ]
        
        for i, issue in enumerate(self.issues, 1):
            lines.append(f"{i}. [{issue.checklist_type}] {issue.requirement_id}")
            lines.append(f"   Section: {issue.section_heading}")
            lines.append(f"   Requirement: {issue.requirement_text}")
            lines.append(f"   Action Required: {issue.instructions}")
            lines.append("")
        
        if self.qa_notes:
            lines.append(f"QA Notes: {self.qa_notes}")
        
        return "\n".join(lines)
    
    def has_issues(self) -> bool:
        """Check if there are any issues to address."""
        return len(self.issues) > 0


# =============================================================================
# Pydantic Models for FastAPI Endpoints (Global ICF Section Indexing)
# =============================================================================

class IndexGlobalIcfRequest(BaseModel):
    """Request model for indexing Global ICF sections."""
    blob_url: str = Field(..., description="Full Azure Blob URL to the Global ICF DOCX file")
    document_id: str = Field(..., description="Unique document ID assigned by frontend")


class SectionRecord(BaseModel):
    """Represents an indexed section in icf-sections-index."""
    id: str = Field(..., description="Unique ID: {document_id}_{section_id}")
    document_id: str = Field(..., description="Parent document ID from frontend")
    section_id: str = Field(..., description="Section ID within document (e.g., SEC-001)")
    heading: str = Field(..., description="Section heading text")
    content: str = Field(..., description="Full section content")
    page_number: int = Field(default=0, description="Page number in source document")
    section_order: int = Field(default=0, description="Order of section in document")
    parent_section_id: Optional[str] = Field(default=None, description="Parent section ID for hierarchy")
    level: int = Field(default=1, description="Heading level (1-6)")
    embedding: Optional[List[float]] = Field(default=None, description="Vector embedding for semantic search")


class IndexGlobalIcfResponse(BaseModel):
    """Response model for Global ICF indexing."""
    success: bool = Field(..., description="Whether indexing was successful")
    message: str = Field(..., description="Status message")
    sections_indexed: int = Field(default=0, description="Number of sections indexed")
    details: Optional[Dict[str, Any]] = Field(default=None, description="Additional metadata")


class GlobalIcfSectionTree(BaseModel):
    """Represents the complete indexed Global ICF document."""
    document_id: str = Field(..., description="Unique document ID")
    document_name: str = Field(..., description="Original filename")
    total_sections: int = Field(default=0, description="Total sections indexed")
    total_paragraphs: int = Field(default=0, description="Total paragraphs in document")
    page_count: int = Field(default=0, description="Total pages in document")
    indexed_at: str = Field(default_factory=lambda: datetime.utcnow().isoformat())
    sections: List[SectionRecord] = Field(default_factory=list)


# =============================================================================
# Human Review Agent Models
# =============================================================================

# Agent author signatures - used to filter client vs agent comments
AGENT_AUTHORS = [
    "ICF-Gen-Agent",
    "ICF-Regen-Agent",
    "ICF-USA-Agent",
    "System"
]


@dataclass
class ParsedComment:
    """Represents a parsed comment from a reviewed document."""
    comment_id: str
    author: str
    date: str
    text: str
    linked_text: str
    paragraph_index: int
    is_client: bool
    section_id: Optional[str] = None
    section_title: Optional[str] = None
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ParsedComment':
        """Create from dictionary."""
        return cls(
            comment_id=data.get('comment_id', ''),
            author=data.get('author', ''),
            date=data.get('date', ''),
            text=data.get('text', ''),
            linked_text=data.get('linked_text', ''),
            paragraph_index=data.get('paragraph_index', -1),
            is_client=data.get('is_client', True),
            section_id=data.get('section_id'),
            section_title=data.get('section_title')
        )


@dataclass
class EditInstruction:
    """LLM-generated edit instruction for a specific comment."""
    comment_id: str
    action: str  # REPLACE, INSERT, DELETE, NO_ACTION, COMMENT_ONLY, CLARIFY
    original_text: str
    new_text: str
    section_id: Optional[str] = None
    confidence: float = 0.0
    reasoning: str = ""
    priority: int = 3  # 1-5 scale (1=highest, 5=lowest)
    rag_ids_used: List[str] = field(default_factory=list)
    rag_sources: List[Dict[str, Any]] = field(default_factory=list)
    
    def to_change_dict(self) -> Dict[str, Any]:
        """Convert to change dict format for document_handler."""
        if self.action == "REPLACE":
            return {
                "type": "replace",
                "original": self.original_text,
                "new_text": self.new_text,
                "reason": self.reasoning,
                "source": f"Client Comment #{self.comment_id}",
                "rag_ids_used": self.rag_ids_used
            }
        elif self.action == "INSERT":
            return {
                "type": "add",
                "new_text": self.new_text,
                "location": f"AFTER:{self.original_text[:50]}",
                "reason": self.reasoning,
                "source": f"Client Comment #{self.comment_id}",
                "rag_ids_used": self.rag_ids_used
            }
        elif self.action == "DELETE":
            return {
                "type": "delete",
                "original": self.original_text,
                "reason": self.reasoning,
                "source": f"Client Comment #{self.comment_id}",
                "rag_ids_used": self.rag_ids_used
            }
        return {}


class RegenerateRequest(BaseModel):
    """Request model for /learn-and-regenerate endpoint."""
    job_id: Optional[str] = Field(default=None, description="Job ID for tracking")
    document_id: str = Field(..., description="Unique identifier for the ICF document")
    icf_case_id: str = Field(default="", description="ICF case identifier for learning artifacts")
    countryid: int = Field(..., description="Country ID (2=USA, 3=Canada, 4=Taiwan, etc.)")
    country_name: str = Field(..., description="Country name for folder structure (usa, canada, taiwan)")
    reviewed_blob_url: str = Field(..., description="Azure Blob URL of the client-reviewed document")
    callback_url: str = Field(..., description="Node.js endpoint to receive completion callback")
    current_version: Optional[int] = Field(default=1, description="Current version number of the document")
    iteration_id: int = Field(default=1, description="Feedback iteration number (1, 2, 3...)")
    study_id: Optional[int] = Field(default=None, description="Study ID for display filename")
    study_name: Optional[str] = Field(default=None, description="Study name for display filename")
    study_icf_type: Optional[str] = Field(default=None, description="Study ICF type for display filename")
    user_name: Optional[str] = Field(default=None, description="User name for display filename")


class RegenerateResponse(BaseModel):
    """Response model for /regenerate-country-icf endpoint (202 Accepted)."""
    success: bool = Field(..., description="Whether request was accepted")
    status: str = Field(default="processing", description="Current status")
    message: str = Field(..., description="Status message")
    document_id: str = Field(..., description="Document ID being processed")
    country: str = Field(..., description="Country name")


class RegenerateCallbackMetadata(BaseModel):
    """Metadata included in regeneration callback."""
    country: str = Field(..., description="Country name")
    countryid: int = Field(..., description="Country ID")
    iteration_id: Optional[int] = Field(default=None, description="Feedback iteration number")
    client_comments_processed: int = Field(default=0, description="Number of client comments processed")
    client_track_changes_kept: int = Field(default=0, description="Number of client track changes kept")
    sections_modified: List[str] = Field(default_factory=list, description="List of modified section titles")
    duration_seconds: float = Field(default=0.0, description="Processing duration in seconds")
    timestamp: str = Field(default_factory=lambda: datetime.utcnow().isoformat())
    no_evidence_count: int = Field(default=0, description="Number of changes without RAG evidence")
    diff_percent: float = Field(default=0.0, description="Percentage of document changed")
    artifacts_indexed: int = Field(default=0, description="Number of learning artifacts indexed")
    diff_summary_blob_url: Optional[str] = Field(default=None, description="Blob URL of diff_summary.json")
    sections_changed: Optional[int] = Field(default=None, description="Number of sections with changes (from diff)")
    total_changes: Optional[int] = Field(default=None, description="Total change count (from diff)")
    qa_passed: Optional[bool] = Field(default=None, description="Whether QA gate passed (Story 827635)")
    qa_report_blob_url: Optional[str] = Field(default=None, description="Blob URL of qa_report.json")
    qa_issues_count: Optional[int] = Field(default=None, description="Number of QA issues found")
    qa_status: Optional[str] = Field(default=None, description="QA status: PASS|REVIEW_REQUIRED|FAIL")
    evidence_validation_summary: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Snapshot of the evidence validation report (validated/rejected counts, etc.)"
    )
    evidence_validation_report_url: Optional[str] = Field(
        default=None,
        description="Blob URL of evidence_validation.json"
    )
    evidence_validated_changes_url: Optional[str] = Field(
        default=None,
        description="Blob URL of validated_changes.json"
    )
    evidence_rejected_changes_url: Optional[str] = Field(
        default=None,
        description="Blob URL of rejected_changes.json"
    )
    # ICR-R1: flow metrics for ICRA UI
    instructions_from_feedback: int = Field(default=0, description="Total instructions from user feedback")
    instructions_applied: int = Field(default=0, description="Count of instructions applied in regeneration")
    instructions_not_used: int = Field(default=0, description="Count of instructions not used")
    not_used_items: List[Dict[str, str]] = Field(default_factory=list, description="List of {summary, reason} for instructions not used")
    # ICR-L1: learning flow metrics (when regen follows learn-and-regen)
    feedback_items_total: int = Field(default=0, description="Total feedback items from learn run")
    feedback_items_learned: int = Field(default=0, description="Count of items learned")
    feedback_items_not_learned: int = Field(default=0, description="Count of items not learned")
    not_learned_items: List[Dict[str, str]] = Field(default_factory=list, description="List of {summary, reason} for items not learned")


class RegenerateCallback(BaseModel):
    """Callback payload sent to Node.js after regeneration completes."""
    jobId: Optional[str] = Field(default=None, description="Job ID for backend tracking")
    stage: Optional[str] = Field(default=None, description="Pipeline stage name")
    qaStatus: Optional[str] = Field(default=None, description="QA gate status: PASS|REVIEW_REQUIRED|FAIL")
    qaReportUrl: Optional[str] = Field(default=None, description="Blob URL of qa_report.json")
    status: int = Field(..., description="Status code: 2=Success, 0=Failed")
    success: bool = Field(..., description="Whether regeneration was successful")
    filename: Optional[str] = Field(default=None, description="Output filename with version")
    blob_url: Optional[str] = Field(default=None, description="Full Azure Blob URL to download the file")
    icfDoc_id: str = Field(..., description="Document ID")
    icf_case_id: str = Field(default="", description="ICF case identifier")
    iteration_id: Optional[int] = Field(default=None, description="Feedback iteration number")
    version: Optional[int] = Field(default=None, description="New version number")
    error: Optional[str] = Field(default=None, description="Error message if failed")
    training_blob_url: Optional[str] = Field(default=None, description="Blob URL of the DPO training JSONL produced during learning")
    metadata: Optional[RegenerateCallbackMetadata] = Field(default=None, description="Processing metadata")
    can_publish: bool = Field(default=True, description="Whether document passed publishing gate")
    publishing_blocked_reasons: List[str] = Field(default_factory=list, description="Reasons if publishing blocked")
    audit_events: List[Dict[str, Any]] = Field(default_factory=list, description="Audit events tracking workflow execution")


# =============================================================================
# Learn-Only API Models
# =============================================================================

class GeneratedIcfLearnOnlyRequest(BaseModel):
    """Request model for /generated-icf/learn-only (backend HTTP fallback format)."""
    feedback_doc_url: str = Field(..., description="Azure Blob URL of the feedback document")
    icf_doc_url: str = Field(..., description="Azure Blob URL of the ICF document")
    icf_document_id: int = Field(..., description="ICF document ID")
    callback_base_url: str = Field(default="", description="Backend base URL for callback")
    country_code: str = Field(default="usa", description="Country code (e.g. USA, CAN)")
    country_id: int = Field(default=2, description="Country ID")

class LearnOnlyRequest(BaseModel):
    """Request model for /learn-only endpoint."""
    document_id: Optional[str] = Field(default="", description="Document ID associated with the learn-only request")
    icf_case_id: str = Field(..., description="Unique ICF case identifier")
    country_name: str = Field(..., description="Country name (usa, canada, taiwan)")
    countryid: int = Field(..., description="Country ID (2=USA, 3=Canada, 4=Taiwan, etc.)")
    iteration_id: int = Field(..., description="Feedback iteration number (1, 2, 3...)")
    reviewed_blob_url: str = Field(..., description="Azure Blob URL of the client-reviewed document")
    base_blob_url: str = Field(default="", description="Azure Blob URL of the base version v(N) document")
    base_version_no: int = Field(default=1, description="Base version number v(N)")
    callback_url: str = Field(..., description="Node.js endpoint to receive completion callback")


class LearnOnlyResponse(BaseModel):
    """Response model for /learn-only endpoint (202 Accepted)."""
    success: bool = Field(..., description="Whether request was accepted")
    status: str = Field(default="processing", description="Current status")
    message: str = Field(..., description="Status message")
    icf_case_id: str = Field(..., description="ICF case ID being processed")
    country: str = Field(..., description="Country name")
    iteration_id: int = Field(..., description="Iteration being processed")
    training_url: Optional[str] = Field(default=None, description="DPO training JSONL blob URL")


class SemanticArtifact(BaseModel):
    """Semantic artifact extracted from client feedback."""
    artifact_id: str = Field(..., description="Unique artifact ID")
    source: str = Field(..., description="Source: 'track_change' or 'comment'")
    section_title: str = Field(default="", description="Section heading")
    change_type: str = Field(..., description="Type: terminology_replacement, content_removal, etc.")
    ai_output: str = Field(..., description="Original AI text (rejected)")
    human_output: str = Field(..., description="Client correction (preferred)")
    intent: str = Field(..., description="Semantic intent of the change")
    priority: int = Field(default=3, description="Priority 1-5 (1=highest)")
    confidence: float = Field(default=0.0, description="Confidence score")
    evidence_ids: List[str] = Field(default_factory=list, description="RAG chunk IDs supporting this change")
    evidence_relevance: float = Field(default=0.0, description="Highest evidence relevance score")


class SemanticIntent(BaseModel):
    """Semantic intent extracted from client track changes."""
    intent_id: str = Field(..., description="Unique intent ID (e.g., SI-0001)")
    section_key: str = Field(default="", description="Section key the change applies to")
    section_title: str = Field(default="", description="Section heading")
    original_text: str = Field(..., description="Original AI-generated text (deleted by client)")
    corrected_text: str = Field(default="", description="Client's replacement text (inserted)")
    intent: str = Field(..., description="Semantic reason for this change")
    change_type: str = Field(default="modification", description="Type: terminology_replacement, content_removal, legal_strengthening, etc.")
    confidence: float = Field(default=0.9, description="Confidence score")
    priority: int = Field(default=3, description="Priority 1-5 (1=highest, 5=lowest)")
    evidence_chunk_ids: List[str] = Field(default_factory=list, description="RAG evidence chunk IDs")
    source: str = Field(default="track_change", description="Always 'track_change' for SemanticIntent")


class RegenerationInstruction(BaseModel):
    """Regeneration instruction extracted from client comments."""
    instruction_id: str = Field(..., description="Unique instruction ID (e.g., RI-0001)")
    section_key: str = Field(default="", description="Section key the comment applies to")
    section_title: str = Field(default="", description="Section heading")
    comment_text: str = Field(..., description="Client's comment text")
    linked_text: str = Field(default="", description="Text the comment was attached to")
    instruction: str = Field(..., description="What the client wants done (LLM-interpreted)")
    action: str = Field(default="MODIFY", description="Action type: MODIFY, ADD, DELETE, CLARIFY")
    confidence: float = Field(default=0.9, description="Confidence score")
    priority: int = Field(default=3, description="Priority 1-5 (1=highest, 5=lowest)")
    evidence_chunk_ids: List[str] = Field(default_factory=list, description="RAG evidence chunk IDs")
    source: str = Field(default="comment", description="Always 'comment' for RegenerationInstruction")


class LearnOnlyCallbackMetadata(BaseModel):
    """Metadata included in learn-only callback."""
    country: str = Field(..., description="Country name")
    countryid: int = Field(..., description="Country ID")
    iteration_id: int = Field(..., description="Iteration number")
    track_changes_extracted: int = Field(default=0, description="Number of track changes found")
    comments_extracted: int = Field(default=0, description="Number of client comments found")
    artifacts_indexed: int = Field(default=0, description="Number of artifacts indexed to learning store")
    artifacts_superseded: int = Field(default=0, description="Number of previous iteration artifacts marked superseded")
    duration_seconds: float = Field(default=0.0, description="Processing duration in seconds")
    timestamp: str = Field(default_factory=lambda: datetime.utcnow().isoformat())
    # ICR-L1: flow metrics for ICRA UI
    feedback_items_total: int = Field(default=0, description="Total feedback items (track changes + comments)")
    feedback_items_learned: int = Field(default=0, description="Count of items successfully learned/indexed")
    feedback_items_not_learned: int = Field(default=0, description="Count of items not learned")
    not_learned_items: List[Dict[str, str]] = Field(default_factory=list, description="List of {summary, reason} for items not learned")


class LearnOnlyCallback(BaseModel):
    """Callback payload sent to Node.js after learn-only completes."""
    status: int = Field(..., description="Status code: 2=Success, 0=Failed")
    success: bool = Field(..., description="Whether learning extraction was successful")
    icf_case_id: str = Field(..., description="ICF case ID")
    iteration_id: int = Field(..., description="Iteration number processed")
    artifact_blob_url: Optional[str] = Field(default=None, description="Blob URL to semantic artifact JSON")
    artifacts: List[SemanticArtifact] = Field(default_factory=list, description="Extracted semantic artifacts")
    error: Optional[str] = Field(default=None, description="Error message if failed")
    metadata: Optional[LearnOnlyCallbackMetadata] = Field(default=None, description="Processing metadata")
    audit_events: List[Dict[str, Any]] = Field(default_factory=list, description="Audit events tracking workflow execution")