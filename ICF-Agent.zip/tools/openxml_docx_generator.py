"""
OpenXML DOCX Generator Tool
Creates DOCX files with proper OpenXML tracked changes markup (<w:ins>, <w:del>, <w:commentReference>).
This is an enhanced tool for generating ICF documents with regulatory tracked changes.
"""

import sys
import io
# Ensure UTF-8 encoding for stdout
if sys.stdout.encoding != 'utf-8':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

from datetime import datetime
from typing import List, Dict, Any
import os
from pathlib import Path
from docx import Document
from docx.oxml import OxmlElement, parse_xml
from docx.oxml.ns import qn, nsdecls
from docx.shared import Pt, RGBColor
from docx.enum.text import WD_COLOR_INDEX
from lxml import etree
import zipfile
import tempfile
import shutil


class OpenXmlDocxGenerator:
    """
    Enhanced tool for generating DOCX files with true OpenXML tracked changes.
    Stores intermediate files in the 'median' folder.
    """
    
    def __init__(self, author: str = "ICF Generator Agent", output_folder: str = "median"):
        """
        Initialize the OpenXML DOCX generator.
        
        Args:
            author: Author name for tracked changes
            output_folder: Folder for storing intermediate DOCX files (default: median)
        """
        self.author = author
        self.output_folder = output_folder
        self.change_id_counter = 1
        self.comment_id_counter = 1
        self.comments = []  # Store comments to add later
        
        # Ensure output folder exists
        Path(output_folder).mkdir(exist_ok=True)
    
    def create_icf_with_tracked_changes(
        self,
        master_docx_path: str,
        changes: List[Dict[str, Any]],
        output_filename: str = None,
        country: str = "Unknown",
        section_tree: Any = None  # Optional: ICFSectionTree for better location finding
    ) -> str:
        """
        Create ICF DOCX with tracked changes based on master template.
        
        Args:
            master_docx_path: Path to master ICF DOCX file
            changes: List of change dictionaries from generator agent
            output_filename: Optional custom output filename
            country: Target country for ICF customization
            
        Returns:
            Path to generated DOCX file in median folder
        """
        # Generate output filename if not provided
        if not output_filename:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            output_filename = f"ICF_{country}_{timestamp}.docx"
        
        output_path = os.path.join(self.output_folder, output_filename)
        
        # Reset comments for this document
        self.comments = []
        self.comment_id_counter = 1
        
        # Load master document
        doc = Document(master_docx_path)
        
        print(f"\n{'='*80}")
        print(f"OpenXML DOCX Generator - Creating ICF with Tracked Changes")
        print(f"{'='*80}")
        print(f"Master ICF: {master_docx_path}")
        print(f"Output: {output_path}")
        print(f"Total Changes: {len(changes)}")
        print(f"Country: {country}")
        print(f"{'='*80}\n")
        
        # Ensure document settings enable track changes display
        self._ensure_track_changes_settings(doc)
        
        # Ensure document settings enable track changes display
        self._ensure_track_changes_settings(doc)
        
        # Initialize comments part if it doesn't exist
        self._ensure_comments_part(doc)
        
        # Sort changes by section order_index if available to maintain document order
        # This ensures changes are applied in the correct sequence
        changes_with_order = []
        for change in changes:
            section_info = change.get('section_info', {})
            order_index = section_info.get('order_index', 999999) if section_info else 999999
            changes_with_order.append((order_index, change))
        
        # Sort by order_index
        changes_with_order.sort(key=lambda x: x[0])
        sorted_changes = [change for _, change in changes_with_order]
        
        # Apply each change
        for idx, change in enumerate(sorted_changes, 1):
            change_type = change.get('change_type', 'insertion')
            location = change.get('location', 'Unknown')
            
            print(f"[{idx}/{len(sorted_changes)}] Applying {change_type.upper()} at '{location}'")
            
            try:
                self._apply_tracked_change(doc, change)
                print(f"  ✅ Successfully applied")
            except Exception as e:
                print(f"  ⚠️ Warning: {e}")
                import traceback
                traceback.print_exc()
        
        # Save document
        doc.save(output_path)
        
        print(f"\n{'='*80}")
        print(f"Document saved initially: {output_path}")
        print(f"{'='*80}\n")
        
        # Add comments to the DOCX using ZIP manipulation
        if self.comments:
            print(f"Adding {len(self.comments)} comments to document...")
            output_path = self._add_comments_to_docx(output_path)
            print(f"✅ Comments added successfully")
        
        print(f"\n{'='*80}")
        print(f"✅ Document created successfully: {output_path}")
        print(f"{'='*80}\n")
        
        return output_path
    
    def _apply_tracked_change(self, doc: Document, change: Dict[str, Any]):
        """Apply a single tracked change to the document."""
        change_type = change.get('change_type', 'insertion').lower()
        location = change.get('location', '')
        old_text = change.get('old_text', '').strip()
        new_text = change.get('new_text', '').strip()
        after_text = change.get('after_text', '').strip()
        section_info = change.get('section_info', {})
        source_section_id = change.get('source_section_id', '')
        
        # Find target paragraph using section info for better accuracy
        target_para = self._find_target_paragraph(doc, location, old_text, after_text, section_info)
        
        if not target_para:
            # Last resort: Try to find by location string in paragraph text
            if location and location != 'Unknown':
                location_lower = location.lower()
                for para in doc.paragraphs:
                    if location_lower in para.text.lower() or any(word in para.text.lower() for word in location_lower.split() if len(word) > 3):
                        print(f"    ✓ Found by location string: {location[:50]}")
                        target_para = para
                        break
            
            # If still not found, try to find a reasonable insertion point
            if not target_para:
                # For insertions, try to find the section by location
                if change_type in ['insertion', 'insert']:
                    # Try to find a section header or similar content
                    if location and location != 'Unknown':
                        # Extract section number/name from location
                        location_parts = location.lower().replace('section', '').strip().split()
                        for para_idx, para in enumerate(doc.paragraphs):
                            para_text_lower = para.text.lower()
                            # Check if paragraph contains location keywords
                            if any(part in para_text_lower for part in location_parts if len(part) > 2):
                                # Found potential section, insert after it
                                print(f"    ⚠️  Found approximate location, inserting after paragraph")
                                # Find next non-empty paragraph after this one, or create new
                                if para_idx + 1 < len(doc.paragraphs):
                                    next_para = doc.paragraphs[para_idx + 1]
                                    if next_para.text.strip():
                                        target_para = next_para
                                    else:
                                        # Insert new paragraph between current and next
                                        # Get the element's parent and insert after
                                        p_element = para._element
                                        new_p = OxmlElement('w:p')
                                        p_element.addnext(new_p)
                                        # Create new paragraph object
                                        target_para = type(para)(new_p, para._parent)
                                        break
                                else:
                                    # Last paragraph - insert after using XML (not at end of document)
                                    # Use XML manipulation to insert after the last paragraph
                                    p_element = para._element
                                    new_p = OxmlElement('w:p')
                                    p_element.addnext(new_p)
                                    target_para = type(para)(new_p, para._parent)
                                    break
                        
                        # If still not found, look for logical section boundaries
                        if not target_para:
                            # Try to find by keywords in location
                            for para_idx, para in enumerate(doc.paragraphs):
                                if any(keyword in para.text.lower() for keyword in ['introduction', 'purpose', 'risks', 'benefits', 'procedures']):
                                    print(f"    ⚠️  Found section keyword, inserting after")
                                    if para_idx + 1 < len(doc.paragraphs):
                                        target_para = doc.paragraphs[para_idx + 1]
                                    else:
                                        # Last paragraph - insert after using XML (not at end)
                                        p_element = para._element
                                        new_p = OxmlElement('w:p')
                                        p_element.addnext(new_p)
                                        target_para = type(para)(new_p, para._parent)
                                    break
                    
                    # Last resort: Find a reasonable location (not at very end)
                    if not target_para:
                        # Find last substantive content paragraph (skip footers, etc.)
                        for para_idx in range(len(doc.paragraphs) - 1, max(0, len(doc.paragraphs) - 20), -1):
                            para = doc.paragraphs[para_idx]
                            para_text = para.text.strip()
                            # Skip short paragraphs that might be footers/headers
                            if len(para_text) > 30 and not para_text.lower().startswith('page'):
                                print(f"    ⚠️  Inserting after last substantial paragraph")
                                # Insert new paragraph after this one
                                p_element = para._element
                                new_p = OxmlElement('w:p')
                                p_element.addnext(new_p)
                                target_para = type(para)(new_p, para._parent)
                                break
                    
                    # Absolute last resort - SKIP if we cannot find an existing section
                    if not target_para:
                        print(f"    ❌ Could not find existing section for insertion - SKIPPING to avoid adding at end of document")
                        print(f"       Location: {location}")
                        print(f"       Requirement: {new_text[:100] if new_text else 'N/A'}...")
                        if section_info:
                            print(f"       Section ID: {section_info.get('section_id', 'N/A')}")
                            print(f"       Section Title: {section_info.get('title', 'N/A')}")
                        return  # Skip this change - do not add at end
                else:
                    # For modifications/deletions, we need the exact location
                    print(f"    ❌ Could not find target paragraph for {change_type} - skipping change")
                    print(f"       Location: {location}")
                    print(f"       Old text: {old_text[:100] if old_text else 'N/A'}")
                    if section_info:
                        print(f"       Section ID: {section_info.get('section_id', 'N/A')}")
                        print(f"       Section Title: {section_info.get('title', 'N/A')}")
                    return
        
        # Apply change based on type
        if change_type in ['insertion', 'insert']:
            # For insertions, check if we should insert inline or as new paragraph
            # If after_text is specified and found, insert inline
            # Otherwise, insert as new paragraph after target
            if after_text and target_para and after_text in target_para.text:
                # Insert inline after the anchor text
                self._insert_with_tracking(target_para, new_text, after_text, change)
            else:
                # Insert as new paragraph after target paragraph
                self._insert_as_new_paragraph(doc, target_para, new_text, change, location)
        elif change_type == 'deletion':
            self._delete_with_tracking(target_para, old_text, change)
        elif change_type == 'modification':
            self._modify_with_tracking(target_para, old_text, new_text, change)
        else:
            print(f"    Unknown change type: {change_type}, treating as insertion")
            self._insert_with_tracking(target_para, new_text, after_text, change)
        
        # Add comment with regulatory justification
        self._add_regulatory_comment(target_para, change)
    
    def _find_target_paragraph(self, doc: Document, location: str, old_text: str, after_text: str, section_info: Dict[str, Any] = None):
        """Find the target paragraph for applying changes."""
        # Strategy 0: Use section_info if available (most accurate)
        if section_info:
            section_title = section_info.get('title', '').strip()
            section_text_sample = section_info.get('text', '').strip()
            section_id = section_info.get('section_id', '')
            
            # Try to find by section title first
            if section_title:
                for para_idx, para in enumerate(doc.paragraphs):
                    para_text = para.text.strip()
                    # Check if paragraph contains the section title
                    if section_title.lower() in para_text.lower():
                        print(f"    ✓ Found by section title: {section_title[:50]}")
                        # For insertions, return the next paragraph after the title
                        # For modifications, return this paragraph or next one with content
                        if para_idx + 1 < len(doc.paragraphs):
                            # Check if next para has content
                            next_para = doc.paragraphs[para_idx + 1]
                            if next_para.text.strip():
                                return next_para
                            # If next is empty, check further
                            for i in range(para_idx + 2, min(para_idx + 5, len(doc.paragraphs))):
                                if doc.paragraphs[i].text.strip():
                                    return doc.paragraphs[i]
                        return para
            
            # Try to find by section text sample (first 200 chars)
            if section_text_sample:
                sample = section_text_sample[:200].strip()
                for para in doc.paragraphs:
                    if sample.lower() in para.text.lower():
                        print(f"    ✓ Found by section text sample")
                        return para
            
            # Try to find by section ID in paragraph text (some parsers include it)
            if section_id:
                for para in doc.paragraphs:
                    if section_id.lower() in para.text.lower():
                        print(f"    ✓ Found by section ID")
                        return para
        
        # Strategy 1: Search by old_text (most reliable)
        if old_text:
            def normalize(text: str) -> str:
                import re
                # Lowercase, collapse whitespace, strip punctuation
                text = text.lower()
                text = re.sub(r"[\\n\\r\\t]+", " ", text)
                text = re.sub(r"[^a-z0-9\\s]", "", text)
                return " ".join(text.split())
            
            normalized_old = normalize(old_text)
            
            for para in doc.paragraphs:
                # Skip table of contents paragraphs (Word uses TOC styles)
                try:
                    style_name = (para.style.name or "").lower()
                    if "toc" in style_name:
                        continue
                except Exception:
                    pass
                para_text = para.text
                if old_text in para_text:
                    print(f"    ✓ Found exact match for old_text")
                    return para
                # Try normalized match
                normalized_para = normalize(para_text)
                if normalized_old and normalized_old in normalized_para:
                    print(f"    ✓ Found normalized match for old_text")
                    return para
        
        # Strategy 2: Search by after_text
        if after_text:
            for para in doc.paragraphs:
                try:
                    style_name = (para.style.name or "").lower()
                    if "toc" in style_name:
                        continue
                except Exception:
                    pass
                if after_text in para.text:
                    print(f"    ✓ Found match for after_text")
                    return para
        
        # Strategy 3: Search by location (section header)
        if location and location != 'Unknown':
            # Try to find section by looking for the section title in paragraphs
            section_keywords = location.lower().replace('section', '').strip()
            for idx, para in enumerate(doc.paragraphs):
                para_text = para.text.lower()
                # Check if this looks like a section header
                if section_keywords in para_text and len(para.text) < 300:
                    print(f"    ✓ Found section header: {para.text[:50]}")
                    # Return the paragraph after the header
                    if idx + 1 < len(doc.paragraphs):
                        return doc.paragraphs[idx + 1]
        
        # Strategy 4: Scan entire document for any partial matches
        if old_text:
            keywords = old_text.split()[:3]  # First 3 words
            keywords = [w for w in keywords if len(w) > 2]  # Filter out short words
            if keywords:
                for para in doc.paragraphs:
                    para_text_lower = para.text.lower()
                    if all(word.lower() in para_text_lower for word in keywords):
                        print(f"    ✓ Found partial keyword match")
                        return para
        
        return None
    
    def _insert_with_tracking(self, paragraph, new_text: str, after_text: str, change: Dict[str, Any]):
        """Insert new text with tracking markup."""
        if not new_text:
            return
        
        # Add space before insertion if needed
        if paragraph.text and not paragraph.text.endswith(' '):
            paragraph.add_run(' ')
        
        # Create proper OpenXML <w:ins> element
        p_element = paragraph._element
        
        # Create insertion element
        ins = OxmlElement('w:ins')
        ins.set(qn('w:id'), str(self.change_id_counter))
        ins.set(qn('w:author'), self.author)
        ins.set(qn('w:date'), datetime.now().isoformat())
        self.change_id_counter += 1
        
        # Create run inside insertion
        run = OxmlElement('w:r')
        run_props = OxmlElement('w:rPr')
        run.append(run_props)
        
        # Add text element
        text_elem = OxmlElement('w:t')
        text_elem.set(qn('xml:space'), 'preserve')
        text_elem.text = new_text
        run.append(text_elem)
        
        # Add run to insertion
        ins.append(run)
        
        # Insert insertion element at appropriate position
        # If after_text is specified, try to insert after that text
        if after_text and after_text in paragraph.text:
            # Find position after after_text
            para_text = paragraph.text
            insert_pos = para_text.find(after_text) + len(after_text)
            # This is complex - for now, append to end
            # TODO: Implement proper inline insertion
            p_element.append(ins)
        else:
            # Append insertion to paragraph
            p_element.append(ins)
    
    def _insert_as_new_paragraph(self, doc: Document, target_para, new_text: str, change: Dict[str, Any], location: str):
        """Insert new text as a new paragraph after the target paragraph."""
        if not new_text:
            return
        
        # Find target paragraph index
        para_idx = None
        if target_para:
            try:
                # Use enumerate to safely find index
                for idx, para in enumerate(doc.paragraphs):
                    if para == target_para:
                        para_idx = idx
                        break
            except (ValueError, AttributeError):
                para_idx = None
        
        # Create new paragraph only if we have a valid target
        if para_idx is not None and para_idx < len(doc.paragraphs) and target_para:
            # Insert after target paragraph using XML manipulation
            p_element = target_para._element
            new_p = OxmlElement('w:p')
            p_element.addnext(new_p)
            
            # Create insertion tracking
            ins = OxmlElement('w:ins')
            ins.set(qn('w:id'), str(self.change_id_counter))
            ins.set(qn('w:author'), self.author)
            ins.set(qn('w:date'), datetime.now().isoformat())
            self.change_id_counter += 1
            
            # Create run inside insertion
            run = OxmlElement('w:r')
            run_props = OxmlElement('w:rPr')
            run.append(run_props)
            
            # Add text element
            text_elem = OxmlElement('w:t')
            text_elem.set(qn('xml:space'), 'preserve')
            text_elem.text = new_text
            run.append(text_elem)
            
            # Add run to insertion
            ins.append(run)
            
            # Add insertion to new paragraph
            new_p.append(ins)
            
            print(f"    ✓ Inserted as new paragraph after target")
        else:
            # Cannot insert - target paragraph not found in document structure
            print(f"    ❌ Cannot insert: target paragraph not found in document - SKIPPING to avoid adding at end")
            print(f"       Location: {location}")
            return  # Skip this change - do not add at end
    
    def _delete_with_tracking(self, paragraph, old_text: str, change: Dict[str, Any]):
        """Delete text with tracking markup."""
        if not old_text:
            return
        
        para_text = paragraph.text
        p_element = paragraph._element
        
        if old_text in para_text:
            # Split and rebuild paragraph
            before, _, after = para_text.partition(old_text)
            
            # Clear paragraph runs
            for run in list(paragraph.runs):
                run._element.getparent().remove(run._element)
            
            # Add text before deletion
            if before:
                run_before = OxmlElement('w:r')
                text_before = OxmlElement('w:t')
                text_before.set(qn('xml:space'), 'preserve')
                text_before.text = before
                run_before.append(text_before)
                p_element.append(run_before)
            
            # Create proper OpenXML <w:del> element
            deletion = OxmlElement('w:del')
            deletion.set(qn('w:id'), str(self.change_id_counter))
            deletion.set(qn('w:author'), self.author)
            deletion.set(qn('w:date'), datetime.now().isoformat())
            self.change_id_counter += 1
            
            # Create run inside deletion
            del_run = OxmlElement('w:r')
            del_run_props = OxmlElement('w:rPr')
            del_run.append(del_run_props)
            
            # Add deleted text
            del_text = OxmlElement('w:delText')
            del_text.set(qn('xml:space'), 'preserve')
            del_text.text = old_text
            del_run.append(del_text)
            
            # Add run to deletion
            deletion.append(del_run)
            p_element.append(deletion)
            
            # Add text after deletion
            if after:
                run_after = OxmlElement('w:r')
                text_after = OxmlElement('w:t')
                text_after.set(qn('xml:space'), 'preserve')
                text_after.text = after
                run_after.append(text_after)
                p_element.append(run_after)
        else:
            # Text not found, create deletion at end
            deletion = OxmlElement('w:del')
            deletion.set(qn('w:id'), str(self.change_id_counter))
            deletion.set(qn('w:author'), self.author)
            deletion.set(qn('w:date'), datetime.now().isoformat())
            self.change_id_counter += 1
            
            del_run = OxmlElement('w:r')
            del_text = OxmlElement('w:delText')
            del_text.set(qn('xml:space'), 'preserve')
            del_text.text = old_text
            del_run.append(del_text)
            deletion.append(del_run)
            p_element.append(deletion)
    
    def _modify_with_tracking(self, paragraph, old_text: str, new_text: str, change: Dict[str, Any]):
        """Modify text with both deletion and insertion tracking."""
        para_text = paragraph.text
        p_element = paragraph._element
        
        if old_text in para_text:
            before, _, after = para_text.partition(old_text)
            
            # Clear paragraph runs
            for run in list(paragraph.runs):
                run._element.getparent().remove(run._element)
            
            # Add text before change
            if before:
                run_before = OxmlElement('w:r')
                text_before = OxmlElement('w:t')
                text_before.set(qn('xml:space'), 'preserve')
                text_before.text = before
                run_before.append(text_before)
                p_element.append(run_before)
            
            # Add deletion element
            deletion = OxmlElement('w:del')
            deletion.set(qn('w:id'), str(self.change_id_counter))
            deletion.set(qn('w:author'), self.author)
            deletion.set(qn('w:date'), datetime.now().isoformat())
            self.change_id_counter += 1
            
            del_run = OxmlElement('w:r')
            del_text = OxmlElement('w:delText')
            del_text.set(qn('xml:space'), 'preserve')
            del_text.text = old_text
            del_run.append(del_text)
            deletion.append(del_run)
            p_element.append(deletion)
            
            # Add space
            space_run = OxmlElement('w:r')
            space_text = OxmlElement('w:t')
            space_text.set(qn('xml:space'), 'preserve')
            space_text.text = ' '
            space_run.append(space_text)
            p_element.append(space_run)
            
            # Add insertion element
            insertion = OxmlElement('w:ins')
            insertion.set(qn('w:id'), str(self.change_id_counter))
            insertion.set(qn('w:author'), self.author)
            insertion.set(qn('w:date'), datetime.now().isoformat())
            self.change_id_counter += 1
            
            ins_run = OxmlElement('w:r')
            ins_text = OxmlElement('w:t')
            ins_text.set(qn('xml:space'), 'preserve')
            ins_text.text = new_text
            ins_run.append(ins_text)
            insertion.append(ins_run)
            p_element.append(insertion)
            
            # Add text after change
            if after:
                run_after = OxmlElement('w:r')
                text_after = OxmlElement('w:t')
                text_after.set(qn('xml:space'), 'preserve')
                text_after.text = after
                run_after.append(text_after)
                p_element.append(run_after)
        else:
            # Text not found, add both at end
            deletion = OxmlElement('w:del')
            deletion.set(qn('w:id'), str(self.change_id_counter))
            deletion.set(qn('w:author'), self.author)
            deletion.set(qn('w:date'), datetime.now().isoformat())
            self.change_id_counter += 1
            
            del_run = OxmlElement('w:r')
            del_text = OxmlElement('w:delText')
            del_text.set(qn('xml:space'), 'preserve')
            del_text.text = old_text
            del_run.append(del_text)
            deletion.append(del_run)
            p_element.append(deletion)
            
            space_run = OxmlElement('w:r')
            space_text = OxmlElement('w:t')
            space_text.set(qn('xml:space'), 'preserve')
            space_text.text = ' '
            space_run.append(space_text)
            p_element.append(space_run)
            
            insertion = OxmlElement('w:ins')
            insertion.set(qn('w:id'), str(self.change_id_counter))
            insertion.set(qn('w:author'), self.author)
            insertion.set(qn('w:date'), datetime.now().isoformat())
            self.change_id_counter += 1
            
            ins_run = OxmlElement('w:r')
            ins_text = OxmlElement('w:t')
            ins_text.set(qn('xml:space'), 'preserve')
            ins_text.text = new_text
            ins_run.append(ins_text)
            insertion.append(ins_run)
            p_element.append(insertion)
    
    def _add_openxml_insertion(self, run, change: Dict[str, Any]):
        """Add proper OpenXML <w:ins> element to run."""
        r_element = run._element
        
        # Create <w:ins> element
        ins = OxmlElement('w:ins')
        ins.set(qn('w:id'), str(self.change_id_counter))
        ins.set(qn('w:author'), self.author)
        ins.set(qn('w:date'), datetime.now().isoformat())
        
        self.change_id_counter += 1
        
        # Move the run element inside the insertion element
        parent = r_element.getparent()
        parent_index = parent.index(r_element)
        
        # Remove run from parent
        parent.remove(r_element)
        
        # Add run to insertion
        ins.append(r_element)
        
        # Insert the insertion element at the same position
        parent.insert(parent_index, ins)
    
    def _add_openxml_deletion(self, run, change: Dict[str, Any]):
        """Add proper OpenXML <w:del> element to run."""
        r_element = run._element
        
        # Create <w:del> element
        deletion = OxmlElement('w:del')
        deletion.set(qn('w:id'), str(self.change_id_counter))
        deletion.set(qn('w:author'), self.author)
        deletion.set(qn('w:date'), datetime.now().isoformat())
        
        self.change_id_counter += 1
        
        # Move the run element inside the deletion element
        parent = r_element.getparent()
        parent_index = parent.index(r_element)
        
        # Remove run from parent
        parent.remove(r_element)
        
        # Add run to deletion
        deletion.append(r_element)
        
        # Insert the deletion element at the same position
        parent.insert(parent_index, deletion)
    
    def _add_regulatory_comment(self, paragraph, change: Dict[str, Any]):
        """Add comment with regulatory reference and justification."""
        comment_text = self._format_regulatory_comment(change)
        
        if not comment_text:
            return
        
        # Add comment range markers
        p_element = paragraph._element
        
        comment_id = str(self.comment_id_counter)
        self.comment_id_counter += 1
        
        # Create comment range start
        comment_range_start = OxmlElement('w:commentRangeStart')
        comment_range_start.set(qn('w:id'), comment_id)
        
        # Create comment range end
        comment_range_end = OxmlElement('w:commentRangeEnd')
        comment_range_end.set(qn('w:id'), comment_id)
        
        # Create comment reference
        comment_ref_run = OxmlElement('w:r')
        comment_ref = OxmlElement('w:commentReference')
        comment_ref.set(qn('w:id'), comment_id)
        comment_ref_run.append(comment_ref)
        
        # Add to paragraph
        p_element.append(comment_range_start)
        p_element.append(comment_range_end)
        p_element.append(comment_ref_run)
        
        # Store comment for later addition
        self.comments.append({
            'id': comment_id,
            'author': self.author,
            'date': datetime.now().isoformat(),
            'text': comment_text
        })
    
    def _add_comment_to_part(self, doc_part, comment_id: str, comment_text: str, change: Dict[str, Any]):
        """Add comment to the document's comments part."""
        try:
            comments_part = doc_part.comments_part
            
            # Create comment element
            comment_xml = f'''
            <w:comment xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"
                       w:id="{comment_id}"
                       w:author="{self.author}"
                       w:date="{datetime.now().isoformat()}">
                <w:p>
                    <w:pPr>
                        <w:pStyle w:val="CommentText"/>
                    </w:pPr>
                    <w:r>
                        <w:rPr>
                            <w:sz w:val="20"/>
                        </w:rPr>
                        <w:t xml:space="preserve">{self._escape_xml(comment_text)}</w:t>
                    </w:r>
                </w:p>
            </w:comment>
            '''
            
            comment_element = parse_xml(comment_xml)
            comments_part.element.append(comment_element)
            
        except Exception as e:
            print(f"    Warning: Could not add comment: {e}")
    
    def _ensure_track_changes_settings(self, doc: Document):
        """
        Ensure document settings enable track changes display.
        This ensures Word will show tracked changes with accept/reject options.
        """
        try:
            # Get or create settings part
            settings_part = doc.part.settings_part
            if not settings_part:
                # Settings part should always exist, but handle gracefully
                return
            
            settings = settings_part.settings_element
            
            # Ensure track changes display settings are enabled
            # These settings control how Word displays tracked changes
            
            # Check if trackRevisions exists, if not create it
            track_revisions = settings.find(qn('w:trackRevisions'))
            if track_revisions is None:
                track_revisions = OxmlElement('w:trackRevisions')
                track_revisions.set(qn('w:val'), '1')  # Enable tracking
                settings.append(track_revisions)
            
            # Ensure document is set to show tracked changes
            # This makes Word display insertions and deletions
            display_backgrounds = settings.find(qn('w:displayBackgroundShape'))
            if display_backgrounds is None:
                display_backgrounds = OxmlElement('w:displayBackgroundShape')
                display_backgrounds.set(qn('w:val'), '1')
                settings.append(display_backgrounds)
                
        except Exception as e:
            # Non-critical - document will still work, changes may just need manual enable in Word
            print(f"    Note: Could not configure track changes settings: {e}")
            print(f"    Tracked changes will still work, but may need to enable in Word's Review tab")
    
    def _ensure_comments_part(self, doc: Document):
        """Ensure the document has a comments part."""
        try:
            if not hasattr(doc.part, 'comments_part') or doc.part.comments_part is None:
                # Create comments part
                from docx.opc.constants import CONTENT_TYPE as CT
                from docx.opc.part import Part
                
                comments_xml = '''
                <w:comments xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
                </w:comments>
                '''
                
                comments_part_xml = parse_xml(comments_xml)
                # Note: Creating comments part requires deeper OPC manipulation
                # For now, we'll add comment text inline in the tracked change markup
                pass
        except Exception as e:
            print(f"    Warning: Could not create comments part: {e}")
    
    def _format_regulatory_comment(self, change: Dict[str, Any]) -> str:
        """Format regulatory comment text."""
        parts = []
        
        # Change info
        change_type = change.get('change_type', 'change').upper()
        location = change.get('location', 'Unknown')
        parts.append(f"🔹 {change_type} - {location}")
        parts.append("-" * 40)
        
        # Regulatory reference
        reg_ref = change.get('regulatory_reference', '')
        if reg_ref:
            parts.append(f"📋 Regulatory Ref: {reg_ref}")
        
        # Justification
        justification = change.get('justification', '')
        if justification:
            parts.append(f"✓ Justification: {justification}")
        
        # Comment
        comment = change.get('comment', '')
        if comment:
            parts.append(f"💬 Note: {comment}")
        
        # QA validation
        qa_validation = change.get('qa_validation', '')
        if qa_validation:
            parts.append("-" * 40)
            parts.append(f"✅ QA: {qa_validation}")
        
        return '\n'.join(parts)
    
    def _escape_xml(self, text: str) -> str:
        """Escape XML special characters."""
        return (text
                .replace('&', '&amp;')
                .replace('<', '&lt;')
                .replace('>', '&gt;')
                .replace('"', '&quot;')
                .replace("'", '&apos;'))
    
    def get_median_files(self) -> List[str]:
        """Get list of all files in median folder."""
        median_path = Path(self.output_folder)
        if median_path.exists():
            return [str(f) for f in median_path.glob('*.docx')]
        return []
    
    def cleanup_median_folder(self, keep_latest: int = 5):
        """Clean up old files in median folder, keeping only the latest N files."""
        files = self.get_median_files()
        if len(files) <= keep_latest:
            return
        
        # Sort by modification time
        files.sort(key=lambda f: os.path.getmtime(f), reverse=True)
        
        # Remove old files
        for old_file in files[keep_latest:]:
            try:
                os.remove(old_file)
                print(f"Cleaned up: {old_file}")
            except Exception as e:
                print(f"Could not remove {old_file}: {e}")
    
    def _add_comments_to_docx(self, docx_path: str) -> str:
        """
        Add comments to DOCX by manipulating the ZIP file directly.
        Returns the path to the modified DOCX.
        """
        # Create temp directory
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            extract_path = temp_path / "docx"
            
            # Extract DOCX (it's a ZIP file)
            with zipfile.ZipFile(docx_path, 'r') as zip_ref:
                zip_ref.extractall(extract_path)
            
            # Create comments.xml
            comments_xml = self._create_comments_xml()
            comments_path = extract_path / "word" / "comments.xml"
            comments_path.write_text(comments_xml, encoding='utf-8')
            
            # Update [Content_Types].xml
            self._update_content_types(extract_path)
            
            # Update document.xml.rels
            self._update_document_rels(extract_path)
            
            # Repackage as DOCX
            output_temp = temp_path / "output.docx"
            with zipfile.ZipFile(output_temp, 'w', zipfile.ZIP_DEFLATED) as docx:
                for file_path in extract_path.rglob('*'):
                    if file_path.is_file():
                        arcname = file_path.relative_to(extract_path)
                        docx.write(file_path, arcname)
            
            # Replace original file
            shutil.copy2(output_temp, docx_path)
        
        return docx_path
    
    def _create_comments_xml(self) -> str:
        """Create comments.xml content."""
        nsmap = {
            'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main',
            'wpc': 'http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas',
            'mc': 'http://schemas.openxmlformats.org/markup-compatibility/2006',
            'o': 'urn:schemas-microsoft-com:office:office',
            'r': 'http://schemas.openxmlformats.org/officeDocument/2006/relationships',
            'v': 'urn:schemas-microsoft-com:vml',
            'wp': 'http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing',
            'w10': 'urn:schemas-microsoft-com:office:word',
        }
        
        # Create root element
        root = etree.Element('{%s}comments' % nsmap['w'], nsmap=nsmap)
        
        # Add each comment
        for comment in self.comments:
            comment_elem = etree.SubElement(root, '{%s}comment' % nsmap['w'])
            comment_elem.set('{%s}id' % nsmap['w'], comment['id'])
            comment_elem.set('{%s}author' % nsmap['w'], comment['author'])
            comment_elem.set('{%s}date' % nsmap['w'], comment['date'])
            comment_elem.set('{%s}initials' % nsmap['w'], 'ICF')
            
            # Add paragraph
            p = etree.SubElement(comment_elem, '{%s}p' % nsmap['w'])
            
            # Add paragraph properties
            pPr = etree.SubElement(p, '{%s}pPr' % nsmap['w'])
            pStyle = etree.SubElement(pPr, '{%s}pStyle' % nsmap['w'])
            pStyle.set('{%s}val' % nsmap['w'], 'CommentText')
            
            # Add text run
            r = etree.SubElement(p, '{%s}r' % nsmap['w'])
            t = etree.SubElement(r, '{%s}t' % nsmap['w'])
            t.set('{http://www.w3.org/XML/1998/namespace}space', 'preserve')
            t.text = comment['text']
        
        # Convert to string
        return etree.tostring(root, encoding='unicode', pretty_print=True, xml_declaration=False)
    
    def _update_content_types(self, extract_path: Path):
        """Update [Content_Types].xml to include comments."""
        content_types_path = extract_path / "[Content_Types].xml"
        
        tree = etree.parse(str(content_types_path))
        root = tree.getroot()
        
        nsmap = {'ct': 'http://schemas.openxmlformats.org/package/2006/content-types'}
        
        # Check if comments override already exists
        existing = root.xpath('//ct:Override[@PartName="/word/comments.xml"]', namespaces=nsmap)
        if not existing:
            override = etree.SubElement(root, '{%s}Override' % nsmap['ct'])
            override.set('PartName', '/word/comments.xml')
            override.set('ContentType', 'application/vnd.openxmlformats-officedocument.wordprocessingml.comments+xml')
        
        tree.write(str(content_types_path), encoding='utf-8', xml_declaration=True, standalone=True)
    
    def _update_document_rels(self, extract_path: Path):
        """Update document.xml.rels to include comments relationship."""
        rels_path = extract_path / "word" / "_rels" / "document.xml.rels"
        
        tree = etree.parse(str(rels_path))
        root = tree.getroot()
        
        nsmap = {'r': 'http://schemas.openxmlformats.org/package/2006/relationships'}
        
        # Check if comments relationship already exists
        existing = root.xpath('//r:Relationship[@Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/comments"]', namespaces=nsmap)
        if not existing:
            # Find highest rId
            rels = root.xpath('//r:Relationship', namespaces=nsmap)
            max_id = 0
            for rel in rels:
                rid = rel.get('Id', '')
                if rid.startswith('rId'):
                    try:
                        num = int(rid[3:])
                        max_id = max(max_id, num)
                    except ValueError:
                        pass
            
            new_id = f"rId{max_id + 1}"
            
            relationship = etree.SubElement(root, '{%s}Relationship' % nsmap['r'])
            relationship.set('Id', new_id)
            relationship.set('Type', 'http://schemas.openxmlformats.org/officeDocument/2006/relationships/comments')
            relationship.set('Target', 'comments.xml')
        
        tree.write(str(rels_path), encoding='utf-8', xml_declaration=True, standalone=True)
