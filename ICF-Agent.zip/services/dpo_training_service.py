"""DPO training orchestration service for Azure OpenAI fine-tuning runs."""

from __future__ import annotations

import json
import os
import threading
import time
import uuid
from datetime import datetime
from typing import Any, Dict, Optional

import requests
from azure.core.exceptions import ResourceExistsError, ResourceNotFoundError
from azure.storage.blob import ContentSettings

from config import Config
from services.client_manager import client_manager
from utils.logger import get_logger


class TrainingRunStatus(str):
    """String-backed status values for DPO runs."""

    QUEUED = "queued"
    RUNNING = "running"
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    CANCELLED = "cancelled"


class DPOTrainingService:
    """Manage lifecycle of DPO training runs and artifact persistence."""

    ARTIFACT_PREFIX = "models/dpo/runs"

    def __init__(self) -> None:
        self._runs: Dict[str, Dict[str, Any]] = {}
        self._lock = threading.Lock()
        self._logger = get_logger("dpo_training_service")
        self._blob_service = client_manager.blob_service_client
        self._container_name = Config.AZURE_STORAGE_CONTAINER_NAME
        self._container_client = None
        if self._blob_service and self._container_name:
            self._container_client = self._blob_service.get_container_client(self._container_name)
            self._ensure_container()

    # ------------------------------------------------------------------
    # Public helpers
    # ------------------------------------------------------------------
    def is_enabled(self) -> bool:
        """True when storage + config are ready for DPO runs."""
        return self._container_client is not None

    def queue_run(self, request: Dict[str, Any]) -> Dict[str, Any]:
        """Create a queued run entry and persist initial status."""
        if not self.is_enabled():
            raise RuntimeError("DPO training service is not configured")

        run_id = request.get("run_id") or uuid.uuid4().hex
        timestamp = datetime.utcnow().isoformat()
        run = {
            "run_id": run_id,
            "status": TrainingRunStatus.QUEUED,
            "stage": "queued",
            "message": "Training run queued",
            "initiated_by": request.get("initiated_by"),
            "notes": request.get("notes"),
            "dry_run": bool(request.get("dry_run", False)),
            "created_at": timestamp,
            "updated_at": timestamp,
            "job_id": None,
            "model_name": None,
            "deployment_name": Config.AZURE_OPENAI_DEPLOYMENT_NAME,
            "artifacts": {
                "config": None,
                "evaluation": None,
                "dataset_manifest": None,
            },
            "metrics": {},
            "request": request or {},
        }

        with self._lock:
            self._runs[run_id] = run
        self._persist_status(run_id)
        self._logger.info("Queued DPO training run", context={"runId": run_id})
        return self._serialize(run)

    def execute_run(self, run_id: str, request: Optional[Dict[str, Any]] = None) -> None:
        """Execute a queued run in the current thread (call from background task)."""
        if not self.is_enabled():
            self._logger.warning("DPO training service disabled - ignoring run", context={"runId": run_id})
            return

        run = self._get_run(run_id)
        if not run:
            self._logger.error("Run not found; cannot execute", context={"runId": run_id})
            return

        payload = dict(request or run.get("request") or {})
        dataset_path = None
        sanitized_path = None
        total_start = time.perf_counter()

        try:
            from scripts.dpo_finetune_runner import DPOFineTuneRunner
            runner = DPOFineTuneRunner()
        except Exception as exc:
            self._logger.exception("Unable to initialize DPO fine-tune runner", context={"runId": run_id})
            self._update_run(
                run_id,
                status=TrainingRunStatus.FAILED,
                stage="failed",
                message=str(exc),
            )
            return

        try:
            self._update_run(
                run_id,
                status=TrainingRunStatus.RUNNING,
                stage="dataset_download",
                message="Downloading DPO dataset",
            )
            dataset_path, record_count = runner.download_dataset()
            manifest_url = self._upload_json_artifact(
                run_id,
                "dataset_manifest.json",
                {
                    "run_id": run_id,
                    "blob_path": runner.DATASET_BLOB_PATH,
                    "records": record_count,
                    "captured_at": datetime.utcnow().isoformat(),
                },
            )
            self._update_run(
                run_id,
                stage="dataset_snapshot",
                message="Dataset snapshot stored",
                artifacts={"dataset_manifest": manifest_url},
                metrics={"dataset_records": record_count},
            )

            sanitized_path, sanitized_records = runner.preprocess_dataset(dataset_path)
            config_url = self._upload_json_artifact(
                run_id,
                "config.json",
                self._build_config_payload(run_id, runner, sanitized_records, payload),
            )
            self._update_run(
                run_id,
                stage="config_ready",
                message="Training configuration stored",
                artifacts={"config": config_url},
                metrics={"sanitized_records": sanitized_records},
            )

            if payload.get("dry_run"):
                total_elapsed = time.perf_counter() - total_start
                eval_url = self._upload_json_artifact(
                    run_id,
                    "eval.json",
                    {
                        "run_id": run_id,
                        "dry_run": True,
                        "records": sanitized_records,
                        "message": "Dry run completed - training job not submitted",
                        "total_seconds": round(total_elapsed, 2),
                    },
                )
                self._update_run(
                    run_id,
                    status=TrainingRunStatus.SUCCEEDED,
                    stage="completed",
                    message="Dry run completed",
                    artifacts={"evaluation": eval_url},
                    metrics={"total_seconds": round(total_elapsed, 2)},
                )
                return

            file_id = runner.upload_training_file(sanitized_path)
            self._update_run(
                run_id,
                stage="file_uploaded",
                message="Training file uploaded",
                metrics={"training_file_id": file_id},
            )
            runner.wait_for_file_processing(file_id)

            job_id = runner.submit_dpo_job(file_id)
            self._update_run(
                run_id,
                stage="fine_tuning",
                message="Fine-tuning job submitted",
                job_id=job_id,
            )
            finetune_start = time.perf_counter()
            model_name = runner.monitor_job(job_id)
            finetune_seconds = time.perf_counter() - finetune_start

            runner.update_deployment(model_name)
            runner.cleanup_old_files()

            eval_url = self._upload_json_artifact(
                run_id,
                "eval.json",
                {
                    "run_id": run_id,
                    "job_id": job_id,
                    "model_name": model_name,
                    "deployment": runner.deployment_name,
                    "records": sanitized_records,
                    "finetune_seconds": round(finetune_seconds, 2),
                    "total_seconds": round(time.perf_counter() - total_start, 2),
                    "completed_at": datetime.utcnow().isoformat(),
                },
            )

            self._update_run(
                run_id,
                status=TrainingRunStatus.SUCCEEDED,
                stage="completed",
                message="DPO training completed",
                model_name=model_name,
                deployment_name=runner.deployment_name,
                artifacts={"evaluation": eval_url},
                metrics={
                    "finetune_seconds": round(finetune_seconds, 2),
                    "total_seconds": round(time.perf_counter() - total_start, 2),
                },
            )
        except Exception as exc:
            self._logger.exception("DPO training run failed", context={"runId": run_id})
            self._update_run(
                run_id,
                status=TrainingRunStatus.FAILED,
                stage="failed",
                message=str(exc),
            )
        finally:
            for path in {dataset_path, sanitized_path}:
                if path and os.path.exists(path):
                    try:
                        os.remove(path)
                    except OSError:
                        self._logger.warning(
                            "Failed to clean up temp file",
                            context={"runId": run_id, "path": path},
                        )

    def get_status(self, run_id: str) -> Optional[Dict[str, Any]]:
        """Return the latest status for a run (from cache or blob)."""
        with self._lock:
            run = self._runs.get(run_id)
        if run:
            return self._serialize(run)
        persisted = self._load_status_from_blob(run_id)
        if persisted:
            with self._lock:
                self._runs[run_id] = persisted
            return self._serialize(persisted)
        return None

    def apply_callback(self, payload: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Update run status via external callback."""
        run_id = payload.get("run_id")
        if not run_id:
            return None
        status = payload.get("status")
        artifacts = payload.get("artifacts")
        metrics = payload.get("metrics")
        updates: Dict[str, Any] = {
            "stage": payload.get("stage", "callback"),
            "message": payload.get("message"),
            "job_id": payload.get("job_id"),
            "model_name": payload.get("model_name"),
            "deployment_name": payload.get("deployment_name"),
        }
        if status:
            updates["status"] = status
        result = self._update_run(run_id, artifacts=artifacts, metrics=metrics, **updates)
        return result

    def get_active_model_info(self) -> Dict[str, Any]:
        """Return deployment metadata for the currently active model."""
        endpoint = (Config.AZURE_OPENAI_ENDPOINT or "").rstrip("/")
        api_key = Config.AZURE_OPENAI_API_KEY
        deployment = Config.AZURE_OPENAI_DEPLOYMENT_NAME
        api_version = Config.AZURE_OPENAI_API_VERSION or "2025-01-01-preview"
        info: Dict[str, Any] = {
            "deployment_name": deployment,
            "configured_model": Config.AZURE_OPENAI_MODEL_VERSION,
        }
        if not endpoint or not api_key or not deployment:
            return info

        url = f"{endpoint}/openai/deployments/{deployment}?api-version={api_version}"
        try:
            response = requests.get(url, headers={"api-key": api_key}, timeout=15)
            response.raise_for_status()
            payload = response.json()
            info.update(
                {
                    "model": payload.get("model"),
                    "status": payload.get("status"),
                    "created_at": payload.get("created_at"),
                    "scale_settings": payload.get("scale_settings"),
                }
            )
        except Exception as exc:
            self._logger.warning(
                "Failed to fetch deployment metadata",
                context={"error": str(exc)},
            )
        return info

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------
    def _ensure_container(self) -> None:
        if not self._container_client:
            return
        try:
            self._container_client.get_container_properties()
        except ResourceNotFoundError:
            try:
                self._container_client.create_container()
            except ResourceExistsError:
                pass
        except Exception as exc:
            self._logger.warning(
                "Unable to verify blob container for DPO runs",
                context={"error": str(exc)},
            )

    def _get_run(self, run_id: str) -> Optional[Dict[str, Any]]:
        with self._lock:
            run = self._runs.get(run_id)
        if run:
            return run
        persisted = self._load_status_from_blob(run_id)
        if persisted:
            with self._lock:
                self._runs[run_id] = persisted
        return persisted

    def _run_prefix(self, run_id: str) -> str:
        return f"{self.ARTIFACT_PREFIX}/{run_id}"

    def _upload_json_artifact(self, run_id: str, filename: str, payload: Dict[str, Any]) -> Optional[str]:
        if not self._container_client:
            return None
        blob_path = f"{self._run_prefix(run_id)}/{filename}"
        blob_client = self._container_client.get_blob_client(blob_path)
        blob_client.upload_blob(
            json.dumps(payload, indent=2).encode("utf-8"),
            overwrite=True,
            content_settings=ContentSettings(content_type="application/json"),
        )
        return blob_client.url

    def _build_config_payload(
        self,
        run_id: str,
        runner: DPOFineTuneRunner,
        record_count: int,
        request: Dict[str, Any],
    ) -> Dict[str, Any]:
        beta = Config.DPO_BETA
        l2_mult = Config.DPO_L2_MULTIPLIER
        return {
            "run_id": run_id,
            "timestamp": datetime.utcnow().isoformat(),
            "initiated_by": request.get("initiated_by"),
            "notes": request.get("notes"),
            "dry_run": bool(request.get("dry_run", False)),
            "dataset": {
                "blob_path": runner.DATASET_BLOB_PATH,
                "records": record_count,
            },
            "azure_openai": {
                "endpoint": runner.endpoint,
                "base_model": runner.base_model,
                "deployment": runner.deployment_name,
                "api_version": runner.api_version,
            },
            "training": {
                "method": "dpo",
                "beta": beta,
                "l2_multiplier": l2_mult,
            },
        }

    def _update_run(
        self,
        run_id: str,
        status: Optional[str] = None,
        stage: Optional[str] = None,
        message: Optional[str] = None,
        artifacts: Optional[Dict[str, Optional[str]]] = None,
        metrics: Optional[Dict[str, Any]] = None,
        **extra: Any,
    ) -> Optional[Dict[str, Any]]:
        run = self._get_run(run_id)
        if not run:
            return None
        with self._lock:
            if status is not None:
                run["status"] = status
            if stage is not None:
                run["stage"] = stage
            if message is not None:
                run["message"] = message
            if artifacts:
                run.setdefault("artifacts", {}).update(
                    {k: v for k, v in artifacts.items() if v is not None}
                )
            if metrics:
                run.setdefault("metrics", {}).update(metrics)
            for key, value in extra.items():
                if value is not None:
                    run[key] = value
            run["updated_at"] = datetime.utcnow().isoformat()
        self._persist_status(run_id)
        return self._serialize(run)

    def _persist_status(self, run_id: str) -> None:
        if not self._container_client:
            return
        run = self._runs.get(run_id)
        if not run:
            return
        payload = self._serialize(run, include_request=True)
        blob_path = f"{self._run_prefix(run_id)}/status.json"
        blob_client = self._container_client.get_blob_client(blob_path)
        blob_client.upload_blob(
            json.dumps(payload, indent=2).encode("utf-8"),
            overwrite=True,
            content_settings=ContentSettings(content_type="application/json"),
        )

    def _load_status_from_blob(self, run_id: str) -> Optional[Dict[str, Any]]:
        if not self._container_client:
            return None
        blob_path = f"{self._run_prefix(run_id)}/status.json"
        blob_client = self._container_client.get_blob_client(blob_path)
        try:
            data = blob_client.download_blob().readall()
        except ResourceNotFoundError:
            return None
        return json.loads(data.decode("utf-8"))

    def _serialize(self, run: Dict[str, Any], include_request: bool = False) -> Dict[str, Any]:
        data = {k: v for k, v in run.items() if k != "request"}
        if include_request:
            data["request"] = run.get("request")
        return json.loads(json.dumps(data))
