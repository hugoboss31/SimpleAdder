"""
Review OpenXML Editor.
OpenXML-based document editor using lxml to:
1. Preserve existing client comments
2. Preserve existing client track changes
3. Add agent modifications as new track changes
Uses comment range markers to find exact edit locations.
"""

import os
import re
import shutil
import zipfile
from copy import deepcopy
from datetime import datetime
from typing import List, Dict, Tuple, Optional

try:
    from lxml import etree
    LXML_AVAILABLE = True
except ImportError:
    LXML_AVAILABLE = False

W_NS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
W = "{" + W_NS + "}"
R_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
XML_NS = "http://www.w3.org/XML/1998/namespace"
XML_SPACE = "{" + XML_NS + "}space"
RELS_NS = "http://schemas.openxmlformats.org/package/2006/relationships"


class ReviewOpenXmlEditor:
    """
    Applies agent edits to reviewed documents while preserving:
    - Client comments (in margins)
    - Client track changes (insertions/deletions)
    - Adds agent modifications as NEW track changes
    """
    
    AGENT_AUTHOR = "ICF-Regen-Agent"
    
    def __init__(self):
        if not LXML_AVAILABLE:
            raise ImportError("lxml is required for OpenXML editing")
        print("  ✓ ReviewOpenXmlEditor initialized")
    
    def _normalize_text(self, text: str) -> str:
        """Normalize text for comparison."""
        if not text:
            return ""
        normalized = re.sub(r'\s+', ' ', text.strip())
        normalized = normalized.replace('\u00a0', ' ')
        normalized = normalized.replace('\u2019', "'")
        normalized = normalized.replace('\u201c', '"').replace('\u201d', '"')
        return normalized.lower()
    
    def apply_edits_preserving_changes(
        self,
        input_path: str,
        output_path: str,
        edit_instructions: List[Dict]
    ) -> Tuple[bool, int, List[str]]:
        """
        Apply agent edits while preserving all existing comments and track changes.
        Uses comment_id to find exact location via commentRangeStart/End markers.
        """
        temp_dir = output_path + "_temp"
        
        try:
            if os.path.exists(temp_dir):
                shutil.rmtree(temp_dir)
            
            with zipfile.ZipFile(input_path, 'r') as zip_ref:
                zip_ref.extractall(temp_dir)
            
            doc_xml_path = os.path.join(temp_dir, "word", "document.xml")
            parser = etree.XMLParser(remove_blank_text=False)
            tree = etree.parse(doc_xml_path, parser)
            root = tree.getroot()
            
            max_revision_id = self._get_max_revision_id(root)
            revision_id = max_revision_id + 1
            
            max_comment_id = self._get_max_comment_id(temp_dir)
            new_comment_id = max_comment_id + 1
            
            date_str = datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
            
            edits_applied = 0
            modified_sections = set()
            new_comments = []
            
            failed_edits = []
            applied_edits = []
            
            total_edits = len([e for e in edit_instructions if e.get('action') != 'NO_ACTION'])
            
            print(f"\n{'='*60}")
            print(f"📝 EDIT APPLICATION LOG")
            print(f"   Total edits to process: {total_edits}")
            print(f"{'='*60}")
            
            edit_index = 0
            for instruction in edit_instructions:
                action = instruction.get('action', 'REPLACE')
                
                if action == 'NO_ACTION':
                    continue
                
                edit_index += 1
                src_comment_id = instruction.get('comment_id', 'unknown')
                original_text = instruction.get('original_text', '')
                new_text = instruction.get('new_text', '')
                original_preview = original_text[:80] + "..." if len(original_text) > 80 else original_text
                
                print(f"\n📝 Edit {edit_index}/{total_edits}: comment_id={src_comment_id}, action={action}")
                print(f"   Original text: \"{original_preview}\"")
                
                success = False
                fail_reason = ""
                
                if action == 'REPLACE':
                    success, revision_id, new_comment_id, fail_reason = self._apply_edit_at_comment_range(
                        root, src_comment_id, original_text, new_text, 
                        revision_id, new_comment_id, date_str, new_comments, instruction
                    )
                elif action == 'DELETE':
                    success, revision_id, new_comment_id, fail_reason = self._apply_edit_at_comment_range(
                        root, src_comment_id, original_text, "",
                        revision_id, new_comment_id, date_str, new_comments, instruction
                    )
                elif action == 'INSERT':
                    success, revision_id, new_comment_id, fail_reason = self._apply_insert_at_comment_range(
                        root, src_comment_id, new_text,
                        revision_id, new_comment_id, date_str, new_comments, instruction
                    )
                elif action == 'COMMENT_ONLY':
                    success, new_comment_id, fail_reason = self._apply_comment_only(
                        root, src_comment_id, new_comment_id, date_str, new_comments, instruction
                    )
                elif action == 'CLARIFY':
                    success, new_comment_id, fail_reason = self._apply_clarify(
                        root, src_comment_id, new_comment_id, date_str, new_comments, instruction
                    )
                
                if success:
                    edits_applied += 1
                    section_id = instruction.get('section_id')
                    if section_id:
                        modified_sections.add(section_id)
                    applied_edits.append(src_comment_id)
                    print(f"   ✅ SUCCESS: Edit applied")
                else:
                    failed_edits.append({'comment_id': src_comment_id, 'reason': fail_reason})
                    print(f"   ❌ FAILED: {fail_reason}")
            
            print(f"\n{'='*60}")
            print(f"📊 EDIT SUMMARY: {edits_applied}/{total_edits} applied")
            if applied_edits:
                print(f"   ✅ Applied: {applied_edits}")
            if failed_edits:
                print(f"   ❌ Failed:")
                for fe in failed_edits:
                    print(f"      - comment_{fe['comment_id']}: {fe['reason']}")
            print(f"{'='*60}\n")
            
            tree.write(doc_xml_path, xml_declaration=True, encoding='UTF-8', standalone='yes')
            
            if new_comments:
                self._append_comments(temp_dir, new_comments)
            
            self._enable_track_changes(temp_dir)
            
            with zipfile.ZipFile(output_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
                for root_dir, dirs, files in os.walk(temp_dir):
                    for file in files:
                        file_path = os.path.join(root_dir, file)
                        arcname = os.path.relpath(file_path, temp_dir)
                        zipf.write(file_path, arcname)
            
            return True, edits_applied, list(modified_sections)
            
        except Exception as e:
            print(f"  ⚠️ OpenXML edit failed: {e}")
            import traceback
            traceback.print_exc()
            return False, 0, []
            
        finally:
            if os.path.exists(temp_dir):
                shutil.rmtree(temp_dir)
    
    def _find_comment_range_elements(
        self,
        root,
        comment_id: str
    ) -> Tuple[Optional[etree.Element], Optional[etree.Element], Optional[etree.Element], Optional[etree.Element]]:
        """
        Find commentRangeStart, commentRangeEnd, and their parent paragraphs.
        Returns (range_start, range_end, start_parent_para, end_parent_para)
        """
        range_start = None
        range_end = None
        start_parent_para = None
        end_parent_para = None
        
        for elem in root.iter():
            if elem.tag == W + 'commentRangeStart':
                if elem.get(W + 'id') == str(comment_id):
                    range_start = elem
                    parent = elem.getparent()
                    while parent is not None:
                        if parent.tag == W + 'p':
                            start_parent_para = parent
                            break
                        parent = parent.getparent()
            
            elif elem.tag == W + 'commentRangeEnd':
                if elem.get(W + 'id') == str(comment_id):
                    range_end = elem
                    parent = elem.getparent()
                    while parent is not None:
                        if parent.tag == W + 'p':
                            end_parent_para = parent
                            break
                        parent = parent.getparent()
        
        return range_start, range_end, start_parent_para, end_parent_para
    
    def _get_text_between_markers(
        self,
        parent_para,
        range_start,
        range_end
    ) -> Tuple[str, List[etree.Element]]:
        """
        Get text and runs between commentRangeStart and commentRangeEnd.
        Returns (combined_text, list_of_run_elements)
        """
        text_parts = []
        runs_in_range = []
        in_range = False
        
        for elem in parent_para.iter():
            if elem == range_start:
                in_range = True
                continue
            
            if elem == range_end:
                in_range = False
                break
            
            if in_range:
                if elem.tag == W + 'r':
                    runs_in_range.append(elem)
                elif elem.tag == W + 't' and elem.text:
                    text_parts.append(elem.text)
        
        return ''.join(text_parts), runs_in_range
    
    def _apply_edit_at_comment_range(
        self,
        root,
        comment_id: str,
        original_text: str,
        new_text: str,
        revision_id: int,
        new_comment_id: int,
        date_str: str,
        new_comments: List,
        instruction: Dict
    ) -> Tuple[bool, int, int, str]:
        """
        Apply REPLACE or DELETE edit at the exact location marked by comment range.
        Preserves the client comment, adds agent response as new comment.
        """
        reasoning = instruction.get('reasoning', '')
        rag_ids = instruction.get('rag_ids_used', [])
        rag_sources = instruction.get('rag_sources', [])
        action = instruction.get('action', 'REPLACE')
        
        range_start, range_end, parent_para, end_para = self._find_comment_range_elements(root, comment_id)
        
        if range_start is None or range_end is None:
            print(f"   ⚠️ Comment range markers not found for comment_id={comment_id}")
            return self._fallback_text_search(
                root, original_text, new_text, revision_id, new_comment_id,
                date_str, new_comments, instruction
            )
        
        if parent_para is None:
            return False, revision_id, new_comment_id, "Parent paragraph not found"
        
        print(f"   ➤ Found comment range markers for comment_id={comment_id}")
        
        linked_text, runs_in_range = self._get_text_between_markers(parent_para, range_start, range_end)
        print(f"   ➤ Linked text ({len(linked_text)} chars): \"{linked_text[:50]}...\"")
        
        if not runs_in_range:
            return False, revision_id, new_comment_id, "No runs found between comment markers"
        
        first_run = runs_in_range[0]
        rPr = first_run.find(W + 'rPr')
        rPr_copy = deepcopy(rPr) if rPr is not None else None
        
        # Handle nested commentRangeStart - find direct child or use first run position
        try:
            insert_position = list(parent_para).index(range_start)
        except ValueError:
            # range_start is nested (inside a run or other element), use first run position
            try:
                insert_position = list(parent_para).index(first_run)
            except ValueError:
                return False, revision_id, new_comment_id, "Cannot find insertion position in paragraph"
        
        for run in runs_in_range:
            if run.getparent() == parent_para:
                parent_para.remove(run)
        
        new_elements = []
        
        del_elem = self._create_deletion(linked_text, revision_id, date_str)
        new_elements.append(del_elem)
        revision_id += 1
        
        if new_text:
            ins_elem = self._create_insertion(new_text, revision_id, date_str)
            new_elements.append(ins_elem)
            revision_id += 1
        
        agent_comment_start = etree.Element(W + 'commentRangeStart')
        agent_comment_start.set(W + 'id', str(new_comment_id))
        
        agent_comment_end = etree.Element(W + 'commentRangeEnd')
        agent_comment_end.set(W + 'id', str(new_comment_id))
        
        agent_comment_ref = self._create_comment_reference(new_comment_id)
        
        new_text_preview = new_text[:50] + '...' if len(new_text) > 50 else new_text
        comment_text = f"{action.upper()}: '{new_text_preview}'  Reason: {reasoning}"
        if rag_sources:
            first_source = rag_sources[0]
            # source_file = first_source.get('source_file', '')
            topic = first_source.get('topic', '')
            comment_text += f" Source: [{first_source.get('rag_id', '')}] - {topic}"
        elif rag_ids:
            comment_text += f" Source: [{', '.join(rag_ids)}]"
        
        new_comments.append({
            'id': new_comment_id,
            'author': self.AGENT_AUTHOR,
            'date': date_str,
            'initials': 'HRA',
            'text': comment_text
        })
        new_comment_id += 1
        
        # Handle nested range_start - use insert_position we already found
        try:
            range_start_idx = list(parent_para).index(range_start)
        except ValueError:
            range_start_idx = insert_position
        
        current_idx = range_start_idx + 1
        parent_para.insert(current_idx, agent_comment_start)
        current_idx += 1
        
        for elem in new_elements:
            parent_para.insert(current_idx, elem)
            current_idx += 1
        
        parent_para.insert(current_idx, agent_comment_end)
        current_idx += 1
        parent_para.insert(current_idx, agent_comment_ref)
        
        return True, revision_id, new_comment_id, ""
    
    def _apply_insert_at_comment_range(
        self,
        root,
        comment_id: str,
        new_text: str,
        revision_id: int,
        new_comment_id: int,
        date_str: str,
        new_comments: List,
        instruction: Dict
    ) -> Tuple[bool, int, int, str]:
        """
        Apply INSERT edit after the comment range end.
        Handles cases where commentRangeEnd is in a different paragraph.
        """
        reasoning = instruction.get('reasoning', '')
        rag_ids = instruction.get('rag_ids_used', [])
        rag_sources = instruction.get('rag_sources', [])
        
        range_start, range_end, start_para, end_para = self._find_comment_range_elements(root, comment_id)
        
        if range_end is None or end_para is None:
            print(f"   ⚠️ Comment range end not found for comment_id={comment_id}")
            original_text = instruction.get('original_text', '')
            return self._fallback_text_search_insert(
                root, original_text, new_text, revision_id, new_comment_id,
                date_str, new_comments, instruction
            )
        
        print(f"   ➤ Found comment range for insert at comment_id={comment_id}")
        
        # Handle nested range_end - may be inside a run, not direct child of paragraph
        try:
            range_end_idx = list(end_para).index(range_end)
        except ValueError:
            # range_end is nested, find last run in paragraph as fallback
            runs = end_para.findall(W + 'r')
            if runs:
                try:
                    range_end_idx = list(end_para).index(runs[-1])
                except ValueError:
                    range_end_idx = len(list(end_para)) - 1
            else:
                range_end_idx = len(list(end_para)) - 1
        
        agent_comment_start = etree.Element(W + 'commentRangeStart')
        agent_comment_start.set(W + 'id', str(new_comment_id))
        
        ins_elem = self._create_insertion(" " + new_text, revision_id, date_str)
        revision_id += 1
        
        agent_comment_end = etree.Element(W + 'commentRangeEnd')
        agent_comment_end.set(W + 'id', str(new_comment_id))
        
        agent_comment_ref = self._create_comment_reference(new_comment_id)
        
        comment_text = f"Agent Insert: {reasoning}"
        if rag_sources:
            first_source = rag_sources[0]
            topic = first_source.get('topic', '')
            comment_text += f" Source: [{first_source.get('rag_id', '')}] - {topic}"
        elif rag_ids:
            comment_text += f" Source: [{', '.join(rag_ids)}]"
        
        new_comments.append({
            'id': new_comment_id,
            'author': self.AGENT_AUTHOR,
            'date': date_str,
            'initials': 'HRA',
            'text': comment_text
        })
        new_comment_id += 1
        
        current_idx = range_end_idx + 2
        end_para.insert(current_idx, agent_comment_start)
        current_idx += 1
        end_para.insert(current_idx, ins_elem)
        current_idx += 1
        end_para.insert(current_idx, agent_comment_end)
        current_idx += 1
        end_para.insert(current_idx, agent_comment_ref)
        
        return True, revision_id, new_comment_id, ""
    
    def _apply_comment_only(
        self,
        root,
        comment_id: str,
        new_comment_id: int,
        date_str: str,
        new_comments: List,
        instruction: Dict
    ) -> Tuple[bool, int, str]:
        """
        Add agent comment only (no track changes).
        Used when no relevant info found in knowledge base.
        """
        reasoning = instruction.get('reasoning', '')
        
        range_start, range_end, start_para, end_para = self._find_comment_range_elements(root, comment_id)
        
        if range_end is None or end_para is None:
            return False, new_comment_id, "Comment range not found"
        
        print(f"   ➤ Adding comment-only response for comment_id={comment_id}")
        
        # Handle nested range_end
        try:
            range_end_idx = list(end_para).index(range_end)
        except ValueError:
            runs = end_para.findall(W + 'r')
            range_end_idx = list(end_para).index(runs[-1]) if runs else len(list(end_para)) - 1        
        agent_comment_start = etree.Element(W + 'commentRangeStart')
        agent_comment_start.set(W + 'id', str(new_comment_id))
        
        agent_comment_end = etree.Element(W + 'commentRangeEnd')
        agent_comment_end.set(W + 'id', str(new_comment_id))
        
        agent_comment_ref = self._create_comment_reference(new_comment_id)
        
        comment_text = f"Agent Note: {reasoning}"
        
        new_comments.append({
            'id': new_comment_id,
            'author': self.AGENT_AUTHOR,
            'date': date_str,
            'initials': 'HRA',
            'text': comment_text
        })
        new_comment_id += 1
        
        current_idx = range_end_idx + 2
        end_para.insert(current_idx, agent_comment_start)
        current_idx += 1
        end_para.insert(current_idx, agent_comment_end)
        current_idx += 1
        end_para.insert(current_idx, agent_comment_ref)
        
        return True, new_comment_id, ""

    def _apply_clarify(
        self,
        root,
        comment_id: str,
        new_comment_id: int,
        date_str: str,
        new_comments: List,
        instruction: Dict
    ) -> Tuple[bool, int, str]:
        """
        Add agent clarification comment with RAG source reference (no track changes).
        Used when client asks to check/verify content.
        """
        reasoning = instruction.get('reasoning', '')
        rag_sources = instruction.get('rag_sources', [])
        
        range_start, range_end, start_para, end_para = self._find_comment_range_elements(root, comment_id)
        
        if range_end is None or end_para is None:
            return False, new_comment_id, "Comment range not found"
        
        print(f"   ➤ Adding clarification response for comment_id={comment_id}")
        
        # Handle nested range_end
        try:
            range_end_idx = list(end_para).index(range_end)
        except ValueError:
            runs = end_para.findall(W + 'r')
            range_end_idx = list(end_para).index(runs[-1]) if runs else len(list(end_para)) - 1        
        agent_comment_start = etree.Element(W + 'commentRangeStart')
        agent_comment_start.set(W + 'id', str(new_comment_id))
        
        agent_comment_end = etree.Element(W + 'commentRangeEnd')
        agent_comment_end.set(W + 'id', str(new_comment_id))
        
        agent_comment_ref = self._create_comment_reference(new_comment_id)
        
        comment_text = f"CLARIFY: {reasoning}"
        if rag_sources:
            first_source = rag_sources[0]
            topic = first_source.get('topic', '')
            comment_text += f" Source: [{first_source.get('rag_id', '')}] - {topic}"
        
        new_comments.append({
            'id': new_comment_id,
            'author': self.AGENT_AUTHOR,
            'date': date_str,
            'initials': 'HRA',
            'text': comment_text
        })
        new_comment_id += 1
        
        current_idx = range_end_idx + 2
        end_para.insert(current_idx, agent_comment_start)
        current_idx += 1
        end_para.insert(current_idx, agent_comment_end)
        current_idx += 1
        end_para.insert(current_idx, agent_comment_ref)
        
        return True, new_comment_id, ""
    
    def _fallback_text_search(
        self,
        root,
        original_text: str,
        new_text: str,
        revision_id: int,
        comment_id: int,
        date_str: str,
        new_comments: List,
        instruction: Dict
    ) -> Tuple[bool, int, int, str]:
        """
        Fallback: search for text in paragraphs when comment markers not found.
        """
        if not original_text:
            return False, revision_id, comment_id, "No original_text for fallback search"
        
        reasoning = instruction.get('reasoning', '')
        rag_ids = instruction.get('rag_ids_used', [])
        
        original_normalized = self._normalize_text(original_text)
        all_paragraphs = list(root.iter(W + 'p'))
        
        print(f"   🔍 Fallback: searching {len(all_paragraphs)} paragraphs...")
        
        for para_idx, para in enumerate(all_paragraphs):
            para_text = self._get_paragraph_text(para)
            para_normalized = self._normalize_text(para_text)
            
            if original_normalized in para_normalized or self._fuzzy_match(original_normalized, para_normalized):
                print(f"   ➤ Fallback match in paragraph {para_idx}")
                
                first_run = para.find(W + 'r')
                rPr = None
                if first_run is not None:
                    rPr = first_run.find(W + 'rPr')
                    rPr = deepcopy(rPr) if rPr is not None else None
                
                runs_to_remove = [r for r in para.findall(W + 'r')]
                for run in runs_to_remove:
                    para.remove(run)
                
                comment_start = etree.Element(W + 'commentRangeStart')
                comment_start.set(W + 'id', str(comment_id))
                para.append(comment_start)
                
                del_elem = self._create_deletion(para_text, revision_id, date_str)
                para.append(del_elem)
                revision_id += 1
                
                if new_text:
                    ins_elem = self._create_insertion(new_text, revision_id, date_str)
                    para.append(ins_elem)
                    revision_id += 1
                
                comment_end = etree.Element(W + 'commentRangeEnd')
                comment_end.set(W + 'id', str(comment_id))
                para.append(comment_end)
                
                comment_ref = self._create_comment_reference(comment_id)
                para.append(comment_ref)
                
                comment_text = f"Agent Edit: {reasoning}"
                if rag_ids:
                    comment_text += f" [Source: {', '.join(rag_ids)}]"
                
                new_comments.append({
                    'id': comment_id,
                    'author': self.AGENT_AUTHOR,
                    'date': date_str,
                    'initials': 'HRA',
                    'text': comment_text
                })
                comment_id += 1
                
                return True, revision_id, comment_id, ""
        
        return False, revision_id, comment_id, "Text not found in document"
    
    def _fallback_text_search_insert(
        self,
        root,
        original_text: str,
        new_text: str,
        revision_id: int,
        comment_id: int,
        date_str: str,
        new_comments: List,
        instruction: Dict
    ) -> Tuple[bool, int, int, str]:
        """
        Fallback for INSERT when comment markers not found.
        """
        if not original_text:
            return False, revision_id, comment_id, "No original_text for fallback search"
        
        reasoning = instruction.get('reasoning', '')
        rag_ids = instruction.get('rag_ids_used', [])
        
        original_normalized = self._normalize_text(original_text)
        all_paragraphs = list(root.iter(W + 'p'))
        
        print(f"   🔍 Fallback insert: searching {len(all_paragraphs)} paragraphs...")
        
        for para_idx, para in enumerate(all_paragraphs):
            para_text = self._get_paragraph_text(para)
            para_normalized = self._normalize_text(para_text)
            
            if original_normalized in para_normalized or self._fuzzy_match(original_normalized, para_normalized):
                print(f"   ➤ Fallback match in paragraph {para_idx}")
                
                comment_start = etree.Element(W + 'commentRangeStart')
                comment_start.set(W + 'id', str(comment_id))
                para.append(comment_start)
                
                ins_elem = self._create_insertion(" " + new_text, revision_id, date_str)
                para.append(ins_elem)
                revision_id += 1
                
                comment_end = etree.Element(W + 'commentRangeEnd')
                comment_end.set(W + 'id', str(comment_id))
                para.append(comment_end)
                
                comment_ref = self._create_comment_reference(comment_id)
                para.append(comment_ref)
                
                comment_text = f"Agent Insert: {reasoning}"
                if rag_ids:
                    comment_text += f" [Source: {', '.join(rag_ids)}]"
                
                new_comments.append({
                    'id': comment_id,
                    'author': self.AGENT_AUTHOR,
                    'date': date_str,
                    'initials': 'HRA',
                    'text': comment_text
                })
                comment_id += 1
                
                return True, revision_id, comment_id, ""
        
        return False, revision_id, comment_id, "Text not found for insert"
    
    def _fuzzy_match(self, target: str, candidate: str) -> bool:
        """Check if >80% of target words are in candidate."""
        if not target or not candidate:
            return False
        
        target_words = set(target.split())
        candidate_words = set(candidate.split())
        
        if len(target_words) < 3:
            return False
        
        common = target_words & candidate_words
        overlap = len(common) / len(target_words)
        
        return overlap >= 0.80
    
    def _get_paragraph_text(self, para) -> str:
        """Get full text from a paragraph."""
        text_parts = []
        for elem in para.iter():
            if elem.tag == W + 't':
                if elem.text:
                    text_parts.append(elem.text)
        return ''.join(text_parts)
    
    def _get_max_revision_id(self, root) -> int:
        """Get maximum revision ID from existing track changes."""
        max_id = 0
        for elem in root.iter():
            if elem.tag in [W + 'ins', W + 'del']:
                rev_id = elem.get(W + 'id')
                if rev_id:
                    try:
                        max_id = max(max_id, int(rev_id))
                    except ValueError:
                        pass
        return max_id
    
    def _get_max_comment_id(self, temp_dir: str) -> int:
        """Get maximum comment ID from existing comments.xml."""
        comments_path = os.path.join(temp_dir, "word", "comments.xml")
        if not os.path.exists(comments_path):
            return -1
        try:
            tree = etree.parse(comments_path)
            root = tree.getroot()
            max_id = -1
            for comment in root.iter(W + 'comment'):
                cid = comment.get(W + 'id')
                if cid:
                    try:
                        max_id = max(max_id, int(cid))
                    except ValueError:
                        pass
            return max_id
        except:
            return -1
    
    def _create_text_run(self, text: str, rPr=None) -> etree.Element:
        """Create a simple text run."""
        run = etree.Element(W + 'r')
        if rPr is not None:
            run.append(deepcopy(rPr))
        t = etree.SubElement(run, W + 't')
        t.set(XML_SPACE, 'preserve')
        t.text = text
        return run
    
    def _create_deletion(self, text: str, revision_id: int, date_str: str) -> etree.Element:
        """Create a tracked deletion element."""
        del_elem = etree.Element(W + 'del')
        del_elem.set(W + 'id', str(revision_id))
        del_elem.set(W + 'author', self.AGENT_AUTHOR)
        del_elem.set(W + 'date', date_str)
        
        run = etree.SubElement(del_elem, W + 'r')
        rPr = etree.SubElement(run, W + 'rPr')
        etree.SubElement(rPr, W + 'strike')
        color = etree.SubElement(rPr, W + 'color')
        color.set(W + 'val', 'FF0000')
        
        del_text = etree.SubElement(run, W + 'delText')
        del_text.set(XML_SPACE, 'preserve')
        del_text.text = text
        
        return del_elem
    
    def _create_insertion(self, text: str, revision_id: int, date_str: str) -> etree.Element:
        """Create a tracked insertion element."""
        ins_elem = etree.Element(W + 'ins')
        ins_elem.set(W + 'id', str(revision_id))
        ins_elem.set(W + 'author', self.AGENT_AUTHOR)
        ins_elem.set(W + 'date', date_str)
        
        run = etree.SubElement(ins_elem, W + 'r')
        rPr = etree.SubElement(run, W + 'rPr')
        underline = etree.SubElement(rPr, W + 'u')
        underline.set(W + 'val', 'single')
        color = etree.SubElement(rPr, W + 'color')
        color.set(W + 'val', 'FF0000')
        
        t = etree.SubElement(run, W + 't')
        t.set(XML_SPACE, 'preserve')
        t.text = text
        
        return ins_elem
    
    def _create_comment_reference(self, comment_id: int) -> etree.Element:
        """Create a comment reference run."""
        run = etree.Element(W + 'r')
        rPr = etree.SubElement(run, W + 'rPr')
        rStyle = etree.SubElement(rPr, W + 'rStyle')
        rStyle.set(W + 'val', 'CommentReference')
        
        comment_ref = etree.SubElement(run, W + 'commentReference')
        comment_ref.set(W + 'id', str(comment_id))
        
        return run
    
    def _append_comments(self, temp_dir: str, new_comments: List[Dict]):
        """Append new agent comments to existing comments.xml (preserves existing)."""
        comments_path = os.path.join(temp_dir, "word", "comments.xml")
        
        if os.path.exists(comments_path):
            tree = etree.parse(comments_path)
            root = tree.getroot()
        else:
            nsmap = {None: W_NS}
            root = etree.Element(W + 'comments', nsmap=nsmap)
            self._update_content_types(temp_dir)
            self._update_document_rels(temp_dir)
        
        for comment in new_comments:
            comment_elem = etree.SubElement(root, W + 'comment')
            comment_elem.set(W + 'id', str(comment['id']))
            comment_elem.set(W + 'author', comment['author'])
            comment_elem.set(W + 'date', comment['date'])
            comment_elem.set(W + 'initials', comment['initials'])
            
            p = etree.SubElement(comment_elem, W + 'p')
            r = etree.SubElement(p, W + 'r')
            t = etree.SubElement(r, W + 't')
            t.set(XML_SPACE, 'preserve')
            t.text = comment['text']
        
        tree = etree.ElementTree(root)
        tree.write(comments_path, xml_declaration=True, encoding='UTF-8', standalone='yes')
    
    def _update_content_types(self, temp_dir: str):
        """Update [Content_Types].xml to include comments."""
        content_types_path = os.path.join(temp_dir, "[Content_Types].xml")
        tree = etree.parse(content_types_path)
        root = tree.getroot()
        
        for child in root:
            if child.get('PartName') == '/word/comments.xml':
                return
        
        ns = root.tag.split('}')[0] + '}' if '}' in root.tag else ''
        override = etree.SubElement(root, ns + 'Override')
        override.set('PartName', '/word/comments.xml')
        override.set('ContentType', 'application/vnd.openxmlformats-officedocument.wordprocessingml.comments+xml')
        
        tree.write(content_types_path, xml_declaration=True, encoding='UTF-8', standalone='yes')
    
    def _update_document_rels(self, temp_dir: str):
        """Update document.xml.rels to include comments relationship."""
        rels_path = os.path.join(temp_dir, "word", "_rels", "document.xml.rels")
        rels_dir = os.path.dirname(rels_path)
        os.makedirs(rels_dir, exist_ok=True)
        
        if os.path.exists(rels_path):
            tree = etree.parse(rels_path)
            root = tree.getroot()
        else:
            nsmap = {None: RELS_NS}
            root = etree.Element('Relationships', nsmap=nsmap)
        
        for child in root:
            if child.get('Target') == 'comments.xml':
                return
        
        max_id = 0
        for child in root:
            rel_id = child.get('Id', '')
            if rel_id.startswith('rId'):
                try:
                    max_id = max(max_id, int(rel_id[3:]))
                except ValueError:
                    pass
        
        ns = root.tag.split('}')[0] + '}' if '}' in root.tag else ''
        rel = etree.SubElement(root, ns + 'Relationship')
        rel.set('Id', f'rId{max_id + 1}')
        rel.set('Type', 'http://schemas.openxmlformats.org/officeDocument/2006/relationships/comments')
        rel.set('Target', 'comments.xml')
        
        tree = etree.ElementTree(root)
        tree.write(rels_path, xml_declaration=True, encoding='UTF-8', standalone='yes')
    
    def _enable_track_changes(self, temp_dir: str):
        """Enable track changes in document settings."""
        settings_path = os.path.join(temp_dir, "word", "settings.xml")
        
        if not os.path.exists(settings_path):
            return
        
        try:
            tree = etree.parse(settings_path)
            root = tree.getroot()
            
            existing = root.find(W + 'trackRevisions')
            if existing is None:
                track_revisions = etree.Element(W + 'trackRevisions')
                root.insert(0, track_revisions)
                tree.write(settings_path, xml_declaration=True, encoding='UTF-8', standalone='yes')
        except Exception as e:
            print(f"  ⚠️ Could not enable track changes: {e}")