"""
Metrics collection for monitoring and observability.
Simple in-memory metrics (can be extended with Prometheus later).
"""

import time
from typing import Dict, Any, Optional
from collections import defaultdict
from datetime import datetime
from threading import Lock


class MetricsCollector:
    """Simple metrics collector for application metrics."""
    
    def __init__(self):
        """Initialize metrics collector."""
        self._counters: Dict[str, int] = defaultdict(int)
        self._gauges: Dict[str, float] = {}
        self._histograms: Dict[str, list] = defaultdict(list)
        self._lock = Lock()
    
    def increment(self, metric_name: str, value: int = 1, labels: Optional[Dict[str, str]] = None):
        """
        Increment a counter metric.
        
        Args:
            metric_name: Name of the metric
            value: Value to increment by
            labels: Optional labels (for now, just append to name)
        """
        with self._lock:
            key = self._build_key(metric_name, labels)
            self._counters[key] += value
    
    def set_gauge(self, metric_name: str, value: float, labels: Optional[Dict[str, str]] = None):
        """
        Set a gauge metric.
        
        Args:
            metric_name: Name of the metric
            value: Gauge value
            labels: Optional labels
        """
        with self._lock:
            key = self._build_key(metric_name, labels)
            self._gauges[key] = value
    
    def record_duration(self, metric_name: str, duration: float, labels: Optional[Dict[str, str]] = None):
        """
        Record a duration/histogram metric.
        
        Args:
            metric_name: Name of the metric
            duration: Duration in seconds
            labels: Optional labels
        """
        with self._lock:
            key = self._build_key(metric_name, labels)
            self._histograms[key].append(duration)
            # Keep only last 1000 values
            if len(self._histograms[key]) > 1000:
                self._histograms[key] = self._histograms[key][-1000:]
    
    def _build_key(self, metric_name: str, labels: Optional[Dict[str, str]]) -> str:
        """Build metric key with labels."""
        if not labels:
            return metric_name
        label_str = ",".join(f"{k}={v}" for k, v in sorted(labels.items()))
        return f"{metric_name}{{{label_str}}}"
    
    def get_all_metrics(self) -> Dict[str, Any]:
        """
        Get all metrics as dictionary.
        
        Returns:
            Dictionary with all metrics
        """
        with self._lock:
            return {
                "counters": dict(self._counters),
                "gauges": dict(self._gauges),
                "histograms": {
                    k: {
                        "count": len(v),
                        "sum": sum(v),
                        "avg": sum(v) / len(v) if v else 0,
                        "min": min(v) if v else 0,
                        "max": max(v) if v else 0
                    }
                    for k, v in self._histograms.items()
                },
                "timestamp": datetime.now().isoformat()
            }
    
    def reset(self):
        """Reset all metrics."""
        with self._lock:
            self._counters.clear()
            self._gauges.clear()
            self._histograms.clear()


# Global metrics collector
_metrics_collector: Optional[MetricsCollector] = None


def get_metrics_collector() -> MetricsCollector:
    """Get global metrics collector instance."""
    global _metrics_collector
    if _metrics_collector is None:
        _metrics_collector = MetricsCollector()
    return _metrics_collector

