"""
Workflow Manager for ICF Generator.
Orchestrates Generator ↔ QA Agent feedback loop (max 2 iterations).
Fully generic - works for any country based on knowledge base.
Uses Azure AI Search with doctypeid filtering.
Supports pre-indexed Global ICF sections via document_id.
"""

import os
import traceback
import shutil
import time
import httpx
from typing import Dict, List, Optional
from datetime import datetime
from config import Config
from services.app_insights import get_logger as get_ai_logger
from .generator_agent import ICFGeneratorAgent
from .qa_agent import QAAgent
from .regenerator_agent import HumanReviewAgent
from models.models import QAFeedback, RegenerateRequest, RegenerateCallback


class WorkflowManager:
    """
    Orchestrates the Generator ↔ QA feedback loop.
    - Runs Generator to create initial country-specific document
    - QA reviews and returns feedback (not document changes)
    - If issues found, Generator re-runs with feedback in prompt
    - Max 2 iterations, then outputs final document
    - Fully generic - works for any country
    - Supports pre-indexed Global ICF sections via document_id
    """
    
    MAX_ITERATIONS = 2
    
    def __init__(
        self,
        country: str,
        knowledge_base_path: str = "knowledge_base",
        blob_container_name: str = "icf-country-dev"
    ):
        """
        Initialize Workflow Manager for a specific country.
        
        Args:
            country: Country code (e.g., 'usa', 'canada', 'uk')
            knowledge_base_path: Local fallback path for knowledge base
            blob_container_name: Azure blob container name
        """
        self.country = country.lower()
        self.country_display = country.upper()
        self.blob_container_name = blob_container_name
        
        self.generator = ICFGeneratorAgent(
            country=self.country,
            knowledge_base_path=knowledge_base_path
        )
        self.qa_agent = QAAgent(country=self.country)
        
        self.current_iteration = 0
        self.iteration_history = []
        self._logger = get_ai_logger("workflow")
        self._log("info", f"WorkflowManager initialized for {self.country_display}")
    
    def index_knowledge_base(self, csv_path: str) -> int:
        """Index the country's Customization Plan CSV."""
        return self.generator.index_knowledge_base(csv_path)

    def _build_dimensions(
        self,
        correlation_id: Optional[str] = None,
        document_id: Optional[str] = None,
        **context: Optional[str]
    ) -> Optional[dict]:
        dims: Dict[str, str] = {}
        if correlation_id:
            dims["correlationId"] = correlation_id
        if document_id:
            dims["documentId"] = document_id
        for key, value in context.items():
            if value is not None:
                dims[key] = str(value)
        return {"custom_dimensions": dims} if dims else None

    def _log(
        self,
        level: str,
        message: str,
        correlation_id: Optional[str] = None,
        document_id: Optional[str] = None,
        **context: Optional[str]
    ) -> None:
        dims = self._build_dimensions(correlation_id, document_id, **context)
        log_method = getattr(self._logger, level, self._logger.info)
        if dims:
            log_method(message, extra=dims)
        else:
            log_method(message)
    
    def load_qa_checklists(
        self,
        from_blob: bool = False,
        local_paths: List[str] = None,
        use_search_index: bool = True
    ) -> int:
        """
        Load QA checklists from Azure AI Search, blob, or local files.
        
        Args:
            from_blob: If True, force load from Azure Blob storage (skip search index)
            local_paths: List of local file paths (if loading locally)
            use_search_index: If True (default), try Azure AI Search first
                             Uses doctypeid=1 (ICF) or doctypeid=4 (Review Checklist)
            
        Returns:
            Number of requirements loaded
        """
        return self.qa_agent.load_checklists(
            from_blob=from_blob,
            local_paths=local_paths,
            use_search_index=use_search_index
        )
    
    def check_document_indexed(self, document_id: str) -> bool:
        """
        Check if a Global ICF document has been indexed.
        
        Args:
            document_id: The document ID to check
            
        Returns:
            True if document sections are indexed
        """
        return self.generator.rag.check_document_indexed(document_id)
    
    def run(
        self,
        input_docx_path: str,
        output_docx_path: str,
        excel_path: str = None,
        blob_container: str = None,
        blob_name: str = None,
        document_id: str = None,
        on_iteration_complete: callable = None,
        icf_case_id: str = None,
        correlation_id: str = None
    ) -> Dict:
        """
        Run the full Generator ↔ QA feedback loop.
        
        Args:
            input_docx_path: Path to global ICF template
            output_docx_path: Path for final country-specific ICF output
            excel_path: Optional Excel requirements file
            blob_container: Optional blob container for requirements
            blob_name: Optional blob name for requirements
            document_id: Optional document ID for pre-indexed Global ICF sections
            on_iteration_complete: Optional callback(iteration, feedback) for UI updates
            
        Returns:
            Dict with results summary
        """
        self._log(
            "info",
            f"Starting ICF Generation Workflow for {self.country_display}",
            correlation_id=correlation_id,
            document_id=document_id
        )
        self._log(
            "debug",
            f"Input: {input_docx_path}, Output: {output_docx_path}",
            correlation_id=correlation_id,
            document_id=document_id
        )
        
        # Check if document is pre-indexed
        if document_id:
            if self.check_document_indexed(document_id):
                self._log("info", "Using pre-indexed sections from icf-sections-index", correlation_id=correlation_id, document_id=document_id)
            else:
                self._log("warning", "Document not indexed, will use runtime parsing", correlation_id=correlation_id, document_id=document_id)
        
        self.current_iteration = 0
        self.iteration_history = []
        
        temp_dir = f"outputs/temp/{self.country}"
        os.makedirs(temp_dir, exist_ok=True)
        
        qa_feedback: Optional[QAFeedback] = None
        final_result = None
        document_title = None
        total_changes = 0
        coverage_stats = {}
        
        for iteration in range(1, self.MAX_ITERATIONS + 1):
            self.current_iteration = iteration
            self._log(
                "info",
                f"ITERATION {iteration}/{self.MAX_ITERATIONS} ({self.country_display})",
                correlation_id=correlation_id,
                document_id=document_id,
                iteration=str(iteration)
            )
            
            iter_output_path = os.path.join(temp_dir, f"iteration_{iteration}.docx")
            
            generator_result = self.generator.generate_country_icf(
                input_docx_path=input_docx_path,
                output_docx_path=iter_output_path,
                excel_path=excel_path,
                blob_container=blob_container,
                blob_name=blob_name,
                qa_feedback=qa_feedback,
                document_id=document_id,
                correlation_id=correlation_id
            )
            
            if not document_title:
                document_title = generator_result.get('title', f'{self.country_display} Informed Consent Form')
            total_changes += generator_result.get('changes_count', 0)
            coverage_stats = generator_result.get('coverage_stats') or coverage_stats
            
            self._log(
                "info",
                "Generator iteration results",
                correlation_id=correlation_id,
                document_id=document_id,
                changes=str(generator_result.get('changes_count', 0))
            )
            
            qa_feedback = self.qa_agent.verify_for_feedback(
                input_docx_path=iter_output_path,
                iteration=iteration,
                correlation_id=correlation_id,
                document_id=document_id
            )
            
            iteration_record = {
                'iteration': iteration,
                'country': self.country_display,
                'generator_changes': generator_result.get('changes_count', 0),
                'qa_status': qa_feedback.status,
                'qa_issues': len(qa_feedback.issues),
                'output_path': iter_output_path,
                'document_id': document_id
            }
            self.iteration_history.append(iteration_record)
            
            if on_iteration_complete:
                on_iteration_complete(iteration, qa_feedback)
            
            if qa_feedback.status == "pass":
                self._log(
                    "info",
                    f"QA PASSED on iteration {iteration}",
                    correlation_id=correlation_id,
                    document_id=document_id
                )
                shutil.copy(iter_output_path, output_docx_path)
                if icf_case_id:
                    blob_folder = f"cases/{icf_case_id}/{self.country}/versions/v1"
                    blob_path = self._upload_to_blob(
                        output_docx_path, 
                        self.blob_container_name, 
                        blob_folder,
                        exact_filename="generated.docx",
                        correlation_id=correlation_id,
                        document_id=document_id
                    )
                else:
                    blob_path = self._upload_to_blob(
                        output_docx_path, 
                        self.blob_container_name, 
                        f"output/{self.country}",
                        correlation_id=correlation_id,
                        document_id=document_id
                    )
                final_result = {
                    'status': 'passed',
                    'country': self.country_display,
                    'iterations': iteration,
                    'title': document_title,
                    'total_changes': total_changes,
                    'qa_issues_resolved': 0,
                    'output_path': output_docx_path,
                    'blob_path': blob_path,
                        'document_id': document_id,
                        'coverage_stats': coverage_stats
                }
                break
            else:
                self._log(
                    "warning",
                    f"QA found {len(qa_feedback.issues)} issues",
                    correlation_id=correlation_id,
                    document_id=document_id,
                    issue_count=len(qa_feedback.issues)
                )
                
                if iteration == self.MAX_ITERATIONS:
                    self._log(
                        "warning",
                        "Max iterations reached. Using current output.",
                        correlation_id=correlation_id,
                        document_id=document_id
                    )
                    shutil.copy(iter_output_path, output_docx_path)
                    if icf_case_id:
                        blob_folder = f"cases/{icf_case_id}/{self.country}/versions/v1"
                        blob_path = self._upload_to_blob(
                            output_docx_path, 
                            self.blob_container_name, 
                            blob_folder,
                            exact_filename="generated.docx",
                            correlation_id=correlation_id,
                            document_id=document_id
                        )
                    else:
                        blob_path = self._upload_to_blob(
                            output_docx_path, 
                            self.blob_container_name, 
                            f"output/{self.country}",
                            correlation_id=correlation_id,
                            document_id=document_id
                        )
                    final_result = {
                        'status': 'max_iterations',
                        'country': self.country_display,
                        'iterations': iteration,
                        'title': document_title,
                        'total_changes': total_changes,
                        'qa_issues_remaining': len(qa_feedback.issues),
                        'remaining_issues': [
                            {
                                'section': issue.section_heading,
                                'requirement': issue.requirement_id,
                                'text': issue.requirement_text[:100]
                            }
                            for issue in qa_feedback.issues[:10]
                        ],
                        'output_path': output_docx_path,
                        'blob_path': blob_path,
                        'document_id': document_id,
                        'coverage_stats': coverage_stats
                    }
                else:
                    qa_feedback.iteration = iteration + 1
                    self._log(
                        "info",
                        f"Sending feedback to Generator for iteration {iteration + 1}",
                        correlation_id=correlation_id,
                        document_id=document_id
                    )
        
        self._cleanup_temp_files(temp_dir, output_docx_path)
        
        self._log(
            "info",
            f"WORKFLOW COMPLETE ({self.country_display}) status={final_result['status']} iterations={final_result['iterations']}",
            correlation_id=correlation_id,
            document_id=document_id,
            country=final_result["country"],
            total_changes=final_result["total_changes"],
            blob_path=final_result.get("blob_path") or ""
        )
        
        return final_result
    
    def _upload_to_blob(
        self,
        local_path: str,
        container_name: str,
        blob_folder: str,
        exact_filename: str = None,
        correlation_id: str = None,
        document_id: str = None
    ) -> str:
        """Upload final document to Azure Blob Storage (connection string or RBAC)."""
        try:
            if not Config.AZURE_STORAGE_CONNECTION_STRING and not Config.AZURE_STORAGE_BLOB_ENDPOINT:
                self._log(
                    "warning",
                    "Blob storage not configured (no connection string or blob endpoint), skipping blob upload",
                    correlation_id=correlation_id,
                    document_id=document_id
                )
                return None

            if not os.path.exists(local_path):
                self._log(
                    "warning",
                    f"Blob upload failed: file not found: {local_path}",
                    correlation_id=correlation_id,
                    document_id=document_id
                )
                return None

            blob_service = Config.get_blob_service_client()
            container_client = blob_service.get_container_client(container_name)
            
            if exact_filename:
                blob_name = f"{blob_folder}/{exact_filename}"
            else:
                filename = os.path.basename(local_path)
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                blob_name = f"{blob_folder}/{timestamp}_{filename}"
            
            with open(local_path, "rb") as data:
                container_client.upload_blob(name=blob_name, data=data, overwrite=True)

            self._log(
                "info",
                f"Uploaded to blob: {container_name}/{blob_name}",
                correlation_id=correlation_id,
                document_id=document_id,
                blob_path=blob_name
            )
            return blob_name
        except Exception as e:
            self._log("error", f"Blob upload failed: {e}", correlation_id=correlation_id, document_id=document_id)
            self._log(
                "debug",
                f"Traceback: {traceback.format_exc()}",
                correlation_id=correlation_id,
                document_id=document_id
            )
            return None
    
    def _cleanup_temp_files(self, temp_dir: str, keep_path: str):
        """Clean up intermediate iteration files."""
        try:
            if os.path.exists(temp_dir):
                for filename in os.listdir(temp_dir):
                    file_path = os.path.join(temp_dir, filename)
                    if file_path != keep_path and os.path.isfile(file_path):
                        try:
                            os.remove(file_path)
                        except PermissionError:
                            time.sleep(0.5)
                            try:
                                os.remove(file_path)
                            except:
                                pass
        except Exception as e:
            pass
    
    def get_iteration_summary(self) -> Dict:
        """Get summary of all iterations."""
        return {
            'country': self.country_display,
            'total_iterations': self.current_iteration,
            'max_iterations': self.MAX_ITERATIONS,
            'history': self.iteration_history
        }
    
    def check_index_status(self) -> Dict:
        """Check status of both Generator and QA indexes."""
        return {
            'country': self.country_display,
            'generator_index': self.generator.rag.check_sync_status(),
            'qa_index': self.qa_agent.check_index_status()
        }


# =============================================================================
# Human Review Workflow
# =============================================================================

class HumanReviewWorkflow:
    """
    Orchestrates the Human Review Agent workflow.
    Processes client-reviewed documents and applies LLM-driven edits.
    Sends callback to Node.js on completion.
    """
    
    def __init__(self):
        self.human_review_agent = HumanReviewAgent()
        self._logger = get_ai_logger("human_review_workflow")
        self._log("info", "HumanReviewWorkflow initialized")

    def _build_dimensions(
        self,
        correlation_id: Optional[str] = None,
        document_id: Optional[str] = None,
        **context: Optional[str]
    ) -> Optional[dict]:
        dims: Dict[str, str] = {}
        if correlation_id:
            dims["correlationId"] = correlation_id
        if document_id:
            dims["documentId"] = document_id
        for key, value in context.items():
            if value is not None:
                dims[key] = str(value)
        return {"custom_dimensions": dims} if dims else None

    def _log(
        self,
        level: str,
        message: str,
        correlation_id: Optional[str] = None,
        document_id: Optional[str] = None,
        **context: Optional[str]
    ) -> None:
        dims = self._build_dimensions(correlation_id, document_id, **context)
        log_method = getattr(self._logger, level, self._logger.info)
        if dims:
            log_method(message, extra=dims)
        else:
            log_method(message)
    
    async def run(
        self,
        request: RegenerateRequest,
        callback_url: str,
        skip_dpo: bool = False,
        correlation_id: str = None,
        send_callback: bool = True
    ) -> RegenerateCallback:
        """
        Run the human review workflow and send callback.
        
        Args:
            request: RegenerateRequest with document details
            callback_url: Node.js endpoint for callback
            
        Returns:
            RegenerateCallback with results
        """
        self._log(
            "info",
            f"HUMAN REVIEW WORKFLOW: {request.document_id}",
            correlation_id=correlation_id,
            document_id=request.document_id
        )
        
        # Process the reviewed document
        callback = await self.human_review_agent.process_reviewed_document(request, skip_dpo=skip_dpo)
        
        # Send callback to Node.js if requested
        if send_callback and callback_url:
            await self._send_callback(callback_url, callback, correlation_id)
        
        return callback
    
    async def _send_callback(
        self,
        callback_url: str,
        callback: RegenerateCallback,
        correlation_id: str = None
    ):
        """
        Send callback to Node.js endpoint.
        
        Args:
            callback_url: Node.js endpoint
            callback: Callback payload
        """
        try:
            headers = {"Content-Type": "application/json"}
            if correlation_id:
                headers["X-Correlation-ID"] = correlation_id
            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.post(
                    callback_url,
                    json=callback.model_dump(),
                    headers=headers
                )
                
                if response.status_code == 200:
                    self._log(
                        "info",
                        f"Callback sent successfully to {callback_url}",
                        correlation_id=correlation_id,
                        document_id=callback.document_id
                    )
                else:
                    self._log(
                        "warning",
                        f"Callback returned status {response.status_code}",
                        correlation_id=correlation_id,
                        document_id=callback.document_id
                    )
                    
        except Exception as e:
            self._log(
                "error",
                f"Callback failed: {e}",
                correlation_id=correlation_id,
                document_id=callback.document_id
            )
    
    def get_comment_preview(self, blob_url: str) -> Dict:
        """
        Get a preview of comments in a reviewed document.
        
        Args:
            blob_url: Azure Blob URL of reviewed document
            
        Returns:
            Summary of comments
        """
        return self.human_review_agent.get_comment_summary(blob_url)