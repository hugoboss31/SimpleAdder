"""
Status enums for ICF Agent callbacks.
Simple pass/fail pattern aligned with icf-backend expectations.
"""

from enum import IntEnum, Enum


class CallbackStatus(IntEnum):
    """
    Callback status codes for icf-backend.
    Backend interprets: 2 = success, 0 = failure
    """
    FAILED = 0
    SUCCESS = 2


class AuditEventType(str, Enum):
    """Audit event types for tracking workflow progression."""
    # Learning workflow events
    LEARNING_STARTED = "LEARNING_STARTED"
    LEARNING_COMPLETED = "LEARNING_COMPLETED"
    LEARNING_FAILED = "LEARNING_FAILED"
    
    # Regeneration workflow events
    REGEN_STARTED = "REGEN_STARTED"
    REGEN_COMPLETED = "REGEN_COMPLETED"
    REGEN_FAILED = "REGEN_FAILED"
    
    # Gate events
    EVIDENCE_GATE_FAILED = "EVIDENCE_GATE_FAILED"
    BUDGET_GATE_TRIMMED = "BUDGET_GATE_TRIMMED"
    QA_FAILED = "QA_FAILED"


# Backward compatibility aliases
STATUS_SUCCESS = CallbackStatus.SUCCESS
STATUS_FAILED = CallbackStatus.FAILED
