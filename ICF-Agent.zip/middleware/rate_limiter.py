"""
Rate limiting middleware for ICF Generator FastAPI.
Simple token bucket implementation.
"""

import os
import time
from threading import Lock
from fastapi import Request, status
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import Response


class TokenBucket:
    """Token bucket for rate limiting."""
    
    def __init__(self, capacity: int, refill_rate: float):
        """
        Initialize token bucket.
        
        Args:
            capacity: Maximum number of tokens
            refill_rate: Tokens added per second
        """
        self.capacity = capacity
        self.refill_rate = refill_rate
        self.tokens = float(capacity)
        self.last_refill = time.time()
        self._lock = Lock()
    
    def consume(self, tokens: int = 1) -> bool:
        """
        Try to consume tokens.
        
        Args:
            tokens: Number of tokens to consume
            
        Returns:
            True if tokens were consumed, False otherwise
        """
        with self._lock:
            now = time.time()
            elapsed = now - self.last_refill
            self.tokens = min(self.capacity, self.tokens + elapsed * self.refill_rate)
            self.last_refill = now
            
            if self.tokens >= tokens:
                self.tokens -= tokens
                return True
            return False
    
    def get_remaining(self) -> int:
        """Get remaining tokens."""
        with self._lock:
            now = time.time()
            elapsed = now - self.last_refill
            self.tokens = min(self.capacity, self.tokens + elapsed * self.refill_rate)
            self.last_refill = now
            return int(self.tokens)


class RateLimiterMiddleware(BaseHTTPMiddleware):
    """Rate limiting middleware for ICF Generator API."""
    
    # Default: 30 requests per minute (ICF generation is expensive)
    DEFAULT_REQUESTS_PER_MINUTE = 30
    
    def __init__(self, app, requests_per_minute: int = None):
        """
        Initialize rate limiter middleware.
        
        Args:
            app: FastAPI application
            requests_per_minute: Requests per minute limit
        """
        super().__init__(app)
        self.requests_per_minute = requests_per_minute or int(
            os.getenv("RATE_LIMIT_REQUESTS_PER_MINUTE", self.DEFAULT_REQUESTS_PER_MINUTE)
        )
        self.enabled = os.getenv("RATE_LIMIT_ENABLED", "true").lower() == "true"
        
        self.bucket = TokenBucket(
            capacity=self.requests_per_minute,
            refill_rate=self.requests_per_minute / 60.0
        )
    
    async def dispatch(self, request: Request, call_next):
        """Process request with rate limiting."""
        # Skip if disabled
        if not self.enabled:
            return await call_next(request)
        
        # Skip health checks
        if request.url.path in ["/health", "/health/ready", "/health/live"]:
            return await call_next(request)
        
        # Check rate limit
        if not self.bucket.consume(1):
            remaining = self.bucket.get_remaining()
            return Response(
                content='{"detail": "Rate limit exceeded. Try again later."}',
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                media_type="application/json",
                headers={
                    "X-RateLimit-Limit": str(self.requests_per_minute),
                    "X-RateLimit-Remaining": str(remaining),
                    "Retry-After": "60"
                }
            )
        
        # Process request
        response = await call_next(request)
        
        # Add rate limit headers
        remaining = self.bucket.get_remaining()
        response.headers["X-RateLimit-Limit"] = str(self.requests_per_minute)
        response.headers["X-RateLimit-Remaining"] = str(remaining)
        
        return response