"""
Centralized configuration for ICF Agent.
Standardizes environment variable names and provides validation.
"""

import os
from typing import Optional, Union

# Load environment variables: .env first (for AZURE_KEY_VAULT_URI), then Key Vault
from dotenv import load_dotenv
load_dotenv()

from load_env_kv import load_env_from_kv
load_env_from_kv()

# Azure Search: use AzureKeyCredential when key is set, else DefaultAzureCredential (RBAC)
from azure.core.credentials import AzureKeyCredential
try:
    from azure.identity import DefaultAzureCredential
except ImportError:
    DefaultAzureCredential = None  # type: ignore[misc, assignment]


class Config:
    """Centralized configuration management."""
    
    # Azure OpenAI Configuration
    AZURE_OPENAI_ENDPOINT = os.getenv("AZURE_OPENAI_ENDPOINT")
    AZURE_OPENAI_API_KEY = os.getenv("AZURE_OPENAI_API_KEY")
    AZURE_OPENAI_DEPLOYMENT_NAME = os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME")
    AZURE_OPENAI_API_VERSION = os.getenv("AZURE_OPENAI_API_VERSION", "2024-02-15-preview")
    
    # Optional: Azure AI Foundry project endpoint for future project/agent APIs (e.g. AIProjectClient)
    AZURE_AI_PROJECT_ENDPOINT = os.getenv("AZURE_AI_PROJECT_ENDPOINT")
    
    # Azure AI Search Configuration - STANDARDIZED
    # Endpoint required. Auth: API key (AZURE_SEARCH_KEY) or RBAC only (no key; use managed identity / DefaultAzureCredential).
    AZURE_SEARCH_ENDPOINT = os.getenv("AZURE_SEARCH_ENDPOINT") or os.getenv("AI_SEARCH_ENDPOINT")
    AZURE_SEARCH_KEY = os.getenv("AZURE_SEARCH_KEY") or os.getenv("AI_SEARCH_KEY")  # Optional when Search is RBAC-only
    AZURE_SEARCH_AUTH_MODE = os.getenv("AZURE_SEARCH_AUTH_MODE", "api_key").strip().lower()
    ICF_SECTIONS_INDEX_NAME = os.getenv("ICF_SECTIONS_INDEX_NAME", "icf-sections-index")
    RAG_INDEX_NAME = os.getenv("RAG_INDEX_NAME") or os.getenv("AI_SEARCH_INDEX_NAME", "icf-rag-index")
    
    # Embeddings Model Configuration
    EMBEDDINGS_MODEL_DEPLOYMENT = os.getenv("EMBEDDINGS_MODEL_DEPLOYMENT", "text-embedding-ada-002")
    EMBEDDINGS_MODEL_VERSION = os.getenv("EMBEDDINGS_MODEL_VERSION", "2")  # ada-002 is v2
    
    # Azure Storage Configuration
    # Connection string (optional when storage is RBAC-only). When set, used for auth; else use account URL + DefaultAzureCredential.
    AZURE_STORAGE_CONNECTION_STRING = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
    AZURE_STORAGE_ACCOUNT_NAME = os.getenv("AZURE_STORAGE_ACCOUNT_NAME")
    # Blob endpoint URL (e.g. https://use2ap3icfstrg001.blob.core.windows.net). If not set, built from AZURE_STORAGE_ACCOUNT_NAME when using RBAC.
    _blob_endpoint = os.getenv("AZURE_STORAGE_BLOB_ENDPOINT")
    AZURE_STORAGE_BLOB_ENDPOINT = _blob_endpoint if _blob_endpoint else (
        f"https://{os.getenv('AZURE_STORAGE_ACCOUNT_NAME', '')}.blob.core.windows.net" if os.getenv("AZURE_STORAGE_ACCOUNT_NAME") else None
    )
    AZURE_STORAGE_CONTAINER_NAME = os.getenv("AZURE_STORAGE_CONTAINER_NAME", "icf-country-storage")
    AZURE_OUTPUT_FOLDER = os.getenv("AZURE_OUTPUT_FOLDER", "outputs")  # Plural: outputs folder in blob
    AZURE_GLOBAL_FOLDER = os.getenv("AZURE_GLOBAL_FOLDER", "global")  # Folder for Global ICFs
    
    # Azure Document Intelligence (optional — app starts without it; add-document/add-folder return 503 if not set)
    AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT = os.getenv("AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT")
    AZURE_DOCUMENT_INTELLIGENCE_KEY = os.getenv("AZURE_DOCUMENT_INTELLIGENCE_KEY")
    
    # Backend API Configuration (for callbacks)
    BACKEND_API_URL = os.getenv("BACKEND_API_URL", "http://localhost:5001")
    # When set (e.g. http://icf-backend.icfagenticai-ns01.svc.cluster.local), use in-cluster service
    # instead of ingress URL; avoids egress and decouples from ingress.
    BACKEND_API_URL_INTERNAL = os.getenv("BACKEND_API_URL_INTERNAL", "").strip() or None
    BACKEND_API_CALLBACK_PATH = "/api/generate-icf-callback"
    
    # Country Management Configuration
    ENABLE_COUNTRY_VALIDATION = os.getenv("ENABLE_COUNTRY_VALIDATION", "true").lower() == "true"
    COUNTRY_CODE_CASE = os.getenv("COUNTRY_CODE_CASE", "upper")  # upper, lower, mixed
    SUPPORTED_COUNTRIES = os.getenv("SUPPORTED_COUNTRIES", "USA,CAN").split(",")
    
    # Checklist Configuration
    CHECKLIST_INDEX_NAME = os.getenv("CHECKLIST_INDEX_NAME", "icf-checklist-index")
    USA_CHECKLISTS = os.getenv("USA_CHECKLISTS", "HIPAA,country").split(",")
    CANADA_CHECKLISTS = os.getenv("CANADA_CHECKLISTS", "PIPEDA,country").split(",")
    
    # Caching Configuration
    CACHE_ENABLED = os.getenv("CACHE_ENABLED", "true").lower() == "true"
    CACHE_DIR = os.getenv("CACHE_DIR", "./cache")
    EMBEDDING_CACHE_TTL_DAYS = int(os.getenv("EMBEDDING_CACHE_TTL_DAYS", "30"))
    RAG_QUERY_CACHE_TTL_DAYS = int(os.getenv("RAG_QUERY_CACHE_TTL_DAYS", "7"))
    SECTION_MATCH_CACHE_TTL_DAYS = int(os.getenv("SECTION_MATCH_CACHE_TTL_DAYS", "1"))
    SECTION_MATCH_THRESHOLD = 0.7  # Min confidence (0–1) to accept a section match
    
    # Learning / corrections (generator agent)
    APPLY_LEARNED_ARTIFACTS = True
    LEARNING_CONTEXT_TOP_K = 5
    
    # Parallel Processing Configuration
    BATCH_SIZE = int(os.getenv("BATCH_SIZE", "5"))
    MAX_CONCURRENT_ITEMS = int(os.getenv("MAX_CONCURRENT_ITEMS", "10"))
    
    # Service Bus Configuration (optional - when disabled, use HTTP endpoints only)
    SERVICE_BUS_ENABLED = os.getenv("SERVICE_BUS_ENABLED", "false").lower() == "true"
    AZURE_SERVICE_BUS_CONNECTION_STRING = os.getenv("AZURE_SERVICE_BUS_CONNECTION_STRING", "").strip() or None

    # Rate Limiting Configuration
    RATE_LIMIT_ENABLED = os.getenv("RATE_LIMIT_ENABLED", "true").lower() == "true"
    RATE_LIMIT_REQUESTS_PER_MINUTE = int(os.getenv("RATE_LIMIT_REQUESTS_PER_MINUTE", "10"))
    
    # Retry Configuration
    MAX_RETRIES = int(os.getenv("MAX_RETRIES", "3"))
    RETRY_BACKOFF_FACTOR = float(os.getenv("RETRY_BACKOFF_FACTOR", "2"))
    RETRY_INITIAL_DELAY = float(os.getenv("RETRY_INITIAL_DELAY", "1"))
    
    @classmethod
    def validate(cls) -> tuple[bool, list[str]]:
        """
        Validate required configuration.
        
        Returns:
            (is_valid, list_of_missing_vars)
        """
        required = [
            ("AZURE_OPENAI_ENDPOINT", cls.AZURE_OPENAI_ENDPOINT),
            ("AZURE_OPENAI_API_KEY", cls.AZURE_OPENAI_API_KEY),
            ("AZURE_OPENAI_DEPLOYMENT_NAME", cls.AZURE_OPENAI_DEPLOYMENT_NAME),
            ("AZURE_OPENAI_API_VERSION", cls.AZURE_OPENAI_API_VERSION),
            ("AZURE_SEARCH_ENDPOINT", cls.AZURE_SEARCH_ENDPOINT),
            ("AZURE_STORAGE", cls.AZURE_STORAGE_CONNECTION_STRING or cls.AZURE_STORAGE_BLOB_ENDPOINT),
        ]
        
        missing = []
        for name, value in required:
            if not value:
                missing.append(name)
        
        return len(missing) == 0, missing
    
    @classmethod
    def get_search_endpoint(cls) -> str:
        """Get Azure Search endpoint. Ensures https when using RBAC (Bearer token requires TLS)."""
        if not cls.AZURE_SEARCH_ENDPOINT:
            raise ValueError("AZURE_SEARCH_ENDPOINT not configured")
        endpoint = cls.AZURE_SEARCH_ENDPOINT.strip()
        if endpoint.startswith("http://"):
            endpoint = "https://" + endpoint[7:]
        elif not endpoint.startswith("https://"):
            endpoint = "https://" + endpoint
        return endpoint

    @classmethod
    def get_search_credential(cls) -> Union[AzureKeyCredential, object]:
        """
        Get credential for Azure AI Search.
        Uses API key if AZURE_SEARCH_KEY is set; otherwise DefaultAzureCredential (RBAC / managed identity).
        """
        if cls.AZURE_SEARCH_AUTH_MODE == "managed_identity":
            if DefaultAzureCredential is None:
                raise ValueError(
                    "Azure Search is configured for managed identity but azure-identity is not available. "
                    "Install azure-identity and ensure the app identity has Search roles."
                )
            return DefaultAzureCredential()
        if cls.AZURE_SEARCH_KEY:
            return AzureKeyCredential(cls.AZURE_SEARCH_KEY)
        if DefaultAzureCredential is None:
            raise ValueError(
                "Azure Search is RBAC-only but AZURE_SEARCH_KEY is not set. "
                "Either set AZURE_SEARCH_KEY or install azure-identity and ensure the app identity has Search roles."
            )
        return DefaultAzureCredential()
    
    @classmethod
    def get_search_key(cls) -> Optional[str]:
        """Get Azure Search API key, or None when using RBAC only."""
        if cls.AZURE_SEARCH_AUTH_MODE == "managed_identity":
            return None
        return cls.AZURE_SEARCH_KEY

    @classmethod
    def get_storage_credential(cls) -> object:
        """
        Get credential for Azure Blob Storage when using RBAC (no connection string).
        Returns DefaultAzureCredential. Use only when AZURE_STORAGE_CONNECTION_STRING is not set.
        """
        if DefaultAzureCredential is None:
            raise ValueError(
                "Storage is RBAC-only but azure-identity is not available. "
                "Install azure-identity and ensure the app identity has Storage Blob Data roles."
            )
        return DefaultAzureCredential()

    @classmethod
    def get_blob_service_client(cls):
        """
        Get BlobServiceClient for Azure Blob Storage.
        Uses connection string if AZURE_STORAGE_CONNECTION_STRING is set; otherwise uses
        AZURE_STORAGE_BLOB_ENDPOINT (or URL built from AZURE_STORAGE_ACCOUNT_NAME) with DefaultAzureCredential (RBAC).
        """
        from azure.storage.blob import BlobServiceClient
        if cls.AZURE_STORAGE_CONNECTION_STRING:
            return BlobServiceClient.from_connection_string(cls.AZURE_STORAGE_CONNECTION_STRING)
        if not cls.AZURE_STORAGE_BLOB_ENDPOINT:
            raise ValueError(
                "Blob Storage not configured. Set AZURE_STORAGE_CONNECTION_STRING or "
                "AZURE_STORAGE_BLOB_ENDPOINT (or AZURE_STORAGE_ACCOUNT_NAME) for RBAC."
            )
        return BlobServiceClient(
            account_url=cls.AZURE_STORAGE_BLOB_ENDPOINT.rstrip("/"),
            credential=cls.get_storage_credential()
        )
    
    @classmethod
    def get_backend_base_url(cls) -> str:
        """Backend base URL for callbacks; prefers in-cluster URL when set."""
        base = (cls.BACKEND_API_URL_INTERNAL or cls.BACKEND_API_URL or "").strip()
        return base or "http://localhost:5001"

    @classmethod
    def get_backend_callback_url(cls) -> str:
        """Get full backend callback URL."""
        return f"{cls.get_backend_base_url()}{cls.BACKEND_API_CALLBACK_PATH}"


# Create instance for easy import
config = Config()

