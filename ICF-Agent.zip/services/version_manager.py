"""
Version Manager for Human Review Agent.
Handles document versioning and Azure Blob upload for regenerated ICFs.
Outputs to: output/{country}/{document_id}_v{n}.docx
"""

import os
import re
import logging
from typing import Optional, Tuple, List
from datetime import datetime

logger = logging.getLogger(__name__)

try:
    from azure.storage.blob import BlobServiceClient, ContentSettings
    AZURE_BLOB_AVAILABLE = True
except ImportError:
    AZURE_BLOB_AVAILABLE = False


class VersionManager:
    """
    Manages document versioning and blob storage for regenerated ICFs.
    
    Version naming: {document_id}_v{n}.docx
    Blob path: output/{country}/{document_id}_v{n}.docx
    """
    
    OUTPUT_CONTAINER = os.getenv("AZURE_STORAGE_CONTAINER_NAME", "icf-country-dev")
    
    def __init__(self):
        self.blob_client = None
        self._init_blob_client()
        print("✅ Version Manager initialized")
    
    def _init_blob_client(self):
        """Initialize Azure Blob Storage client (connection string or RBAC)."""
        if not AZURE_BLOB_AVAILABLE:
            print("  ⚠️ Azure Blob SDK not available")
            return
        
        try:
            from config import Config
            if Config.AZURE_STORAGE_CONNECTION_STRING:
                self.blob_client = BlobServiceClient.from_connection_string(Config.AZURE_STORAGE_CONNECTION_STRING)
            elif Config.AZURE_STORAGE_BLOB_ENDPOINT:
                self.blob_client = Config.get_blob_service_client()
            else:
                print("  ⚠️ Azure Storage not configured (no connection string or blob endpoint)")
                return
            print("  ✓ Azure Blob Storage ready")
        except Exception as e:
            print(f"  ⚠️ Blob Storage init failed: {e}")
    
    def get_next_version(
        self,
        document_id: str,
        country: str,
        current_version: Optional[int] = None,
        icf_case_id: Optional[str] = None
    ) -> int:
        """
        Determine the next version number for a document.
        
        Args:
            document_id: Document ID
            country: Country name (usa, canada, taiwan)
            current_version: Current version if known
            icf_case_id: ICF case identifier
            
        Returns:
            Next version number
        """
        if current_version is not None:
            return current_version + 1
        
        if self.blob_client:
            existing_versions = self._get_existing_versions(document_id, country, icf_case_id)
            if existing_versions:
                return max(existing_versions) + 1
        
        return 1
    
    def _get_existing_versions(
        self,
        document_id: str,
        country: str,
        icf_case_id: Optional[str] = None
    ) -> List[int]:
        """
        Get list of existing version numbers for a document.
        Supports both path structures.
        
        Args:
            document_id: Document ID
            country: Country name
            icf_case_id: ICF case identifier (uses new path structure)
            
        Returns:
            List of version numbers found
        """
        versions = []
        
        if not self.blob_client:
            return versions
        
        try:
            container_client = self.blob_client.get_container_client(self.OUTPUT_CONTAINER)
            
            if icf_case_id:
                prefix = f"cases/{icf_case_id}/{country.lower()}/versions/v"
                for blob in container_client.list_blobs(name_starts_with=prefix):
                    match = re.search(r'/versions/v(\d+)/', blob.name)
                    if match:
                        versions.append(int(match.group(1)))
            else:
                prefix = f"output/{country.lower()}/{document_id}_v"
                for blob in container_client.list_blobs(name_starts_with=prefix):
                    match = re.search(rf'{document_id}_v(\d+)\.docx$', blob.name)
                    if match:
                        versions.append(int(match.group(1)))
        except Exception as e:
            print(f"  ⚠️ Error scanning versions: {e}")
        
        return versions
    
    def generate_output_filename(
        self,
        document_id: str,
        version: int
    ) -> str:
        """
        Generate output filename with version.
        
        Args:
            document_id: Document ID
            version: Version number
            
        Returns:
            Filename: {document_id}_v{n}.docx
        """
        return f"{document_id}_v{version}.docx"

    @staticmethod
    def generate_display_filename(
        country: str,
        study_id: Optional[int] = None,
        study_name: str = "",
        icf_type: str = "",
        user_name: str = "User",
        version: int = 1,
        date: Optional[datetime] = None,
    ) -> str:
        """
        Generate user-facing display filename per convention:
        CountryCode_StudyId_StudyName_ICFType_UserName_Version_Date.docx

        Args:
            country: Country name/code (e.g. usa)
            study_id: Study ID (optional)
            study_name: Study name (spaces sanitized to underscores)
            icf_type: Study ICF type (optional)
            user_name: User name (spaces sanitized)
            version: Version number (output as X.0)
            date: Date for filename (default: now, format dd-MMM-yyyy)

        Returns:
            Display filename, e.g. USA_245675_ISU_ABXIS_Corporation_ISU302-005_Mitul_1.0_03-Mar-2026.docx
        """
        def _sanitize(s: str) -> str:
            if not s:
                return ""
            for c in ' /\\:*?"<>|':
                s = s.replace(c, "_")
            return s.strip("_")

        country_upper = (country or "USA").upper()
        study_name_s = _sanitize(study_name or "")
        icf_type_s = _sanitize(icf_type or "")
        user_name_s = _sanitize(user_name or "User")
        version_str = f"{version}.0"
        dt = date or datetime.now()
        date_str = dt.strftime("%d-%b-%Y")

        study_id_str = "" if study_id is None else str(study_id)
        parts = [country_upper, study_id_str, study_name_s, icf_type_s, user_name_s, version_str, date_str]
        parts_clean = [p for p in parts if p]
        if parts_clean:
            return "_".join(parts_clean) + ".docx"
        return f"{country_upper}_ICF_{dt.strftime('%Y%m%d_%H%M%S')}.docx"
    
    def generate_blob_path(
        self,
        document_id: str,
        country: str,
        version: int,
        icf_case_id: Optional[str] = None
    ) -> str:
        """
        Generate full blob path for output.
        
        New structure: cases/{icfCaseId}/{country}/versions/v{n}/generated.docx
        Fallback (no case ID): output/{country}/{document_id}_v{n}.docx
        
        Args:
            document_id: Document ID
            country: Country name
            version: Version number
            icf_case_id: ICF case identifier (uses new path structure)
            
        Returns:
            Blob path string
        """
        if icf_case_id:
            return f"cases/{icf_case_id}/{country.lower()}/versions/v{version}/generated.docx"
        filename = self.generate_output_filename(document_id, version)
        return f"output/{country.lower()}/{filename}"
    
    def upload_regenerated_document(
        self,
        local_path: str,
        document_id: str,
        country: str,
        version: int,
        icf_case_id: Optional[str] = None
    ) -> Tuple[bool, str, str]:
        """
        Upload regenerated document to Azure Blob Storage.
        Automatically handles container creation and same-version overwrites.
        
        Args:
            local_path: Path to local DOCX file
            document_id: Document ID
            country: Country name
            version: Version number
            icf_case_id: ICF case identifier (uses new path structure)
            
        Returns:
            Tuple of (success, blob_url, error_message)
        """
        if not self.blob_client:
            return False, "", "Blob client not initialized"
        
        blob_path = self.generate_blob_path(document_id, country, version, icf_case_id)
        
        try:
            container_client = self.blob_client.get_container_client(self.OUTPUT_CONTAINER)
            try:
                container_client.get_container_properties()
            except Exception:
                container_client.create_container()
                print(f"  ✓ Created container: {self.OUTPUT_CONTAINER}")
            
            blob_client = self.blob_client.get_blob_client(
                container=self.OUTPUT_CONTAINER,
                blob=blob_path
            )
            
            content_settings = ContentSettings(
                content_type='application/vnd.openxmlformats-officedocument.wordprocessingml.document'
            )
            
            with open(local_path, "rb") as f:
                blob_client.upload_blob(
                    f,
                    overwrite=True,
                    content_settings=content_settings
                )
            
            blob_url = blob_client.url
            print(f"  ✓ Uploaded: {blob_path}")
            
            return True, blob_url, ""
            
        except Exception as e:
            error_msg = f"Upload failed: {str(e)}"
            print(f"  ⚠️ {error_msg}")
            return False, "", error_msg
    
    def download_reviewed_document(
        self,
        blob_url: str,
        local_path: str
    ) -> Tuple[bool, str]:
        """
        Download reviewed document from Azure Blob Storage.
        
        Args:
            blob_url: Full Azure Blob URL
            local_path: Local path to save file
            
        Returns:
            Tuple of (success, error_message)
        """
        if not self.blob_client:
            return False, "Blob client not initialized"
        
        try:
            # Parse blob URL to get container and blob name
            container, blob_name = self._parse_blob_url(blob_url)
            
            blob_client = self.blob_client.get_blob_client(
                container=container,
                blob=blob_name
            )
            
            # Ensure directory exists
            os.makedirs(os.path.dirname(local_path), exist_ok=True)
            
            with open(local_path, "wb") as f:
                download_stream = blob_client.download_blob()
                f.write(download_stream.readall())
            
            print(f"  ✓ Downloaded: {blob_name}")
            return True, ""
            
        except Exception as e:
            error_msg = f"Download failed: {str(e)}"
            print(f"  ⚠️ {error_msg}")
            return False, error_msg
    
    def _parse_blob_url(self, blob_url: str) -> Tuple[str, str]:
        """
        Parse Azure Blob URL to extract container and blob name.
        
        Args:
            blob_url: Full Azure Blob URL
            
        Returns:
            Tuple of (container_name, blob_name)
        """
        # Log original URL
        logger.info(f"[VERSION_MANAGER URL TRACE] Original blob_url: '{blob_url}'")
        logger.info(f"[VERSION_MANAGER URL TRACE] Original repr: {repr(blob_url)}")
        
        # Clean the URL - strip whitespace and quotes
        # Also decode URL-encoded characters (e.g., %22 for quotes)
        from urllib.parse import urlparse, unquote
        blob_url = unquote(blob_url.strip()).strip('"').strip("'")
        
        # Log cleaned URL
        logger.info(f"[VERSION_MANAGER URL TRACE] After cleaning: '{blob_url}'")
        logger.info(f"[VERSION_MANAGER URL TRACE] After cleaning repr: {repr(blob_url)}")
        
        # URL format: https://{account}.blob.core.windows.net/{container}/{blob_path}
        
        parsed = urlparse(blob_url)
        logger.info(f"[VERSION_MANAGER URL TRACE] Parsed netloc: '{parsed.netloc}'")
        logger.info(f"[VERSION_MANAGER URL TRACE] Parsed path: '{parsed.path}'")
        
        path_parts = parsed.path.lstrip('/').split('/', 1)
        logger.info(f"[VERSION_MANAGER URL TRACE] Path parts: {path_parts}")
        
        if len(path_parts) == 2:
            logger.info(f"[VERSION_MANAGER URL TRACE] Returning container='{path_parts[0]}', blob='{path_parts[1]}'")
            return path_parts[0], path_parts[1]
        
        # Fallback: assume icf-dev container
        return self.OUTPUT_CONTAINER, path_parts[0] if path_parts else ""
    
    def get_version_history(
        self,
        document_id: str,
        country: str,
        icf_case_id: Optional[str] = None
    ) -> List[dict]:
        """
        Get version history for a document.
        Supports both path structures.
        
        Args:
            document_id: Document ID
            country: Country name
            icf_case_id: ICF case identifier (uses new path structure)
            
        Returns:
            List of version info dicts
        """
        history = []
        
        if not self.blob_client:
            return history
        
        try:
            container_client = self.blob_client.get_container_client(self.OUTPUT_CONTAINER)
            
            if icf_case_id:
                prefix = f"cases/{icf_case_id}/{country.lower()}/versions/"
                version_pattern = r'/versions/v(\d+)/'
            else:
                prefix = f"output/{country.lower()}/{document_id}_v"
                version_pattern = rf'{document_id}_v(\d+)\.docx$'
            
            for blob in container_client.list_blobs(name_starts_with=prefix):
                match = re.search(version_pattern, blob.name)
                if match:
                    version = int(match.group(1))
                    blob_client_item = self.blob_client.get_blob_client(
                        container=self.OUTPUT_CONTAINER,
                        blob=blob.name
                    )
                    history.append({
                        'version': version,
                        'filename': os.path.basename(blob.name),
                        'blob_path': blob.name,
                        'blob_url': blob_client_item.url,
                        'size': blob.size,
                        'last_modified': blob.last_modified.isoformat() if blob.last_modified else None
                    })
            
            history.sort(key=lambda x: x['version'])
            
        except Exception as e:
            print(f"  ⚠️ Error getting version history: {e}")
        
        return history
    
    def delete_version(
        self,
        document_id: str,
        country: str,
        version: int,
        icf_case_id: Optional[str] = None
    ) -> Tuple[bool, str]:
        """
        Delete a specific version of a document.
        
        Args:
            document_id: Document ID
            country: Country name
            version: Version number to delete
            icf_case_id: ICF case identifier (uses new path structure)
            
        Returns:
            Tuple of (success, error_message)
        """
        if not self.blob_client:
            return False, "Blob client not initialized"
        
        blob_path = self.generate_blob_path(document_id, country, version, icf_case_id)
        
        try:
            blob_client = self.blob_client.get_blob_client(
                container=self.OUTPUT_CONTAINER,
                blob=blob_path
            )
            blob_client.delete_blob()
            
            print(f"  ✓ Deleted: {blob_path}")
            return True, ""
            
        except Exception as e:
            error_msg = f"Delete failed: {str(e)}"
            print(f"  ⚠️ {error_msg}")
            return False, error_msg
    
    def cleanup_temp_files(self, temp_dir: str):
        """
        Clean up temporary files after processing.
        
        Args:
            temp_dir: Temporary directory to clean
        """
        import shutil
        
        if os.path.exists(temp_dir):
            try:
                shutil.rmtree(temp_dir)
                print(f"  ✓ Cleaned up temp: {temp_dir}")
            except Exception as e:
                print(f"  ⚠️ Cleanup failed: {e}")