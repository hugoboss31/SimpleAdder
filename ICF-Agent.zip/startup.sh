#!/bin/bash
# Startup script for Azure App Service (Linux)
# This script is used by Azure App Service to start the FastAPI application

# Install gunicorn if not already installed (fallback)
if ! command -v gunicorn &> /dev/null; then
    pip install gunicorn
fi

# Start the application with gunicorn and uvicorn workers
# Using gunicorn for production-grade WSGI server with uvicorn workers for async support
gunicorn app:app \
    --bind 0.0.0.0:8000 \
    --workers 4 \
    --worker-class uvicorn.workers.UvicornWorker \
    --timeout 600 \
    --access-logfile - \
    --error-logfile - \
    --log-level info

