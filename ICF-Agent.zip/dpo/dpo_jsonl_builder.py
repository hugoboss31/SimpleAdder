"""JSONL builder for DPO training datasets."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Dict, List


@dataclass
class DPOJsonlBuilder:
    """Builds and validates DPO JSONL records for fine-tuning."""

    country: str
    version: str = "1.0"
    records: List[Dict[str, Any]] = field(default_factory=list)

    def create_record(
        self,
        system_prompt: str,
        user_prompt: str,
        preferred_output: str,
        non_preferred_output: str,
        metadata: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Create a single JSONL record with schema_version and metadata."""
        record = {
            "schema_version": self.version,
            "input": {
                "messages": [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt},
                ],
                "tools": [],
                "parallel_tool_calls": True,
            },
            "preferred_output": [
                {"role": "assistant", "content": preferred_output}
            ],
            "non_preferred_output": [
                {"role": "assistant", "content": non_preferred_output}
            ],
            "metadata": metadata,
        }

        self._validate_record(record)
        return record

    def add_record(self, record: Dict[str, Any]) -> None:
        """Add a validated record to the builder."""
        self._validate_record(record)
        self.records.append(record)

    def to_jsonl_string(self) -> str:
        """Serialize records to JSONL string (one record per line)."""
        return "\n".join(json.dumps(r, ensure_ascii=True) for r in self.records)

    def _validate_record(self, record: Dict[str, Any]) -> None:
        """Basic schema validation for DPO JSONL records."""
        if "schema_version" not in record:
            raise ValueError("Missing schema_version")
        if "input" not in record or "messages" not in record["input"]:
            raise ValueError("Missing input.messages")
        if "preferred_output" not in record or "non_preferred_output" not in record:
            raise ValueError("Missing preferred_output or non_preferred_output")
        if "metadata" not in record:
            raise ValueError("Missing metadata")

        messages = record["input"].get("messages", [])
        if len(messages) < 2:
            raise ValueError("input.messages must include system and user messages")

        if not isinstance(record["preferred_output"], list):
            raise ValueError("preferred_output must be a list")
        if not isinstance(record["non_preferred_output"], list):
            raise ValueError("non_preferred_output must be a list")
