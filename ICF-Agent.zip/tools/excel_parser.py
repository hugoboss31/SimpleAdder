"""Excel parser for customization plans."""

import os
from typing import List, Dict, Any, Optional
import pandas as pd
from pathlib import Path
from schemas.icf_schemas import CustomizationPlanItem, CustomizationPlan, RequirementType


class ExcelCustomizationPlanParser:
    """Parser for Excel customization plan files."""
    
    def __init__(self):
        """Initialize the parser."""
        pass
    
    def parse_customization_plan(
        self,
        excel_path: str,
        country: str,
        plan_id: Optional[str] = None
    ) -> CustomizationPlan:
        """
        Parse Excel customization plan into structured format.
        
        Expected Excel columns:
        - Item ID (or auto-generated)
        - Topic (e.g., "Compensation", "Contact for further information")
        - Requirement Text (country-specific guidance)
        - Requirement Type (mandatory/optional)
        - Applies To (existing_section/insert_new/both)
        - Synonyms (optional, comma-separated)
        - Importance (high/medium/low, optional)
        
        Args:
            excel_path: Path to Excel file
            country: Target country code
            plan_id: Optional plan identifier (auto-generated if not provided)
            
        Returns:
            CustomizationPlan object
        """
        if not Path(excel_path).exists():
            raise FileNotFoundError(f"Excel file not found: {excel_path}")
        
        # Read Excel file
        try:
            # Try reading with header first
            df = pd.read_excel(excel_path)
            
            # Check if this is a two-column format (Topic | Requirement)
            # Common pattern: Column 0 has topics, Column 1 has requirements
            if len(df.columns) == 2 and (df.columns[0] == country or df.columns[0] == 'USA' or 'Unnamed' in str(df.columns[0])):
                # This is the two-column format: Topic | Requirement
                print(f"[INFO] Detected two-column format for {country}")
                df = pd.read_excel(excel_path, header=None)
                # Skip header rows (usually first 1-2 rows)
                # Find first row with both columns filled and valid topic
                start_idx = 0
                for idx, row in df.iterrows():
                    col0_val = str(row[0]).strip() if pd.notna(row[0]) else ""
                    col1_val = str(row[1]).strip() if pd.notna(row[1]) else ""
                    
                    # Skip empty rows and header rows
                    if col0_val and col1_val and col0_val.lower() not in ['versions', 'usa', 'topic', 'item', 'nan', 'none']:
                        # Check if it looks like a real topic (not a header)
                        if len(col0_val) > 3 and col0_val[0].isupper():
                            start_idx = idx
                            break
                
                # Create new dataframe with proper columns
                df_clean = pd.DataFrame({
                    'topic': df.iloc[start_idx:, 0],
                    'requirement_text': df.iloc[start_idx:, 1]
                })
                # Clean up: remove rows where topic or requirement is empty/NaN
                df_clean = df_clean.dropna(subset=['topic', 'requirement_text'])
                df_clean = df_clean[df_clean['topic'].astype(str).str.strip() != '']
                df_clean = df_clean[df_clean['requirement_text'].astype(str).str.strip() != '']
                # Remove rows where topic is NaN-like
                df_clean = df_clean[~df_clean['topic'].astype(str).str.lower().isin(['nan', 'none', ''])]
                df = df_clean.reset_index(drop=True)
            else:
                # Standard format - normalize column names
                column_mapping = self._normalize_columns(df.columns.tolist())
                df = df.rename(columns=column_mapping)
                
        except Exception as e:
            raise ValueError(f"Failed to read Excel file: {e}")
        
        # Generate plan_id if not provided
        if not plan_id:
            plan_id = f"{country}_plan_{Path(excel_path).stem}"
        
        # Parse items
        items = []
        for idx, row in df.iterrows():
            try:
                item = self._parse_row(row, idx, country)
                if item:
                    items.append(item)
            except Exception as e:
                print(f"Warning: Failed to parse row {idx}: {e}")
                continue
        
        return CustomizationPlan(
            plan_id=plan_id,
            country=country,
            source_file=excel_path,
            items=items,
            metadata={
                "total_rows": len(df),
                "parsed_items": len(items),
                "columns": list(df.columns)
            }
        )
    
    def _normalize_columns(self, columns: List[str]) -> Dict[str, str]:
        """Normalize column names to standard format."""
        mapping = {}
        
        # Common variations
        variations = {
            "item_id": ["item id", "itemid", "id", "item_id", "item"],
            "topic": ["topic", "subject", "section", "category", "theme"],
            "requirement_text": ["requirement text", "requirement", "text", "guidance", "requirement_text", "description"],
            "requirement_type": ["requirement type", "type", "requirement_type", "mandatory/optional"],
            "applies_to": ["applies to", "applies_to", "action", "location"],
            "synonyms": ["synonyms", "alternatives", "related terms"],
            "importance": ["importance", "priority", "risk level"]
        }
        
        for standard_name, variants in variations.items():
            for col in columns:
                col_lower = col.lower().strip()
                if col_lower in variants or standard_name.lower() in col_lower:
                    mapping[col] = standard_name
                    break
        
        return mapping
    
    def _parse_row(self, row: pd.Series, index: int, country: str) -> Optional[CustomizationPlanItem]:
        """Parse a single row into CustomizationPlanItem."""
        # Extract topic (handle both formats)
        topic = ""
        if "topic" in row.index:
            topic = str(row.get("topic", "")).strip()
        elif len(row.index) >= 1:
            # Two-column format: first column is topic
            topic = str(row.iloc[0]).strip() if pd.notna(row.iloc[0]) else ""
        
        if not topic or topic.lower() in ['nan', 'none', '']:
            return None  # Skip rows without topic
        
        # Skip header-like rows
        if topic.lower() in ['versions', 'usa', 'topic', 'item', 'item id']:
            return None
        
        # Extract requirement_text (handle both formats)
        requirement_text = ""
        if "requirement_text" in row.index:
            requirement_text = str(row.get("requirement_text", "")).strip()
        elif len(row.index) >= 2:
            # Two-column format: second column is requirement
            requirement_text = str(row.iloc[1]).strip() if pd.notna(row.iloc[1]) else ""
        
        if not requirement_text or requirement_text.lower() in ['nan', 'none', '']:
            return None  # Skip rows without requirement text
        
        # Extract item_id
        item_id = str(row.get("item_id", f"{country}-{index+1:02d}")).strip()
        
        # Extract requirement_type
        req_type_str = str(row.get("requirement_type", "mandatory")).strip().lower()
        if "optional" in req_type_str:
            requirement_type = RequirementType.OPTIONAL
        else:
            requirement_type = RequirementType.MANDATORY
        
        # Extract applies_to
        applies_to = row.get("applies_to", None)
        if applies_to:
            applies_to = str(applies_to).strip().lower()
            if applies_to not in ["existing_section", "insert_new", "both"]:
                applies_to = None
        
        # Extract synonyms
        synonyms_str = str(row.get("synonyms", "")).strip()
        synonyms = []
        if synonyms_str and synonyms_str.lower() != "nan":
            synonyms = [s.strip() for s in synonyms_str.split(",") if s.strip()]
        
        # Extract importance
        importance = row.get("importance", None)
        if importance:
            importance = str(importance).strip().lower()
            if importance not in ["high", "medium", "low"]:
                importance = None
        
        # Determine importance based on topic if not provided
        if not importance:
            importance = self._infer_importance(topic)
        
        return CustomizationPlanItem(
            item_id=item_id,
            topic=topic,
            country=country,
            requirement_text=requirement_text,
            requirement_type=requirement_type,
            applies_to=applies_to,
            synonyms=synonyms,
            importance=importance,
            metadata={
                "row_index": index,
                "raw_data": row.to_dict()
            }
        )
    
    def _infer_importance(self, topic: str) -> Optional[str]:
        """Infer importance level based on topic keywords."""
        topic_lower = topic.lower()
        
        high_risk_keywords = [
            "compensation", "indemnity", "insurance", "injury",
            "data protection", "privacy", "confidentiality",
            "pregnancy", "minors", "children", "vulnerable"
        ]
        
        if any(keyword in topic_lower for keyword in high_risk_keywords):
            return "high"
        
        return "medium"  # Default to medium if not clearly high-risk

