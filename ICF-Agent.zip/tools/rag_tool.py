"""RAG tool for querying regulatory knowledge base using hybrid vector search."""

import os
from typing import List, Dict, Any
from azure.search.documents import SearchClient
from azure.search.documents.models import VectorizedQuery
from openai import AzureOpenAI
from config import config


class RAGTool:
    """Tool for querying regulatory documents using Azure AI Search with hybrid search (BM25 + vector)."""
    
    def __init__(self):
        self.search_endpoint = config.get_search_endpoint()
        self.search_credential = config.get_search_credential()
        self.index_name = config.RAG_INDEX_NAME
        
        self.openai_endpoint = config.AZURE_OPENAI_ENDPOINT
        self.openai_key = config.AZURE_OPENAI_API_KEY
        self.embedding_deployment = config.EMBEDDINGS_MODEL_DEPLOYMENT
        
        if not self.search_endpoint or not self.index_name:
            raise ValueError("AZURE_SEARCH_ENDPOINT and index name must be configured")
        
        self.search_client = SearchClient(
            endpoint=self.search_endpoint,
            index_name=self.index_name,
            credential=self.search_credential
        )
        
        if not self.openai_endpoint or not self.openai_key:
            raise ValueError(
                "OpenAI client is required but not configured. "
                "Please set AZURE_OPENAI_ENDPOINT and AZURE_OPENAI_API_KEY in .env"
            )
        
        self.openai_client = AzureOpenAI(
            azure_endpoint=self.openai_endpoint,
            api_key=self.openai_key,
            api_version=config.AZURE_OPENAI_API_VERSION
        )
    
    def _get_embedding(self, text: str) -> List[float]:
        """Generate embedding vector for text."""
        if not self.openai_client:
            raise ValueError("OpenAI client not configured for embeddings")
        
        response = self.openai_client.embeddings.create(
            model=self.embedding_deployment,
            input=text
        )
        
        return response.data[0].embedding
    
    def query_regulations(self, query: str, country: str, top_k: int = 10) -> List[Dict[str, Any]]:
        """
        Query regulatory knowledge base using hybrid search (BM25 + vector).
        
        Args:
            query: Natural language query
            country: Target country code (for context, not filtering)
            top_k: Number of results
            
        Returns:
            List of regulatory rules with semantic similarity scores
        """
        try:
            # Build semantic query for better embedding
            semantic_query = f"{query} {country} regulatory requirements"
            
            # Generate embedding for vector search - OpenAI client is required
            try:
                embedding = self._get_embedding(semantic_query)
                # Use contentVector field (matches rag_agent.py indexing)
                # Try both field names for compatibility
                vector_query = VectorizedQuery(
                    vector=embedding,
                    k_nearest_neighbors=top_k * 2,  # Get more candidates for semantic matching
                    fields="contentVector"  # Primary field name from rag_agent.py
                )
            except Exception as e:
                # If contentVector fails, try "embedding" field name
                try:
                    vector_query = VectorizedQuery(
                        vector=embedding,
                        k_nearest_neighbors=top_k * 2,
                        fields="embedding"
                    )
                except Exception as e2:
                    raise RuntimeError(f"Failed to create vector query with both field names: {e}, {e2}") from e
            
            # Perform hybrid search: BM25 + vector (both required)
            search_options = {
                "search_text": query,  # BM25 keyword search
                "vector_queries": [vector_query],  # Vector semantic search (required)
                "top": top_k,
                "select": ["id", "content", "source", "doc_type", "chunk_id", "storage_type"]
            }
            
            results = self.search_client.search(**search_options)
            
            rules = []
            for result in results:
                # Extract fields with priority order
                rule = {
                    'id': result.get('id', result.get('chunk_id', 'unknown')),
                    'content': result.get('content', result.get('chunk', result.get('text', ''))),
                    'source': result.get('source', result.get('title', 'Unknown')),
                    'relevance_score': result.get('@search.score', 0.0),
                    'doc_type': result.get('doc_type'),
                    'chunk_id': result.get('chunk_id', 0)
                }
                
                # Add any additional fields that might be present
                for key, value in result.items():
                    if key not in rule and not key.startswith('@'):
                        rule[key] = value
                
                rules.append(rule)
            
            return rules
        except Exception as e:
            print(f"Warning: RAG search failed: {e}")
            import traceback
            traceback.print_exc()
            return []
    
    def verify_reference(self, reference: str, country: str) -> Dict[str, Any]:
        """
        Verify if a regulatory reference is valid.
        
        Args:
            reference: Regulatory reference string
            country: Target country
            
        Returns:
            Validation result with details
        """
        try:
            results = self.search_client.search(
                search_text=reference,
                top=1
            )
            
            for result in results:
                return {
                    'valid': True,
                    'rule': dict(result),
                    'message': f"Valid reference: {reference}"
                }
            
            return {
                'valid': False,
                'rule': None,
                'message': f"Reference not found: {reference}"
            }
        except Exception as e:
            print(f"Warning: Reference verification failed: {e}")
            return {
                'valid': False,
                'rule': None,
                'message': f"Verification error: {str(e)}"
            }
