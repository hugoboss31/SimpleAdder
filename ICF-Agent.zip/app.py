"""
FastAPI Backend for Multi-Country ICF Generator.
Provides APIs for Node.js integration:
- Index Customization Plans (doctypeid=3)
- Index Regulatory Documents (doctypeid=1,4)
- Index Global ICF Sections (icf-sections-index)
- Generate Country-Specific ICF with feedback loop
- Regenerate Country ICF from Human Review
"""

import os
import tempfile
import logging
import asyncio
import json
from datetime import datetime
from typing import Any, Dict, Optional
from urllib.parse import urlparse
import requests
from fastapi import BackgroundTasks, FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from dotenv import load_dotenv

from azure.storage.blob import BlobServiceClient
from azure.core.credentials import AzureKeyCredential

from agents import WorkflowManager
from agents.workflow import HumanReviewWorkflow
from services.indexer import MultiCountryIndexer
from agents.ingestion_agent import IngestionService
from services.generator_knowledge_store import GeneratorKnowledgeStore
from config import Config
from utils.warmup import warmup_service
from models.models import RegenerateRequest, RegenerateResponse, LearnOnlyRequest, LearnOnlyResponse
from services.learning_artifacts import LearnPipeline
from services.app_insights import get_logger, track_event, track_exception
from services.dpo_training_service import DPOTrainingService
from dpo import DPOTrainingGenerator
from middleware import RateLimiterMiddleware, CorrelationIdMiddleware

load_dotenv()

# Application Insights - must run before app creation when connection string is set
_app_insights_conn = os.getenv("APPLICATION_INSIGHTS_CONNECTION_STRING")
if _app_insights_conn:
    try:
        from azure.monitor.opentelemetry import configure_azure_monitor
        configure_azure_monitor(connection_string=_app_insights_conn)
    except Exception as e:
        logging.warning(f"Application Insights configure failed: {e}")

app = FastAPI(
    title="ICF Generator API",
    description="Multi-Country ICF Generation with Azure AI Search",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.add_middleware(RateLimiterMiddleware, requests_per_minute=30) 
app.add_middleware(CorrelationIdMiddleware)

# Global services
dpo_training_service = DPOTrainingService()
# =============================================================================
# PYDANTIC MODELS
# =============================================================================

class IndexCountryDocumentRequest(BaseModel):
    blob_url: str
    countryid: int
    doctypeid: int  # 2=Regulatory, 3=Customization Plan, 4=Review Checklist
    country_name: str

class IndexGlobalIcfRequest(BaseModel):
    blob_url: str
    document_id: str

class DeleteIndexRequest(BaseModel):
    document_id: str

class GenerateCountryIcfRequest(BaseModel):
    global_icf_document_id: str
    global_icf_blob_url: str
    country: str
    enable_qa_loop: bool = True
    icf_document_id: int
    icf_case_id: str = ""
    study_id: Optional[int] = None
    study_name: Optional[str] = None
    study_icf_type: Optional[str] = None
    user_name: Optional[str] = None

class RemoveIndexRequest(BaseModel):
    document_id: str

class HealthResponse(BaseModel):
    status: str
    timestamp: str

class IndexResponse(BaseModel):
    success: bool
    message: str
    documents_indexed: int = 0
    index_name: Optional[str] = None

class GenerateResponse(BaseModel):
    success: bool
    message: str
    output_blob_path: Optional[str] = None
    iterations: int = 0
    total_changes: int = 0
    country: str = ""
    document_id: Optional[str] = None
    coverage_stats: Optional[dict] = None


class DPOTrainingRunRequest(BaseModel):
    initiated_by: Optional[str] = None
    notes: Optional[str] = None
    dry_run: bool = False


class DPOTrainingCallbackRequest(BaseModel):
    run_id: str
    status: Optional[str] = None
    job_id: Optional[str] = None
    model_name: Optional[str] = None
    deployment_name: Optional[str] = None
    stage: Optional[str] = None
    message: Optional[str] = None
    artifacts: Optional[Dict[str, str]] = None
    metrics: Optional[Dict[str, Any]] = None


class DPOTrainingArtifacts(BaseModel):
    config: Optional[str] = None
    evaluation: Optional[str] = None
    dataset_manifest: Optional[str] = None


class DPOTrainingRunStatusResponse(BaseModel):
    run_id: str
    status: str
    stage: Optional[str] = None
    message: Optional[str] = None
    initiated_by: Optional[str] = None
    notes: Optional[str] = None
    dry_run: bool = False
    job_id: Optional[str] = None
    model_name: Optional[str] = None
    deployment_name: Optional[str] = None
    created_at: str
    updated_at: str
    artifacts: DPOTrainingArtifacts = Field(default_factory=DPOTrainingArtifacts)
    metrics: Dict[str, Any] = Field(default_factory=dict)


class DPOModelInfoResponse(BaseModel):
    deployment_name: Optional[str] = None
    configured_model: Optional[str] = None
    model: Optional[str] = None
    status: Optional[str] = None
    created_at: Optional[str] = None
    scale_settings: Optional[Dict[str, Any]] = None

# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def get_blob_service():
    """Get Azure Blob Service Client (connection string or RBAC via Config)."""
    from config import config
    try:
        return config.get_blob_service_client()
    except ValueError as e:
        raise HTTPException(status_code=500, detail="Azure Storage not configured") from e

def download_from_blob_url(blob_url: str) -> tuple:
    """
    Download file from blob URL to temp file.
    Returns (temp_file_path, filename)
    """
    logger = logging.getLogger("download_from_blob_url")
    # Log original URL for debugging
    logger.info(f"[URL TRACE] Original blob_url received: '{blob_url}'")
    logger.info(f"[URL TRACE] Original blob_url repr: {repr(blob_url)}")
    logger.info(f"[URL TRACE] Original blob_url length: {len(blob_url)}")
    
    blob_service = get_blob_service()
    container_name = os.getenv("AZURE_STORAGE_CONTAINER_NAME", "icf-country-dev")
    
    # Clean the URL - strip whitespace and quotes
    # Also decode URL-encoded characters (e.g., %22 for quotes)
    from urllib.parse import unquote
    blob_url = blob_url.strip()
    blob_url = unquote(blob_url.strip()).strip('"').strip("'")
    blob_url = blob_url.replace("%22", "").replace("%27", "").replace('"', "").replace("'", "")

    
    # Log cleaned URL
    logger.info(f"[URL TRACE] After cleaning blob_url: '{blob_url}'")
    logger.info(f"[URL TRACE] After cleaning repr: {repr(blob_url)}")
    logger.info(f"[URL TRACE] After cleaning length: {len(blob_url)}")
    
    # Extract blob path from URL
    blob_path = blob_url
    if blob_url.startswith("http"):
        # Parse URL: https://account.blob.core.windows.net/container/path/file.docx
        parts = blob_url.split("/")
        logger.info(f"[URL TRACE] URL parts: {parts}")
        for i, part in enumerate(parts):
            if "blob.core.windows.net" in part:
                logger.info(f"[URL TRACE] Found blob host at index {i}: '{part}'")
                # Container is next, then path - sanitize to remove any stray quotes
                if i + 2 < len(parts):
                    container_name = parts[i + 1].replace('"', "").replace("'", "")
                    blob_path = "/".join(parts[i + 2:]).replace('"', "").replace("'", "")
                    logger.info(f"[URL TRACE] Extracted container_name: '{container_name}'")
                    logger.info(f"[URL TRACE] Extracted blob_path: '{blob_path}'")
                break
    container_name = container_name.replace("%22", "").replace("%27", "")
    blob_path = blob_path.replace("%22", "").replace("%27", "")

    filename = blob_path.split("/")[-1]
    
    logger.info(f"[URL TRACE] Final filename: '{filename}'")
    logger.info(f"[URL TRACE] Calling get_blob_client with container='{container_name}', blob='{blob_path}'")
    
    # Download to temp file
    blob_client = blob_service.get_blob_client(container=container_name, blob=blob_path)
    file_bytes = blob_client.download_blob().readall()
    
    # Save to temp file
    temp_dir = tempfile.mkdtemp()
    temp_path = os.path.join(temp_dir, filename)
    with open(temp_path, "wb") as f:
        f.write(file_bytes)

    # python-docx requires .docx (OOXML); .doc causes "content type is themeManager" error
    ext = (filename or "").lower().split(".")[-1] if "." in (filename or "") else ""
    if ext == "doc":
        raise ValueError(
            f"Global ICF document '{filename}' has .doc extension. "
            "Only .docx format is supported. Please re-upload the document as .docx (File > Save As > Word Document)."
        )

    return temp_path, filename

def get_country_name_from_id(countryid: int) -> str:
    """Map countryid to country name."""
    mapping = {1: "global", 2: "usa", 3: "canada", 4: "taiwan", 5: "argentina", 6: "france"}
    return mapping.get(countryid, "unknown")

def check_azure_connections() -> dict:
    """Check all Azure service connections."""
    status = {"blob": False, "search": False, "openai": False}
    
    # Check Blob
    try:
        conn_str = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
        if conn_str:
            blob_service = BlobServiceClient.from_connection_string(conn_str)
            container = blob_service.get_container_client(os.getenv("AZURE_STORAGE_CONTAINER_NAME", "icf-country-dev"))
            container.exists()
            status["blob"] = True
    except Exception:
        pass
    
    # Check AI Search
    try:
        from azure.search.documents.indexes import SearchIndexClient

        index_client = SearchIndexClient(
            endpoint=Config.get_search_endpoint(),
            credential=Config.get_search_credential()
        )
        # Just list indexes to verify connection
        list(index_client.list_indexes())
        status["search"] = True
    except:
        pass
    
    # Check OpenAI
    try:
        api_key = os.getenv("AZURE_OPENAI_API_KEY")
        endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
        if api_key and endpoint:
            status["openai"] = True
    except:
        pass
    
    return status

def _resolve_callback_url(callback_url: str) -> str:
    """
    If the callback URL points to localhost and BACKEND_API_URL is set to a non-localhost URL,
    resolve to BACKEND_API_URL with the same path. This fixes Azure deployments where the
    backend sends localhost:8080 (its own PORT) which the agent cannot reach.
    """
    if not callback_url or not callback_url.strip():
        return callback_url
    try:
        parsed = urlparse(callback_url)
        host = (parsed.hostname or "").lower()
        if host not in ("localhost", "127.0.0.1", "::1"):
            return callback_url
        backend_base = Config.get_backend_base_url()
        if not backend_base:
            return callback_url
        backend_parsed = urlparse(backend_base)
        if (backend_parsed.hostname or "").lower() in ("localhost", "127.0.0.1", "::1"):
            return callback_url
        path = parsed.path or "/"
        if not path.startswith("/"):
            path = "/" + path
        resolved = backend_base.rstrip("/") + path
        if parsed.query:
            resolved += "?" + parsed.query
        _cb_log = get_logger("callback")
        _cb_log.info(f"Resolved callback localhost -> backend: {resolved}")
        return resolved
    except Exception:
        return callback_url

def send_callback(callback_url: str, payload: dict, correlation_id: str = None):
    """Send callback to Node.js when generation completes. Retries on timeout/connection errors."""
    import time
    _cb_logger = get_logger("callback")
    url = _resolve_callback_url(callback_url)
    headers = {"X-Correlation-ID": correlation_id} if correlation_id else None
    timeout_seconds = 60
    max_attempts = 3
    backoff_seconds = 5
    last_error = None
    for attempt in range(1, max_attempts + 1):
        try:
            resp = requests.post(url, json=payload, timeout=timeout_seconds, headers=headers)
            if resp.ok:
                _cb_logger.info(f"Callback sent to {url} status={resp.status_code}" + (f" correlationId={correlation_id}" if correlation_id else ""))
                return
            _cb_logger.error(f"Callback to {url} returned {resp.status_code}: {resp.text[:200]}")
            return
        except Exception as e:
            last_error = e
            _cb_logger.warning(f"Callback attempt {attempt}/{max_attempts} failed to {url}: {e}")
            if attempt < max_attempts:
                time.sleep(backoff_seconds)
    _cb_logger.error(f"Callback failed to {url} after {max_attempts} attempts: {last_error}")


def build_dpo_override_payload(artifacts, country: str, icf_case_id: str, iteration_id: int):
    """Normalize freshly generated artifacts so DPOTrainingGenerator sees full metadata."""
    overrides = []
    if not artifacts:
        return overrides

    for artifact in artifacts:
        artifact_dict = artifact.model_dump() if hasattr(artifact, "model_dump") else dict(artifact)
        section = artifact_dict.get("section_title") or artifact_dict.get("change_type") or "Unknown"
        human_output = artifact_dict.get("human_output", "")

        overrides.append(
            {
                **artifact_dict,
                "country": country,
                "section_type": section,
                "context": f"{section}: {human_output[:100]}",
                "source_document_id": icf_case_id,
                "icf_case_id": icf_case_id,
                "iteration_id": iteration_id,
                "version": iteration_id,
            }
        )

    return overrides

# =============================================================================
# ROOT ENDPOINT
# =============================================================================

@app.get("/")
async def root():
    """Root endpoint - API information."""
    return {
        "message": "ICF Generator Agent API",
        "version": "1.0.0",
        "description": "FastAPI service for generating country-specific ICF documents using LLM agents",
        "documentation": "/docs",
        "health": "/health",
        "endpoints": {
            "health": "GET /health",
            "health_ready": "GET /health/ready",
            "health_live": "GET /health/live",
            "index_global_icf": "POST /index-global-icf",
            "index_country_document": "POST /index-country-document",
            "remove_country_document": "DELETE /index-country-document",
            "generate_country_icf": "POST /generate-country-icf",
            "learn_only": "POST /learn-only",
            "learn_and_regenerate": "POST /learn-and-regenerate",
            "document_status": "GET /document-status/{document_id}",
            "countries": "GET /countries",
            "index_status": "GET /index-status/{country}",
            "dpo_train": "POST /api/dpo/train",
            "dpo_train_status": "GET /api/dpo/train/status?runId=",
            "dpo_callback": "POST /api/dpo/callback",
            "dpo_model": "GET /api/dpo/model"
        }
    }

# =============================================================================
# HEALTH ENDPOINTS
# =============================================================================

@app.get("/health", response_model=HealthResponse)
async def health():
    """Basic health check."""
    return HealthResponse(
        status="healthy",
        timestamp=datetime.utcnow().isoformat()
    )

@app.get("/health/ready")
async def health_ready():
    """Readiness probe - checks if service is ready to accept requests."""
    connections = check_azure_connections()
    
    is_ready = all(connections.values())
    
    return {
        "status": "ready" if is_ready else "not_ready",
        "timestamp": datetime.utcnow().isoformat(),
        "connections": connections
    }

@app.get("/health/live")
async def health_live():
    """Liveness probe - checks if service is alive."""
    return {
        "status": "alive",
        "timestamp": datetime.utcnow().isoformat()
    }

# =============================================================================
# DPO TRAINING ENDPOINTS
# =============================================================================


def _require_dpo_service() -> DPOTrainingService:
    if not dpo_training_service or not dpo_training_service.is_enabled():
        raise HTTPException(status_code=503, detail="DPO training service is not configured")
    return dpo_training_service


@app.post("/api/dpo/train", status_code=202, response_model=DPOTrainingRunStatusResponse)
async def trigger_dpo_training_run(
    request: DPOTrainingRunRequest,
    background_tasks: BackgroundTasks
):
    service = _require_dpo_service()
    payload = request.model_dump(exclude_none=True)
    try:
        run = service.queue_run(payload)
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc

    background_tasks.add_task(service.execute_run, run["run_id"], payload)
    return run


@app.get("/api/dpo/train/status", response_model=DPOTrainingRunStatusResponse)
async def get_dpo_training_status(
    run_id: Optional[str] = Query(None),
    runId: Optional[str] = Query(None)
):
    identifier = run_id or runId
    if not identifier:
        raise HTTPException(status_code=400, detail="Query parameter 'run_id' or 'runId' is required")

    service = _require_dpo_service()
    status = service.get_status(identifier)
    if not status:
        raise HTTPException(status_code=404, detail=f"No DPO training run found for {identifier}")
    return status


@app.post("/api/dpo/callback", response_model=DPOTrainingRunStatusResponse)
async def handle_dpo_training_callback(request: DPOTrainingCallbackRequest):
    service = _require_dpo_service()
    result = service.apply_callback(request.model_dump(exclude_none=True))
    if not result:
        raise HTTPException(status_code=404, detail="DPO training run not found")
    return result


@app.get("/api/dpo/model", response_model=DPOModelInfoResponse)
async def get_dpo_model_metadata():
    if not dpo_training_service:
        raise HTTPException(status_code=503, detail="DPO training utilities unavailable")
    return dpo_training_service.get_active_model_info()

# =============================================================================
# INDEX ENDPOINTS
# =============================================================================

# Country-Specific Document Indexing
@app.post("/index-country-document", response_model=IndexResponse)
async def index_country_document(request: IndexCountryDocumentRequest):
    """
    Index country-specific document (Customization Plan, Regulatory, or Checklist).
    doctypeid: 2=Regulatory Document, 3=Customization Plan, 4=Review Checklist
    """
    try:
        # Document type mapping
        DOC_TYPES = {
            2: "Regulatory Document",
            3: "Customization Plan",
            4: "Review Checklist"
        }
        
        if request.doctypeid not in DOC_TYPES:
            raise HTTPException(
                status_code=400, 
                detail=f"doctypeid must be one of {list(DOC_TYPES.keys())}"
            )
        
        indexer = MultiCountryIndexer()
        
        result = indexer.index_document(
            blob_url=request.blob_url,
            countryid=request.countryid,
            doctypeid=request.doctypeid,
            country_name=request.country_name
        )
        
        doc_type_name = DOC_TYPES[request.doctypeid]
        
        return IndexResponse(
            success=True,
            message=f"Indexed {doc_type_name} for {request.country_name.upper()}",
            documents_indexed=result.get("indexed", 0),
            index_name=f"icf-index-{request.country_name}"
        )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.delete("/index-country-document", response_model=IndexResponse)
async def remove_country_document(request: IndexCountryDocumentRequest):
    """
    Remove country-specific document from index.
    Used when a file is deleted from blob storage.
    doctypeid: 2=Regulatory Document, 3=Customization Plan, 4=Review Checklist
    """
    try:
        indexer = MultiCountryIndexer()
        
        result = indexer.remove_document(
            blob_url=request.blob_url,
            countryid=request.countryid,
            doctypeid=request.doctypeid,
            country_name=request.country_name
        )
        
        return IndexResponse(
            success=result["success"],
            message=result["message"],
            documents_indexed=result.get("deleted", 0),
            index_name=result.get("index_name")
        )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# Global ICF Indexing
@app.post("/index-global-icf", response_model=IndexResponse)
async def index_global_icf(request: IndexGlobalIcfRequest):
    """
    Index Global ICF document sections.
    Downloads DOCX from blob, extracts sections, indexes to icf-sections-index.
    """
    try:
        # Download file from blob
        temp_path, filename = download_from_blob_url(request.blob_url)
        
        # Initialize IngestionService
        ingestion_service = IngestionService()
        
        # Ingest and index sections
        result = ingestion_service.ingest_global_icf(
            docx_path=temp_path,
            document_id=request.document_id
        )
        
        # Cleanup temp file
        try:
            os.remove(temp_path)
            os.rmdir(os.path.dirname(temp_path))
        except:
            pass
        
        return IndexResponse(
            success=True,
            message=f"Indexed {result.total_sections} sections for document {request.document_id}",
            documents_indexed=result.total_sections,
            index_name="icf-sections-index"
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    
@app.delete("/delete-global-icf", response_model=IndexResponse)
async def delete_global_icf(req: DeleteIndexRequest):
    """
    Delete all indexed ICF sections for a given document_id
    from Azure AI Search (default index: icf-sections-index).
    """
    try:
        
        indexer = MultiCountryIndexer()

        # Allow overriding via ENV for flexibility
        index_name = os.getenv("ICF_SECTIONS_INDEX_NAME", "icf-sections-index")

        deleted_count, message, final_index_name = indexer.delete_global_icf_sections(
            document_id=req.document_id,
            index_name=index_name
        )

        return IndexResponse(
            success=True,
            message=message,
            documents_indexed=deleted_count,
            index_name=final_index_name
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    
@app.delete("/index-global-icf", response_model=IndexResponse)
async def remove_global_icf(request: RemoveIndexRequest):
    """
    Remove Global ICF document sections from index.
    Deletes all sections for the given document_id from icf-sections-index.
    Used when a Global ICF document is deleted from blob storage.
    """
    try:
        # Initialize IngestionService
        ingestion_service = IngestionService()
        
        # Delete all sections for this document
        sections_deleted = ingestion_service.delete_document_sections(request.document_id)
        
        return IndexResponse(
                success=True,
            message=f"Removed {sections_deleted} sections for document {request.document_id}",
            documents_indexed=sections_deleted,
            index_name=os.getenv("ICF_SECTIONS_INDEX_NAME", "icf-sections-index")
        )
    except HTTPException:
        raise

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# =============================================================================
# GENERATION ENDPOINTS
# =============================================================================

@app.post("/generate-country-icf", status_code=202)
async def generate_country_icf(
    request: GenerateCountryIcfRequest,
    background_tasks: BackgroundTasks
):
    """
    Generate country-specific ICF using indexed documents.
    
    - Uses pre-indexed Global ICF sections (from icf-sections-index)
    - Queries country-specific Customization Plan (doctypeid=3)
    - Runs Generator ↔ QA feedback loop (max 3 iterations)
    - Saves output to blob: output/{country}/{timestamp}_{filename}.docx
    - Returns immediately with 202 Accepted - processing continues in background
    """
    country = request.country.lower().replace(' ', '-').replace('_', '-')
    
    def process_generation():
        """Background task to process ICF generation."""
        logger = get_logger("generate_country_icf")
        logger.setLevel(logging.INFO)
        if not logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter(
                '%(asctime)s [%(levelname)s] %(message)s',
                datefmt='%Y-%m-%d %H:%M:%S'
            )
            handler.setFormatter(formatter)
            logger.addHandler(handler)
        temp_path = None
        temp_dir = None
        output_path = None
        start_time = datetime.now()
        
        try:
            logger.info(f"🚀 Starting ICF generation background task")
            logger.info(f"   Country: {country.upper()}")
            logger.info(f"   Document ID: {request.global_icf_document_id}")
            logger.info(f"   Global ICF Blob URL: {request.global_icf_blob_url}")
            logger.info(f"   QA Loop Enabled: {request.enable_qa_loop}")
            
            track_event("GeneratorStarted", {
                "icf_case_id": request.icf_case_id,
                "country": country,
                "document_id": request.global_icf_document_id,
                "qa_loop_enabled": str(request.enable_qa_loop)
            })
            
            # Download Global ICF from blob (needed for OpenXML generation)
            logger.info(f"📥 Downloading Global ICF document from blob storage...")
            temp_path, filename = download_from_blob_url(request.global_icf_blob_url)
            logger.info(f"   ✓ Downloaded to: {temp_path}")
            
            # Use temp file for processing (not saved locally)
            temp_dir = tempfile.mkdtemp()

            # Build filename: CountryCode_StudyId_StudyName_ICFType_UserName_Version_Date.docx
            def _sanitize(s: str) -> str:
                if not s:
                    return ""
                for c in ' /\\:*?"<>|':
                    s = s.replace(c, "_")
                return s.strip("_")

            study_id = getattr(request, "study_id", None) or ""
            study_name = _sanitize(getattr(request, "study_name", "") or "")
            icf_type = _sanitize(getattr(request, "study_icf_type", "") or "")
            user_name = _sanitize(getattr(request, "user_name", "") or "User")
            version_str = "1.0"
            date_str = datetime.now().strftime("%d-%b-%Y")
            parts = [country.upper(), str(study_id), study_name, icf_type, user_name, version_str, date_str]
            parts_clean = [p for p in parts if p]
            if parts_clean:
                output_filename = "_".join(parts_clean) + ".docx"
            else:
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                output_filename = f"{country.upper()}_ICF_{timestamp}.docx"

            output_path = os.path.join(temp_dir, output_filename)
            logger.info(f"   Output path: {output_path}")
            
            # Initialize workflow manager
            logger.info(f"🔧 Initializing WorkflowManager for {country.upper()}...")
            workflow = WorkflowManager(
                country=country,
                knowledge_base_path="knowledge_base",
                blob_container_name=os.getenv("AZURE_STORAGE_CONTAINER_NAME", "icf-country-dev")
            )
            logger.info(f"   ✓ WorkflowManager initialized")
            
            # QA loop enabled, but checklist loading disabled for generation
            if request.enable_qa_loop:
                logger.info("📋 QA checklist loading disabled for generation")
            
            # Run the generation workflow
            logger.info(f"⚙︝  Starting generation workflow...")
            workflow_start = datetime.now()
            result = workflow.run(
                input_docx_path=temp_path,
                output_docx_path=output_path,
                document_id=request.global_icf_document_id,
                icf_case_id=request.icf_case_id or None
            )
            workflow_duration = (datetime.now() - workflow_start).total_seconds()
            
            blob_path = result.get('blob_path') or None
            if blob_path == 'N/A':
                blob_path = None
            iterations = result.get('iterations', 0)
            total_changes = result.get('total_changes', 0)
            coverage_stats = result.get('coverage_stats') or {}
            total_duration = (datetime.now() - start_time).total_seconds()
            
            logger.info(f"✅ Generation completed successfully!")
            logger.info(f"   Output blob path: {blob_path or 'N/A'}")
            logger.info(f"   Iterations: {iterations}")
            logger.info(f"   Total changes: {total_changes}")
            if coverage_stats:
                logger.info(f"   Coverage stats: {coverage_stats}")
            learning_stats = (coverage_stats or {}).get('learning_stats', {})
            if learning_stats:
                logger.info(f"   📚 Learning stats (multi-strategy matching):\n{json.dumps(learning_stats, indent=2)}")
            logger.info(f"   Workflow duration: {workflow_duration:.2f} seconds")
            logger.info(f"   Total duration: {total_duration:.2f} seconds")
            
            track_event("GeneratorCompleted", {
                "icf_case_id": request.icf_case_id,
                "country": country,
                "document_id": request.global_icf_document_id,
                "iterations": str(iterations),
                "total_changes": str(total_changes),
                "duration_seconds": str(round(total_duration, 2)),
                **{k: str(v) for k, v in coverage_stats.items()}
            })

            # Send callback to backend (uses BACKEND_API_URL_INTERNAL when set for in-cluster)
            backend_url = Config.get_backend_base_url()
            if backend_url:
                callback_url = f"{backend_url.rstrip('/')}/api/generate-icf-callback"
                if blob_path:
                    storage_account = Config.AZURE_STORAGE_ACCOUNT_NAME
                    container_name = Config.AZURE_STORAGE_CONTAINER_NAME
                    if storage_account and container_name:
                        full_blob_url = f"https://{storage_account}.blob.core.windows.net/{container_name}/{blob_path}"
                        logger.info(f"📞 Sending success callback to: {callback_url}")
                        metadata = {
                            "country": country.upper(),
                            "iterations": iterations,
                            "total_changes": total_changes,
                            "duration_seconds": total_duration
                        }
                        if coverage_stats:
                            metadata.update(coverage_stats)
                        send_callback(callback_url, {
                            "status": 2,
                            "filename": output_filename,
                            "blob_url": full_blob_url,
                            "icfDoc_id": request.icf_document_id,
                            "icf_case_id": request.icf_case_id,
                            "version": 1,
                            "version_no": 1,
                            "success": True,
                            "error": None,
                            "metadata": metadata
                        })
                        logger.info(f"   Blob path: {blob_path}")
                    else:
                        logger.error("❌ Cannot send success callback: AZURE_STORAGE_ACCOUNT_NAME or AZURE_STORAGE_CONTAINER_NAME not set - sending error callback")
                        send_callback(callback_url, {
                            "status": 0,
                            "filename": None,
                            "blob_url": None,
                            "icfDoc_id": request.icf_document_id,
                            "success": False,
                            "error": "Blob URL not configured: storage account or container name missing",
                            "metadata": {"country": country.upper(), "duration_seconds": total_duration}
                        })
                else:
                    logger.error("❌ Blob upload failed (blob_path is None) - sending error callback")
                    send_callback(callback_url, {
                        "status": 0,
                        "filename": None,
                        "blob_url": None,
                        "icfDoc_id": request.icf_document_id,
                        "success": False,
                        "error": "Blob upload failed: generated document was not uploaded to storage",
                        "metadata": {"country": country.upper(), "duration_seconds": total_duration}
                    })
            else:
                logger.warning(f"⚠︝  No BACKEND_API_URL configured - skipping callback")
            
        except Exception as e:
            error_duration = (datetime.now() - start_time).total_seconds()
            logger.error(f"❌ Generation failed after {error_duration:.2f} seconds")
            logger.error(f"   Error: {str(e)}")
            logger.error(f"   Country: {country.upper()}")
            logger.error(f"   Document ID: {request.global_icf_document_id}")
            import traceback
            logger.error(f"   Traceback:\n{traceback.format_exc()}")
            
            track_event("GeneratorFailed", {
                "icf_case_id": request.icf_case_id,
                "country": country,
                "document_id": request.global_icf_document_id,
                "error": str(e),
                "duration_seconds": str(round(error_duration, 2))
            })
            track_exception(e, {
                "icf_case_id": request.icf_case_id,
                "country": country,
                "pipeline": "generate_country_icf"
            })
            # Send error callback to backend
            backend_url = Config.get_backend_base_url()
            if backend_url:
                callback_url = f"{backend_url.rstrip('/')}/api/generate-icf-callback"
                logger.info(f"📞 Sending error callback to: {callback_url}")
                send_callback(callback_url, {
                    "status": 0,
                    "filename": None,
                    "blob_url": None,
                    "icfDoc_id": request.icf_document_id,
                    "success": False,
                    "error": str(e),
                    "metadata": {"country": country.upper(), "duration_seconds": error_duration}
                })
            else:
                logger.warning(f"⚠︝  No BACKEND_API_URL configured - skipping error callback")
        finally:
            # Cleanup temp files
            logger.info(f"🧹 Cleaning up temporary files...")
            try:
                if temp_path and os.path.exists(temp_path):
                    os.remove(temp_path)
                    logger.debug(f"   ✓ Removed temp input file: {temp_path}")
                    if os.path.dirname(temp_path) and os.path.exists(os.path.dirname(temp_path)):
                        os.rmdir(os.path.dirname(temp_path))
                        logger.debug(f"   ✓ Removed temp input directory: {os.path.dirname(temp_path)}")
            except Exception as cleanup_error:
                logger.warning(f"   ⚠︝  Failed to cleanup temp input file: {cleanup_error}")

            try:
                if output_path and os.path.exists(output_path):
                    os.remove(output_path)
                    logger.debug(f"   ✓ Removed temp output file: {output_path}")
                if temp_dir and os.path.exists(temp_dir):
                    os.rmdir(temp_dir)
                    logger.debug(f"   ✓ Removed temp output directory: {temp_dir}")
            except Exception as cleanup_error:
                logger.warning(f"   ⚠︝  Failed to cleanup temp output files: {cleanup_error}")
            
            logger.info(f"🝝 Background task completed")
    
    # Add background task and return immediately
    background_tasks.add_task(process_generation)
    
    return {
        "success": True,
        "message": f"ICF generation initiated for {country.upper()}. Processing in background.",
        "status": "processing",
        "country": country.upper(),
        "document_id": request.global_icf_document_id
    }


@app.post("/learn-and-regenerate", status_code=202, response_model=RegenerateResponse)
async def learn_and_regenerate(
    request: RegenerateRequest,
    background_tasks: BackgroundTasks
):
    """
    Learn-and-Regenerate pipeline:
    
    Phase 1 (Learning): Same as learn-only
    - Downloads reviewed document with client comments/track changes
    - Supersedes/deletes previous iteration artifacts
    - Extracts semantic changes using LLM analysis
    - Maps to RAG evidence (5 hard gates)
    - Indexes new learning artifacts to Azure AI Search
    - Uploads artifact JSON to blob storage
    
    Phase 2 (Regeneration):
    - Loads learning artifacts from index (filter: icfCaseId, is_superseded eq false)
    - Applies learned patterns via HumanReviewAgent
    - Evidence Validator runs 5 hard gates on proposed changes
    - Uploads new version to blob: cases/{icfCaseId}/{country}/versions/v{n}/generated.docx
    - Callbacks to Node.js on completion
    
    Returns 202 Accepted - processing continues in background.
    """
    country = request.country_name.lower().replace(' ', '-').replace('_', '-')
    icf_case_id = request.icf_case_id or request.document_id

    def process_regeneration():
        """Background task to process learn-and-regenerate."""
        logger = get_logger("learn_and_regenerate")
        logger.setLevel(logging.INFO)
        if not logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter(
                '%(asctime)s [%(levelname)s] %(message)s',
                datefmt='%Y-%m-%d %H:%M:%S'
            )
            handler.setFormatter(formatter)
            logger.addHandler(handler)

        start_time = datetime.now()
        learn_result = None
        temp_path = None

        training_url = None

        try:
            logger.info(f"🔄 Starting Learn-and-Regenerate pipeline")
            logger.info(f"   Document ID: {request.document_id}")
            logger.info(f"   ICF Case ID: {icf_case_id}")
            logger.info(f"   Country: {country.upper()} (ID: {request.countryid})")
            logger.info(f"   Iteration: {request.iteration_id}")
            logger.info(f"   Reviewed Doc URL: {request.reviewed_blob_url}")
            logger.info(f"   Version: {request.current_version}")
            
            track_event("RegeneratorStarted", {
                "icf_case_id": icf_case_id,
                "country": country,
                "iteration_id": str(request.iteration_id),
                "current_version": str(request.current_version)
            })

            # =========================================================
            # PHASE 1: LEARNING (same as learn-only)
            # =========================================================
            logger.info(f"\n📖 PHASE 1: Learning")

            temp_path, filename = download_from_blob_url(request.reviewed_blob_url)
            logger.info(f"   ✓ Downloaded reviewed document: {filename}")

            from services.comment_extractor import CommentExtractor
            extractor = CommentExtractor()
            all_comments = extractor.extract_comments(temp_path)
            client_comments = [c for c in all_comments if c.is_client]
            logger.info(f"   ✓ Extracted {len(client_comments)} client comments")

            comments_for_pipeline = []
            for c in client_comments:
                comments_for_pipeline.append({
                    "text": c.text,
                    "linked_text": c.linked_text,
                    "section_heading": c.section_title or "Unknown",
                    "author": c.author
                })

            pipeline = LearnPipeline(country=country)

            learn_result = pipeline.run_learn_only_pipeline(
                reviewed_path=temp_path,
                icf_case_id=icf_case_id,
                iteration_id=request.iteration_id,
                comments=comments_for_pipeline
            )

            artifacts_payload = build_dpo_override_payload(
                learn_result.get("artifacts", []),
                country=country,
                icf_case_id=icf_case_id,
                iteration_id=request.iteration_id,
            )

            learn_duration = (datetime.now() - start_time).total_seconds()
            logger.info(f"   ✓ Learning complete in {learn_duration:.2f}s")
            logger.info(f"   Artifacts indexed: {learn_result.get('artifacts_indexed', 0)}")
            logger.info(f"   Artifacts superseded: {learn_result.get('artifacts_superseded', 0)}")
            try:
                dpo_generator = DPOTrainingGenerator(country=country)
                dpo_result = dpo_generator.generate_training_dataset(
                    icf_case_id=icf_case_id,
                    iteration_id=request.iteration_id,
                    include_superseded=False,
                    artifacts_override=artifacts_payload
                )
                training_url = dpo_result.get("blob_url")
                if training_url:
                    logger.info(f"   ✓ DPO training JSONL updated: {training_url}")
            except Exception as dpo_error:
                logger.warning(f"   ⚠️ DPO JSONL generation skipped: {dpo_error}")


            # Clean up temp file before regeneration (workflow will re-download)
            if temp_path and os.path.exists(temp_path):
                try:
                    os.remove(temp_path)
                    os.rmdir(os.path.dirname(temp_path))
                except:
                    pass
                temp_path = None

            # =========================================================
            # PHASE 1.5: Send learn callback to update database
            # =========================================================
            if request.callback_url:
                learn_callback_url = request.callback_url.replace("/api/regeneration-callback", "/api/learn-callback")
                if "/api/learn-callback" not in learn_callback_url:
                    # Fallback: construct from base URL
                    base_url = request.callback_url.rsplit("/api/", 1)[0]
                    learn_callback_url = f"{base_url}/api/learn-callback"
                
                track_changes = learn_result.get("track_changes_extracted", 0)
                comments_count = learn_result.get("comments_extracted", 0)
                indexed = learn_result.get("artifacts_indexed", 0)
                total_items = track_changes + comments_count
                not_learned = max(0, total_items - indexed)
                
                learn_callback_payload = {
                    "icfDoc_id": request.document_id,
                    "status": 2 if learn_result.get("success") else 0,
                    "success": learn_result.get("success", False),
                    "icf_case_id": icf_case_id,
                    "country": country.upper(),
                    "countryid": request.countryid,
                    "iteration_id": request.iteration_id,
                    "artifacts_count": len(learn_result.get("artifacts", [])),
                    "artifacts_indexed": indexed,
                    "artifacts_superseded": learn_result.get("artifacts_superseded", 0),
                    "artifact_blob_url": learn_result.get("artifact_blob_url"),
                    "error": None,
                    "metadata": {
                        "track_changes_extracted": track_changes,
                        "comments_extracted": comments_count,
                        "duration_seconds": learn_duration,
                        "feedback_items_total": total_items,
                        "feedback_items_learned": indexed,
                        "feedback_items_not_learned": not_learned,
                        "not_learned_items": learn_result.get("not_learned_items", []),
                    },
                }
                
                logger.info(f"   📤 Sending learn callback to: {learn_callback_url}")
                send_callback(learn_callback_url, learn_callback_payload)
                logger.info(f"   ✓ Learn callback sent successfully")

            # =========================================================
            # PHASE 2: REGENERATION
            # =========================================================
            logger.info(f"\n🔄 PHASE 2: Regeneration")

            workflow = HumanReviewWorkflow()

            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            try:
                callback = loop.run_until_complete(
                    workflow.run(request, request.callback_url, skip_dpo=False, send_callback=False)
                )
            finally:
                loop.close()

            if callback.metadata:
                callback.metadata.artifacts_indexed = learn_result.get('artifacts_indexed', 0)
                track_changes = learn_result.get("track_changes_extracted", 0)
                comments = learn_result.get("comments_extracted", 0)
                indexed = learn_result.get("artifacts_indexed", 0)
                total_items = track_changes + comments
                not_learned = max(0, total_items - indexed)
                callback.metadata.feedback_items_total = total_items
                callback.metadata.feedback_items_learned = indexed
                callback.metadata.feedback_items_not_learned = not_learned
                callback.metadata.not_learned_items = learn_result.get("not_learned_items", [])
                # Evidence gate fields from learn pipeline
                callback.metadata.evidence_validation_summary = learn_result.get("validation_report")
                evidence_urls = learn_result.get("evidence_artifact_urls", {})
                callback.metadata.evidence_validation_report_url = evidence_urls.get("evidence_validation.json")
                callback.metadata.evidence_validated_changes_url = evidence_urls.get("validated_changes.json")
                callback.metadata.evidence_rejected_changes_url = evidence_urls.get("rejected_changes.json")
                callback.metadata.no_evidence_count = learn_result.get("no_evidence_count", 0)
            callback.training_blob_url = training_url
            # Publishing gate from learn pipeline
            callback.can_publish = learn_result.get("can_publish", True)
            callback.publishing_blocked_reasons = learn_result.get("publishing_blocked_reasons", [])

            if request.callback_url:
                send_callback(request.callback_url, callback.model_dump())

            total_duration = (datetime.now() - start_time).total_seconds()

            if callback.success:
                logger.info(f"✅ Learn-and-Regenerate completed successfully!")
                logger.info(f"   Output: {callback.filename}")
                logger.info(f"   Version: {callback.version}")
                logger.info(f"   Learning artifacts: {learn_result.get('artifacts_indexed', 0)}")
                logger.info(f"   Duration: {total_duration:.2f} seconds")
                
                track_event("RegeneratorCompleted", {
                    "icf_case_id": icf_case_id,
                    "icfDoc_id": request.document_id,
                    "country": country,
                    "iteration_id": str(request.iteration_id),
                    "version": request.current_version,
                    "artifacts_indexed": str(learn_result.get('artifacts_indexed', 0)),
                    "duration_seconds": str(round(total_duration, 2))
                })

            else:
                logger.error(f"❌ Regeneration phase failed")
                logger.error(f"   Error: {callback.error}")
                
                track_event("RegeneratorFailed", {
                    "icf_case_id": icf_case_id,
                    "icfDoc_id": request.document_id,
                    "country": country,
                    "iteration_id": str(request.iteration_id),
                    "version": request.current_version,
                    "error": str(callback.error)
                })

        except Exception as e:
            error_duration = (datetime.now() - start_time).total_seconds()
            logger.error(f"❌ Learn-and-Regenerate failed after {error_duration:.2f} seconds")
            logger.error(f"   Error: {str(e)}")
            import traceback
            logger.error(f"   Traceback:\n{traceback.format_exc()}")
            
            track_event("RegeneratorFailed", {
                "icf_case_id": icf_case_id,
                "icfDoc_id": request.document_id,
                "country": country,
                "iteration_id": str(request.iteration_id),
                "version": request.current_version,
                "error": str(e),
                "duration_seconds": str(round(error_duration, 2))
            })
            track_exception(e, {
                "icf_case_id": icf_case_id,
                "icfDoc_id": request.document_id,
                "country": country,
                "pipeline": "learn_and_regenerate"
            })

            if request.callback_url:
                send_callback(request.callback_url, {
                    "status": 0,
                    "success": False,
                    "filename": None,
                    "blob_url": None,
                    "icfDoc_id": request.document_id,
                    "icf_case_id": icf_case_id,
                    "version": request.current_version,
                    "error": str(e),
                    "training_blob_url": training_url,
                    "metadata": {
                        "country": country.upper(),
                        "countryid": request.countryid,
                        "iteration_id": request.iteration_id,
                        "artifacts_indexed": learn_result.get("artifacts_indexed", 0) if learn_result else 0,
                        "duration_seconds": error_duration
                    }
                })
        finally:
            if temp_path and os.path.exists(temp_path):
                try:
                    os.remove(temp_path)
                    os.rmdir(os.path.dirname(temp_path))
                except:
                    pass

    # Add background task and return immediately
    background_tasks.add_task(process_regeneration)

    return RegenerateResponse(
        success=True,
        status="processing",
        message=f"Learn-and-Regenerate initiated for {country.upper()} (iteration {request.iteration_id}). Processing in background.",
        document_id=request.document_id,
        country=country.upper(),
        training_url=None
    )


@app.post("/learn-only", status_code=202, response_model=LearnOnlyResponse)
async def learn_only(
    request: LearnOnlyRequest,
    background_tasks: BackgroundTasks
):
    """
    Learn-Only pipeline: extract semantic artifacts from client feedback WITHOUT regeneration.

    - Downloads reviewed document with client comments/track changes
    - Supersedes previous iteration artifacts (handles version conflicts)
    - Extracts semantic changes using LLM analysis
    - Maps to RAG evidence (5 hard gates)
    - Indexes new learning artifacts to Azure AI Search
    - Uploads artifact JSON to blob storage
    - Callbacks to Node.js on completion
    """
    country = request.country_name.lower().replace(' ', '-').replace('_', '-')

    def process_learn_only():
        from services.audit_agent import AuditAgent
        from constants.enums import AuditEventType
        
        logger = get_logger("learn_only")
        logger.setLevel(logging.INFO)
        if not logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter(
                '%(asctime)s [%(levelname)s] %(message)s',
                datefmt='%Y-%m-%d %H:%M:%S'
            )
            handler.setFormatter(formatter)
            logger.addHandler(handler)
        
        # Initialize audit agent
        audit_agent = AuditAgent(
            job_id=request.document_id or request.icf_case_id,
            icf_case_id=request.icf_case_id,
            iteration_id=request.iteration_id,
            correlation_id=None
        )

        start_time = datetime.now()
        temp_path = None

        training_url = None
        base_doc_path = None
        icf_doc_id = request.document_id or request.icf_case_id

        try:
            logger.info(f"📖 Starting Learn-Only pipeline")
            logger.info(f"   ICF Case ID: {request.icf_case_id}")
            logger.info(f"   Country: {country.upper()}")
            logger.info(f"   Iteration: {request.iteration_id}")
            logger.info(f"   Reviewed Doc URL: {request.reviewed_blob_url}")
            
            # Emit LEARNING_STARTED audit event
            audit_agent.emit_event(
                event_type=AuditEventType.LEARNING_STARTED,
                metrics={
                    "country": country.upper(),
                    "countryid": request.countryid,
                    "iteration_id": request.iteration_id
                }
            )
            
            track_event("LearningStarted", {
                "icf_case_id": request.icf_case_id,
                "country": country,
                "iteration_id": str(request.iteration_id)
            })
            temp_path, filename = download_from_blob_url(request.reviewed_blob_url)
            logger.info(f"   ✓ Downloaded reviewed document: {filename}")

            if request.base_blob_url:
                logger.info(f"   Base Doc URL: {request.base_blob_url}")
                base_doc_path, base_filename = download_from_blob_url(request.base_blob_url)
                logger.info(f"   ✓ Downloaded base document v{request.base_version_no}: {base_filename}")

            from services.comment_extractor import CommentExtractor
            extractor = CommentExtractor()
            all_comments = extractor.extract_comments(temp_path)
            client_comments = [c for c in all_comments if c.is_client]
            logger.info(f"   ✓ Extracted {len(client_comments)} client comments")

            comments_for_pipeline = []
            for c in client_comments:
                comments_for_pipeline.append({
                    "text": c.text,
                    "linked_text": c.linked_text,
                    "section_heading": c.section_title or "Unknown",
                    "author": c.author
                })

            pipeline = LearnPipeline(country=country)

            result = pipeline.run_learn_only_pipeline(
                reviewed_path=temp_path,
                icf_case_id=request.icf_case_id,
                iteration_id=request.iteration_id,
                comments=comments_for_pipeline,
                base_doc_path=base_doc_path
            )

            artifacts_payload = build_dpo_override_payload(
                result.get("artifacts", []),
                country=country,
                icf_case_id=request.icf_case_id,
                iteration_id=request.iteration_id,
            )

            total_duration = (datetime.now() - start_time).total_seconds()

            logger.info(f"✅ Learn-Only pipeline completed!")
            logger.info(f"   Artifacts indexed: {result.get('artifacts_indexed', 0)}")
            logger.info(f"   Artifacts superseded: {result.get('artifacts_superseded', 0)}")
            logger.info(f"   Duration: {total_duration:.2f}s")
            
            track_event("LearningCompleted", {
                "icf_case_id": request.icf_case_id,
                "country": country,
                "iteration_id": str(request.iteration_id),
                "artifacts_indexed": str(result.get('artifacts_indexed', 0)),
                "artifacts_superseded": str(result.get('artifacts_superseded', 0)),
                "duration_seconds": str(round(total_duration, 2))
            })
            
            # Emit LEARNING_COMPLETED audit event
            audit_agent.emit_event(
                event_type=AuditEventType.LEARNING_COMPLETED,
                metrics={
                    "artifacts_indexed": result.get('artifacts_indexed', 0),
                    "artifacts_superseded": result.get('artifacts_superseded', 0),
                    "duration_seconds": round(total_duration, 2),
                    "track_changes_extracted": result.get("track_changes_extracted", 0),
                    "comments_extracted": result.get("comments_extracted", 0)
                }
            )
            
            # Upload audit snapshot to blob
            try:
                audit_snapshot = audit_agent.generate_audit_snapshot(workflow_type="learning")
                if audit_snapshot:
                    from azure.storage.blob import BlobServiceClient, ContentSettings
                    conn_str = Config.AZURE_STORAGE_CONNECTION_STRING
                    container_name = Config.AZURE_STORAGE_CONTAINER_NAME
                    if conn_str:
                        blob_path = f"cases/{request.icf_case_id}/iterations/iter_{request.iteration_id}/audit_snapshot.json"
                        blob_service = BlobServiceClient.from_connection_string(conn_str)
                        blob_client = blob_service.get_blob_client(container=container_name, blob=blob_path)
                        json_content = json.dumps(audit_snapshot, indent=2, default=str)
                        blob_client.upload_blob(
                            json_content, overwrite=True,
                            content_settings=ContentSettings(content_type="application/json"),
                        )
                        logger.info(f"   ✓ Uploaded audit_snapshot: {blob_path}")
            except Exception as upload_err:
                logger.warning(f"   ⚠️ Audit snapshot upload failed: {upload_err}")
            
            try:
                dpo_generator = DPOTrainingGenerator(country=country)
                dpo_result = dpo_generator.generate_training_dataset(
                    icf_case_id=request.icf_case_id,
                    iteration_id=request.iteration_id,
                    include_superseded=False,
                    artifacts_override=artifacts_payload
                )
                training_url = dpo_result.get("blob_url")
                if training_url:
                    logger.info(f"   ✓ DPO training JSONL updated: {training_url}")
            except Exception as dpo_error:
                logger.warning(f"   ⚠️ DPO JSONL generation skipped: {dpo_error}")


            if request.callback_url:
                callback_payload = {
                    "status": 2 if result.get("success") else 0,
                    "success": result.get("success", False),
                    "icfDoc_id": icf_doc_id,
                    "icf_case_id": request.icf_case_id,
                    "country": country.upper(),
                    "countryid": request.countryid,
                    "iteration_id": request.iteration_id,
                    "artifacts_count": len(result.get("artifacts", [])),
                    "artifacts_indexed": result.get("artifacts_indexed", 0),
                    "artifacts_superseded": result.get("artifacts_superseded", 0),
                    "artifact_blob_url": result.get("artifact_blob_url"),
                    "training_blob_url": training_url,
                    "error": None,
                    "metadata": {
                        "track_changes_extracted": result.get("track_changes_extracted", 0),
                        "comments_extracted": result.get("comments_extracted", 0),
                        "intent_count": result.get("intent_count", 0),
                        "instruction_count": result.get("instruction_count", 0),
                        "duration_seconds": total_duration
                    },
                    "audit_events": audit_agent.get_events()
                }
                send_callback(request.callback_url, callback_payload)
                logger.info(f"   ✓ Callback sent to {request.callback_url}")
                
        except Exception as e:
            error_duration = (datetime.now() - start_time).total_seconds()
            logger.error(f"❌ Learn-Only failed after {error_duration:.2f}s: {e}")
            import traceback
            logger.error(traceback.format_exc())
            
            # Emit LEARNING_FAILED audit event
            audit_agent.emit_event(
                event_type=AuditEventType.LEARNING_FAILED,
                metrics={"error": str(e), "duration_seconds": round(error_duration, 2)}
            )
            
            # Upload audit snapshot to blob (even for failures)
            try:
                audit_snapshot = audit_agent.generate_audit_snapshot(workflow_type="learning")
                if audit_snapshot:
                    from azure.storage.blob import BlobServiceClient, ContentSettings
                    conn_str = Config.AZURE_STORAGE_CONNECTION_STRING
                    container_name = Config.AZURE_STORAGE_CONTAINER_NAME
                    if conn_str:
                        blob_path = f"cases/{request.icf_case_id}/iterations/iter_{request.iteration_id}/audit_snapshot.json"
                        blob_service = BlobServiceClient.from_connection_string(conn_str)
                        blob_client = blob_service.get_blob_client(container=container_name, blob=blob_path)
                        json_content = json.dumps(audit_snapshot, indent=2, default=str)
                        blob_client.upload_blob(
                            json_content, overwrite=True,
                            content_settings=ContentSettings(content_type="application/json"),
                        )
                        logger.info(f"   ✓ Uploaded audit_snapshot (failed): {blob_path}")
            except Exception as upload_err:
                logger.warning(f"   ⚠️ Audit snapshot upload failed: {upload_err}")
            
            track_event("LearningFailed", {
                "icf_case_id": request.icf_case_id,
                "country": country,
                "iteration_id": str(request.iteration_id),
                "error": str(e),
                "duration_seconds": str(round(error_duration, 2))
            })
            track_exception(e, {
                "icf_case_id": request.icf_case_id,
                "country": country,
                "pipeline": "learn_only"
            })

            if request.callback_url:
                send_callback(request.callback_url, {
                    "status": 0,
                        "success": False,
                    "icfDoc_id": icf_doc_id,
                    "icf_case_id": request.icf_case_id,
                    "country": country.upper(),
                    "countryid": request.countryid,
                    "iteration_id": request.iteration_id,
                    "artifacts_count": 0,
                    "artifacts_indexed": 0,
                    "artifacts_superseded": 0,
                    "artifact_blob_url": None,
                    "training_blob_url": training_url,
                        "error": str(e),
                    "metadata": {"duration_seconds": error_duration},
                    "audit_events": audit_agent.get_events()
                })
        finally:
            if temp_path and os.path.exists(temp_path):
                try:
                    os.remove(temp_path)
                    os.rmdir(os.path.dirname(temp_path))
                except:
                    pass
            if base_doc_path and os.path.exists(base_doc_path):
                try:
                    os.remove(base_doc_path)
                    os.rmdir(os.path.dirname(base_doc_path))
                except:
                    pass

    background_tasks.add_task(process_learn_only)

    return LearnOnlyResponse(
        success=True,
        status="processing",
        message=f"Learn-Only pipeline initiated for {country.upper()} (iteration {request.iteration_id}). Processing in background.",
        icf_case_id=request.icf_case_id,
        country=country.upper(),
        iteration_id=request.iteration_id,
        training_url=None
    )


@app.get("/comment-preview/{document_id}")
async def get_comment_preview(document_id: str, blob_url: str):
    """
    Get a preview of comments in a reviewed document.
    Useful for UI to show what will be processed before regeneration.
    """
    try:
        workflow = HumanReviewWorkflow()
        summary = workflow.get_comment_preview(blob_url)
        
        return {
            "document_id": document_id,
            "blob_url": blob_url,
            "summary": summary
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# =============================================================================
# UTILITY ENDPOINTS
# =============================================================================

@app.get("/document-status/{document_id}")
async def document_status(document_id: str):
    """Check if a Global ICF document has been indexed."""
    try:
        # Use any country's RAG store to check sections index
        rag = GeneratorKnowledgeStore(country="usa", auto_sync=False)
        is_indexed = rag.check_document_indexed(document_id)
        
        sections = []
        if is_indexed:
            sections = rag.get_global_icf_sections(document_id)
        
        return {
            "document_id": document_id,
            "is_indexed": is_indexed,
            "sections_count": len(sections),
            "index_name": "icf-sections-index"
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/countries")
async def list_countries():
    """List available countries from blob storage."""
    try:
        indexer = MultiCountryIndexer()
        countries = indexer.get_available_countries()
        
        # Add countryid for each
        country_list = []
        for country in countries:
            countryid = indexer._get_countryid(country)
            country_list.append({
                "name": country,
                "code": country.lower().replace(' ', '-'),
                "countryid": countryid
            })
        
        return {
            "countries": country_list,
            "count": len(country_list)
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/index-status/{country}")
async def index_status(country: str):
    """Check index status for a country."""
    try:
        country_code = country.lower().replace(' ', '-').replace('_', '-')
        
        rag = GeneratorKnowledgeStore(country=country_code, auto_sync=False)
        status = rag.check_sync_status()
        
        return status
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# =============================================================================
# GUARDRAILS (Story 827607)
# =============================================================================

class ChangeBudgetRequest(BaseModel):
    icfCaseId: str
    baseVersionNo: int
    plannedVersionNo: int
    changePlanBlobUrl: Optional[str] = None
    changePlan: Optional[dict] = None
    baseWordCount: int = 5000


@app.post("/agent/guardrails/change-budget")
async def change_budget_guardrail(req: ChangeBudgetRequest):
    """
    Evaluate Regeneration Change Plan against budget (Story 827607).
    Returns PASSED or FAILED; when FAILED and hardFailOnExceed, regeneration must not run.
    """
    from services.change_budget_gate import ChangeBudgetGate
    gate = ChangeBudgetGate()
    plan = None
    if req.changePlan:
        plan = req.changePlan
    elif req.changePlanBlobUrl:
        plan = gate._load_plan(req.changePlanBlobUrl)
    if not plan:
        raise HTTPException(status_code=400, detail="Provide changePlanBlobUrl or changePlan")
    result, passed = gate.evaluate(plan, base_word_count=req.baseWordCount)
    blob_url = gate.upload_eval(result, req.icfCaseId, req.plannedVersionNo)
    result["blobUrl"] = blob_url
    if passed:
        return {"status": "PASSED", "estimatedDiffPercent": result["measured"]["estimatedDiffPercent"], "sectionsChanged": result["measured"]["sectionsChanged"], "result": result}
    return {"status": "FAILED", "failureReasons": result["failureReasons"], "result": result}


# =============================================================================
# EVIDENCE VALIDATOR (Story 827628)
# =============================================================================

class ValidateEvidenceRequest(BaseModel):
    icfCaseId: str
    countryCode: str = "usa"
    baseVersionNo: int = 1
    proposedChanges: list
    allowedSources: Optional[list] = None
    minRelevance: float = 0.70
    versionNo: Optional[int] = None


@app.post("/internal/validate-evidence")
async def validate_evidence(req: ValidateEvidenceRequest):
    """Validate proposed changes have evidence (Story 827628). Anti-hallucination gate."""
    from services.evidence_validator import EvidenceValidatorAgent
    validator = EvidenceValidatorAgent(country=req.countryCode)
    report = validator.validate(
        req.proposedChanges,
        min_relevance=req.minRelevance,
        allowed_sources=req.allowedSources,
    )
    version_no = req.versionNo or req.baseVersionNo + 1
    blob_url = validator.upload_report(report, req.icfCaseId, version_no)
    report["reportUrl"] = blob_url
    return report


# =============================================================================
# STARTUP AND SHUTDOWN EVENTS
# =============================================================================

@app.on_event("startup")
async def startup_event():
    """Run warm-up service and start Service Bus consumer on application startup."""
    def _startup_log(msg: str, level: str = "info", exc_info: bool = False):
        try:
            _log = get_logger("startup")
            if level == "error" and exc_info:
                _log.error(msg, exc_info=True)
            else:
                getattr(_log, level)(msg)
        except Exception:
            print(f"[startup] {msg}")

    try:
        stats = await warmup_service.warmup()
        _startup_log(f"Application startup complete. Warm-up stats: {stats}")
        track_event("AppStarted", {"status": "healthy"})
    except Exception as e:
        _startup_log(f"Warm-up failed: {e}", "error", exc_info=True)
        track_event("AppStarted", {"status": "warmup_failed", "error": str(e)})
        # Don't fail startup if warm-up fails
        pass

    # Start Service Bus consumer if enabled via SERVICE_BUS_ENABLED=true
    if Config.SERVICE_BUS_ENABLED:
        try:
            from services.service_bus_consumer import start_consumer
            start_consumer()
            logging.info("Service Bus consumer started (SERVICE_BUS_ENABLED=true)")
        except Exception as e:
            logging.error(f"Service Bus consumer failed to start: {e}", exc_info=True)
    else:
        logging.info("Service Bus disabled (SERVICE_BUS_ENABLED=false), using HTTP endpoints only")


@app.on_event("shutdown")
async def shutdown_event():
    """Stop Service Bus consumer on application shutdown."""
    if Config.SERVICE_BUS_ENABLED:
        try:
            from services.service_bus_consumer import stop_consumer
            stop_consumer()
            logging.info("Service Bus consumer stopped")
        except Exception as e:
            logging.error(f"Service Bus consumer shutdown error: {e}", exc_info=True)

# =============================================================================
# MAIN
# =============================================================================

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=5000)