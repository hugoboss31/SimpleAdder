"""
Learning Models for Learn Pipeline.
Dataclasses for semantic extraction, preference pairs, and publishing metrics.
"""

import os
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Any
from datetime import datetime


@dataclass
class RawDelta:
    """Raw track change extracted from document."""
    delta_id: str
    change_type: str  # INSERT, DELETE, REPLACE
    original_text: str
    modified_text: str
    paragraph_id: str
    section_id: Optional[str] = None
    section_title: Optional[str] = None
    author: str = ""
    date: str = ""


@dataclass
class SemanticChange:
    """Classified semantic change with intent and confidence."""
    change_id: str
    source: str  # "track_change" | "comment"
    section_id: str
    section_title: str
    change_type: str  # terminology | tone | legal | structural | content_addition | content_removal
    original_text: str
    modified_text: str
    intent: str
    confidence: float
    priority: int = 3  # 1-5 scale (1=highest, 5=lowest)
    is_learning_candidate: bool = False
    rag_reference: Optional[str] = None
    rag_ids_used: List[str] = field(default_factory=list)
    evidence_found: bool = False
    evidence_relevance: float = 0.0  # Highest relevance score from evidence
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "change_id": self.change_id,
            "source": self.source,
            "section_id": self.section_id,
            "section_title": self.section_title,
            "change_type": self.change_type,
            "original_text": self.original_text,
            "modified_text": self.modified_text,
            "intent": self.intent,
            "confidence": self.confidence,
            "priority": self.priority,
            "is_learning_candidate": self.is_learning_candidate,
            "rag_reference": self.rag_reference,
            "rag_ids_used": self.rag_ids_used,
            "evidence_relevance": self.evidence_relevance,
            "evidence_found": self.evidence_found
        }


@dataclass
class DPOPreferencePair:
    """Preference pair for Learn Pipeline training with versioning support."""
    pair_id: str
    country: str
    section_type: str
    ai_output: str  # rejected (original AI text)
    human_output: str  # preferred (client-corrected text)
    context: str  # surrounding paragraph
    intent: str = ""  # LLM-extracted intent
    confidence: float = 0.0
    priority: int = 3  # 1-5 scale (1=highest, 5=lowest)
    source_document_id: str = ""
    evidence_ids: List[str] = field(default_factory=list)  # RAG chunk IDs (relevance >= 0.7)
    version: int = 1
    # Versioning fields for conflict resolution
    icf_case_id: str = ""  # ICF case identifier
    iteration_id: int = 1  # Feedback iteration number (1, 2, 3...)
    is_superseded: bool = False  # True if newer iteration replaces this artifact
    superseded_by: Optional[str] = None  # ID of the artifact that superseded this one
    created_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    embedding: Optional[List[float]] = None
    
    def to_index_doc(self) -> Dict[str, Any]:
        """Convert to Azure AI Search document format."""
        return {
            "id": self.pair_id,
            "country": self.country,
            "section_type": self.section_type,
            "ai_output": self.ai_output,
            "human_output": self.human_output,
            "context": self.context,
            "intent": self.intent,
            "confidence": self.confidence,
            "priority": self.priority,
            "source_document_id": self.source_document_id,
            "evidence_ids": self.evidence_ids,
            "version": self.version,
            "icf_case_id": self.icf_case_id,
            "iteration_id": self.iteration_id,
            "is_superseded": self.is_superseded,
            "superseded_by": self.superseded_by,
            "created_at": self.created_at,
            "embedding": self.embedding
        }


@dataclass
class PublishingMetrics:
    """Metrics for publishing gate validation."""
    diff_percent: float = 0.0
    sections_changed: int = 0
    added_count: int = 0
    removed_count: int = 0
    modified_count: int = 0
    no_evidence_count: int = 0
    avg_confidence: float = 0.0
    artifacts_indexed: int = 0
    total_changes: int = 0
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "diff_percent": round(self.diff_percent, 2),
            "sections_changed": self.sections_changed,
            "added_count": self.added_count,
            "removed_count": self.removed_count,
            "modified_count": self.modified_count,
            "no_evidence_count": self.no_evidence_count,
            "avg_confidence": round(self.avg_confidence, 2),
            "artifacts_indexed": self.artifacts_indexed,
            "total_changes": self.total_changes
        }


@dataclass
class PublishingGateResult:
    """Result of publishing gate validation."""
    can_publish: bool
    rejection_reasons: List[str] = field(default_factory=list)
    metrics: Optional[PublishingMetrics] = None
    validation_report: Optional[Dict[str, Any]] = None
    evidence_artifact_urls: Dict[str, str] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "can_publish": self.can_publish,
            "rejection_reasons": self.rejection_reasons,
            "metrics": self.metrics.to_dict() if self.metrics else None,
            "validation_report": self.validation_report,
            "evidence_artifact_urls": self.evidence_artifact_urls
        }


# Publishing rules configuration (configurable via env: MAX_DIFF_PERCENT, MAX_SECTIONS_CHANGED)
def _get_publishing_rules() -> Dict[str, Any]:
    max_diff = os.getenv("MAX_DIFF_PERCENT")
    max_sections = os.getenv("MAX_SECTIONS_CHANGED")
    return {
        "max_diff_percent": float(max_diff) if max_diff is not None else 5.0,
        "max_sections_changed": int(max_sections) if max_sections is not None else 10,
        "min_confidence": 0.0,  # 0.7
        "require_evidence": True
    }


PUBLISHING_RULES = _get_publishing_rules()

# Change type classifications
CHANGE_TYPES = [
    "terminology_replacement",
    "tone_adjustment",
    "legal_strengthening",
    "content_addition",
    "content_removal",
    "structural_change"
]