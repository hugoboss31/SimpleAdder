"""
Warm-up Service for Pre-computation and Cache Warming.
Pre-loads common country indexes, pre-computes embeddings, and warms cache on startup.
"""

import os
import logging
from typing import List, Optional
from dotenv import load_dotenv

load_dotenv()

logger = logging.getLogger(__name__)


class WarmupService:
    """Service to warm up the system on startup."""
    
    # Common countries to pre-load
    COMMON_COUNTRIES = ["usa", "canada"]
    
    # Common section embeddings to pre-compute
    COMMON_SECTIONS = [
        "compensation payment reimbursement",
        "insurance indemnity liability",
        "data protection privacy",
        "contact information investigator",
        "risks side effects adverse events",
        "benefits direct indirect",
        "voluntary participation withdrawal",
        "consent form signature",
    ]
    
    # Common RAG queries to warm cache
    COMMON_RAG_QUERIES = [
        "format language document standards",
        "footer pagination header requirements",
        "compensation payment reimbursement travel expenses",
        "insurance indemnity liability coverage",
        "contact information investigator ethics committee",
        "data protection privacy authorization",
        "risks side effects adverse events",
        "benefits direct indirect potential",
        "voluntary participation withdrawal rights",
        "consent form signature witness requirements",
    ]
    
    def __init__(self, enabled: bool = True):
        """
        Initialize warm-up service.
        
        Args:
            enabled: If False, warm-up will be skipped
        """
        self.enabled = enabled and os.getenv("WARMUP_ENABLED", "true").lower() == "true"
        if not self.enabled:
            logger.info("Warm-up service is disabled")
    
    async def warmup(self) -> dict:
        """
        Perform warm-up operations.
        
        Returns:
            dict with warm-up statistics
        """
        if not self.enabled:
            return {"enabled": False, "message": "Warm-up disabled"}
        
        logger.info("🔥 Starting warm-up service...")
        stats = {
            "enabled": True,
            "indexes_loaded": 0,
            "embeddings_computed": 0,
            "rag_queries_warmed": 0,
            "errors": []
        }
        
        try:
            # 1. Pre-load common country indexes
            stats["indexes_loaded"] = await self._warmup_indexes()
            
            # 2. Pre-compute common embeddings
            stats["embeddings_computed"] = await self._warmup_embeddings()
            
            # 3. Warm RAG query cache
            stats["rag_queries_warmed"] = await self._warmup_rag_queries()
            
            logger.info(f"✅ Warm-up completed: {stats}")
        except Exception as e:
            error_msg = f"Warm-up error: {str(e)}"
            logger.error(error_msg, exc_info=True)
            stats["errors"].append(error_msg)
        
        return stats
    
    async def _warmup_indexes(self) -> int:
        """Pre-load common country indexes."""
        logger.info("  📚 Pre-loading country indexes...")
        loaded = 0
        
        try:
            from services.generator_knowledge_store import GeneratorKnowledgeStore
            
            for country in self.COMMON_COUNTRIES:
                try:
                    # Initialize knowledge store (this loads the index)
                    store = GeneratorKnowledgeStore(country, auto_sync=False)
                    # Perform a simple query to ensure index is loaded
                    results = store.query_regulations("test", top_k=1)
                    loaded += 1
                    logger.info(f"    ✓ Loaded index for {country}")
                except Exception as e:
                    logger.warning(f"    ⚠️ Failed to load index for {country}: {e}")
                    continue
        
        except Exception as e:
            logger.error(f"  ⚠️ Error pre-loading indexes: {e}")
        
        return loaded
    
    async def _warmup_embeddings(self) -> int:
        """Pre-compute embeddings for common sections."""
        logger.info("  🧮 Pre-computing embeddings...")
        computed = 0
        
        try:
            from services.generator_knowledge_store import GeneratorKnowledgeStore
            from utils import cache
            
            # Use USA as default country for embedding warm-up
            store = GeneratorKnowledgeStore("usa", auto_sync=False)
            
            for section_text in self.COMMON_SECTIONS:
                try:
                    # Check if already cached
                    cached = cache.get_embedding(section_text)
                    if cached:
                        continue
                    
                    # Generate embedding (will be cached automatically)
                    embedding = store._embed(section_text)
                    if embedding and len(embedding) > 0:
                        computed += 1
                        logger.debug(f"    ✓ Computed embedding for: {section_text[:50]}")
                except Exception as e:
                    logger.warning(f"    ⚠️ Failed to compute embedding: {e}")
                    continue
        
        except Exception as e:
            logger.error(f"  ⚠️ Error pre-computing embeddings: {e}")
        
        return computed
    
    async def _warmup_rag_queries(self) -> int:
        """Warm RAG query cache with common queries."""
        logger.info("  🔍 Warming RAG query cache...")
        warmed = 0
        
        try:
            from services.generator_knowledge_store import GeneratorKnowledgeStore
            
            # Warm queries for common countries
            for country in self.COMMON_COUNTRIES:
                try:
                    store = GeneratorKnowledgeStore(country, auto_sync=False)
                    
                    for query in self.COMMON_RAG_QUERIES:
                        try:
                            # Execute query (will be cached automatically)
                            results = store.query_regulations(query, top_k=3)
                            if results:
                                warmed += 1
                                logger.debug(f"    ✓ Warmed query for {country}: {query[:50]}")
                        except Exception as e:
                            logger.debug(f"    ⚠️ Query failed: {query[:50]}")
                            continue
                
                except Exception as e:
                    logger.warning(f"    ⚠️ Failed to warm queries for {country}: {e}")
                    continue
        
        except Exception as e:
            logger.error(f"  ⚠️ Error warming RAG queries: {e}")
        
        return warmed


# Global warm-up service instance
warmup_service = WarmupService()
