# PowerShell script to start all ICF POC services
# Make sure you have:
# 1. Node.js installed
# 2. Python 3.x with venv activated
# 3. Environment variables configured (.env files)

Write-Host "🚀 Starting ICF POC Services..." -ForegroundColor Green
Write-Host ""

# Check if services are already running
$backendRunning = Test-NetConnection -ComputerName localhost -Port 5001 -InformationLevel Quiet -WarningAction SilentlyContinue
$agentRunning = Test-NetConnection -ComputerName localhost -Port 8000 -InformationLevel Quiet -WarningAction SilentlyContinue
$webRunning = Test-NetConnection -ComputerName localhost -Port 5173 -InformationLevel Quiet -WarningAction SilentlyContinue

if ($backendRunning) {
    Write-Host "⚠️  Backend is already running on port 5001" -ForegroundColor Yellow
} else {
    Write-Host "📦 Starting Backend (Node.js) on port 5001..." -ForegroundColor Cyan
    Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd '$PSScriptRoot\icf-backend'; npm run dev" -WindowStyle Normal
    Start-Sleep -Seconds 3
}

if ($agentRunning) {
    Write-Host "⚠️  Agent service is already running on port 8000" -ForegroundColor Yellow
} else {
    Write-Host "🐍 Starting Agent Service (Python/FastAPI) on port 8000..." -ForegroundColor Cyan
    Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd '$PSScriptRoot\icf-agent'; .\venv\Scripts\Activate.ps1; python app.py" -WindowStyle Normal
    Start-Sleep -Seconds 3
}

if ($webRunning) {
    Write-Host "⚠️  Web app is already running on port 5173" -ForegroundColor Yellow
} else {
    Write-Host "🌐 Starting Web App (React) on port 5173..." -ForegroundColor Cyan
    Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd '$PSScriptRoot\icf-web'; `$env:VITE_API_BASE_URL='http://localhost:5001/api'; npm run dev" -WindowStyle Normal
    Start-Sleep -Seconds 3
}

Write-Host ""
Write-Host "✅ All services starting..." -ForegroundColor Green
Write-Host ""
Write-Host "📍 Service URLs:" -ForegroundColor Yellow
Write-Host "   Backend API:  http://localhost:5001/api" -ForegroundColor White
Write-Host "   Agent API:    http://localhost:8000" -ForegroundColor White
Write-Host "   Web App:      http://localhost:5173" -ForegroundColor White
Write-Host ""
Write-Host "⏳ Waiting for services to initialize..." -ForegroundColor Cyan
Start-Sleep -Seconds 5

# Check if services are up
Write-Host ""
Write-Host "🔍 Checking service health..." -ForegroundColor Cyan

try {
    $backendHealth = Invoke-WebRequest -Uri "http://localhost:5001/api/health" -UseBasicParsing -TimeoutSec 2 -ErrorAction SilentlyContinue
    if ($backendHealth.StatusCode -eq 200) {
        Write-Host "✅ Backend is healthy" -ForegroundColor Green
    }
} catch {
    Write-Host "⚠️  Backend not responding yet" -ForegroundColor Yellow
}

try {
    $agentHealth = Invoke-WebRequest -Uri "http://localhost:8000/" -UseBasicParsing -TimeoutSec 2 -ErrorAction SilentlyContinue
    if ($agentHealth.StatusCode -eq 200) {
        Write-Host "✅ Agent service is healthy" -ForegroundColor Green
    }
} catch {
    Write-Host "⚠️  Agent service not responding yet" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "🎉 Setup complete! Open http://localhost:5173 in your browser" -ForegroundColor Green
Write-Host ""
Write-Host "💡 Note: Make sure you have configured environment variables:" -ForegroundColor Cyan
Write-Host "   - Backend: DATABASE_URL, AZURE_STORAGE_CONNECTION_STRING, etc." -ForegroundColor White
Write-Host "   - Agent: AZURE_OPENAI_*, AZURE_STORAGE_*, etc." -ForegroundColor White
Write-Host ""
Write-Host "Press any key to exit..." -ForegroundColor Gray
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")

