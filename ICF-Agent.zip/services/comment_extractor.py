"""
Comment Extractor for Human Review Agent.
Parses DOCX files to extract comments with their linked text ranges using OpenXML.
Identifies client vs agent comments based on author signatures.
"""

import os
import zipfile
import shutil
from typing import List, Dict, Optional
from lxml import etree
from dataclasses import asdict

from models.models import ParsedComment, AGENT_AUTHORS

# XML Namespaces
W_NS = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
W = '{%s}' % W_NS


class CommentExtractor:
    """
    Extracts comments from DOCX files with their linked text.
    Uses OpenXML parsing to identify commentRangeStart/End markers.
    """
    
    def __init__(self):
        print("✅ Comment Extractor initialized")
    
    def extract_comments(self, docx_path: str) -> List[ParsedComment]:
        """
        Extract all comments from a DOCX file with their linked text.
        
        Args:
            docx_path: Path to the DOCX file
            
        Returns:
            List of ParsedComment objects with comment text and linked text ranges
        """
        temp_dir = docx_path + "_comment_extract_temp"
        parsed_comments = []
        
        try:
            if os.path.exists(temp_dir):
                shutil.rmtree(temp_dir)
            
            with zipfile.ZipFile(docx_path, 'r') as zip_ref:
                zip_ref.extractall(temp_dir)
            
            # Parse comments.xml if exists
            comments_path = os.path.join(temp_dir, "word", "comments.xml")
            if not os.path.exists(comments_path):
                print("  ℹ️ No comments found in document")
                return []
            
            # Load comments
            parser = etree.XMLParser(remove_blank_text=False)
            comments_tree = etree.parse(comments_path, parser)
            comments_root = comments_tree.getroot()
            
            # Build comment ID -> comment data mapping
            comment_map = self._parse_comments_xml(comments_root)
            
            # Parse document.xml to find comment ranges and linked text
            doc_xml_path = os.path.join(temp_dir, "word", "document.xml")
            doc_tree = etree.parse(doc_xml_path, parser)
            doc_root = doc_tree.getroot()
            
            # Find linked text for each comment
            linked_texts = self._extract_comment_linked_texts(doc_root)
            
            # Build final parsed comments
            for comment_id, comment_data in comment_map.items():
                linked_info = linked_texts.get(comment_id, {})
                
                parsed_comment = ParsedComment(
                    comment_id=comment_id,
                    author=comment_data['author'],
                    date=comment_data['date'],
                    text=comment_data['text'],
                    linked_text=linked_info.get('text', ''),
                    paragraph_index=linked_info.get('paragraph_index', -1),
                    is_client=comment_data['is_client'],
                    section_id=None,
                    section_title=None
                )
                parsed_comments.append(parsed_comment)
            
            client_count = sum(1 for c in parsed_comments if c.is_client)
            print(f"  ✓ Extracted {len(parsed_comments)} comments ({client_count} from clients)")
            
        except Exception as e:
            print(f"⚠️ Comment extraction failed: {e}")
            import traceback
            traceback.print_exc()
        finally:
            if os.path.exists(temp_dir):
                shutil.rmtree(temp_dir)
        
        return parsed_comments
    
    def _parse_comments_xml(self, comments_root) -> Dict[str, Dict]:
        """
        Parse comments.xml to extract comment metadata.
        
        Returns:
            Dict mapping comment_id -> {author, date, text, is_client}
        """
        comment_map = {}
        
        for comment_elem in comments_root.iter(W + 'comment'):
            comment_id = comment_elem.get(W + 'id')
            author = comment_elem.get(W + 'author', 'Unknown')
            date = comment_elem.get(W + 'date', '')
            
            # Extract comment text from all text elements
            comment_text_parts = []
            for t_elem in comment_elem.iter(W + 't'):
                if t_elem.text:
                    comment_text_parts.append(t_elem.text)
            comment_text = ''.join(comment_text_parts)
            
            # Determine if client or agent based on author
            is_client = author not in AGENT_AUTHORS
            
            comment_map[comment_id] = {
                'author': author,
                'date': date,
                'text': comment_text,
                'is_client': is_client
            }
        
        return comment_map
    
    def _extract_comment_linked_texts(self, doc_root) -> Dict[str, Dict]:
        """
        Extract the text that each comment is linked to using commentRangeStart/End.
        
        Args:
            doc_root: Parsed document.xml root element
            
        Returns:
            Dict mapping comment_id -> {'text': linked_text, 'paragraph_index': idx}
        """
        linked_texts = {}
        
        # Track active comment ranges
        active_ranges: Dict[str, List[str]] = {}  # comment_id -> list of text parts
        active_para_idx: Dict[str, int] = {}  # comment_id -> paragraph index where it started
        
        body = doc_root.find('.//' + W + 'body')
        if body is None:
            return linked_texts
        
        paragraphs = list(body.iter(W + 'p'))
        
        for para_idx, para in enumerate(paragraphs):
            # Process all elements in order within the paragraph
            for elem in para.iter():
                # Comment range start
                if elem.tag == W + 'commentRangeStart':
                    comment_id = elem.get(W + 'id')
                    if comment_id:
                        active_ranges[comment_id] = []
                        active_para_idx[comment_id] = para_idx
                
                # Text element - add to all active ranges
                elif elem.tag == W + 't' and elem.text:
                    for comment_id in active_ranges:
                        active_ranges[comment_id].append(elem.text)
                
                # Comment range end
                elif elem.tag == W + 'commentRangeEnd':
                    comment_id = elem.get(W + 'id')
                    if comment_id and comment_id in active_ranges:
                        linked_text = ''.join(active_ranges[comment_id])
                        linked_texts[comment_id] = {
                            'text': linked_text,
                            'paragraph_index': active_para_idx.get(comment_id, para_idx)
                        }
                        del active_ranges[comment_id]
                        if comment_id in active_para_idx:
                            del active_para_idx[comment_id]
        
        return linked_texts
    
    def get_client_comments(self, docx_path: str) -> List[ParsedComment]:
        """
        Extract only client comments (not agent comments) from document.
        
        Args:
            docx_path: Path to the DOCX file
            
        Returns:
            List of ParsedComment objects from clients only
        """
        all_comments = self.extract_comments(docx_path)
        return [c for c in all_comments if c.is_client]
    
    def get_agent_comments(self, docx_path: str) -> List[ParsedComment]:
        """
        Extract only agent comments from document.
        
        Args:
            docx_path: Path to the DOCX file
            
        Returns:
            List of ParsedComment objects from agents only
        """
        all_comments = self.extract_comments(docx_path)
        return [c for c in all_comments if not c.is_client]
    
    def has_client_comments(self, docx_path: str) -> bool:
        """
        Check if document has any client comments.
        
        Args:
            docx_path: Path to the DOCX file
            
        Returns:
            True if document has client comments
        """
        client_comments = self.get_client_comments(docx_path)
        return len(client_comments) > 0
    
    def has_client_track_changes(self, docx_path: str) -> bool:
        """
        Check if document has track changes made by clients (not agents).
        
        Args:
            docx_path: Path to the DOCX file
            
        Returns:
            True if client made manual track changes
        """
        temp_dir = docx_path + "_track_check_temp"
        
        try:
            if os.path.exists(temp_dir):
                shutil.rmtree(temp_dir)
            
            with zipfile.ZipFile(docx_path, 'r') as zip_ref:
                zip_ref.extractall(temp_dir)
            
            doc_xml_path = os.path.join(temp_dir, "word", "document.xml")
            parser = etree.XMLParser(remove_blank_text=False)
            tree = etree.parse(doc_xml_path, parser)
            root = tree.getroot()
            
            # Check for insertions and deletions by non-agent authors
            for elem in root.iter():
                if elem.tag in [W + 'ins', W + 'del']:
                    author = elem.get(W + 'author', '')
                    if author and author not in AGENT_AUTHORS:
                        return True
            
            return False
            
        except Exception as e:
            print(f"⚠️ Track change check failed: {e}")
            return False
        finally:
            if os.path.exists(temp_dir):
                shutil.rmtree(temp_dir)
    
    def get_comment_summary(self, docx_path: str) -> Dict[str, any]:
        """
        Get a summary of comments in the document.
        
        Args:
            docx_path: Path to the DOCX file
            
        Returns:
            Summary dict with counts and details
        """
        all_comments = self.extract_comments(docx_path)
        client_comments = [c for c in all_comments if c.is_client]
        agent_comments = [c for c in all_comments if not c.is_client]
        has_track_changes = self.has_client_track_changes(docx_path)
        
        return {
            'total_comments': len(all_comments),
            'client_comments': len(client_comments),
            'agent_comments': len(agent_comments),
            'has_client_track_changes': has_track_changes,
            'client_authors': list(set(c.author for c in client_comments)),
            'agent_authors': list(set(c.author for c in agent_comments))
        }
    
    def link_comments_to_sections(
        self,
        comments: List[ParsedComment],
        section_map: Dict[int, Dict[str, str]]
    ) -> List[ParsedComment]:
        """
        Link parsed comments to their corresponding sections using paragraph index.
        
        Args:
            comments: List of parsed comments
            section_map: Dict mapping paragraph_index -> {section_id, section_title}
        
        Returns:
            Updated comments with section_id and section_title populated
        """
        for comment in comments:
            para_idx = comment.paragraph_index
            
            if para_idx < 0:
                continue
            
            # Find the section this paragraph belongs to
            # Look for the highest section start index that is <= para_idx
            best_section = None
            best_section_start = -1
            
            for section_start, section_info in section_map.items():
                if section_start <= para_idx and section_start > best_section_start:
                    best_section = section_info
                    best_section_start = section_start
            
            if best_section:
                comment.section_id = best_section.get('section_id')
                comment.section_title = best_section.get('section_title')
        
        return comments