"""AI Search index manager for Checklist validation."""

import os
from typing import Optional
from azure.search.documents.indexes import SearchIndexClient
from azure.search.documents.indexes.models import (
    SearchIndex,
    SearchField,
    SearchFieldDataType,
    VectorSearch,
    HnswAlgorithmConfiguration,
    VectorSearchProfile
)
from azure.core.credentials import AzureKeyCredential
from dotenv import load_dotenv

load_dotenv()


class ChecklistIndexManager:
    """Manages the AI Search index for checklist items."""
    
    def __init__(self, index_name: Optional[str] = None):
        """
        Initialize the checklist index manager.
        
        Args:
            index_name: Name of the index (defaults to env var or "icf-checklist-index")
        """
        from config import config
        
        self.search_endpoint = config.get_search_endpoint()
        self.search_key = config.get_search_key()
        self.index_name = index_name or config.CHECKLIST_INDEX_NAME
        
        if not all([self.search_endpoint, self.search_key]):
            raise ValueError("AI Search credentials not configured in .env")
        
        self.index_client = SearchIndexClient(
            endpoint=self.search_endpoint,
            credential=AzureKeyCredential(self.search_key)
        )
    
    def create_index(self, force_recreate: bool = False) -> bool:
        """
        Create the checklist index with proper schema.
        
        Args:
            force_recreate: If True, delete existing index and recreate
            
        Returns:
            True if index was created successfully
        """
        try:
            # Check if index exists
            try:
                existing_index = self.index_client.get_index(self.index_name)
                if force_recreate:
                    print(f"[INFO] Deleting existing index: {self.index_name}")
                    self.index_client.delete_index(self.index_name)
                else:
                    print(f"[OK] Index '{self.index_name}' already exists")
                    return True
            except Exception:
                # Index doesn't exist, will create it
                pass
            
            print(f"[INFO] Creating checklist index: {self.index_name}")
            
            # Define fields for checklist items (based on ChecklistValidator expectations)
            fields = [
                SearchField(
                    name="id",
                    type=SearchFieldDataType.String,
                    key=True,
                    sortable=True,
                    filterable=True
                ),
                SearchField(
                    name="content",
                    type=SearchFieldDataType.String,
                    searchable=True,
                    filterable=False,
                    sortable=False
                ),
                SearchField(
                    name="contentVector",
                    type=SearchFieldDataType.Collection(SearchFieldDataType.Single),
                    searchable=True,
                    vector_search_dimensions=1536,  # For text-embedding-ada-002
                    vector_search_profile_name="vector-profile"
                ),
                SearchField(
                    name="country",
                    type=SearchFieldDataType.String,
                    filterable=True,
                    facetable=True
                ),
                SearchField(
                    name="checklist_type",
                    type=SearchFieldDataType.String,
                    filterable=True,
                    facetable=True
                ),
                SearchField(
                    name="checklist_item",
                    type=SearchFieldDataType.String,
                    searchable=True,
                    filterable=False,
                    sortable=False
                ),
                SearchField(
                    name="requirements",
                    type=SearchFieldDataType.String,
                    searchable=True,
                    filterable=False,
                    sortable=False
                ),
            ]
            
            # Configure vector search
            vector_search = VectorSearch(
                algorithms=[
                    HnswAlgorithmConfiguration(
                        name="hnsw-config",
                        parameters={
                            "m": 4,
                            "efConstruction": 400,
                            "efSearch": 500,
                            "metric": "cosine"
                        }
                    )
                ],
                profiles=[
                    VectorSearchProfile(
                        name="vector-profile",
                        algorithm_configuration_name="hnsw-config"
                    )
                ]
            )
            
            # Create index
            index = SearchIndex(
                name=self.index_name,
                fields=fields,
                vector_search=vector_search
            )
            
            self.index_client.create_index(index)
            print(f"[OK] Index '{self.index_name}' created successfully")
            return True
            
        except Exception as e:
            print(f"[ERROR] Failed to create checklist index: {e}")
            raise
    
    def index_exists(self) -> bool:
        """Check if the index exists."""
        try:
            self.index_client.get_index(self.index_name)
            return True
        except Exception:
            return False
    
    def get_document_count(self) -> int:
        """Get number of documents in the index."""
        try:
            from azure.search.documents import SearchClient
            search_client = SearchClient(
                endpoint=self.search_endpoint,
                index_name=self.index_name,
                credential=AzureKeyCredential(self.search_key)
            )
            result = search_client.search(search_text="*", include_total_count=True, top=0)
            return result.get_count() or 0
        except Exception as e:
            print(f"[WARNING] Could not get document count for checklist index: {e}")
            return 0
